"""Context file management for fire-phoenix projects.

Schema version 3.0 (per adr/0030-user-context-split.md):
- `.fire-phoenix/context.yml` (project, version-controlled) owns:
  paths, governance, preferences (team default), language (team default),
  integrations. NO `current:` block.
- `.fire-phoenix/user-context.yml` (per-user, gitignored, optional) owns:
  preferences (user override), language (user override), and `current:`
  (per-user work cursor — feature/intent/plan/tasks/checklist/branch).
- `load_context_file()` deep-merges both files with user-context.yml
  winning on conflict. user-context.yml is optional in fresh clones.

Schema version 2.0 history (per adr/0020-l1-l4-paths-configurable.md):
- `paths:` block owns skill-output locations (docs/, docs/intents/, etc.).
- `governance:` block owns L1-L4 governance locations (product / status /
  decisions filenames + specs / contracts / adr dir names).
- The adr/0011 `paths.specs` → `paths.intents` legacy shim is removed.

Governance defaults (per adr/0026-l1-l4-defaults-under-docs.md, 2026-06-11):
- Default values are docs/-rooted (e.g. `docs/PRODUCT.md`, `docs/specs`).
  CLAUDE.md and AGENTS.md stay at project root by external convention.
"""

from pathlib import Path
from typing import Any

import yaml

from .fsutil import atomic_write_text, validate_rel_path

# Config keys whose values are project-relative paths and must not escape the
# project root (F-07). Validated at load time so a bad value fails once, early,
# with the offending key named — not mid-install.
_PATH_KEYS = ("docs", "intents", "plans", "tasks", "templates", "scripts", "existing_docs")
_GOVERNANCE_KEYS = (
    "product_file",
    "status_file",
    "decisions_file",
    "specs_dir",
    "contracts_dir",
    "adr_dir",
    "adr_drafts_dir",
    "decisions_pending_dir",
)

SCHEMA_VERSION = "3.0"

# Canonical project archetypes (matches the `fire-phoenix init --archetype`
# choices). Persisted in context.yml so post-init sessions, `upgrade`, and the
# managed context section stay archetype-aware (adr/0068).
ARCHETYPES = ("greenfield", "brownfield", "migration")
DEFAULT_ARCHETYPE = "greenfield"

# Canonical role-level enums. Non-tech uses fluency descriptors (what the
# person can do); tech uses industry-standard career-ladder vocabulary.
NON_TECH_ROLE_LEVELS = ("non-technical", "familiar", "fluent", "technical")
TECH_ROLE_LEVELS = ("junior", "mid", "senior", "staff")

# Default role-level values seeded at init time.
DEFAULT_NON_TECH_ROLE_LEVEL = "non-technical"
DEFAULT_TECH_ROLE_LEVEL = "mid"

# Default language values seeded at init time.
DEFAULT_OUTPUT_LANGUAGE = "English"
DEFAULT_INTERACTION_LANGUAGE = "English"


class SchemaVersionError(RuntimeError):
    """Raised when a context file carries a pre-v3.0 schema.

    Per adr/0030 §Decision: legacy v2.0 / v1.0 files are NOT silently
    migrated. Users must update by hand (or re-init in a fresh dir).
    """


def _render_context_content(
    integrations: list[str],
    docs_dir: str = "docs",
    intents_dir: str = "docs/intents",
    plans_dir: str = "docs/plans",
    tasks_dir: str = "docs/tasks",
    templates_dir: str = "templates",
    scripts_dir: str = "scripts",
    product_file: str = "docs/PRODUCT.md",
    status_file: str = "docs/STATUS.md",
    decisions_file: str = "docs/decisions.md",
    specs_dir: str = "docs/specs",
    contracts_dir: str = "docs/contracts",
    adr_dir: str = "docs/adr",
    adr_drafts_dir: str = "docs/adr-drafts",
    decisions_pending_dir: str = "docs/decisions-pending",
    output_lang: str = DEFAULT_OUTPUT_LANGUAGE,
    interaction_lang: str = DEFAULT_INTERACTION_LANGUAGE,
    output_format: str = "markdown",
    task_numbering: str = "sequential",
    confirm_before_write: bool = True,
    auto_update_context: bool = True,
    non_tech_role_level: str = DEFAULT_NON_TECH_ROLE_LEVEL,
    tech_role_level: str = DEFAULT_TECH_ROLE_LEVEL,
    archetype: str = DEFAULT_ARCHETYPE,
    commands: dict[str, str | None] | None = None,
    existing_docs: str | None = None,
) -> str:
    """Render the full annotated project ``context.yml`` content string.

    Called by both ``create_context_file`` (first-time) and
    ``merge_context_file`` (re-render with existing user values) so that
    comments are always preserved regardless of how the file is updated.

    Schema 3.0: no ``current:`` block — that block lives in
    ``.fire-phoenix/user-context.yml`` per adr/0030.
    """
    integrations_yaml = "\n".join(f"  - {i}" for i in integrations)
    cbw = str(confirm_before_write).lower()
    auc = str(auto_update_context).lower()
    commands = commands or {}

    def _scalar(v: str | None) -> str:
        if v is None:
            return "null"
        # Safe single-scalar YAML rendering (commands may carry :, #, quotes).
        return yaml.safe_dump(v, default_flow_style=True).strip().removesuffix("\n...").strip()

    cmd_build = _scalar(commands.get("build"))
    cmd_test = _scalar(commands.get("test"))
    cmd_lint = _scalar(commands.get("lint"))
    existing_docs_yaml = _scalar(existing_docs)

    return f"""\
# fire-phoenix context.yml — team-shared IDD project state (commit this file).
# Comment-light so it stays cheap to @-import; per-user half is
# .fire-phoenix/user-context.yml (deep-merged at load, user wins).
# Full schema: docs/reference/ (roles: docs/reference/role-levels.md).
schema_version: "{SCHEMA_VERSION}"
archetype: {archetype}  # greenfield | brownfield | migration (set at init)

# paths — where skill outputs are written (project-root-relative).
paths:
  docs: {docs_dir}  # root docs directory
  intents: {intents_dir}  # per-feature drafts; BA promotes to governance.specs_dir/epic-*.md (canonical L2)
  plans: {plans_dir}  # implementation plans
  tasks: {tasks_dir}  # task lists
  templates: {templates_dir}  # per-skill templates
  scripts: {scripts_dir}  # per-skill scripts
  existing_docs: {existing_docs_yaml}  # pre-existing docs dir observed at init (informational)

# commands — declared in the project's own manifests, recorded at init
# (brownfield/migration probe); OBSERVED verbatim, confirm before relying on.
commands:
  build: {cmd_build}
  test: {cmd_test}
  lint: {cmd_lint}

# governance — L1-L4 governance artefact locations (project-configurable).
governance:
  product_file: {product_file}  # L1 product intent
  status_file: {status_file}  # L1 in-flight status
  decisions_file: {decisions_file}  # L4 decisions index (append-only)
  specs_dir: {specs_dir}  # L2 epic specs (canonical)
  contracts_dir: {contracts_dir}  # L3 task contracts
  adr_dir: {adr_dir}  # L4 ADRs (immutable once Decided)
  adr_drafts_dir: {adr_drafts_dir}  # pending ADR drafts (promoted into adr_dir)
  decisions_pending_dir: {decisions_pending_dir}  # pending decisions (promoted into decisions_file)

# preferences — team defaults; a dev may override any in user-context.yml.
preferences:
  output_format: {output_format}  # document format (markdown)
  task_numbering: {task_numbering}  # sequential | timestamp
  confirm_before_write: {cbw}  # ask before writing files (false for CI)
  auto_update_context: {auc}  # auto-update the current.* cursor
  non_tech_role_level: {non_tech_role_level}  # non-technical | familiar | fluent | technical
  tech_role_level: {tech_role_level}  # junior | mid | senior | staff

# language — free-form (e.g. "English", "Vietnamese"); agents honour both.
language:
  output: {output_lang}  # language for written artefacts
  interaction: {interaction_lang}  # language for Q&A / confirmations

# integrations — installed AI providers (manage via `fire-phoenix install`).
integrations:
{integrations_yaml}
"""


def _render_user_context_content(
    output_lang: str = DEFAULT_OUTPUT_LANGUAGE,
    interaction_lang: str = DEFAULT_INTERACTION_LANGUAGE,
    non_tech_role_level: str = DEFAULT_NON_TECH_ROLE_LEVEL,
    tech_role_level: str = DEFAULT_TECH_ROLE_LEVEL,
    current_feature: str | None = None,
    current_intent: str | None = None,
    current_plan: str | None = None,
    current_tasks: str | None = None,
    current_checklist: str | None = None,
    current_branch: str | None = None,
) -> str:
    """Render the full annotated ``user-context.yml`` content string.

    This file is per-user and should be gitignored. It carries the user's
    active work cursor (`current:`) plus any personal overrides of
    `preferences:` / `language:` keys from the project's `context.yml`.
    """

    def _yaml_or_null(v: str | None) -> str:
        return "null" if v is None else str(v)

    return f"""\
# fire-phoenix user-context.yml — per-developer state. GITIGNORED, do NOT commit.
# Deep-merged with the team-shared context.yml at load; THIS file wins on conflict.
# current.* lives ONLY here. Full schema: docs/reference/role-levels.md + docs/reference/.
schema_version: "{SCHEMA_VERSION}"

# preferences — personal overrides of the context.yml team defaults.
preferences:
  non_tech_role_level: {non_tech_role_level}  # non-technical | familiar | fluent | technical
  tech_role_level: {tech_role_level}  # junior | mid | senior | staff

# language — personal overrides of the context.yml team defaults.
language:
  output: {output_lang}
  interaction: {interaction_lang}

# current — this user's active work item (null when nothing is active).
current:
  feature: {_yaml_or_null(current_feature)}  # feature slug, e.g. user-authentication
  intent: {_yaml_or_null(current_intent)}  # active intent file path
  plan: {_yaml_or_null(current_plan)}  # active plan file path
  tasks: {_yaml_or_null(current_tasks)}  # active tasks list path
  checklist: {_yaml_or_null(current_checklist)}  # active checklist path
  branch: {_yaml_or_null(current_branch)}  # git branch for this feature
"""


def create_context_file(
    project_path: Path,
    integrations: list[str] = None,  # type: ignore[assignment]
    docs_dir: str = "docs",
    intents_dir: str = "docs/intents",
    plans_dir: str = "docs/plans",
    tasks_dir: str = "docs/tasks",
    templates_dir: str = "templates",
    scripts_dir: str = "scripts",
    product_file: str = "docs/PRODUCT.md",
    status_file: str = "docs/STATUS.md",
    decisions_file: str = "docs/decisions.md",
    specs_dir: str = "docs/specs",
    contracts_dir: str = "docs/contracts",
    adr_dir: str = "docs/adr",
    adr_drafts_dir: str = "docs/adr-drafts",
    decisions_pending_dir: str = "docs/decisions-pending",
    output_lang: str = DEFAULT_OUTPUT_LANGUAGE,
    interaction_lang: str = DEFAULT_INTERACTION_LANGUAGE,
    non_tech_role_level: str = DEFAULT_NON_TECH_ROLE_LEVEL,
    tech_role_level: str = DEFAULT_TECH_ROLE_LEVEL,
    archetype: str = DEFAULT_ARCHETYPE,
    commands: dict[str, str | None] | None = None,
    existing_docs: str | None = None,
) -> None:
    """Create ``.fire-phoenix/context.yml`` with the documented v3.0 schema.

    Per adr/0030: this writes ONLY the team-shared project file. The
    per-user `.fire-phoenix/user-context.yml` is written by
    :func:`create_user_context_file`.
    """
    if integrations is None:
        integrations = ["claude"]

    content = _render_context_content(
        integrations=integrations,
        docs_dir=docs_dir,
        intents_dir=intents_dir,
        plans_dir=plans_dir,
        tasks_dir=tasks_dir,
        templates_dir=templates_dir,
        scripts_dir=scripts_dir,
        product_file=product_file,
        status_file=status_file,
        decisions_file=decisions_file,
        specs_dir=specs_dir,
        contracts_dir=contracts_dir,
        adr_dir=adr_dir,
        adr_drafts_dir=adr_drafts_dir,
        decisions_pending_dir=decisions_pending_dir,
        output_lang=output_lang,
        interaction_lang=interaction_lang,
        non_tech_role_level=non_tech_role_level,
        tech_role_level=tech_role_level,
        archetype=archetype,
        commands=commands,
        existing_docs=existing_docs,
    )

    context_file = project_path / ".fire-phoenix" / "context.yml"
    context_file.parent.mkdir(parents=True, exist_ok=True)
    atomic_write_text(context_file, content)


def create_user_context_file(
    project_path: Path,
    output_lang: str = DEFAULT_OUTPUT_LANGUAGE,
    interaction_lang: str = DEFAULT_INTERACTION_LANGUAGE,
    non_tech_role_level: str = DEFAULT_NON_TECH_ROLE_LEVEL,
    tech_role_level: str = DEFAULT_TECH_ROLE_LEVEL,
) -> None:
    """Create ``.fire-phoenix/user-context.yml`` with the documented v3.0 schema.

    Per adr/0030: this writes the per-user, gitignored file. At init time
    the same values written to ``context.yml`` are mirrored here; users can
    later edit this file to diverge from team defaults.

    Preserve-existing: if the file already exists, leave it untouched.
    Callers that need to update must rewrite explicitly via :func:`save_user_context_file`.
    """
    user_context_file = project_path / ".fire-phoenix" / "user-context.yml"
    if user_context_file.exists():
        return
    content = _render_user_context_content(
        output_lang=output_lang,
        interaction_lang=interaction_lang,
        non_tech_role_level=non_tech_role_level,
        tech_role_level=tech_role_level,
    )
    user_context_file.parent.mkdir(parents=True, exist_ok=True)
    atomic_write_text(user_context_file, content)


def _deep_merge_user_wins(project: dict, user: dict) -> dict:
    """Deep-merge ``user`` into ``project``; user values win on conflict.

    Per adr/0030 §Decision. Nested dicts merge recursively; scalar / list
    values from user replace the project value entirely.
    """
    merged: dict[str, Any] = dict(project)
    for key, uval in user.items():
        if key in merged and isinstance(merged[key], dict) and isinstance(uval, dict):
            merged[key] = _deep_merge_user_wins(merged[key], uval)
        else:
            merged[key] = uval
    return merged


_DEFAULT_CURRENT_BLOCK: dict[str, None] = {
    "feature": None,
    "intent": None,
    "plan": None,
    "tasks": None,
    "checklist": None,
    "branch": None,
}


def load_context_file(project_root: Path) -> dict[str, Any]:
    """Load and merge the two context files (per adr/0030).

    Reads ``.fire-phoenix/context.yml`` (required when present at all) and
    ``.fire-phoenix/user-context.yml`` (optional — common to be absent in
    fresh clones), then deep-merges with user-context.yml winning on
    conflict.

    Args:
        project_root: Root directory of the fire-phoenix project.

    Returns:
        Parsed + merged context dictionary, or empty dict if NEITHER file
        exists. The ``current`` block is always present in the returned
        dict (defaulted to all-null if user-context.yml is absent).

    Raises:
        yaml.YAMLError: If either context file is malformed.
        SchemaVersionError: If either file's ``schema_version`` is present
            and not "3.0" (per adr/0030 — no silent migration of legacy
            v1.0 / v2.0 files).
    """
    context_file = project_root / ".fire-phoenix" / "context.yml"
    user_context_file = project_root / ".fire-phoenix" / "user-context.yml"

    if not context_file.exists() and not user_context_file.exists():
        return {}

    project_data: dict[str, Any] = {}
    if context_file.exists():
        with open(context_file, encoding="utf-8") as f:
            project_data = yaml.safe_load(f) or {}
        _check_schema(project_data, context_file, project_root)

    user_data: dict[str, Any] = {}
    if user_context_file.exists():
        with open(user_context_file, encoding="utf-8") as f:
            user_data = yaml.safe_load(f) or {}
        _check_schema(user_data, user_context_file, project_root)

    merged = _deep_merge_user_wins(project_data, user_data)

    # Ensure `current` block is always present (per adr/0030 it lives in
    # user-context.yml; absent → all-null defaults).
    if "current" not in merged or not isinstance(merged.get("current"), dict):
        merged["current"] = dict(_DEFAULT_CURRENT_BLOCK)
    else:
        for key, default in _DEFAULT_CURRENT_BLOCK.items():
            merged["current"].setdefault(key, default)

    _validate_configured_paths(merged, project_root)

    return merged


def _validate_configured_paths(data: dict[str, Any], project_root: Path) -> None:
    """Reject `paths.*`/`governance.*` values that escape the project root (F-07).

    Raises ``fsutil.PathTraversalError`` (a ``ValueError``) naming the offending
    ``block.key`` so a bad config fails once at load, not mid-install.
    """
    for block, keys in (("paths", _PATH_KEYS), ("governance", _GOVERNANCE_KEYS)):
        section = data.get(block) or {}
        if not isinstance(section, dict):
            continue
        for key in keys:
            value = section.get(key)
            if isinstance(value, str) and value:
                validate_rel_path(project_root, value, key=f"{block}.{key}")


def _check_schema(data: dict, file_path: Path, project_root: Path) -> None:
    """Raise SchemaVersionError if the loaded file's schema_version is wrong."""
    declared = data.get("schema_version")
    if declared is not None and declared != SCHEMA_VERSION:
        rel = file_path.relative_to(project_root)
        raise SchemaVersionError(
            f"{rel} at {project_root} has schema_version {declared!r}; this "
            f"fire-phoenix requires {SCHEMA_VERSION!r}. To migrate by hand: "
            f"bump schema_version to '{SCHEMA_VERSION}', remove the "
            f"`current:` block from context.yml (relocate it to "
            f".fire-phoenix/user-context.yml along with personal overrides "
            f"of preferences: and language:), and add "
            f"`.fire-phoenix/user-context.yml` to your .gitignore. See the "
            f"upgrade guide for the full recipe."
        )


def _deep_merge(existing: dict, template: dict) -> dict:
    """Recursively merge *template* into *existing*; existing values win.

    Used by ``merge_context_file`` to inject new template keys into an
    existing user-edited file without clobbering anything the user set.
    Opposite precedence from :func:`_deep_merge_user_wins` (which is used
    at load time for the project + user override merge).
    """
    merged = dict(existing)
    for key, tval in template.items():
        if key not in merged:
            merged[key] = tval
        elif isinstance(merged[key], dict) and isinstance(tval, dict):
            merged[key] = _deep_merge(merged[key], tval)
        # else: existing scalar/list wins — do not overwrite
    return merged


def merge_context_file(
    project_root: Path,
    new_integrations: list[str] | None = None,
) -> None:
    """Merge template defaults into an existing ``context.yml`` (schema 3.0).

    Reads the existing project file (bypassing the strict schema check),
    union-merges integrations, re-renders the fully-annotated template
    with the user's values substituted in. Per adr/0030 this only touches
    ``context.yml`` — ``user-context.yml`` is left alone.

    Comments are preserved by re-rendering the fully-annotated template
    with the user's existing values substituted in, rather than round-
    tripping through ``yaml.dump`` which strips all comments.
    """
    context_file = project_root / ".fire-phoenix" / "context.yml"
    if not context_file.exists():
        create_context_file(project_root, integrations=new_integrations)  # type: ignore[arg-type]
        return

    with open(context_file, encoding="utf-8") as f:
        existing = yaml.safe_load(f) or {}

    # Union-merge integrations list
    old_list = existing.get("integrations", [])
    new_list = new_integrations or []
    union = list(dict.fromkeys(old_list + new_list))  # preserves order, no dups

    paths = existing.get("paths", {}) or {}
    governance = existing.get("governance", {}) or {}
    prefs = existing.get("preferences", {}) or {}
    lang = existing.get("language", {}) or {}
    # Archetype is user/init-owned: preserve verbatim, default only when absent.
    archetype = existing.get("archetype") or DEFAULT_ARCHETYPE
    # W5 probe-seeded blocks: preserve whatever the user/init recorded.
    existing_commands = existing.get("commands") or {}
    existing_docs = paths.get("existing_docs")

    content = _render_context_content(
        integrations=union,
        docs_dir=paths.get("docs", "docs"),
        intents_dir=paths.get("intents", "docs/intents"),
        plans_dir=paths.get("plans", "docs/plans"),
        tasks_dir=paths.get("tasks", "docs/tasks"),
        templates_dir=paths.get("templates", "templates"),
        scripts_dir=paths.get("scripts", "scripts"),
        product_file=governance.get("product_file", "docs/PRODUCT.md"),
        status_file=governance.get("status_file", "docs/STATUS.md"),
        decisions_file=governance.get("decisions_file", "docs/decisions.md"),
        specs_dir=governance.get("specs_dir", "docs/specs"),
        contracts_dir=governance.get("contracts_dir", "docs/contracts"),
        adr_dir=governance.get("adr_dir", "docs/adr"),
        adr_drafts_dir=governance.get("adr_drafts_dir", "docs/adr-drafts"),
        decisions_pending_dir=governance.get("decisions_pending_dir", "docs/decisions-pending"),
        output_lang=lang.get("output", DEFAULT_OUTPUT_LANGUAGE),
        interaction_lang=lang.get("interaction", DEFAULT_INTERACTION_LANGUAGE),
        output_format=prefs.get("output_format", "markdown"),
        task_numbering=prefs.get("task_numbering", "sequential"),
        confirm_before_write=prefs.get("confirm_before_write", True),
        auto_update_context=prefs.get("auto_update_context", True),
        non_tech_role_level=prefs.get("non_tech_role_level", DEFAULT_NON_TECH_ROLE_LEVEL),
        tech_role_level=prefs.get("tech_role_level", DEFAULT_TECH_ROLE_LEVEL),
        archetype=archetype,
        commands=existing_commands,
        existing_docs=existing_docs,
    )

    atomic_write_text(context_file, content)


def _build_project_template(integrations: list[str]) -> dict[str, Any]:
    """Return the default project ``context.yml`` dict (schema 3.0).

    No ``current:`` block per adr/0030 — that lives in user-context.yml.
    """
    return {
        "schema_version": SCHEMA_VERSION,
        "archetype": DEFAULT_ARCHETYPE,
        "paths": {
            "docs": "docs",
            "intents": "docs/intents",
            "plans": "docs/plans",
            "tasks": "docs/tasks",
            "templates": "templates",
            "scripts": "scripts",
            "existing_docs": None,
        },
        "commands": {"build": None, "test": None, "lint": None},
        "governance": {
            "product_file": "docs/PRODUCT.md",
            "status_file": "docs/STATUS.md",
            "decisions_file": "docs/decisions.md",
            "specs_dir": "docs/specs",
            "contracts_dir": "docs/contracts",
            "adr_dir": "docs/adr",
            "adr_drafts_dir": "docs/adr-drafts",
            "decisions_pending_dir": "docs/decisions-pending",
        },
        "preferences": {
            "output_format": "markdown",
            "task_numbering": "sequential",
            "confirm_before_write": True,
            "auto_update_context": True,
            "non_tech_role_level": DEFAULT_NON_TECH_ROLE_LEVEL,
            "tech_role_level": DEFAULT_TECH_ROLE_LEVEL,
        },
        "language": {
            "output": DEFAULT_OUTPUT_LANGUAGE,
            "interaction": DEFAULT_INTERACTION_LANGUAGE,
        },
        "integrations": integrations,
    }


def _build_user_template() -> dict[str, Any]:
    """Return the default per-user ``user-context.yml`` dict (schema 3.0).

    All values seeded at team defaults; users edit this file to diverge.
    """
    return {
        "schema_version": SCHEMA_VERSION,
        "preferences": {
            "non_tech_role_level": DEFAULT_NON_TECH_ROLE_LEVEL,
            "tech_role_level": DEFAULT_TECH_ROLE_LEVEL,
        },
        "language": {
            "output": DEFAULT_OUTPUT_LANGUAGE,
            "interaction": DEFAULT_INTERACTION_LANGUAGE,
        },
        "current": dict(_DEFAULT_CURRENT_BLOCK),
    }


# Backwards-compatible alias retained for any caller still using the old
# name. Returns the project template (the file that actually carries
# `integrations:`). Callers that need the user template must use
# `_build_user_template()` directly.
_build_context_template = _build_project_template


def save_context_file(project_root: Path, data: dict[str, Any]) -> None:
    """Save context data to ``.fire-phoenix/context.yml`` (project file).

    Args:
        project_root: Root directory of the fire-phoenix project
        data: Context dictionary to save
    """
    context_file = project_root / ".fire-phoenix" / "context.yml"
    atomic_write_text(
        context_file,
        yaml.dump(data, default_flow_style=False, sort_keys=False, allow_unicode=True),
    )


def save_user_context_file(project_root: Path, data: dict[str, Any]) -> None:
    """Save context data to ``.fire-phoenix/user-context.yml`` (user file).

    Used by helpers that update ``current.*`` cursor values. Per adr/0030
    this file is per-user + gitignored.

    Args:
        project_root: Root directory of the fire-phoenix project
        data: User context dictionary to save
    """
    user_context_file = project_root / ".fire-phoenix" / "user-context.yml"
    atomic_write_text(
        user_context_file,
        yaml.dump(data, default_flow_style=False, sort_keys=False, allow_unicode=True),
    )
