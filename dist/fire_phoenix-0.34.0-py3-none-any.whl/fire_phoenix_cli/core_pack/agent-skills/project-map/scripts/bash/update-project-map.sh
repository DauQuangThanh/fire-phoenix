#!/usr/bin/env bash
# project-map — regenerate the annotated folder tree and write it into the
# preserved TREE sub-block of every root agent context file (CLAUDE.md /
# AGENTS.md / GEMINI.md and any sibling carrying the Fire Phoenix envelope).
#
# Usage: update-project-map.sh [--auto] [--depth N] [--tree-file FILE] [--help]
#
#   --auto           Non-interactive: write the generated tree with no pause.
#   --depth N        Tree depth (default 2).
#   --tree-file F    Use F verbatim as the tree block (the agent's annotated
#                    tree) instead of the mechanically generated one.
#
# Skill-specific helpers live here (the shared common.sh is a
# byte-identical canonical library — action-specific logic must not live in it).

set -euo pipefail
SCRIPT_DIR="$(CDPATH="" cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=common.sh
source "$SCRIPT_DIR/common.sh"

TREE_START="<!-- PROJECT FOLDER TREE START -->"
TREE_END="<!-- PROJECT FOLDER TREE END -->"
ENVELOPE_START="<!-- Fire Phoenix START -->"
PRUNE_DIRS=".git node_modules .venv .venv-t __pycache__ .mypy_cache .ruff_cache .pytest_cache dist build site .tmp-test .idea .vscode"

_is_pruned() {
    local name="$1" p
    for p in $PRUNE_DIRS; do [ "$name" = "$p" ] && return 0; done
    case "$name" in .*) return 0 ;; esac   # hidden dirs excluded from the map
    return 1
}

# OBSERVED-only indented directory tree under <root> to <depth>. Prints what is
# on disk, infers nothing — annotations are the agent's job (SKILL.md).
generate_tree() {
    local root="$1" depth="${2:-2}"
    echo '```'
    echo "$(basename "$root")/"
    _walk_dir() {
        local dir="$1" indent="$2" lvl="$3" child name
        [ "$lvl" -ge "$depth" ] && return
        while IFS= read -r child; do
            [ -z "$child" ] && continue
            name="$(basename "$child")"
            _is_pruned "$name" && continue
            echo "${indent}${name}/"
            _walk_dir "$child" "${indent}  " "$((lvl + 1))"
        done < <(find "$dir" -mindepth 1 -maxdepth 1 -type d 2>/dev/null | sort)
    }
    _walk_dir "$root" "  " 0
    echo '```'
}

list_context_files() {
    local root="$1" f
    for f in "$root"/CLAUDE.md "$root"/AGENTS.md "$root"/GEMINI.md "$root"/*.md; do
        [ -f "$f" ] || continue
        grep -qF "$ENVELOPE_START" "$f" 2>/dev/null && echo "$f"
    done | sort -u
}

# Replace the TREE-marker inner of <file> with the contents of <content_file>.
# Returns 0 on write, 2 when either marker is absent (no change).
inject_tree_block() {
    local file="$1" content_file="$2"
    grep -qF "$TREE_START" "$file" 2>/dev/null || return 2
    grep -qF "$TREE_END" "$file" 2>/dev/null || return 2
    awk -v startm="$TREE_START" -v endm="$TREE_END" -v cf="$content_file" '
        index($0, startm) { print; while ((getline line < cf) > 0) print line; close(cf); skip=1; next }
        index($0, endm)   { skip=0 }
        !skip             { print }
    ' "$file" > "${file}.fp-tmp" && mv "${file}.fp-tmp" "$file"
}

AUTO=0; DEPTH=2; TREE_FILE=""
while [ $# -gt 0 ]; do
    case "$1" in
        --auto) AUTO=1 ;;
        --depth) DEPTH="$2"; shift ;;
        --tree-file) TREE_FILE="$2"; shift ;;
        --help)
            sed -n '2,12p' "${BASH_SOURCE[0]}" | sed 's/^# \{0,1\}//'
            exit 0 ;;
        *) echo "unknown arg: $1" >&2; exit 64 ;;
    esac
    shift
done

read_context
ROOT="${FIRE_PHOENIX_REPO_ROOT:-}"
[ -n "$ROOT" ] || { echo "not inside a fire-phoenix project (.fire-phoenix/ not found)" >&2; exit 1; }

TMP_TREE="$(mktemp)"; trap 'rm -f "$TMP_TREE"' EXIT
if [ -n "$TREE_FILE" ]; then
    cat "$TREE_FILE" > "$TMP_TREE"
else
    generate_tree "$ROOT" "$DEPTH" > "$TMP_TREE"
fi

echo "== generated project map (depth $DEPTH) =="
cat "$TMP_TREE"
if [ -z "$TREE_FILE" ] && [ "$AUTO" -eq 0 ]; then
    echo
    echo "NEXT: annotate each major folder with a one-line OBSERVED note, then re-run:" >&2
    echo "  update-project-map.sh --tree-file <annotated> [--auto]" >&2
    exit 0
fi

WROTE=0; MISSING=0
while IFS= read -r f; do
    [ -z "$f" ] && continue
    if inject_tree_block "$f" "$TMP_TREE"; then
        echo "updated: ${f#"$ROOT"/}"; WROTE=$((WROTE + 1))
    else
        echo "SKIP (no TREE markers — needs 'fire-phoenix upgrade'): ${f#"$ROOT"/}" >&2
        MISSING=$((MISSING + 1))
    fi
done < <(list_context_files "$ROOT")

if [ "$WROTE" -eq 0 ] && [ "$MISSING" -eq 0 ]; then
    echo "no root context file with a Fire Phoenix envelope found — run 'fire-phoenix upgrade' first" >&2
    exit 3
fi
echo "project-map: updated $WROTE file(s), skipped $MISSING."
