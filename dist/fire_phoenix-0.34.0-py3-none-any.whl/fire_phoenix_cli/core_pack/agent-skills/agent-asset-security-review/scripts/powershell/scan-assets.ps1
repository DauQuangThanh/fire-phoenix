<#
.SYNOPSIS
  agent-asset-security-review — read-only signature scan over the agent assets
  INSTALLED IN THE CURRENT PROJECT (subagent definitions + skills + their
  scripts under each AI tool's config dir — .claude/, .gemini/, .cursor/, … —
  plus root context files and hook configs). Emits a markdown triage table
  (THREAT-CLASS | file:line | snippet). The subagent verifies, classifies, and
  suggests fixes. This script never classifies as malicious on its own and
  NEVER executes a match. PowerShell sibling of scan-assets.sh.

.PARAMETER Auto   Non-interactive.
.PARAMETER Path   Explicit scan root(s); overrides auto-discovery.
.PARAMETER Out    Also write the triage table to this file.

  Skill-specific helpers live here; common.ps1 is byte-identical
  canonical and carries no action logic.
#>
[CmdletBinding()]
param(
    [switch]$Auto,
    [string[]]$Path = @(),
    [string]$Out = ''
)

$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'common.ps1')

# Threat signatures: @{ Class = ...; Pattern = <regex> }. Heuristic triage only.
$signatures = @(
    @{ Class = 'DANGEROUS-SCRIPT'; Pattern = '(curl|wget)[^|]*\|\s*(ba)?sh' }
    @{ Class = 'DANGEROUS-SCRIPT'; Pattern = 'base64\s+(-d|--decode)' }
    @{ Class = 'DANGEROUS-SCRIPT'; Pattern = '\beval\s+["$`]' }
    @{ Class = 'DANGEROUS-SCRIPT'; Pattern = 'rm\s+-rf\s+[/~]' }
    @{ Class = 'DANGEROUS-SCRIPT'; Pattern = 'chmod\s+(777|\+s)' }
    @{ Class = 'DANGEROUS-SCRIPT'; Pattern = '(/dev/tcp/|mkfifo|nc\s+-e|bash\s+-i|Invoke-Expression|iex\s)' }
    @{ Class = 'CREDENTIAL-THEFT'; Pattern = '(~/\.aws|~/\.ssh|id_rsa|\.netrc)' }
    @{ Class = 'CREDENTIAL-THEFT'; Pattern = '(AWS_SECRET|ANTHROPIC_API_KEY|GITHUB_TOKEN|_API_KEY|_SECRET)' }
    @{ Class = 'CREDENTIAL-THEFT'; Pattern = '(printenv|env\s*\||cat\s+[^;]*token)' }
    @{ Class = 'SUPPLY-CHAIN'; Pattern = '(pip[0-9]?|pipx|uv)\s+install' }
    @{ Class = 'SUPPLY-CHAIN'; Pattern = '(npm|pnpm|yarn)\s+(install|add)|npx\s' }
    @{ Class = 'SUPPLY-CHAIN'; Pattern = '@latest|--index-url|--extra-index-url' }
    @{ Class = 'PRIVILEGE-ESCALATION'; Pattern = '(^|\s)sudo\s' }
    @{ Class = 'PRIVILEGE-ESCALATION'; Pattern = '\.git/hooks|/etc/|~/\.(bashrc|zshrc|profile)' }
    @{ Class = 'PROMPT-INJECTION'; Pattern = '[Ii]gnore\s+(all\s+)?previous\s+instructions' }
    @{ Class = 'PROMPT-INJECTION'; Pattern = 'disregard\s+[^.]*instructions|you\s+are\s+now' }
    @{ Class = 'PROMPT-INJECTION'; Pattern = '(exfiltrat|do\s+not\s+tell\s+the\s+user)' }
    @{ Class = 'INDIRECT-INJECTION'; Pattern = '(read|fetch|open)[^.\n]*https?://[^.\n]*(run|follow|execute|obey)' }
)

$root = Find-FirePhoenixRoot
if (-not $root) { $root = (Get-Location).Path }
if ($Path.Count -eq 0) {
    # Auto-discover installed AI-tool config dirs holding agents/agent/skills.
    $discovered = @()
    Get-ChildItem -LiteralPath $root -Directory -Force -Filter '.*' -ErrorAction SilentlyContinue | ForEach-Object {
        if ($_.Name -in @('.git')) { return }
        $p = $_.FullName
        if ((Test-Path (Join-Path $p 'agents')) -or (Test-Path (Join-Path $p 'agent')) -or (Test-Path (Join-Path $p 'skills'))) {
            $discovered += $p
        }
    }
    foreach ($f in @('CLAUDE.md', 'AGENTS.md', 'GEMINI.md')) {
        $fp = Join-Path $root $f
        if (Test-Path -LiteralPath $fp -PathType Leaf) { $discovered += $fp }
    }
    $Path = $discovered
}
if ($Path.Count -eq 0) {
    Write-Error "no installed agent assets found under $root — this reviewer scans a project where fire-phoenix assets are installed. Pass -Path <dir> to target a specific tree."
    exit 3
}

# docs-example allowlist: skip reference/checklist docs that deliberately carry
# attack strings (see references/docs-example-allowlist.md).
function Test-Allowlisted { param([string]$P)
    return ($P -match '/references/' -or $P -match 'checklist' -or $P -match '-patterns\.md$' -or $P -match '-allowlist\.md$' -or $P -match 'severity-rubric\.md$' -or $P -match 'agent-asset-security-review/SKILL\.md$' -or $P -match 'asset-security-reviewer\.md$')
}

$lines = New-Object System.Collections.Generic.List[string]
$lines.Add('# Asset-security triage (heuristic — verify each before reporting)')
$lines.Add('')
$lines.Add('| Threat class | Location | Snippet |')
$lines.Add('|---|---|---|')

$exts = @('.md', '.sh', '.ps1', '.json', '.yml', '.yaml', '.toml')
$hits = 0
foreach ($base in $Path) {
    Get-ChildItem -LiteralPath $base -Recurse -File -ErrorAction SilentlyContinue |
        Where-Object { $exts -contains $_.Extension } | Sort-Object FullName | ForEach-Object {
            $full = $_.FullName.Replace('\', '/')
            if (Test-Allowlisted $full) { return }
            $n = 0
            foreach ($raw in (Get-Content -LiteralPath $_.FullName -ErrorAction SilentlyContinue)) {
                $n++
                foreach ($sig in $signatures) {
                    if ($raw -match $sig.Pattern) {
                        $snip = ($raw -replace '\|', '\|').Trim()
                        if ($snip.Length -gt 80) { $snip = $snip.Substring(0, 80) }
                        $rel = $full.Substring($root.Length).TrimStart('/')
                        $lines.Add("| $($sig.Class) | ${rel}:$n | ``$snip`` |")
                        $hits++
                    }
                }
            }
        }
}
$lines.Add('')
$lines.Add("_$hits raw signature hit(s). Heuristic only: confirm real vs. documentation-example, classify, assign severity, and suggest a fix per the skill's references._")

$text = $lines -join "`n"
Write-Output $text
if ($Out) { Set-Content -LiteralPath $Out -Value $text -Encoding utf8 }
if (-not $Auto) { Write-Warning 'NEXT: verify each hit (docs-example allowlist applied), then author {context.paths.docs}/reviews/asset-security.md.' }
