---
name: codebase-scan
description: 'Scans an existing codebase for an overview: language + LOC by directory, detected frameworks, entry points, test-coverage signals, build/lint/format tooling. Seeds the other technical-analyst skills. Runs after the inventory-existing census; use before architecture extraction or dependency mapping.'
license: MIT
compatibility: Designed for agentskills.io-compatible agents.
metadata:
  author: Dau Quang Thanh
  version: '1.0'
  requires: []
---

## User Input

```text
$ARGUMENTS
```

## Audience and tone (interactive mode)

**Register first — adapt to role level.** Before applying the beginner floor
below, resolve the reader's level from the merged `.fire-phoenix/context.yml`
+ `.fire-phoenix/user-context.yml` (`user-context.yml` wins): use
`preferences.tech_role_level` for technical work (`junior` → hand-hold, one
path; `mid` → ≥2 options with one-line trade-offs; `senior` → defer on
judgment, surface edge cases, be brief; `staff` → be terse, challenge
premises, skip obvious caveats) and `preferences.non_tech_role_level` for
stakeholder work (`non-technical` → outcomes not jargon; `familiar` → simple
jargon glossed; `fluent` → concepts without explanation; `technical` → full
vocabulary). An explicit in-session signal (e.g. "be terse", "skip the
explanation") overrides everything. The plain-English, one-question-at-a-time
floor below applies **only when the relevant level is unset**; never treat
role level as a gate. Full rule: `.fire-phoenix/references/subagents/register-resolution.md`.

When `FIRE_PHOENIX_AGENT_MODE=interactive` (the default), assume the user
has **limited technical background and limited domain knowledge**
— they may know basics but lack deep expertise in this skill's
area. Run this skill as a guided questionnaire:

- **One question at a time.** No walls of questions.
- **Yes / no first.** Phrase so `yes`, `no`, `not sure`, or `skip`
  is a valid answer.
- **Translate jargon, don't strip it.** Use the technical term but
  always pair it with a plain-English gloss the first time it
  appears.
- **Choices, not blank fields.** When yes/no isn't enough, offer
  2-4 lettered options (A/B/C/D) with one-line plain-language
  descriptions of the trade-off. Always include "Not sure — pick
  a sensible default".
- **Always recommend.** State the option you would pick and why in
  one sentence so the user can reply "yes" / "ok" to accept. Pull
  defaults from upstream artefacts (spec, architecture, ADRs,
  standards) before asking blank.
- **Show, don't ask.** When upstream artefacts already imply an
  answer, propose it as a pre-filled finding and ask for a
  yes / no confirmation rather than asking the user to fill in a
  blank.
- **`not sure` / `skip` triggers a sensible default**, marked
  "(default applied — confirm later)" in the artefact, and a debt
  entry in this skill's debt file.

When `FIRE_PHOENIX_AGENT_MODE=auto` (or `--auto`), skip the questionnaire
entirely: apply sensible defaults from upstream artefacts and log
decisions to the parent agent's decision log.

## Inputs

- Project root files (package.json, pyproject.toml, go.mod, …)
- Source tree under `src/`, `lib/`, `app/`, …

## Outputs

- `{context.paths.docs}/analysis/codebase-scan.md`
- `{context.paths.docs}/analysis/codebase-scan.extract`

## Context Update

Does not mutate `.fire-phoenix/context.yml`.

## Handoffs

- `architecture-extraction` starts from this scan.
- `api-docs` narrows to detected HTTP / RPC frameworks.
- `dependency-map` uses the LOC + entry-point list.

## AI authoring scope

**Does:** classify files by extension, count LOC per top-level
dir, detect primary language(s), detect frameworks (web, test,
build, lint), find entry points (`main.*`, `server.*`,
`index.*`).

**Does not:** modify files, run tests, push anything.

## Scan flow (staged)

Work the stages in order — each narrows the next. Every recorded
fact carries a confidence tag: **`OBSERVED`** (read directly,
`file:line` cited), **`INFERRED (low|med|high confidence)`**
(pattern-matched, reasoning stated), or **`UNKNOWN`** (surfaced
as an open question, never guessed).

1. **Inventory** — manifests, languages, LOC per top-level dir,
   build / test / lint tooling, per
   `references/detection-signals.md`. Mostly `OBSERVED`.
2. **Entry points** — `main.*` / `server.*` / `index.*` / CLI
   commands / scheduled jobs / queue consumers. An entry point
   named by convention but not traced is `INFERRED`, not
   `OBSERVED`.
3. **Hot paths** — the most-imported modules, the largest files,
   and (when git history is available) the most-churned areas.
   These are where later extraction and refactoring effort
   concentrates.
4. **Risk areas** — untested directories, generated or vendored
   code mixed into source, dynamic typing walls (`any`,
   reflection), config entries shaped like secrets. Flag; do not
   fix.

**Verify before asserting** — before any claim lands in the
artefact, re-check its evidence: open the file, confirm the
line still says what the claim says (mirrors the security
reviewer's verification pass). A claim that cannot be verified
is recorded as `UNKNOWN` and logged as an `ANALYSISDEBT-` — it
is never promoted "to be safe".

## Usage

> `<SKILL_DIR>` = the integration's skills root (e.g. `.claude/skills/`
> for Claude Code, `.codex/skills/` for Codex,
> `.cursor/skills/` for Cursor, `.kiro/skills/` for Kiro).
> Scripts live at `<SKILL_DIR>/<skill-name>/scripts/…`.

```bash
bash <SKILL_DIR>/codebase-scan/scripts/bash/scan.sh --auto
```

### Answer keys

| Key | Default |
|---|---|
| `CS_EXCLUDE_GLOBS` | `node_modules/**,dist/**,.venv/**,build/**,target/**` |
