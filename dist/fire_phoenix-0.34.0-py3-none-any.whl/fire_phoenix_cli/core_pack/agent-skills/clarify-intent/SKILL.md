---
name: clarify-intent
description: Identifies underspecified areas in the current feature spec by asking
  up to 5 highly targeted clarification questions and encoding answers
  back into the spec. Use when a spec has gaps or ambiguities, before
  implementation starts, or when the team disagrees on scope.
license: MIT
compatibility: Designed for agentskills.io-compatible agents.
metadata:
  author: Dau Quang Thanh
  version: '1.0'
  requires: [intent]
  scripts:
    sh: scripts/bash/check-prerequisites.sh --json --paths-only
    ps: scripts/powershell/check-prerequisites.ps1 -Json -PathsOnly
---

## User Input

```text
$ARGUMENTS
```

You **MUST** consider the user input (if not empty).

## Pre-Execution Checks

**Check for extension hooks (before clarification)**:

- If `.fire-phoenix/extensions.yml` is absent, skip silently.
- If it exists, read `references/extension-hooks.md` §Pre-execution
  and apply that hook protocol against the
  `hooks.before_clarify-specs` key before the Outline.

## Outline

Goal: Detect and reduce ambiguity or missing decision points in the active feature spec; record clarifications directly in it.

Note: This workflow should run and complete BEFORE `/plan`. If the user explicitly skips clarification (e.g., exploratory spike), you may proceed but must warn that downstream rework risk rises.

### Audience and tone (interactive mode)

**Register first — adapt to role level.** Before applying the beginner floor
below, resolve the reader's level from merged `.fire-phoenix/context.yml`
+ `.fire-phoenix/user-context.yml` (`user-context.yml` wins): use
`preferences.tech_role_level` for tech work (`junior` → hand-hold, one
path; `mid` → ≥2 options with trade-offs; `senior` → defer on judgment,
surface edge cases, be brief; `staff` → be terse, challenge premises, skip
caveats) and `preferences.non_tech_role_level` for stakeholder work
(`non-technical` → outcomes not jargon; `familiar` → jargon glossed; `fluent`
→ concepts unexplained; `technical` → full vocabulary). An explicit
in-session signal (e.g. "be terse", "skip the
explanation") overrides everything. The plain-English, one-question-at-a-time
floor below applies **only when the relevant level is unset**; never treat
role level as a gate. Full rule: `.fire-phoenix/references/subagents/register-resolution.md`.

If `FIRE_PHOENIX_AGENT_MODE=interactive` (the default), assume the user has
**no technical and no business-domain background**. The step-2
taxonomy is your **internal** coverage map — never expose its
labels to the user.

Before presenting any question in step 4, read
`references/interactive-style.md` (yes/no-first phrasing,
plain-English translations, recommendation duty, default handling).
Skip it in auto mode.

When `FIRE_PHOENIX_AGENT_MODE=auto` (or `--auto`), skip the question loop:
pick the recommended option for every Partial / Missing category and
log decisions to the business-analyst decision log.

Execution steps:

1. Run `{SCRIPT}` from repo root **once** (`--json --paths-only` / `-Json -PathsOnly`). Parse minimal JSON fields:
   - `FEATURE_DIR`
   - `FEATURE_SPEC`
   - (Optionally capture `IMPL_PLAN`, `TASKS` for future flows.)
   - If JSON parsing fails, abort and tell the user to re-run `/intent` to populate `{context.current.intent}` in `.fire-phoenix/context.yml`.
   - For single quotes in args like "I'm Groot", use escape syntax: e.g 'I'\''m Groot' (or double-quote if possible: "I'm Groot").

2. Load the current spec file. Run a structured ambiguity & coverage scan using the taxonomy in `references/ambiguity-taxonomy.md` — read it only now, once the spec is loaded (not when aborting for a missing spec). For each category, mark status: Clear / Partial / Missing. Produce an internal coverage map for prioritization (output it only if no questions will be asked).

   For each Partial or Missing category, add a candidate question unless:
   - Clarification would not change implementation or validation strategy
   - Information is better deferred to planning (note internally)

3. Generate (internally) a prioritized queue of candidates (max 5). Do NOT output all at once. Apply these constraints:
    - Questions are limited to 5 total across the session.
    - Each question must be answerable with EITHER:
       - A short multiple‑choice selection (2–5 distinct, mutually exclusive options), OR
       - A one-word / short‑phrase answer (constrain: "Answer in <=5 words").
    - Only include questions whose answers affect architecture, data modeling, task decomposition, test design, UX behavior, operational readiness, or compliance validation.
    - Balance coverage: cover the highest-impact unresolved categories first; avoid two low-impact questions when one high-impact area (e.g., security posture) is unresolved.
    - Exclude questions already answered, trivial stylistic preferences, or plan-level execution details (unless blocking correctness).
    - Favor clarifications that cut rework risk or prevent misaligned acceptance tests.
    - If more than 5 categories remain, pick the top 5 by (Impact * Uncertainty) heuristic.

4. Sequential questioning loop (interactive):
    - Present EXACTLY ONE question at a time.
    - **Always rewrite the question in plain everyday language before showing it.** Never expose taxonomy labels (NFR, observability, scalability, throughput, idempotent, RBAC, PII, eventual consistency). Translate it into a concrete situation with an example — worked translations in `references/interactive-style.md` (already read).
    - Before a multiple-choice or short-answer question,
      read `references/question-formats.md` and render in that
      format (recommended-option header, options table with
      plain descriptions, reply instructions). Skip it in auto
      mode — no questions asked.
    - After the user answers:
       - If the user replies "yes", "recommended", or "suggested", use your prior recommendation/suggestion as the answer.
       - If the user replies "not sure" or "skip", apply the recommendation/suggestion as default, mark the spec entry "(default applied — confirm later)", and continue unblocked.
       - Otherwise, validate the answer maps to one option or fits <=5 words.
       - If ambiguous, ask for quick disambiguation in plain words (same question; do not advance).
       - Once satisfactory, record it in working memory (not yet to disk) and move to the next question.
    - Stop asking further questions when:
       - All critical ambiguities resolved early (remaining items unnecessary), OR
       - User signals completion ("done", "good", "no more", "that's enough"), OR
       - You reach 5 asked questions.
    - Never reveal future questions.
    - If no valid questions exist at start, report no critical ambiguities.

5. Integration after EACH accepted answer (incremental):
    - Keep an in-memory copy of the spec (loaded once) plus the raw file contents.
    - For the first integrated answer this session:
       - Ensure a `## Clarifications` section exists (create it after the top-level overview section per the spec template).
       - Under it, create (if absent) a `### Session YYYY-MM-DD` subheading for today.
    - Append a bullet after acceptance: `- Q: <question> → A: <final answer>`.
    - Then apply the clarification to the best-fit section(s):
       - Functional ambiguity → Update or add a bullet in Functional Requirements.
       - User interaction / actor distinction → Update User Stories or Actors subsection (if present) with clarified role, constraint, or scenario.
       - Data shape / entities → Update Data Model (add fields, types, relationships) preserving ordering; note new constraints.
       - Non-functional constraint → Add/modify measurable criteria in Success Criteria > Measurable Outcomes (convert vague adjective to metric or target).
       - Edge case / negative flow → Add a new bullet under Edge Cases / Error Handling (or create it if the template provides a placeholder).
       - Terminology conflict → Normalize term across spec; keep original only if necessary, adding `(formerly referred to as "X")` once.
    - If the clarification invalidates an earlier ambiguous statement, replace it, not duplicate; leave no obsolete contradictory text.
    - Save the spec AFTER each integration to cut context-loss risk (atomic overwrite).
    - Preserve formatting: don't reorder unrelated sections; keep heading hierarchy intact.
    - Keep each inserted clarification minimal and testable (no narrative drift).

6. Validation (after EACH write plus final pass):
   - Clarifications session has one bullet per accepted answer (no duplicates).
   - Total asked (accepted) questions ≤ 5.
   - Updated sections have no lingering vague placeholders the answer resolved.
   - No contradictory earlier statement remains (now-invalid alternatives removed).
   - Markdown structure valid; only allowed new headings: `## Clarifications`, `### Session YYYY-MM-DD`.
   - Terminology consistency: same canonical term across all sections.

7. Write the updated spec back to `FEATURE_SPEC`.

8. Report completion (after the loop or early termination):
   - Number of questions asked & answered.
   - Path to updated spec.
   - Sections touched (list names).
   - Coverage summary table: each taxonomy category with Status — Resolved (was Partial/Missing, now addressed), Deferred (exceeds quota or better for planning), Clear (already sufficient), Outstanding (still Partial/Missing, low impact).
   - If any Outstanding or Deferred remain, recommend whether to proceed to `/plan` or rerun `/clarify-specs` post-plan.
   - Suggested next command.

Behavior rules:

- If no meaningful ambiguities found (or all candidates are low-impact), respond: "No critical ambiguities detected worth formal clarification." and suggest proceeding.
- If spec file missing, tell the user to run `/intent` first (do not create a new spec here).
- Never exceed 5 total asked questions (retries for a single question don't count as new).
- Avoid speculative tech-stack questions unless absence blocks functional clarity.
- Respect user early termination signals ("stop", "done", "proceed").
- If no questions asked due to full coverage, output a compact summary (all Clear) then suggest advancing.
- If quota reached with unresolved high-impact categories, flag them Deferred with rationale.

Context for prioritization: $ARGUMENTS

## Post-Execution Checks

**Check for extension hooks (after clarification)**:

- If `.fire-phoenix/extensions.yml` is absent, skip silently.
- If it exists, read `references/extension-hooks.md`
  §Post-completion and apply that hook protocol against the
  `hooks.after_clarify-specs` key.

## Inputs

- **Feature Specification** (`{context.current.intent}`)
  - If set: read the spec file.
  - If null: Search {context.paths.intents} for the most recent intent.md.
  - If not provided (intent gate, adr/0064): clarify-intent needs an existing intent, so when none exists, bootstrap it first (Option A) not merely advise — in interactive mode confirm "No intent found — start by developing it?" then run the `intent` skill (greenfield) or `recover-intent`/`recover-spec` (brownfield); in auto mode run it and continue. Never clarify a non-existent intent.

## Outputs

- **Updated Specification** (`{context.current.intent}`)
  - Behavior: Update the spec in-place with clarifications. Ask before overwriting if confirm_before_write is true.
  - Overwrite guarded by `{context.preferences.confirm_before_write}`.

## Context Update

This skill does NOT modify `.fire-phoenix/context.yml` or `.fire-phoenix/user-context.yml` (in-spec updates only).

## Handoffs

- **Build Technical Plan**: run `/plan` to continue.
