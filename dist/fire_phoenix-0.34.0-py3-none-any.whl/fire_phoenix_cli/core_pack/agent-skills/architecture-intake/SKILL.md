---
name: architecture-intake
description: Captures architecture inputs — quality-attribute ranking, hard constraints, team context, operational envelope, integration surface, deployment preferences — into one intake artefact the architect works from. Use when starting system design or before producing ADRs and C4 diagrams.
license: MIT
compatibility: Designed for agentskills.io-compatible agents.
metadata:
  author: Dau Quang Thanh
  version: '1.0'
  requires: []
---

## User Input

```text
$ARGUMENTS
```

## Audience and tone (interactive mode)

**Register first — adapt to role level.** Before applying the beginner floor
below, resolve the reader's level from the merged `.fire-phoenix/context.yml`
+ `.fire-phoenix/user-context.yml` (`user-context.yml` wins): use
`preferences.tech_role_level` for technical work (`junior` → hand-hold, one
path; `mid` → ≥2 options with one-line trade-offs; `senior` → defer on
judgment, surface edge cases, be brief; `staff` → be terse, challenge
premises, skip obvious caveats) and `preferences.non_tech_role_level` for
stakeholder work (`non-technical` → outcomes not jargon; `familiar` → simple
jargon glossed; `fluent` → concepts without explanation; `technical` → full
vocabulary). An explicit in-session signal (e.g. "be terse", "skip the
explanation") overrides everything. The plain-English, one-question-at-a-time
floor below applies **only when the relevant level is unset**; never treat
role level as a gate. Full rule: `.fire-phoenix/references/subagents/register-resolution.md`.

When `FIRE_PHOENIX_AGENT_MODE=interactive` (the default), assume the user
has **limited technical background and limited domain knowledge**
— they may know basics but lack deep expertise in this skill's
area. Run this skill as a guided questionnaire:

- **One question at a time.** No walls of questions.
- **Yes / no first.** Phrase so `yes`, `no`, `not sure`, or `skip`
  is a valid answer.
- **Translate jargon, don't strip it.** Use the technical term but
  always pair it with a plain-English gloss the first time it
  appears.
- **Choices, not blank fields.** When yes/no isn't enough, offer
  2-4 lettered options (A/B/C/D) with one-line plain-language
  descriptions of the trade-off. Always include "Not sure — pick
  a sensible default".
- **Always recommend.** State the option you would pick and why in
  one sentence so the user can reply "yes" / "ok" to accept. Pull
  defaults from upstream artefacts (spec, architecture, ADRs,
  standards) before asking blank.
- **Show, don't ask.** When upstream artefacts already imply an
  answer, propose it as a pre-filled finding and ask for a
  yes / no confirmation rather than asking the user to fill in a
  blank.
- **`not sure` / `skip` triggers a sensible default**, marked
  "(default applied — confirm later)" in the artefact, and a debt
  entry in this skill's debt file.

When `FIRE_PHOENIX_AGENT_MODE=auto` (or `--auto`), skip the questionnaire
entirely: apply sensible defaults from upstream artefacts and log
decisions to the parent agent's decision log.

## Inputs

- `.fire-phoenix/context.yml`
- `{context.paths.intents}/**/intent.md` — functional + NFR source
- Optional (brownfield): `{context.paths.docs}/architecture/extracted.md`
  — the recovered as-is architecture. Pre-fill constraints, integration
  surface, and the operational envelope from it, and record any intake
  answer that contradicts it as a drift finding (same rule as
  `architecture-extraction`'s reconciliation step), never silently.
  Statements about the *existing* system carry OBSERVED / INFERRED
  (low|med|high confidence) / UNKNOWN tags; "(AI proposal — confirm)"
  stays reserved for forward-looking proposals.

## Outputs

- `{context.paths.docs}/architecture/intake.md`
- `{context.paths.docs}/architecture/intake.extract`

## Context Update

Does not mutate `.fire-phoenix/context.yml`.

## Handoffs

- `technology-research` reads intake to scope candidate evaluations.
- `adr-author` reads constraints to frame the context of each ADR.
- `c4-diagrams` reads the integration surface for the context
  diagram.
- `business-analyst` receives the candidate negative acceptance
  criteria mapped from named failure conditions; the
  business-analyst authors the final criteria.

## AI authoring scope

**Does:** ask the user structured questions, record answers,
propose sensible defaults with "(AI proposal — confirm)".

**Does not:** interview stakeholders, assume anything about budget
without the user stating it, commit the team to a stack, author
final acceptance criteria (it proposes candidates; the
business-analyst authors).

## Intake flow

1. **Rank quality attributes** — force a 1–5 ordering using the
   canonical names in `references/quality-attributes.md`.
2. **Elicit NFRs per category** — walk
   `references/nfr-elicitation-checklist.md` (performance,
   availability, security, compliance, data retention,
   operability). Every target gets a number or an explicit band;
   an unquantified NFR is a `TDEBT-`.
3. **Capture constraints, team context, operational envelope,
   integration surface, deployment preferences** — the template
   sections, pre-filled from upstream artefacts where possible.
4. **Map failure conditions to candidate negative ACs** — for
   every *named failure condition* surfaced by the checklist's
   closing questions ("what happens when this target is
   missed?"), draft one candidate negative acceptance criterion
   in Given/When/Then form (see the mapping guidance at the end
   of the checklist). Record them in the intake artefact and
   hand them to the business-analyst, who authors the final
   criteria; this skill only proposes.
5. **Write the artefact** — every "TBD" answer also lands in
   `tech-debts.md` with owner + priority.

Rigor scaling: under Profile **P** (Prototype/Demo) step 4 may
cover only the top-ranked risk and says so in the artefact;
Profile **F** (Production, the default when none is declared)
maps every named failure condition.

## Usage

> `<SKILL_DIR>` = the integration's skills root (e.g. `.claude/skills/`
> for Claude Code, `.codex/skills/` for Codex,
> `.cursor/skills/` for Cursor, `.kiro/skills/` for Kiro).
> Scripts live at `<SKILL_DIR>/<skill-name>/scripts/…`.

```bash
bash <SKILL_DIR>/architecture-intake/scripts/bash/draft-intake.sh --auto  # uses defaults + env vars
bash <SKILL_DIR>/architecture-intake/scripts/bash/draft-intake.sh         # interactive
```

### Answer keys

| Key | Default |
|---|---|
| `AI_QA_TOP5` | empty (→ debt) |
| `AI_HARD_CONSTRAINTS` | empty |
| `AI_TEAM_SIZE_BAND` | `6-15` |
| `AI_PEAK_QPS` | empty |
| `AI_SLA_TARGET` | `99.9%` |
| `AI_DEPLOY_PREF` | `no-preference` |

## References

- `references/quality-attributes.md` — canonical
  quality-attribute vocabulary for the ranking.
- `references/nfr-elicitation-checklist.md` — per-category NFR
  questions, quantification bar, and the failure-condition →
  candidate-negative-AC mapping.
