---
name: feature-checklist
description: Generates a custom checklist for the current feature based on user
  requirements, validating quality and completeness of requirements
  in a given domain. Use when reviewing feature completeness, running
  pre-implementation checks, or verifying that requirements meet
  acceptance standards.
license: MIT
compatibility: Designed for agentskills.io-compatible agents.
metadata:
  author: Dau Quang Thanh
  version: '1.0'
  requires: [plan]
  scripts:
    sh: scripts/bash/check-prerequisites.sh --json
    ps: scripts/powershell/check-prerequisites.ps1 -Json
---

## Checklist Purpose: "Unit Tests for English"

**CRITICAL CONCEPT**: Checklists are **UNIT TESTS FOR REQUIREMENTS WRITING** - they validate requirement quality, clarity, and completeness in a given domain.

Every item tests the requirements themselves — NOT whether the
implementation works. If unsure which an item tests, read
`references/item-examples.md` (✅/❌ catalogues); skip it when the
distinction is clear.

**Metaphor**: If your spec is code written in English, the checklist is its unit test suite — testing whether requirements are well-written, complete, unambiguous, and ready for implementation, NOT whether the implementation works.

## Milestone / DoD and ceremony-prep checklists

The project-manager and scrum-master agents also use this skill
for **milestone, Definition-of-Done, and ceremony-prep**
checklists (domains B–D in the interactive questionnaire) — a
second mode checking **delivery completeness
with evidence**, not requirements wording, so the
"unit tests for English" rules above govern only the
requirements-quality domain. For a delivery checklist (B–D),
read `references/dod-anatomy.md` and follow it —
falsifiable claim + named evidence per item, evidence sources,
DoD inheritance, and the unticked-item rule; do not read it for
requirements-quality (domain A) checklists.

Everything else (questionnaire, file handling, CHK numbering,
template structure) applies to both modes.

## User Input

```text
$ARGUMENTS
```

You **MUST** consider the user input before proceeding (if not empty).

## Audience and tone (interactive mode)

**Register first — adapt to role level.** Resolve the reader's level
from the merged `.fire-phoenix/context.yml`
+ `.fire-phoenix/user-context.yml` (`user-context.yml` wins): use
`preferences.tech_role_level` for technical work (`junior` → hand-hold, one
path; `mid` → ≥2 options, one-line trade-offs; `senior` → defer on
judgment, surface edge cases, be brief; `staff` → terse, challenge
premises, skip obvious caveats) and `preferences.non_tech_role_level` for
stakeholder work (`non-technical` → outcomes not jargon; `familiar` → simple
jargon glossed; `fluent` → concepts without explanation; `technical` → full
vocabulary). An explicit in-session signal (e.g. "be terse", "skip the
explanation") overrides everything. The plain-English, one-question-at-a-time
floor below is limited: it applies **only when the relevant level is unset**;
never treat it as a gate. Full rule: `.fire-phoenix/references/subagents/register-resolution.md`.

When `FIRE_PHOENIX_AGENT_MODE=interactive` (the default), assume the user
has **no technical or business-domain background** and run this
as a guided questionnaire. Before asking anything, read
`references/interactive-questionnaire.md` (conversational rules,
domain phrasing, `not sure` / `skip` handling). Do not read it in
auto mode.

When `FIRE_PHOENIX_AGENT_MODE=auto` (or `--auto`), skip the questionnaire:
pick a domain from upstream artefacts, generate the checklist, and
log decisions to the parent agent's decision log.

## Pre-Execution Checks

**Check for extension hooks (before checklist generation)**:

- If `.fire-phoenix/extensions.yml` does not exist in the project
  root, skip silently.
- If it exists, read `references/extension-hooks.md` §Pre-execution
  and apply the hook protocol there against the
  `hooks.before_checklist` before the Execution Steps.

## Execution Steps

1. **Setup**: Run `{SCRIPT}` from repo root and parse JSON for FEATURE_DIR and AVAILABLE_DOCS list.
   - All file paths must be absolute.
   - For single quotes in args like "I'm Groot", use escape syntax: e.g 'I'\''m Groot' (or double-quote if possible: "I'm Groot").

2. **Clarify intent (dynamic)**: Derive up to THREE contextual clarifying questions (no pre-baked catalog). They MUST:
   - From the user's phrasing + signals extracted from spec/plan/tasks
   - Only ask what materially changes content
   - Skip individually if already unambiguous in `$ARGUMENTS`
   - Prefer precision over breadth

   Before formulating or presenting any question, read
   `references/clarifying-questions.md` (generation algorithm,
   question formatting rules, defaults when interaction is
   impossible, and the Q4/Q5 escalation rule). Skip it when zero
   questions are needed (`$ARGUMENTS` already unambiguous) and in
   auto mode.

3. **Understand user request**: Combine `$ARGUMENTS` + clarifying answers:
   - Derive checklist theme (e.g., security, review, deploy, ux)
   - Consolidate the user's must-have items
   - Map focus selections to category scaffolding
   - Infer any missing context from spec/plan/tasks (do NOT hallucinate)

4. **Load feature context**: Read from FEATURE_DIR:
   - intent.md: Feature requirements and scope
   - plan.md (if exists): Technical details, dependencies
   - tasks.md (if exists): Implementation tasks

   **Context Loading Strategy**:
   - Load only portions relevant to active focus areas (no full-file dumping)
   - Summarize long sections into concise scenario/requirement bullets
   - Progressive disclosure: add follow-on retrieval only if gaps detected
   - For large source docs, generate interim summary items, not raw text

5. **Generate checklist** - Create "Unit Tests for Requirements":
   - Create `FEATURE_DIR/checklists/` if it doesn't exist
   - Generate unique filename:
     - Short, descriptive name based on domain (e.g., `ux.md`, `api.md`, `security.md`)
     - Format: `[domain].md`
   - File handling:
     - If file does NOT exist: Create new file and number items starting from CHK001
     - If file exists: Append new items, continuing from the last CHK ID (e.g., last item CHK015 → start at CHK016)
   - Never delete or replace existing content — always preserve and append

   **CORE PRINCIPLE - Test the Requirements, Not the Implementation**:
   Every checklist item MUST evaluate the REQUIREMENTS THEMSELVES for:
   - **Completeness**: all necessary requirements present?
   - **Clarity**: requirements unambiguous and specific?
   - **Consistency**: requirements align with each other?
   - **Measurability**: requirements objectively verifiable?
   - **Coverage**: all scenarios/edge cases addressed?

   **Category Structure** - Group items by requirement quality dimensions:
   - **Requirement Completeness** (all documented?)
   - **Requirement Clarity** (specific, unambiguous?)
   - **Requirement Consistency** (aligned, no conflicts?)
   - **Acceptance Criteria Quality** (measurable?)
   - **Scenario Coverage** (all flows/cases?)
   - **Edge Case Coverage** (boundaries defined?)
   - **Non-Functional Requirements** (Performance, Security, Accessibility, etc. — specified?)
   - **Dependencies & Assumptions** (documented, validated?)
   - **Ambiguities & Conflicts** (what needs clarification?)

   **ITEM STRUCTURE**:
   Each item follows this pattern:
   - Question format asking about requirement quality
   - Focus on what's WRITTEN (or not written) in the spec/plan
   - Include quality dimension in brackets [Completeness/Clarity/Consistency/etc.]
   - Reference `[Spec §X.Y]` when checking existing requirements
   - Use `[Gap]` when checking for missing requirements

   **Scenario Classification & Coverage** (Requirements Quality Focus):
   - Check requirements exist for: Primary, Alternate, Exception/Error, Recovery, Non-Functional scenarios
   - For each scenario class, ask: "Are [scenario type] requirements complete, clear, and consistent?"
   - If scenario class missing: "Are [scenario type] requirements intentionally excluded or missing? [Gap]"
   - Include resilience/rollback on state mutation: "Are rollback requirements defined for migration failures? [Gap]"

   **Traceability Requirements**:
   - MINIMUM: ≥80% of items MUST include ≥1 traceability reference
   - Each item references `[Spec §X.Y]`, or markers: `[Gap]`, `[Ambiguity]`, `[Conflict]`, `[Assumption]`
   - If no ID system exists: "Is a requirement & acceptance criteria ID scheme established? [Traceability]"

   **Surface & Resolve Issues** (Requirements Quality Problems):
   Ask about the requirements themselves — ambiguities,
   conflicts, assumptions, dependencies, missing definitions (if
   unsure how to phrase one, see `references/item-examples.md`).

   **Content Consolidation**:
   - Soft cap: If raw candidate items > 40, prioritize by risk/impact
   - Merge near-duplicates on the same requirement aspect
   - If >5 low-impact edge cases, create one item: "Are edge cases X, Y, Z addressed in requirements? [Coverage]"

   **🚫 PROHIBITED / ✅ REQUIRED**: any item starting with
   "Verify", "Test", "Confirm", "Check" + implementation behavior
   is an implementation test and is prohibited; required items ask
   whether requirements are defined, quantified, consistent, and
   measurable. If an item might cross that line, read the full
   catalogues in `references/item-examples.md` §Prohibited /
   §Required patterns; otherwise skip that file.

6. **Structure Reference**: Follow the canonical template in `templates/checklist-template.md` (title, meta section, category headings, ID formatting). If unavailable, use: H1 title, purpose/created meta lines, `##` category sections with `- [ ] CHK### <requirement item>` lines, globally incrementing IDs from CHK001.

7. **Report**: Output the checklist path, item count, and whether the run created or appended to a file. Summarize:
   - Focus areas selected
   - Depth level
   - Actor/timing
   - Any user-specified must-have items incorporated

**Important**: Each `/checklist` invocation uses a short, descriptive filename and either creates a new file or appends to an existing one. This allows:

- Multiple checklists of different types (e.g., `ux.md`, `test.md`, `security.md`)
- Simple, memorable filenames indicating checklist purpose
- Easy navigation in the `checklists/` folder

To avoid clutter, use descriptive types and clean up obsolete checklists.

## Example Catalogues

For an unfamiliar domain, read
`references/item-examples.md` — per-dimension examples, sample
items per domain, and anti-example CHK lists. Skip it when
your items already follow the required question form.

## Post-Execution Checks

**Check for extension hooks (after checklist generation)**:

- If `.fire-phoenix/extensions.yml` does not exist in the project
  root, skip silently.
- If it exists, read `references/extension-hooks.md`
  §Post-completion and apply the hook protocol there against
  `hooks.after_checklist`.

## Inputs

- **Feature Specification** (`{context.current.intent}`)
  - If set: Read that file.
  - If null: Search {context.paths.intents} for the latest intent.md.
  - If not provided: Ask the user to run /intent first.

## Outputs

- **Checklist File** (`{context.paths.intents}/{context.current.feature}/checklists/{domain}.md`)
  - Behavior: Write the file. If it exists and confirm_before_write is true, ask the user.
  - Overwrite guarded by `{context.preferences.confirm_before_write}`.

## Context Update

This skill does NOT modify `.fire-phoenix/context.yml` or `.fire-phoenix/user-context.yml` (checklists are validation, not workflow progression).
