"""fire-phoenix — setup tool for intent-driven development projects.

This package is the public Python API. Concrete behaviour lives in the
domain subpackages (``cli``, ``installer``, ``skills``, ``subagents``,
``presets``, ``extensions``, ``integrations``, ``workflows``). This module
re-exports the small surface external callers rely on via
``from fire_phoenix_cli import X``.
"""

from fire_phoenix_cli.cli import app, main
from fire_phoenix_cli.config import DEFAULT_SKILLS_DIR, SKILL_DESCRIPTIONS
from fire_phoenix_cli.installer import AGENT_CONFIG

__all__ = [
    "AGENT_CONFIG",
    "DEFAULT_SKILLS_DIR",
    "SKILL_DESCRIPTIONS",
    "app",
    "main",
]
