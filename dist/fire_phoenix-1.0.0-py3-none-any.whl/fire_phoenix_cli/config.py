"""Init options configuration management for fire-phoenix projects."""

from pathlib import Path
from typing import Any

import yaml

INIT_OPTIONS_FILE = ".fire-phoenix/init-options.yml"

# Default destination for installed agent skills relative to a project root.
DEFAULT_SKILLS_DIR = ".agents/skills"

# Human-readable descriptions used when rendering bundled skills into
# integration-specific command files (presets/extensions). Keys are bundle
# names (post-prefix-removal, per adr/0003).
SKILL_DESCRIPTIONS = {
    "specify": "Create or update feature specifications from natural language descriptions.",
    "plan": "Generate technical implementation plans from feature specifications.",
    "taskify": "Break down implementation plans into actionable task lists.",
    "implement": "Execute all tasks from the task breakdown to build the feature.",
    "analyze": "Perform cross-artifact consistency analysis across intent.md, plan.md, and tasks.md.",
    "clarify": "Structured clarification workflow for underspecified requirements.",
    "standardize": "Create or update project governing principles and development guidelines.",
    "checklist": "Generate custom quality checklists for validating requirements completeness and clarity.",
    "tasks-to-issues": "Convert tasks from tasks.md into GitHub issues.",
}


def save_init_options(project_path: Path, options: dict[str, Any]) -> None:
    """Persist the CLI options used during ``fire-phoenix init``.

    Writes a small YAML file to ``.fire-phoenix/init-options.yml`` so that
    later operations (e.g. preset install) can adapt their behaviour
    without scanning the filesystem.
    """
    dest = project_path / INIT_OPTIONS_FILE
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_text(
        yaml.safe_dump(options, sort_keys=True, default_flow_style=False, allow_unicode=True),
        encoding="utf-8",
    )


def load_init_options(project_path: Path) -> dict[str, Any]:
    """Load the init options previously saved by ``fire-phoenix init``.

    Returns an empty dict if the file does not exist or cannot be parsed.
    """
    path = project_path / INIT_OPTIONS_FILE
    if not path.exists():
        return {}
    try:
        return yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    except (yaml.YAMLError, OSError):
        return {}
