"""Skill bundle subpackage.

Owns code that consumes ``assets/agent-skills/<name>/`` bundles:
rendering for install (``render``). Discovery, validation, and registry
queries currently live ad-hoc in ``extensions.py``, ``skill_assets.py``,
and ``scripts/lint_skills.py``; migration into this subpackage will be
authored under a dedicated contract when scheduled.
"""

from .render import CommandRegistrar, _build_agent_configs

__all__ = ["CommandRegistrar", "_build_agent_configs"]
