"""Workflow engine — loads, validates, and executes workflow YAML definitions.

The engine is the orchestrator that:
- Parses workflow YAML definitions
- Validates step configurations and requirements
- Executes steps sequentially, dispatching to the correct step type
- Manages state persistence for resume capability

Since the stage-5 reduction (adr/0049, task-0098) the engine is a **linear**
verb executor — a sequence of `command` / `prompt` / `gate` steps with human
gates. Control-flow steps (if/switch/while/fan) and the branch parser were
removed; orchestration is expressed by composing `change` verbs, not engine
conditionals.
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any

import yaml

from .base import RunStatus, StepContext, StepResult, StepStatus

# Engine safety bounds (improving-pro-plan.md §P2-4, F-10). Defaults are the
# out-of-the-box budget; a workflow may raise them via a ``limits:`` block up to
# the hard ceiling, which can never be exceeded.
DEFAULT_STEP_BUDGET = 500
HARD_STEP_BUDGET = 10_000


def _clamp(value: Any, default: int, ceiling: int) -> int:
    """Return *value* as an int in ``[1, ceiling]``, or *default* if unusable."""
    if not isinstance(value, int) or isinstance(value, bool) or value < 1:
        return default
    return min(value, ceiling)


# -- Workflow Definition --------------------------------------------------


class WorkflowDefinition:
    """Parsed and validated workflow YAML definition."""

    def __init__(self, data: dict[str, Any], source_path: Path | None = None) -> None:
        self.data = data
        self.source_path = source_path

        wf = data.get("workflow")
        # A non-mapping `workflow:` (null / scalar / list) must degrade to an
        # empty mapping — an empty id then trips normal validation rather than
        # crashing construction with AttributeError.
        workflow = wf if isinstance(wf, dict) else {}
        self.id: str = workflow.get("id", "")
        self.name: str = workflow.get("name", "")
        self.version: str = workflow.get("version", "0.0.0")
        self.author: str = workflow.get("author", "")
        self.description: str = workflow.get("description", "")
        self.schema_version: str = data.get("schema_version", "1.0")

        # Defaults
        self.default_integration: str | None = workflow.get("integration")
        self.default_model: str | None = workflow.get("model")
        # Run mode default: "interactive" (safe; agent attached to the terminal)
        # or "auto" (unattended; headless + granted tool permissions). The CLI
        # `--auto` flag overrides this. Anything other than "auto" is treated as
        # interactive.
        self.execution: str = str(workflow.get("execution", "interactive")).lower()
        self.default_options: dict[str, Any] = workflow.get("options") or {}
        if not isinstance(self.default_options, dict):
            self.default_options = {}

        # Requirements (declared but not yet enforced at runtime;
        # enforcement is a planned enhancement)
        self.requires: dict[str, Any] = data.get("requires", {})

        # Inputs
        self.inputs: dict[str, Any] = data.get("inputs", {})

        # Steps
        self.steps: list[dict[str, Any]] = data.get("steps", [])

    @classmethod
    def from_yaml(cls, path: Path) -> WorkflowDefinition:
        """Load a workflow definition from a YAML file."""
        with open(path, encoding="utf-8") as f:
            data = yaml.safe_load(f)
        if not isinstance(data, dict):
            msg = f"Workflow YAML must be a mapping, got {type(data).__name__}."
            raise ValueError(msg)
        return cls(data, source_path=path)

    @classmethod
    def from_string(cls, content: str) -> WorkflowDefinition:
        """Load a workflow definition from a YAML string."""
        data = yaml.safe_load(content)
        if not isinstance(data, dict):
            msg = f"Workflow YAML must be a mapping, got {type(data).__name__}."
            raise ValueError(msg)
        return cls(data)


# -- Workflow Validation --------------------------------------------------

# ID format: lowercase alphanumeric with hyphens
_ID_PATTERN = re.compile(r"^[a-z0-9][a-z0-9-]*[a-z0-9]$|^[a-z0-9]$")


# Valid step types (matching STEP_REGISTRY keys)
def _get_valid_step_types() -> set[str]:
    """Return valid step types from the registry, with a built-in fallback."""
    from . import STEP_REGISTRY

    if STEP_REGISTRY:
        return set(STEP_REGISTRY.keys())
    # Fallback: the linear verb-executor step types (task-0098).
    return {"command", "prompt", "gate"}


def validate_workflow(definition: WorkflowDefinition) -> list[str]:
    """Validate a workflow definition and return a list of error messages.

    An empty list means the workflow is valid.
    """
    errors: list[str] = []

    # -- Schema version ---------------------------------------------------
    if definition.schema_version not in ("1.0", "1"):
        errors.append(f"Unsupported schema_version {definition.schema_version!r}. Expected '1.0'.")

    # -- Top-level fields -------------------------------------------------
    if not definition.id:
        errors.append("Workflow is missing 'workflow.id'.")
    elif not _ID_PATTERN.match(definition.id):
        errors.append(f"Workflow ID {definition.id!r} must be lowercase alphanumeric with hyphens.")

    if not definition.name:
        errors.append("Workflow is missing 'workflow.name'.")

    if not definition.version:
        errors.append("Workflow is missing 'workflow.version'.")
    elif not re.match(r"^\d+\.\d+\.\d+$", definition.version):
        errors.append(
            f"Workflow version {definition.version!r} is not valid "
            f"semantic versioning (expected X.Y.Z)."
        )

    # -- Inputs -----------------------------------------------------------
    if not isinstance(definition.inputs, dict):
        errors.append("'inputs' must be a mapping (or omitted).")
    else:
        for input_name, input_def in definition.inputs.items():
            if not isinstance(input_def, dict):
                errors.append(f"Input {input_name!r} must be a mapping.")
                continue
            input_type = input_def.get("type")
            if input_type and input_type not in ("string", "number", "boolean"):
                errors.append(
                    f"Input {input_name!r} has invalid type {input_type!r}. "
                    f"Must be 'string', 'number', or 'boolean'."
                )

    # -- Steps ------------------------------------------------------------
    if not isinstance(definition.steps, list):
        errors.append("'steps' must be a list.")
        return errors
    if not definition.steps:
        errors.append("Workflow has no steps defined.")

    seen_ids: set[str] = set()
    _validate_steps(definition.steps, seen_ids, errors)

    return errors


def _validate_steps(
    steps: list[dict[str, Any]],
    seen_ids: set[str],
    errors: list[str],
) -> None:
    """Recursively validate a list of steps."""
    from . import STEP_REGISTRY

    for step_config in steps:
        if not isinstance(step_config, dict):
            errors.append(f"Step must be a mapping, got {type(step_config).__name__}.")
            continue

        step_id = step_config.get("id")
        if not step_id:
            errors.append("Step is missing 'id' field.")
            continue

        if ":" in step_id:
            errors.append(
                f"Step ID {step_id!r} contains ':' which is reserved "
                f"for engine-generated nested IDs (parentId:childId)."
            )

        if step_id in seen_ids:
            errors.append(f"Duplicate step ID {step_id!r}.")
        seen_ids.add(step_id)

        # Determine step type
        step_type = step_config.get("type", "command")
        if step_type not in _get_valid_step_types():
            errors.append(f"Step {step_id!r} has invalid type {step_type!r}.")
            continue

        # Delegate to step-specific validation
        step_impl = STEP_REGISTRY.get(step_type)
        if step_impl:
            step_errors = step_impl.validate(step_config)
            errors.extend(step_errors)

        # The engine is a linear verb executor (task-0098): it iterates only the
        # top-level `steps` list. A surviving step type that still carries a
        # control-flow nesting key (`then`/`else`/`steps`/`cases`/`default`/`step`)
        # is a half-migrated control-flow step whose children would be SILENTLY
        # DROPPED at run time. Reject it loudly instead of validating dead steps
        # as if they were real (B13/task-0099).
        for nested_key in ("then", "else", "steps", "cases", "default", "step"):
            if nested_key in step_config:
                errors.append(
                    f"Step {step_id!r} has a nested {nested_key!r} key, but the engine "
                    f"is a linear verb executor — nested/control-flow steps are not "
                    f"executed. Flatten the workflow into top-level steps."
                )


# -- Run State Persistence ------------------------------------------------
#
# Lives in `run_state.py` (task-0147 W3): engine.py is the executor, that module
# is the persistence layer, and they were together only by history. Imported —
# not re-exported — because a shim purely for old import paths is the kind of
# back-compat scaffolding working rule 8 rules out; the seven call sites moved
# to the new module instead.

from .run_state import RunState, RunStateError, _read_json_mapping, _validate_run_id  # noqa: E402

# -- Workflow Engine ------------------------------------------------------


class WorkflowEngine:
    """Orchestrator that loads, validates, and executes workflow definitions."""

    def __init__(self, project_root: Path | None = None) -> None:
        self.project_root = project_root or Path(".")
        self.on_step_start: Any = None  # Callable[[str, str, str], None] | None
        self.on_step_complete: Any = None  # Callable[[str, str, float, str|None, dict], None]
        self.on_warning: Any = None  # Callable[[str], None] | None
        # When False, command steps capture their CLI output instead of
        # streaming it live — lets the CLI render a progress spinner.
        self.stream_output: bool = True
        # When True, agent (command) steps run unattended: headless with tool
        # permissions granted and FIRE_PHOENIX_AGENT_MODE=auto. Default False =
        # interactive (agent attached to the terminal; user approves live).
        # Set from `--auto` or a workflow's `execution: auto`.
        self.unattended: bool = False
        # Step budget (F-10) — configured per run in _configure_limits().
        self._step_budget = DEFAULT_STEP_BUDGET
        self._step_count = 0

    def _configure_limits(self, definition: WorkflowDefinition) -> None:
        """Read the optional ``limits:`` block, clamped to hard ceilings (F-10)."""
        limits: dict[str, Any] = {}
        data = getattr(definition, "data", None) or {}
        if isinstance(data, dict):
            raw = data.get("limits")
            if not isinstance(raw, dict):
                wf = data.get("workflow")
                raw = wf.get("limits") if isinstance(wf, dict) else None
            # A non-mapping `limits:` (list/scalar) degrades to defaults instead
            # of crashing the engine and leaving the run stuck in RUNNING.
            limits = raw if isinstance(raw, dict) else {}
        self._step_budget = _clamp(limits.get("max_steps"), DEFAULT_STEP_BUDGET, HARD_STEP_BUDGET)
        self._step_count = 0

    def _preflight_requires(self, definition: WorkflowDefinition) -> list[str]:
        """Return human-readable messages for any unmet ``workflow.requires`` (F-20).

        Supports ``requires.tools`` (checked via ``shutil.which``) and
        ``requires.integrations`` (checked against the project's installed
        integrations). Fails the run before step 1 instead of deep inside it.

        ``requires.integrations`` accepts either a flat list — every listed
        integration must be installed (AND semantics) — or a mapping with
        ``all`` (every listed integration installed) and/or ``any`` (at least
        one installed). The bundled workflows use the ``any`` form.
        """
        requires = getattr(definition, "requires", {}) or {}
        if not isinstance(requires, dict):
            return []
        missing: list[str] = []

        import shutil

        for tool in requires.get("tools", []) or []:
            if shutil.which(str(tool)) is None:
                missing.append(f"required tool not found on PATH: {tool!r}")

        needed_integrations = requires.get("integrations", []) or []
        if needed_integrations:
            installed = self._installed_integrations()
            if isinstance(needed_integrations, dict):
                all_required = needed_integrations.get("all", []) or []
                any_required = needed_integrations.get("any", []) or []
                for key in all_required:
                    if str(key) not in installed:
                        missing.append(f"required integration not installed: {key!r}")
                if any_required and not any(str(k) in installed for k in any_required):
                    options = ", ".join(repr(str(k)) for k in any_required)
                    missing.append(
                        f"requires at least one of these integrations installed: {options}"
                    )
            else:
                for key in needed_integrations:
                    if str(key) not in installed:
                        missing.append(f"required integration not installed: {key!r}")
        return missing

    def _installed_integrations(self) -> set[str]:
        """Read installed integration keys from ``.fire-phoenix/integration.yml``."""
        path = self.project_root / ".fire-phoenix" / "integration.yml"
        if not path.exists():
            return set()
        try:
            data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
        except yaml.YAMLError:
            return set()
        return {str(k) for k in (data.get("integrations", []) or [])}

    def _fail_limit(self, state: RunState, limit_name: str, detail: str) -> None:
        """Fail the run because a safety budget was exceeded (F-10)."""
        state.status = RunStatus.FAILED
        state.append_log({"event": "limit_exceeded", "limit": limit_name, "error": detail})
        state.save()

    def load_workflow(self, source: str | Path) -> WorkflowDefinition:
        """Load a workflow from an installed ID or a local YAML path.

        Parameters
        ----------
        source:
            Either a workflow ID (looked up in the installed workflows
            directory) or a path to a YAML file.

        Returns
        -------
        A parsed ``WorkflowDefinition`` (not yet validated; call
        ``validate_workflow()`` or ``engine.validate()`` separately).

        Raises
        ------
        FileNotFoundError:
            If the workflow file cannot be found.
        ValueError:
            If the workflow YAML is invalid.
        """
        path = Path(source)

        # Try as a direct file path first
        if path.suffix in (".yml", ".yaml") and path.exists():
            return WorkflowDefinition.from_yaml(path)

        # Try as an installed workflow ID
        installed_path = (
            self.project_root / ".fire-phoenix" / "workflows" / str(source) / "workflow.yml"
        )
        if installed_path.exists():
            return WorkflowDefinition.from_yaml(installed_path)

        msg = f"Workflow not found: {source}"
        raise FileNotFoundError(msg)

    def validate(self, definition: WorkflowDefinition) -> list[str]:
        """Validate a workflow definition."""
        return validate_workflow(definition)

    def execute(
        self,
        definition: WorkflowDefinition,
        inputs: dict[str, Any] | None = None,
        run_id: str | None = None,
    ) -> RunState:
        """Execute a workflow definition.

        Parameters
        ----------
        definition:
            The validated workflow definition.
        inputs:
            User-provided input values.
        run_id:
            Optional run ID (auto-generated if not provided).

        Returns
        -------
        The final ``RunState`` after execution completes (or pauses).
        """
        from . import STEP_REGISTRY

        state = RunState(
            run_id=run_id,
            workflow_id=definition.id,
            project_root=self.project_root,
        )

        # Persist a copy of the workflow definition so resume can
        # reload it even if the original source is no longer available
        # (e.g. a local YAML path that was moved or deleted).
        run_dir = self.project_root / ".fire-phoenix" / "workflows" / "runs" / state.run_id
        run_dir.mkdir(parents=True, exist_ok=True)
        workflow_copy = run_dir / "workflow.yml"
        import yaml

        with open(workflow_copy, "w", encoding="utf-8") as f:
            yaml.safe_dump(definition.data, f, sort_keys=False, allow_unicode=True)

        # Resolve inputs
        resolved_inputs = self._resolve_inputs(definition, inputs or {})
        state.inputs = resolved_inputs
        state.status = RunStatus.RUNNING
        state.save()

        context = StepContext(
            inputs=resolved_inputs,
            default_integration=definition.default_integration,
            default_model=definition.default_model,
            default_options=definition.default_options,
            project_root=str(self.project_root),
            run_id=state.run_id,
            stream=self.stream_output,
            unattended=self.unattended,
        )

        # Pre-flight: fail before step 1 if declared requirements are missing (F-20).
        missing = self._preflight_requires(definition)
        if missing:
            state.status = RunStatus.FAILED
            detail = "; ".join(missing)
            state.append_log({"event": "requires_unmet", "error": detail})
            state.save()
            state.append_log({"event": "workflow_finished", "status": state.status.value})
            state.save()
            return state

        # Execute steps
        self._configure_limits(definition)
        try:
            self._execute_steps(definition.steps, context, state, STEP_REGISTRY)
        except KeyboardInterrupt:
            state.status = RunStatus.PAUSED
            state.append_log({"event": "workflow_interrupted"})
            state.save()
            return state
        except Exception as exc:  # allowlist: deliberate broad-except
            # Workflow step boundary (see tests/test_except_hygiene.py): an
            # arbitrary registered step function may raise any exception type.
            # Record the failure into run state, then re-raise — this is NOT a
            # silent swallow, so narrowing would only drop the failure
            # annotation for exotic error types.
            state.status = RunStatus.FAILED
            state.append_log({"event": "workflow_failed", "error": str(exc)})
            state.save()
            raise

        if state.status == RunStatus.RUNNING:
            state.status = RunStatus.COMPLETED
        state.append_log({"event": "workflow_finished", "status": state.status.value})
        state.save()
        return state

    def resume(self, run_id: str) -> RunState:
        """Resume a paused or failed workflow run."""
        _validate_run_id(run_id)
        state = RunState.load(run_id, self.project_root)
        if state.status not in (RunStatus.PAUSED, RunStatus.NEEDS_INPUT, RunStatus.FAILED):
            msg = f"Cannot resume run {run_id!r} with status {state.status.value!r}."
            raise ValueError(msg)

        # Load the workflow definition — try the persisted copy in the
        # run directory first so resume works even if the original
        # source (e.g. a local YAML path) is no longer available.
        run_dir = self.project_root / ".fire-phoenix" / "workflows" / "runs" / run_id
        run_copy = run_dir / "workflow.yml"
        if run_copy.exists():
            definition = WorkflowDefinition.from_yaml(run_copy)
        else:
            definition = self.load_workflow(state.workflow_id)

        # Restore context
        context = StepContext(
            inputs=state.inputs,
            steps=state.step_results,
            default_integration=definition.default_integration,
            default_model=definition.default_model,
            default_options=definition.default_options,
            project_root=str(self.project_root),
            run_id=state.run_id,
            stream=self.stream_output,
            unattended=self.unattended,
            # Tell the step being resumed into that this is a re-entry (adr/0047):
            # an interactive command step verifies `produces` + completes instead
            # of emitting NEEDS_INPUT again.
            resumed_step_id=state.current_step_id,
        )

        from . import STEP_REGISTRY

        self._configure_limits(definition)
        state.status = RunStatus.RUNNING
        state.save()

        # Resume from the current step — re-execute it so gates
        # can prompt interactively again.
        remaining_steps = definition.steps[state.current_step_index :]
        step_offset = state.current_step_index

        try:
            self._execute_steps(
                remaining_steps,
                context,
                state,
                STEP_REGISTRY,
                step_offset=step_offset,
            )
        except KeyboardInterrupt:
            state.status = RunStatus.PAUSED
            state.append_log({"event": "workflow_interrupted"})
            state.save()
            return state
        except Exception as exc:  # allowlist: deliberate broad-except
            # Workflow resume step boundary (see tests/test_except_hygiene.py) —
            # same rationale as the initial-run boundary above: annotate run
            # state with the failure, then re-raise.
            state.status = RunStatus.FAILED
            state.append_log({"event": "resume_failed", "error": str(exc)})
            state.save()
            raise

        if state.status == RunStatus.RUNNING:
            state.status = RunStatus.COMPLETED
        state.append_log({"event": "workflow_finished", "status": state.status.value})
        state.save()
        return state

    def _execute_steps(
        self,
        steps: list[dict[str, Any]],
        context: StepContext,
        state: RunState,
        registry: dict[str, Any],
        *,
        step_offset: int = 0,
        depth: int = 0,
    ) -> None:
        """Execute a list of steps sequentially."""
        for i, step_config in enumerate(steps):
            # Per-run step budget (F-10): guards against unbounded expansion.
            self._step_count += 1
            if self._step_count > self._step_budget:
                self._fail_limit(
                    state,
                    "max_steps",
                    f"run exceeded the step budget of {self._step_budget} steps",
                )
                return

            # Global index so the id-less fallback and current_step_index stay
            # stable across a resume slice (B17/task-0099).
            global_index = step_offset + i
            step_id = step_config.get("id", f"step-{global_index}")
            step_type = step_config.get("type", "command")

            state.current_step_id = step_id
            state.current_step_index = global_index
            state.save()

            state.append_log({"event": "step_started", "step_id": step_id, "type": step_type})

            # Log progress — use the engine's on_step_start callback if set,
            # otherwise stay silent (library-safe default).
            label = step_config.get("command", "") or step_type
            if self.on_step_start is not None:
                self.on_step_start(step_id, label, step_type)

            step_impl = registry.get(step_type)
            if not step_impl:
                unknown_err = f"Unknown step type: {step_type!r}"
                if self.on_step_complete is not None:
                    self.on_step_complete(step_id, "failed", 0.0, unknown_err, {})
                state.status = RunStatus.FAILED
                state.append_log(
                    {
                        "event": "step_failed",
                        "step_id": step_id,
                        "error": unknown_err,
                    }
                )
                state.save()
                return

            import time as _time

            _step_t0 = _time.monotonic()
            result: StepResult = step_impl.execute(step_config, context)
            _step_elapsed = _time.monotonic() - _step_t0

            # Surface any per-step warnings (e.g. unsafe_shell opt-in, F-04),
            # naming the workflow and step so the operator can locate them.
            for warning in result.output.get("warnings", []) or []:
                message = f"[{state.workflow_id}:{step_id}] {warning}"
                state.append_log({"event": "step_warning", "step_id": step_id, "warning": message})
                if self.on_warning is not None:
                    self.on_warning(message)

            # Record step results — prefer resolved values from step output
            step_data = {
                "integration": result.output.get("integration")
                or step_config.get("integration")
                or context.default_integration,
                "model": result.output.get("model")
                or step_config.get("model")
                or context.default_model,
                "options": result.output.get("options") or step_config.get("options", {}),
                "input": result.output.get("input") or step_config.get("input", {}),
                "output": result.output,
                "status": result.status.value,
            }
            context.steps[step_id] = step_data
            state.step_results[step_id] = step_data

            state.append_log(
                {
                    "event": "step_completed",
                    "step_id": step_id,
                    "status": result.status.value,
                }
            )

            if self.on_step_complete is not None:
                self.on_step_complete(
                    step_id,
                    result.status.value,
                    _step_elapsed,
                    result.error,
                    result.output,
                )

            # Handle gate pauses
            if result.status == StepStatus.PAUSED:
                state.status = RunStatus.PAUSED
                state.save()
                return

            # Handle a command step awaiting a human turn (adr/0047). Same
            # pause/resume mechanics as a gate, but a distinct run status so the
            # user (and CLI) can tell "run the command, then resume" from a
            # review gate.
            if result.status == StepStatus.NEEDS_INPUT:
                state.status = RunStatus.NEEDS_INPUT
                state.save()
                return

            # Handle failures
            if result.status == StepStatus.FAILED:
                # Gate abort (output.aborted) maps to ABORTED status
                if result.output.get("aborted"):
                    state.status = RunStatus.ABORTED
                    state.append_log(
                        {
                            "event": "workflow_aborted",
                            "step_id": step_id,
                        }
                    )
                else:
                    state.status = RunStatus.FAILED
                    state.append_log(
                        {
                            "event": "step_failed",
                            "step_id": step_id,
                            "error": result.error,
                        }
                    )
                state.save()
                return

    def _resolve_inputs(
        self,
        definition: WorkflowDefinition,
        provided: dict[str, Any],
    ) -> dict[str, Any]:
        """Resolve workflow inputs against definitions and provided values."""
        resolved: dict[str, Any] = {}
        for name, input_def in definition.inputs.items():
            if not isinstance(input_def, dict):
                continue
            if name in provided:
                resolved[name] = self._coerce_input(name, provided[name], input_def)
            elif "default" in input_def:
                # Defaults go through the same type-coercion + enum allow-list
                # as provided values — a default outside its enum must not slip
                # through unvalidated.
                resolved[name] = self._coerce_input(name, input_def["default"], input_def)
            elif input_def.get("required", False):
                msg = f"Required input {name!r} not provided."
                raise ValueError(msg)
        return resolved

    @staticmethod
    def _coerce_input(name: str, value: Any, input_def: dict[str, Any]) -> Any:
        """Coerce a provided input value to the declared type."""
        input_type = input_def.get("type", "string")
        enum_values = input_def.get("enum")

        if input_type == "number":
            try:
                value = float(value)
                if value == int(value):
                    value = int(value)
            except (ValueError, TypeError, OverflowError):
                # OverflowError: int(float('inf'))/int(float('-inf')); nan is a
                # ValueError. All are rejected as a non-finite number.
                msg = f"Input {name!r} expected a number, got {value!r}."
                raise ValueError(msg) from None
        elif input_type == "boolean":
            if isinstance(value, str):
                if value.lower() in ("true", "1", "yes"):
                    value = True
                elif value.lower() in ("false", "0", "no"):
                    value = False
                else:
                    msg = f"Input {name!r} expected a boolean, got {value!r}."
                    raise ValueError(msg)

        if enum_values is not None and value not in enum_values:
            msg = f"Input {name!r} value {value!r} not in allowed values: {enum_values}."
            raise ValueError(msg)

        return value

    def list_runs(self) -> list[dict[str, Any]]:
        """List all workflow runs in the project.

        A corrupt run is skipped and reported, not fatal (AC-PH-016). The bare
        ``json.load`` this replaces meant **one** damaged ``state.json`` aborted
        the whole listing, hiding every healthy run — a request that had nothing
        to do with the corrupt file failed because of it. Partial corruption may
        cost partial results; it must not cost all of them.

        "Unreadable" means the same thing here as in ``RunState.load``: bad JSON,
        a non-object top level, **or** a missing ``run_id``. The last one matters
        because callers subscript ``run_data["run_id"]`` to render a row — a
        well-formed JSON object that happens to lack the key would otherwise turn
        a tolerated corruption into a ``KeyError`` one layer up.

        Reports on stderr rather than through ``ui.console``: the ``workflows``
        layer must not import the presentation layer (module-boundary contract),
        the same reason ``WorkflowRegistry._quarantine`` prints directly.
        """
        import sys

        runs_dir = self.project_root / ".fire-phoenix" / "workflows" / "runs"
        if not runs_dir.exists():
            return []

        runs: list[dict[str, Any]] = []
        for run_dir in sorted(runs_dir.iterdir()):
            if not run_dir.is_dir():
                continue
            state_path = run_dir / "state.json"
            if not state_path.exists():
                continue
            try:
                data = _read_json_mapping(state_path)
                if "run_id" not in data:
                    msg = f"{state_path} is missing the required key 'run_id'."
                    raise RunStateError(msg)
            except RunStateError as exc:
                # Silent skipping would be its own failure mode: the user would
                # see a run simply missing from the list with no explanation.
                print(f"Warning: skipping unreadable run {run_dir.name}: {exc}", file=sys.stderr)
                continue
            runs.append(data)
        return runs


class WorkflowAbortError(Exception):
    """Raised when a workflow is aborted (e.g., gate rejection)."""
