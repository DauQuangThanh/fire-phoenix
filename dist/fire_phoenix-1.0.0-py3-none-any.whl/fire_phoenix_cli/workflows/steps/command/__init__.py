"""Command step — dispatches a fire-phoenix command to an integration CLI."""

from __future__ import annotations

import glob as _glob
import os
import shutil
import time
from pathlib import Path
from typing import Any

from fire_phoenix_cli.workflows.base import StepBase, StepContext, StepResult, StepStatus
from fire_phoenix_cli.workflows.expressions import evaluate_expression


class CommandStep(StepBase):
    """Default step type — invokes a fire-phoenix command via the integration CLI.

    The command files (skills, markdown, TOML) are already installed in
    the integration's directory on disk.  This step tells the CLI to
    execute the command by name (e.g. ``/fire-phoenix.intent`` or
    ``/intent``) rather than reading the file contents.

    .. note::

        Run mode (``StepContext.unattended``) decides behaviour (adr/0047):

        * **interactive** (default) — the step does NOT spawn a CLI. It returns
          ``NEEDS_INPUT`` with the ``invocation`` to run; the engine pauses the
          run. On ``resume`` (``context.resumed_step_id`` matches) it verifies
          ``produces`` and completes.
        * **unattended** (``--auto``) — dispatches the command headlessly with
          tool permissions granted; ``output.exit_code`` is captured, and a
          declared ``produces`` is verified before the step completes.
    """

    type_key = "command"

    def execute(self, config: dict[str, Any], context: StepContext) -> StepResult:
        command = config.get("command", "")
        input_data = config.get("input", {})

        # Resolve expressions in input
        resolved_input: dict[str, Any] = {}
        for key, value in input_data.items():
            resolved_input[key] = evaluate_expression(value, context)

        # Resolve integration (step → workflow default → project default)
        integration = config.get("integration") or context.default_integration
        if integration and isinstance(integration, str) and "{{" in integration:
            integration = evaluate_expression(integration, context)

        # Resolve model
        model = config.get("model") or context.default_model
        if model and isinstance(model, str) and "{{" in model:
            model = evaluate_expression(model, context)

        # Merge options (workflow defaults ← step overrides)
        options = dict(context.default_options)
        step_options = config.get("options", {})
        if step_options:
            options.update(step_options)

        # Attempt CLI dispatch. When the caller has disabled streaming
        # (e.g. the CLI is showing a progress spinner), capture output so
        # nothing writes to the terminal mid-spinner; the captured
        # stdout/stderr are returned in ``output`` for later rendering.
        args_str = str(resolved_input.get("args", ""))
        timeout = config.get("timeout", 600)
        stream = getattr(context, "stream", True)
        unattended = getattr(context, "unattended", False)
        produces = config.get("produces")

        base_output: dict[str, Any] = {
            "command": command,
            "integration": integration,
            "model": model,
            "options": options,
            "input": resolved_input,
        }

        # Interactive (default, adr/0047): do NOT spawn a nested agent CLI —
        # that would strand the run until the user quit the whole CLI. Instead
        # emit the command for the user to run in their own attached session and
        # pause the run as NEEDS_INPUT; on resume, verify `produces` and
        # complete. Only --auto/unattended dispatches headlessly (adr/0046).
        if not unattended:
            return self._interactive_step(config, context, base_output, produces, args_str)

        dispatch_start = time.time()
        dispatch_result = self._try_dispatch(
            command,
            integration,
            model,
            args_str,
            context,
            timeout=timeout,
            stream=stream,
            unattended=unattended,
        )

        output: dict[str, Any] = dict(base_output)

        if dispatch_result is not None:
            output["exit_code"] = dispatch_result["exit_code"]
            output["stdout"] = dispatch_result["stdout"]
            output["stderr"] = dispatch_result["stderr"]
            output["dispatched"] = True
            if dispatch_result["exit_code"] != 0:
                return StepResult(
                    status=StepStatus.FAILED,
                    output=output,
                    error=dispatch_result["stderr"]
                    or f"Command exited with code {dispatch_result['exit_code']}",
                )
            # Output safety net: a zero exit code is not proof the step did its
            # work (e.g. a headless agent blocked on a permission prompt exits 0
            # after only printing text). When the step declares `produces`,
            # require that a matching artefact was actually created/modified.
            if produces:
                missing = self._verify_produces(produces, context, dispatch_start)
                if missing is not None:
                    output["produced"] = False
                    return StepResult(status=StepStatus.FAILED, output=output, error=missing)
                output["produced"] = True
            return StepResult(
                status=StepStatus.COMPLETED,
                output=output,
            )
        else:
            output["exit_code"] = 1
            output["dispatched"] = False
            return StepResult(
                status=StepStatus.FAILED,
                output=output,
                error=(
                    f"Cannot dispatch command {command!r}: "
                    f"integration {integration!r} CLI not found or not installed. "
                    f"Install the CLI tool or check 'fire-phoenix integration list'."
                ),
            )

    def _interactive_step(
        self,
        config: dict[str, Any],
        context: StepContext,
        base_output: dict[str, Any],
        produces: Any,
        args_str: str,
    ) -> StepResult:
        """Interactive ``command`` step (adr/0047).

        First encounter → emit the command for the user to run in their own
        agent session and return ``NEEDS_INPUT`` (the engine pauses the run).
        Resume re-entry (``context.resumed_step_id`` matches this step) → the
        user has run it, so verify ``produces`` and complete (or FAIL loudly if
        a declared artefact is still missing).
        """
        step_id = config.get("id")
        invocation = self._invocation_hint(
            base_output.get("command", ""), base_output.get("integration"), args_str, context
        )
        output = dict(base_output)
        output["invocation"] = invocation

        resumed = step_id is not None and getattr(context, "resumed_step_id", None) == step_id
        if resumed:
            output["needs_input"] = False
            if produces:
                missing = self._verify_produces(produces, context, None)
                if missing is not None:
                    output["produced"] = False
                    return StepResult(status=StepStatus.FAILED, output=output, error=missing)
                output["produced"] = True
                return StepResult(status=StepStatus.COMPLETED, output=output)
            # No `produces:` declared — there is nothing to verify, so the step
            # completes on the user's word alone. Do NOT report it as a verified
            # success: flag it unverified so the operator sees the run trusted an
            # unchecked manual step (B12/task-0099, adr/0047 safety net).
            output["unverified"] = True
            self._announce_unverified(step_id, context)
            return StepResult(status=StepStatus.COMPLETED, output=output)

        output["needs_input"] = True
        self._announce_needs_input(invocation, produces, context)
        return StepResult(status=StepStatus.NEEDS_INPUT, output=output)

    @staticmethod
    def _invocation_hint(command: str, integration: Any, args: str, context: StepContext) -> str:
        """The exact slash-command the user should run in their agent."""
        prompt: str | None = None
        if integration and isinstance(integration, str):
            try:
                from fire_phoenix_cli.integrations import get_integration

                impl = get_integration(integration)
                if impl is not None:
                    prompt = impl.build_command_invocation(command, args)
            except Exception:
                prompt = None
        if not prompt:
            prompt = f"{command} {args}".strip()
        return prompt

    @staticmethod
    def _announce_needs_input(invocation: str, produces: Any, context: StepContext) -> None:
        """Print the run-this-then-resume guidance. Skipped when the caller
        disabled streaming (a progress spinner owns the terminal; the CLI
        renders the guidance from ``output`` in that case)."""
        if not getattr(context, "stream", True):
            return
        run_id = getattr(context, "run_id", None) or "<run-id>"
        print("\n  ┌─ Input needed ─────────────────────────────")
        print("  │ Run this in your agent, then resume the workflow:")
        print(f"  │   {invocation}")
        if produces:
            exp = produces if isinstance(produces, str) else ", ".join(str(p) for p in produces)
            print(f"  │ (expected output: {exp})")
        print(f"  │ Resume:  fire-phoenix workflow resume {run_id}")
        print("  └────────────────────────────────────────────")

    @staticmethod
    def _announce_unverified(step_id: str | None, context: StepContext) -> None:
        """Warn that a resumed interactive step completed with no output to verify."""
        if not getattr(context, "stream", True):
            return
        print(
            f"\n  ⚠ Step {step_id or '<step>'!r} completed without output verification "
            "(no `produces:` declared) — trusted as done on your word."
        )

    @staticmethod
    def _verify_produces(produces: Any, context: StepContext, since: float | None) -> str | None:
        """Return an error string if no declared artefact was produced, else ``None``.

        *produces* is a path/glob (or list of them), relative to the project
        root unless absolute; ``{{ … }}`` expressions are resolved against the
        context. When *since* is a timestamp, at least one matching file must
        have been created/modified at/after it — *since* is captured just before
        dispatch, so no backward slack is allowed (a prior step's freshly-touched
        artefact must not count, B16/task-0099) — used after a headless dispatch.
        When *since* is ``None``, a
        matching file need only exist — used on interactive resume, where the
        user created it in a separate process (adr/0047).
        """
        root = Path(context.project_root) if context.project_root else Path(".")
        patterns = produces if isinstance(produces, list) else [produces]
        checked: list[str] = []
        for pat in patterns:
            resolved = (
                evaluate_expression(pat, context) if isinstance(pat, str) and "{{" in pat else pat
            )
            resolved = str(resolved)
            checked.append(resolved)
            abspat = resolved if os.path.isabs(resolved) else str(root / resolved)
            for match in _glob.glob(abspat, recursive=True):
                if since is None:
                    return None
                try:
                    if os.path.getmtime(match) >= since:
                        return None
                except OSError:
                    continue
        return (
            f"Step reported success but produced none of its declared outputs "
            f"({', '.join(checked)}). The agent likely could not complete the step — "
            f"in a non-interactive run this usually means it was blocked on a tool "
            f"permission prompt. Re-run with --auto (unattended, permissions granted) "
            f"or run interactively so you can approve tools live."
        )

    @staticmethod
    def _try_dispatch(
        command: str,
        integration_key: str | None,
        model: str | None,
        args: str,
        context: StepContext,
        timeout: int = 600,
        stream: bool = True,
        unattended: bool = False,
    ) -> dict[str, Any] | None:
        """Invoke *command* by name through the integration CLI.

        The integration's ``dispatch_command`` builds the native
        slash-command invocation (e.g. ``/fire-phoenix.intent`` for
        markdown agents, ``/intent`` for skills agents),
        then executes the CLI non-interactively.

        Returns the dispatch result dict, or ``None`` if dispatch is
        not possible (integration not found, CLI not installed, or
        dispatch not supported).
        """
        if not integration_key:
            return None

        try:
            from fire_phoenix_cli.integrations import get_integration
        except ImportError:
            return None

        impl = get_integration(integration_key)
        if impl is None:
            return None

        # Check if the integration supports CLI dispatch
        if impl.build_exec_args("test") is None:
            return None

        # Check if the CLI tool is actually installed
        if not shutil.which(impl.key):
            return None

        project_root = Path(context.project_root) if context.project_root else None

        try:
            return impl.dispatch_command(
                command,
                args=args,
                project_root=project_root,
                model=model,
                timeout=timeout,
                stream=stream,
                unattended=unattended,
            )
        except (NotImplementedError, OSError):
            return None

    def validate(self, config: dict[str, Any]) -> list[str]:
        errors = super().validate(config)
        if "command" not in config:
            errors.append(f"Command step {config.get('id', '?')!r} is missing 'command' field.")
        if "timeout" in config:
            t = config["timeout"]
            if not isinstance(t, int) or t <= 0:
                errors.append(
                    f"Command step {config.get('id', '?')!r}: timeout must be a positive integer, got {t!r}."
                )
        if "produces" in config:
            p = config["produces"]
            if not (
                isinstance(p, str) or (isinstance(p, list) and all(isinstance(x, str) for x in p))
            ):
                errors.append(
                    f"Command step {config.get('id', '?')!r}: produces must be a string or list of strings, got {type(p).__name__}."
                )
        return errors
