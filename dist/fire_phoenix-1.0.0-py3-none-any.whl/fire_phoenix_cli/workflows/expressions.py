"""Expression evaluator for workflow templates.

A small, dependency-free grammar for ``{{ ... }}`` expressions in workflow YAML.
No file I/O, no imports, no arbitrary code execution — literals go through
``ast.literal_eval`` and everything else is a hand-written recursive-descent
parser (improving-pro-plan.md §P2-2, F-17).

Grammar (lowest to highest precedence)::

    expr        := or_expr
    or_expr     := and_expr ("or" and_expr)*
    and_expr    := not_expr ("and" not_expr)*
    not_expr    := "not" not_expr | comparison
    comparison  := filter_expr ( OP filter_expr )?      # OP: == != < > <= >= in "not in"
    filter_expr := primary ( "|" filter )*
    filter      := NAME ( "(" args? ")" )?              # default | join | contains | map
    primary     := literal | path | "(" expr ")"
    path        := NAME ( "." NAME | "[" INT "]" )*
    literal     := NUMBER | STRING | true|false|none|null | "[" list "]"

Design decisions (F-17):

- **Precedence and parentheses are explicit** — no more substring/`split()`
  heuristics that misfired on values containing ``" in "`` or quoted commas.
- **``in`` / ``not in`` operate on lists only.** A non-list right operand is a
  parse-time / eval-time error, not a silent ``False``.
- **Parse failures raise** :class:`ExpressionError` with the offending text and
  position. The engine fails the step rather than silently evaluating to false.
"""

from __future__ import annotations

import ast
import re
from collections.abc import Callable
from typing import Any

_EXPR_PATTERN = re.compile(r"\{\{(.+?)\}\}")


class ExpressionError(ValueError):
    """Raised when a workflow expression cannot be parsed or evaluated."""


# -- Custom filters -------------------------------------------------------


def _filter_default(value: Any, default_value: Any = "") -> Any:
    if value is None or value == "":
        return default_value
    return value


def _filter_join(value: Any, separator: str = ", ") -> str:
    if isinstance(value, list):
        return separator.join(str(v) for v in value)
    return str(value)


def _filter_map(value: Any, attr: str) -> list[Any]:
    if not isinstance(value, list):
        return []
    result = []
    for item in value:
        if isinstance(item, dict):
            v: Any = item
            for part in attr.split("."):
                v = v.get(part) if isinstance(v, dict) else None
                if v is None:
                    break
            result.append(v)
        else:
            result.append(item)
    return result


def _filter_contains(value: Any, needle: Any) -> bool:
    if isinstance(value, str | list):
        return needle in value
    return False


_FILTERS: dict[str, Callable[..., Any]] = {
    "default": _filter_default,
    "join": _filter_join,
    "map": _filter_map,
    "contains": _filter_contains,
}


# -- Namespace + path resolution ------------------------------------------


def _build_namespace(context: Any) -> dict[str, Any]:
    ns: dict[str, Any] = {}
    if hasattr(context, "inputs"):
        ns["inputs"] = context.inputs or {}
    if hasattr(context, "steps"):
        ns["steps"] = context.steps or {}
    return ns


def _resolve_dot_path(namespace: dict[str, Any], parts: list[tuple[str, int | None]]) -> Any:
    """Resolve a parsed path (list of (name, index?) segments) against *namespace*.

    A missing key resolves to ``None`` (not an error) — only *syntax* is an error.
    """
    current: Any = namespace
    for name, index in parts:
        if isinstance(current, dict):
            current = current.get(name)
        else:
            return None
        if index is not None:
            if isinstance(current, list) and 0 <= index < len(current):
                current = current[index]
            else:
                return None
        if current is None:
            return None
    return current


# -- Tokenizer ------------------------------------------------------------

_TOKEN_RE = re.compile(
    r"""
      (?P<WS>\s+)
    | (?P<NUMBER>\d+\.\d+|\d+)
    | (?P<STRING>'[^']*'|"[^"]*")
    | (?P<OP>==|!=|>=|<=|>|<|\||\(|\)|\[|\]|,|\.)
    | (?P<NAME>[A-Za-z_][A-Za-z0-9_-]*)
    """,
    re.VERBOSE,
)

_KEYWORDS = {"and", "or", "not", "in", "true", "false", "none", "null"}


class _Tok:
    __slots__ = ("kind", "value", "pos")

    def __init__(self, kind: str, value: str, pos: int) -> None:
        self.kind = kind
        self.value = value
        self.pos = pos


def _tokenize(src: str) -> list[_Tok]:
    tokens: list[_Tok] = []
    i = 0
    while i < len(src):
        m = _TOKEN_RE.match(src, i)
        if not m:
            raise ExpressionError(f"Unexpected character {src[i]!r} at position {i} in {src!r}")
        i = m.end()
        kind = m.lastgroup
        # Every _TOKEN_RE alternative is a named group, so a successful match
        # always sets lastgroup — narrow str | None to str for the callers below.
        assert kind is not None
        if kind == "WS":
            continue
        value = m.group()
        if kind == "NAME" and value.lower() in _KEYWORDS:
            tokens.append(_Tok("KW", value.lower(), m.start()))
        else:
            tokens.append(_Tok(kind, value, m.start()))
    tokens.append(_Tok("EOF", "", len(src)))
    return tokens


# -- Parser + evaluator (recursive descent) -------------------------------


class _Parser:
    def __init__(self, tokens: list[_Tok], src: str, namespace: dict[str, Any]) -> None:
        self.toks = tokens
        self.src = src
        self.ns = namespace
        self.i = 0
        # >0 while parsing a short-circuited (dead) operand of `and`/`or`: tokens
        # are still consumed for a correct parse, but value-level operations
        # (comparisons, filter application) are skipped so the dead operand can
        # never raise. Syntax/authoring errors (unknown filter, bad tokens) still
        # raise. This makes short-circuit truly lazy (task-0151 L7).
        self._suppress = 0

    def _peek(self) -> _Tok:
        return self.toks[self.i]

    def _advance(self) -> _Tok:
        tok = self.toks[self.i]
        self.i += 1
        return tok

    def _error(self, msg: str) -> ExpressionError:
        tok = self._peek()
        return ExpressionError(f"{msg} at position {tok.pos} in {self.src!r}")

    def _expect(self, kind: str, value: str | None = None) -> _Tok:
        tok = self._peek()
        if tok.kind != kind or (value is not None and tok.value != value):
            raise self._error(f"expected {value or kind!r}, found {tok.value or 'end'!r}")
        return self._advance()

    def parse(self) -> Any:
        value = self._or()
        if self._peek().kind != "EOF":
            raise self._error(f"unexpected trailing token {self._peek().value!r}")
        return value

    def _or(self) -> Any:
        # Python `or` semantics: return the first truthy operand as-is (not
        # coerced to bool), else the last operand. Short-circuit is lazy — once a
        # truthy operand is found, later operands are parsed (tokens consumed)
        # under suppression so a value error on the dead branch never raises
        # (task-0151 L7). The common fallback idiom ``{{ x or 'default' }}``
        # yields ``x`` or ``'default'`` rather than the string ``'True'``.
        value = self._and()
        while self._peek().kind == "KW" and self._peek().value == "or":
            self._advance()
            dead = bool(value)  # left already truthy → right is short-circuited
            if dead:
                self._suppress += 1
                try:
                    self._and()
                finally:
                    self._suppress -= 1
            else:
                right = self._and()
                if not value:
                    value = right
        return value

    def _and(self) -> Any:
        # Python `and` semantics: return the first falsy operand as-is, else the
        # last operand. Short-circuit is lazy — once a falsy operand is found,
        # later operands are parsed under suppression so a filter/comparison on
        # the dead branch never raises (task-0151 L7). This makes the None-guard
        # idiom ``{{ steps.x.output and steps.x.output.field | filter }}`` safe.
        value = self._not()
        while self._peek().kind == "KW" and self._peek().value == "and":
            self._advance()
            dead = not value  # left already falsy → right is short-circuited
            if dead:
                self._suppress += 1
                try:
                    self._not()
                finally:
                    self._suppress -= 1
            else:
                value = self._not()
        return value

    def _not(self) -> Any:
        if self._peek().kind == "KW" and self._peek().value == "not":
            self._advance()
            return not bool(self._not())
        return self._comparison()

    def _comparison(self) -> Any:
        left = self._filter_expr()
        tok = self._peek()
        op: str | None = None
        if tok.kind == "OP" and tok.value in ("==", "!=", ">", "<", ">=", "<="):
            op = tok.value
            self._advance()
        elif tok.kind == "KW" and tok.value == "in":
            op = "in"
            self._advance()
        elif tok.kind == "KW" and tok.value == "not":
            # "not in"
            self._advance()
            self._expect("KW", "in")
            op = "not in"
        if op is None:
            return left
        right = self._filter_expr()
        return self._apply_comparison(op, left, right)

    def _apply_comparison(self, op: str, left: Any, right: Any) -> Any:
        if self._suppress:
            # Dead operand of a short-circuited and/or: tokens already consumed;
            # skip the comparison so a type mismatch can't raise (task-0151 L7).
            return None
        if op in ("==", "!="):
            # Coerce numeric strings on both sides so equality matches the
            # ordering operators (B14/task-0099): CLI `--input` values arrive as
            # strings, so `inputs.count == 3` must not be silently False.
            cl, cr = _coerce_numeric(left), _coerce_numeric(right)
            return cl == cr if op == "==" else cl != cr
        if op in ("in", "not in"):
            if not isinstance(right, list):
                raise ExpressionError(
                    f"'{op}' requires a list on the right-hand side, got "
                    f"{type(right).__name__} in {self.src!r}"
                )
            return (left in right) if op == "in" else (left not in right)
        # Ordering comparisons — coerce numeric strings, else fail cleanly.
        return _compare(op, left, right)

    def _filter_expr(self) -> Any:
        value = self._primary()
        while self._peek().kind == "OP" and self._peek().value == "|":
            self._advance()
            name_tok = self._expect("NAME")
            fname = name_tok.value
            if fname not in _FILTERS:
                raise ExpressionError(f"unknown filter {fname!r} in {self.src!r}")
            args: list[Any] = []
            if self._peek().kind == "OP" and self._peek().value == "(":
                self._advance()
                if not (self._peek().kind == "OP" and self._peek().value == ")"):
                    args.append(self._or())
                    while self._peek().kind == "OP" and self._peek().value == ",":
                        self._advance()
                        args.append(self._or())
                self._expect("OP", ")")
            if self._suppress:
                # Dead operand of a short-circuited and/or: the filter name was
                # still validated above (authoring errors always surface), but
                # skip APPLYING it so a value mismatch can't raise (task-0151 L7).
                value = None
                continue
            try:
                value = _FILTERS[fname](value, *args)
            except TypeError as exc:
                # A filter called with the wrong arity raises a bare TypeError;
                # surface it as an ExpressionError so the engine fails the step
                # cleanly instead of crashing the run (B15/task-0099).
                raise ExpressionError(
                    f"filter {fname!r} called with wrong arguments in {self.src!r}: {exc}"
                ) from exc
        return value

    def _primary(self) -> Any:
        tok = self._peek()
        if tok.kind == "OP" and tok.value == "(":
            self._advance()
            value = self._or()
            self._expect("OP", ")")
            return value
        if tok.kind == "OP" and tok.value == "[":
            return self._list_literal()
        if tok.kind == "NUMBER":
            self._advance()
            return ast.literal_eval(tok.value)
        if tok.kind == "STRING":
            self._advance()
            return ast.literal_eval(tok.value)
        if tok.kind == "KW" and tok.value in ("true", "false"):
            self._advance()
            return tok.value == "true"
        if tok.kind == "KW" and tok.value in ("none", "null"):
            self._advance()
            return None
        if tok.kind == "NAME":
            return self._path()
        raise self._error(f"unexpected token {tok.value or 'end'!r}")

    def _list_literal(self) -> list[Any]:
        self._expect("OP", "[")
        items: list[Any] = []
        if not (self._peek().kind == "OP" and self._peek().value == "]"):
            items.append(self._or())
            while self._peek().kind == "OP" and self._peek().value == ",":
                self._advance()
                items.append(self._or())
        self._expect("OP", "]")
        return items

    def _path(self) -> Any:
        segments: list[tuple[str, int | None]] = []
        name = self._expect("NAME").value
        index = self._maybe_index()
        segments.append((name, index))
        while self._peek().kind == "OP" and self._peek().value == ".":
            self._advance()
            # A dotted segment name may be a NAME or a keyword-looking word.
            seg = self._peek()
            if seg.kind in ("NAME", "KW"):
                self._advance()
                segments.append((seg.value, self._maybe_index()))
            else:
                raise self._error("expected attribute name after '.'")
        return _resolve_dot_path(self.ns, segments)

    def _maybe_index(self) -> int | None:
        if self._peek().kind == "OP" and self._peek().value == "[":
            self._advance()
            idx_tok = self._expect("NUMBER")
            if "." in idx_tok.value:
                raise self._error("list index must be an integer")
            self._expect("OP", "]")
            return int(idx_tok.value)
        return None


def _coerce_numeric(v: Any) -> Any:
    """Coerce a numeric-looking string to int/float; leave everything else as-is."""
    if isinstance(v, str):
        try:
            return float(v) if "." in v else int(v)
        except ValueError:
            return v
    return v


def _compare(op: str, left: Any, right: Any) -> bool:
    left, right = _coerce_numeric(left), _coerce_numeric(right)
    try:
        if op == ">":
            return left > right
        if op == "<":
            return left < right
        if op == ">=":
            return left >= right
        if op == "<=":
            return left <= right
    except TypeError as exc:
        raise ExpressionError(f"cannot compare {left!r} {op} {right!r}: {exc}") from exc
    return False


def _evaluate_expression_string(expr: str, namespace: dict[str, Any]) -> Any:
    tokens = _tokenize(expr)
    return _Parser(tokens, expr, namespace).parse()


# -- Public API -----------------------------------------------------------


def evaluate_expression(template: str, context: Any) -> Any:
    """Evaluate a template string containing ``{{ ... }}`` expressions.

    A single whole-string expression returns its typed value; a mixed or
    multi-expression template returns an interpolated string. Non-string input
    is returned unchanged.

    Raises :class:`ExpressionError` on a malformed expression — the engine
    fails the step rather than silently treating it as false (F-17).
    """
    if not isinstance(template, str):
        return template

    namespace = _build_namespace(context)

    # A template is a single whole-string expression only when it contains
    # EXACTLY ONE `{{ … }}` match spanning the entire (stripped) string — then
    # its typed value is returned. `fullmatch` was wrong here: its backtracking
    # let `"{{ a }} {{ b }}"` match as one expression whose body held a literal
    # `}}`, crashing the parser (B1/task-0099). `finditer` splits the template
    # the same way the interpolating `sub` below does, so the single-vs-multi
    # decision stays consistent with the substitution.
    stripped = template.strip()
    matches = list(_EXPR_PATTERN.finditer(stripped))
    if len(matches) == 1 and matches[0].span() == (0, len(stripped)):
        return _evaluate_expression_string(matches[0].group(1).strip(), namespace)

    def _replace(m: re.Match[str]) -> str:
        value = _evaluate_expression_string(m.group(1).strip(), namespace)
        return str(value) if value is not None else ""

    return _EXPR_PATTERN.sub(_replace, template)


# NOTE: the branch-condition entry (`evaluate_condition`) was removed with the
# control-flow steps in the stage-5 engine reduction (adr/0049, task-0098). The
# engine is a linear verb executor; this module now only interpolates `{{ }}`
# values for the `command` / `gate` / `prompt` steps. The grammar retains the
# `or`/`and` value-fallback idioms those steps use.
