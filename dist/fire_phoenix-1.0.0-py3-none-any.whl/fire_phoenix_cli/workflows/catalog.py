"""Workflow catalog — discovery and installed-workflow tracking.

Mirrors the extension/preset catalog pattern (offline-only):
- ``WorkflowCatalog`` — read-only view over the single bundled catalog + search.
- ``WorkflowRegistry`` — tracks installed workflows on disk.

The remote-catalog surface (URL stack, per-URL cache, ``workflow catalog
add/list/remove``) was removed per ``adr/0062``.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC
from pathlib import Path
from typing import Any

import yaml

from ..catalog_base import CatalogBase
from ..fsutil import atomic_write_text

# ---------------------------------------------------------------------------
# Errors
# ---------------------------------------------------------------------------


class WorkflowCatalogError(Exception):
    """Base error for workflow catalog operations."""


class WorkflowValidationError(WorkflowCatalogError):
    """Validation error for catalog config or workflow data."""


# ---------------------------------------------------------------------------
# CatalogEntry
# ---------------------------------------------------------------------------


@dataclass
class WorkflowCatalogEntry:
    """Represents a single catalog source in the catalog stack."""

    url: str
    name: str
    priority: int
    install_allowed: bool
    description: str = ""


# ---------------------------------------------------------------------------
# WorkflowRegistry
# ---------------------------------------------------------------------------


class WorkflowRegistry:
    """Manages the registry of installed workflows.

    Tracks installed workflows and their metadata in
    ``.fire-phoenix/workflows/workflow-registry.yml``.
    """

    REGISTRY_FILE = "workflow-registry.yml"
    SCHEMA_VERSION = "1.0"

    def __init__(self, project_root: Path) -> None:
        self.project_root = project_root
        self.workflows_dir = project_root / ".fire-phoenix" / "workflows"
        self.registry_path = self.workflows_dir / self.REGISTRY_FILE
        self.data = self._load()

    def _load(self) -> dict[str, Any]:
        """Load registry from disk or create default.

        A corrupt or non-mapping registry is moved aside to a ``.corrupt``
        sibling and reported before falling back to an empty registry: silently
        resetting discarded every installed-workflow record with no way back
        (AC-PH-008).
        """
        default: dict[str, Any] = {"schema_version": self.SCHEMA_VERSION, "workflows": {}}
        if not self.registry_path.exists():
            return default
        try:
            with open(self.registry_path, encoding="utf-8") as f:
                data = yaml.safe_load(f)
        except (yaml.YAMLError, ValueError):
            self._quarantine("unparseable YAML")
            return default
        except OSError:
            # Unreadable (permissions, transient I/O): do NOT quarantine — the
            # file may be perfectly valid and still needed.
            return default
        if isinstance(data, dict):
            return data
        self._quarantine(f"expected a mapping, found {type(data).__name__}")
        return default

    def _quarantine(self, reason: str) -> None:
        """Move the unusable registry aside so its content stays recoverable.

        Warns on stderr rather than through ``ui.console``: the ``workflows``
        layer must not import the presentation layer (module-boundary contract).
        """
        import sys

        backup = self.registry_path.with_suffix(self.registry_path.suffix + ".corrupt")
        counter = 1
        while backup.exists():
            backup = self.registry_path.with_suffix(
                f"{self.registry_path.suffix}.corrupt.{counter}"
            )
            counter += 1
        try:
            self.registry_path.rename(backup)
        except OSError:
            print(
                f"Warning: workflow registry at {self.registry_path} is unusable "
                f"({reason}) and could not be moved aside.",
                file=sys.stderr,
            )
            return
        print(
            f"Warning: workflow registry was unusable ({reason}); moved to "
            f"{backup.name} and starting from an empty registry. "
            "Re-install any workflows you still need.",
            file=sys.stderr,
        )

    def save(self) -> None:
        """Persist registry to disk atomically.

        A plain ``open(...,'w')`` truncates first, so a crash mid-write
        permanently forgot every installed workflow. atomic_write_text writes a
        sibling temp then atomically replaces, leaving the previous good
        registry intact on interruption.
        """
        self.workflows_dir.mkdir(parents=True, exist_ok=True)
        text = yaml.safe_dump(
            self.data, sort_keys=False, default_flow_style=False, allow_unicode=True
        )
        atomic_write_text(self.registry_path, text)

    def add(self, workflow_id: str, metadata: dict[str, Any]) -> None:
        """Add or update an installed workflow entry."""
        from datetime import datetime

        existing = self.data["workflows"].get(workflow_id, {})
        metadata["installed_at"] = existing.get("installed_at", datetime.now(UTC).isoformat())
        metadata["updated_at"] = datetime.now(UTC).isoformat()
        self.data["workflows"][workflow_id] = metadata
        self.save()

    def remove(self, workflow_id: str) -> bool:
        """Remove an installed workflow entry. Returns True if found."""
        if workflow_id in self.data["workflows"]:
            del self.data["workflows"][workflow_id]
            self.save()
            return True
        return False

    def get(self, workflow_id: str) -> dict[str, Any] | None:
        """Get metadata for an installed workflow."""
        return self.data["workflows"].get(workflow_id)

    def list(self) -> dict[str, dict[str, Any]]:
        """Return all installed workflows."""
        return dict(self.data["workflows"])

    def is_installed(self, workflow_id: str) -> bool:
        """Check if a workflow is installed."""
        return workflow_id in self.data["workflows"]


# ---------------------------------------------------------------------------
# WorkflowCatalog
# ---------------------------------------------------------------------------


class WorkflowCatalog(CatalogBase):
    """Read-only view over the bundled workflow catalog (F-18, offline-only).

    Only the single bundled catalog is used. The remote-catalog surface (URL
    config stack, cache, ``workflow catalog add/list/remove``) was removed per
    ``adr/0062``.
    """

    catalog_kind = "workflows"
    error_class = WorkflowValidationError

    def __init__(self, project_root: Path) -> None:
        self.project_root = project_root
        self.workflows_dir = project_root / ".fire-phoenix" / "workflows"

    def _make_entry(self, **kwargs: Any) -> WorkflowCatalogEntry:
        return WorkflowCatalogEntry(**kwargs)

    def _get_merged_workflows(self, force_refresh: bool = False) -> dict[str, dict[str, Any]]:
        """Merged, annotated workflow dicts keyed by id (delegates to CatalogBase)."""
        return self._merged(force_refresh)

    def get_workflow_info(self, workflow_id: str) -> dict[str, Any] | None:
        """Get details for a specific workflow from the catalog."""
        return self.get_info(workflow_id)
