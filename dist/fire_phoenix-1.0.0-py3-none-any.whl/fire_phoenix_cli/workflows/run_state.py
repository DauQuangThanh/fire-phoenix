"""Workflow run-state persistence — the on-disk record of a single run.

Split out of ``engine.py`` by ``task-0147`` W3: the engine is the *executor*,
this is the *persistence* half, and the two were only together by history. The
split also kept ``engine.py`` under its ``adr/0058`` LOC ceiling without asking
for a higher one.

Everything here is re-exported from ``engine`` so existing imports keep working.
"""

from __future__ import annotations

import json
import re
import uuid
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from ..fsutil import atomic_write_text
from .base import RunStatus

_RUN_ID_RE = re.compile(r"^[a-zA-Z0-9][a-zA-Z0-9_-]*$")


class RunStateError(Exception):
    """A run's persisted state exists but is unusable.

    Distinct from ``FileNotFoundError`` (the run was never created), because
    the two call for different user actions. The message always names the
    offending file — see ``RunState.load``.
    """


def _read_json_mapping(path: Path) -> dict[str, Any]:
    """Read *path* as a JSON object, or raise ``RunStateError`` naming it."""
    try:
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
    except json.JSONDecodeError as exc:
        msg = f"{path} is not valid JSON ({exc}). Delete the run directory to discard it."
        raise RunStateError(msg) from exc
    except OSError as exc:
        msg = f"{path} could not be read: {exc}"
        raise RunStateError(msg) from exc
    if not isinstance(data, dict):
        msg = f"{path} should hold a JSON object, found {type(data).__name__}."
        raise RunStateError(msg)
    return data


def _validate_run_id(run_id: str) -> str:
    """Return ``run_id`` if safe, else raise ``ValueError``.

    Must be called on the *raw* argument before it is joined into any path.
    A run_id like ``../../elsewhere`` would otherwise escape the runs
    directory (path traversal) because the earlier regex check ran only
    against the value stored inside the already-loaded state file.
    """
    if not isinstance(run_id, str) or not _RUN_ID_RE.match(run_id):
        msg = f"Invalid run_id {run_id!r}: must be alphanumeric with hyphens/underscores only."
        raise ValueError(msg)
    return run_id


class RunState:
    """Manages workflow run state for persistence and resume."""

    def __init__(
        self,
        run_id: str | None = None,
        workflow_id: str = "",
        project_root: Path | None = None,
    ) -> None:
        self.run_id = run_id or str(uuid.uuid4())[:8]
        _validate_run_id(self.run_id)
        self.workflow_id = workflow_id
        self.project_root = project_root or Path(".")
        self.status = RunStatus.CREATED
        self.current_step_index = 0
        self.current_step_id: str | None = None
        self.step_results: dict[str, dict[str, Any]] = {}
        self.inputs: dict[str, Any] = {}
        self.created_at = datetime.now(UTC).isoformat()
        self.updated_at = self.created_at
        self.log_entries: list[dict[str, Any]] = []

    @property
    def runs_dir(self) -> Path:
        return self.project_root / ".fire-phoenix" / "workflows" / "runs" / self.run_id

    def save(self) -> None:
        """Persist current state to disk."""
        self.updated_at = datetime.now(UTC).isoformat()
        runs_dir = self.runs_dir
        runs_dir.mkdir(parents=True, exist_ok=True)

        state_data = {
            "run_id": self.run_id,
            "workflow_id": self.workflow_id,
            "status": self.status.value,
            "current_step_index": self.current_step_index,
            "current_step_id": self.current_step_id,
            "step_results": self.step_results,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
        }
        # Atomic writes (F-06): an interrupted run must never leave a
        # truncated state.json that resume would choke on.
        atomic_write_text(runs_dir / "state.json", json.dumps(state_data, indent=2))
        atomic_write_text(runs_dir / "inputs.json", json.dumps({"inputs": self.inputs}, indent=2))

    @classmethod
    def load(cls, run_id: str, project_root: Path) -> RunState:
        """Load a run state from disk.

        Raises:
            FileNotFoundError: The run does not exist. Kept distinct from
                corruption — "never created" and "created then damaged" call
                for different user actions.
            RunStateError: ``state.json`` or ``inputs.json`` exists but is
                unusable. The message always names the offending file
                (AC-PH-016): the CLI boundary already prevents a traceback, but
                it can only echo the exception, so ``JSONDecodeError:
                Expecting value: line 1 column 1`` left the user with no idea
                which of possibly many runs to delete.
        """
        _validate_run_id(run_id)
        runs_dir = project_root / ".fire-phoenix" / "workflows" / "runs" / run_id
        state_path = runs_dir / "state.json"
        if not state_path.exists():
            msg = f"Run state not found: {state_path}"
            raise FileNotFoundError(msg)

        state_data = _read_json_mapping(state_path)

        try:
            state = cls(
                run_id=state_data["run_id"],
                workflow_id=state_data["workflow_id"],
                project_root=project_root,
            )
            state.status = RunStatus(state_data["status"])
        except KeyError as exc:
            msg = f"{state_path} is missing the required key {exc.args[0]!r}."
            raise RunStateError(msg) from exc
        except ValueError as exc:
            # RunStatus(...) on an unrecognised value, or _validate_run_id on a
            # tampered id inside an otherwise well-formed file.
            msg = f"{state_path} holds an invalid value: {exc}"
            raise RunStateError(msg) from exc

        state.current_step_index = state_data.get("current_step_index", 0)
        state.current_step_id = state_data.get("current_step_id")
        state.step_results = state_data.get("step_results", {})
        state.created_at = state_data.get("created_at", "")
        state.updated_at = state_data.get("updated_at", "")

        inputs_path = runs_dir / "inputs.json"
        if inputs_path.exists():
            inputs_data = _read_json_mapping(inputs_path)
            state.inputs = inputs_data.get("inputs", {})

        return state

    def append_log(self, entry: dict[str, Any]) -> None:
        """Append a log entry to the run log."""
        entry["timestamp"] = datetime.now(UTC).isoformat()
        self.log_entries.append(entry)

        runs_dir = self.runs_dir
        runs_dir.mkdir(parents=True, exist_ok=True)
        with open(runs_dir / "log.jsonl", "a", encoding="utf-8") as f:
            f.write(json.dumps(entry) + "\n")
