"""Workflow engine for multi-step, resumable automation workflows.

Provides:
- ``StepBase`` — abstract base every step type must implement.
- ``StepContext`` — execution context passed to each step.
- ``StepResult`` — return value from step execution.
- ``STEP_REGISTRY`` — maps ``type_key`` to ``StepBase`` subclass instances.
- ``WorkflowEngine`` — orchestrator that loads, validates, and executes
  workflow YAML definitions.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .base import StepBase

# Maps step type_key → StepBase instance.
STEP_REGISTRY: dict[str, StepBase] = {}


def _register_step(step: StepBase) -> None:
    """Register a step type instance in the global registry.

    Raises ``ValueError`` for falsy keys and ``KeyError`` for duplicates.
    """
    key = step.type_key
    if not key:
        raise ValueError("Cannot register step type with an empty type_key.")
    if key in STEP_REGISTRY:
        raise KeyError(f"Step type with key {key!r} is already registered.")
    STEP_REGISTRY[key] = step


def get_step_type(type_key: str) -> StepBase | None:
    """Return the step type for *type_key*, or ``None`` if not registered."""
    return STEP_REGISTRY.get(type_key)


# -- Register built-in step types ----------------------------------------


def _register_builtin_steps() -> None:
    """Register the built-in step types of the linear verb executor.

    After the stage-5 engine reduction (task-0098) the engine runs a linear
    sequence of verb steps with human gates — no control-flow steps. Only the
    executor steps ship: ``command`` (invoke a skill/command), ``prompt`` (task
    the agent), ``gate`` (pause for approval).
    """
    from .steps.command import CommandStep
    from .steps.gate import GateStep
    from .steps.prompt import PromptStep

    _register_step(CommandStep())
    _register_step(GateStep())
    _register_step(PromptStep())


_register_builtin_steps()
