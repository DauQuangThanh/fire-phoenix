"""Base classes for workflow step types.

Provides:
- ``StepBase`` — abstract base every step type must implement.
- ``StepContext`` — execution context passed to each step.
- ``StepResult`` — return value from step execution.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import StrEnum
from typing import Any


class StepStatus(StrEnum):
    """Status of a step execution."""

    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    SKIPPED = "skipped"
    PAUSED = "paused"
    #: The step needs a human turn before it can complete (adr/0047): an
    #: interactive ``command`` step emits this so the run pauses while the user
    #: runs the command in their own agent session, then resumes.
    NEEDS_INPUT = "needs_input"


class RunStatus(StrEnum):
    """Status of a workflow run."""

    CREATED = "created"
    RUNNING = "running"
    PAUSED = "paused"
    #: Paused awaiting a human turn on an interactive ``command`` step (adr/0047).
    #: Distinct from ``PAUSED`` (a review gate); resumable the same way.
    NEEDS_INPUT = "needs_input"
    COMPLETED = "completed"
    FAILED = "failed"
    ABORTED = "aborted"


@dataclass
class StepContext:
    """Execution context passed to each step.

    Contains everything the step needs to resolve expressions, dispatch
    commands, and record results.
    """

    #: Resolved workflow inputs (from user prompts / defaults).
    inputs: dict[str, Any] = field(default_factory=dict)

    #: Accumulated step results keyed by step ID.
    #: Each entry is ``{"integration": ..., "model": ..., "options": ...,
    #:   "input": ..., "output": ...}``.
    steps: dict[str, dict[str, Any]] = field(default_factory=dict)

    #: Workflow-level default integration key.
    default_integration: str | None = None

    #: Workflow-level default model.
    default_model: str | None = None

    #: Workflow-level default options.
    default_options: dict[str, Any] = field(default_factory=dict)

    #: Project root path.
    project_root: str | None = None

    #: Current run ID.
    run_id: str | None = None

    #: Whether command steps stream their CLI output live to the terminal
    #: (``True``) or capture it for the caller to render afterwards
    #: (``False``). The CLI sets this to ``False`` when showing a progress
    #: spinner, so nothing writes to the terminal while the spinner animates.
    stream: bool = True

    #: Set by the engine on ``resume`` to the id of the step being resumed into
    #: (adr/0047). An interactive ``command`` step compares it to its own id to
    #: tell a fresh encounter (emit ``NEEDS_INPUT`` and pause) from a resume
    #: re-entry (the user has run the command — verify ``produces`` and complete).
    resumed_step_id: str | None = None

    #: Run mode for agent (command) steps. ``False`` (default) = *interactive*:
    #: the agent CLI is attached to the terminal so the user approves tools and
    #: answers clarifications live, and the skill runs in
    #: ``FIRE_PHOENIX_AGENT_MODE=interactive``. ``True`` = *unattended* (``--auto``):
    #: the agent runs headless with tool permissions granted and
    #: ``FIRE_PHOENIX_AGENT_MODE=auto`` (proceeds on documented assumptions, no
    #: prompts); the workflow's review gates are the human checkpoints.
    unattended: bool = False


@dataclass
class StepResult:
    """Return value from a step execution."""

    #: Step status.
    status: StepStatus = StepStatus.COMPLETED

    #: Output data (stored as ``steps.<id>.output``).
    output: dict[str, Any] = field(default_factory=dict)

    #: Error message if step failed.
    error: str | None = None


class StepBase(ABC):
    """Abstract base class for workflow step types.

    Every step type — built-in or extension-provided — implements this
    interface and registers in ``STEP_REGISTRY``.
    """

    #: Matches the ``type:`` value in workflow YAML.
    type_key: str = ""

    @abstractmethod
    def execute(self, config: dict[str, Any], context: StepContext) -> StepResult:
        """Execute the step with the given config and context.

        Parameters
        ----------
        config:
            The step configuration from workflow YAML.
        context:
            The execution context with inputs, accumulated step results, etc.

        Returns
        -------
        StepResult with status, output data, and optional nested steps.
        """

    def validate(self, config: dict[str, Any]) -> list[str]:
        """Validate step configuration and return a list of error messages.

        An empty list means the configuration is valid.
        """
        errors: list[str] = []
        if "id" not in config:
            errors.append("Step is missing required 'id' field.")
        return errors

    def can_resume(self, state: dict[str, Any]) -> bool:
        """Return whether this step can be resumed from the given state."""
        return True
