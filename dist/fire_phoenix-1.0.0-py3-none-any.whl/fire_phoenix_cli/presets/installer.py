"""Preset installer — the disk-mutating side of the preset lifecycle.

Owns ``PresetManager`` (install, remove, replay wraps, register skills/commands
across detected AI agents) and ``_substitute_core_template`` (the helper that
expands ``{CORE_TEMPLATE}`` placeholders for ``strategy: wrap`` command
presets).  Read-only catalog/registry queries live in ``catalog.py``; manifest
schema and validation live in ``publisher.py``.
"""

import contextlib
import shutil
import tempfile
from pathlib import Path
from typing import TYPE_CHECKING, Any

import yaml
from packaging.specifiers import InvalidSpecifier, SpecifierSet

from packaging import version as pkg_version

from ..extensions import normalize_priority
from .catalog import PresetRegistry, PresetResolver
from .publisher import (
    PresetCompatibilityError,
    PresetError,
    PresetManifest,
    PresetValidationError,
)

if TYPE_CHECKING:
    from ..skills.render import CommandRegistrar


def _substitute_core_template(
    body: str,
    cmd_name: str,
    project_root: "Path",
    registrar: "CommandRegistrar",
) -> "tuple[str, dict]":
    """Substitute {CORE_TEMPLATE} with the body of the installed core command template.

    Args:
        body: Preset command body (may contain {CORE_TEMPLATE} placeholder).
        cmd_name: Full command name (e.g. "fire-phoenix.git.feature" or "fire-phoenix.intent").
        project_root: Project root path.
        registrar: CommandRegistrar instance for parse_frontmatter.

    Returns:
        A tuple of (body, core_frontmatter) where body has {CORE_TEMPLATE} replaced
        by the core template body and core_frontmatter holds the core template's parsed
        frontmatter (so callers can inherit scripts/agent_scripts from it).  Both are
        unchanged / empty when the placeholder is absent or the core template file does
        not exist.
    """
    if "{CORE_TEMPLATE}" not in body:
        return body, {}

    # Derive the short name (strip "fire-phoenix." prefix) used by core command templates.
    short_name = cmd_name
    if short_name.startswith("fire-phoenix."):
        short_name = short_name[len("fire-phoenix.") :]

    resolver = PresetResolver(project_root)
    # Resolution order for the core template:
    # 1. resolve_core(cmd_name) — covers tier-1 project overrides and tier-3/4
    #    name-based lookup (file named <cmd_name>.md).  Checked first so that a
    #    local override always wins, even for extension commands.
    # 2. resolve_extension_command_via_manifest(cmd_name) — manifest-based tier-3
    #    fallback for extension commands whose file is named differently from the
    #    command name (e.g. fire-phoenix.selftest.extension → commands/selftest.md).
    # 3. resolve_core(short_name) — core template fallback using the unprefixed
    #    name (e.g. specify → templates/commands/specify.md).
    # resolve_core() skips installed presets (tier 2) to prevent accidental nesting
    # where another preset's wrap output is mistaken for the real core.
    core_file = (
        resolver.resolve_core(cmd_name, "command")
        or resolver.resolve_extension_command_via_manifest(cmd_name)
        or resolver.resolve_core(short_name, "command")
    )
    if core_file is None:
        return body, {}

    core_frontmatter, core_body = registrar.parse_frontmatter(core_file.read_text(encoding="utf-8"))
    return body.replace("{CORE_TEMPLATE}", core_body), core_frontmatter


class PresetManager:
    """Manages preset lifecycle: installation, removal, updates."""

    def __init__(self, project_root: Path):
        """Initialize preset manager.

        Args:
            project_root: Path to project root directory
        """
        self.project_root = project_root
        self.presets_dir = project_root / ".fire-phoenix" / "presets"
        self.registry = PresetRegistry(self.presets_dir)

    def check_compatibility(self, manifest: PresetManifest, fire_phoenix_version: str) -> bool:
        """Check if preset is compatible with current fire-phoenix version.

        Args:
            manifest: Preset manifest
            fire_phoenix_version: Current fire-phoenix version

        Returns:
            True if compatible

        Raises:
            PresetCompatibilityError: If pack is incompatible
        """
        required = manifest.requires_fire_phoenix_version
        current = pkg_version.Version(fire_phoenix_version)

        if not isinstance(required, str) or not required.strip():
            raise PresetCompatibilityError(
                f"Preset has an invalid requires.fire_phoenix_version: {required!r}"
            )

        try:
            specifier = SpecifierSet(required)
            if current not in specifier:
                raise PresetCompatibilityError(
                    f"Preset requires fire-phoenix {required}, "
                    f"but {fire_phoenix_version} is installed.\n"
                    f"Upgrade fire-phoenix with: uv tool install fire-phoenix --force"
                )
        except InvalidSpecifier:
            raise PresetCompatibilityError(f"Invalid version specifier: {required}")  # noqa: B904

        return True

    def _register_commands(
        self, manifest: PresetManifest, preset_dir: Path
    ) -> dict[str, list[str]]:
        """Register preset command overrides with all detected AI agents.

        Scans the preset's templates for type "command", reads each command
        file, and writes it to every detected agent directory using the
        CommandRegistrar from the agents module.

        Args:
            manifest: Preset manifest
            preset_dir: Installed preset directory

        Returns:
            Dictionary mapping agent names to lists of registered command names
        """
        command_templates = [t for t in manifest.templates if t.get("type") == "command"]
        if not command_templates:
            return {}

        # Filter out extension command overrides if the extension isn't installed.
        # Command names follow the pattern: fire-phoenix.<ext-id>.<cmd-name>
        # Core commands (e.g. fire-phoenix.intent) have only one dot — always register.
        extensions_dir = self.project_root / ".fire-phoenix" / "extensions"
        filtered = []
        for cmd in command_templates:
            parts = cmd["name"].split(".")
            if len(parts) >= 3 and parts[0] == "fire-phoenix":
                ext_id = parts[1]
                if not (extensions_dir / ext_id).is_dir():
                    continue
            filtered.append(cmd)

        if not filtered:
            return {}

        try:
            from ..skills.render import CommandRegistrar
        except ImportError:
            return {}

        registrar = CommandRegistrar()
        return registrar.register_commands_for_all_agents(
            filtered, manifest.id, preset_dir, self.project_root
        )

    def _unregister_commands(self, registered_commands: dict[str, list[str]]) -> None:
        """Remove previously registered command files from agent directories.

        Args:
            registered_commands: Dict mapping agent names to command name lists
        """
        try:
            from ..skills.render import CommandRegistrar
        except ImportError:
            return

        registrar = CommandRegistrar()
        registrar.unregister_commands(registered_commands, self.project_root)

    def _replay_wraps_for_command(self, cmd_name: str) -> None:
        """Recompose and rewrite agent files for a wrap-strategy command.

        Collects all installed presets that declare cmd_name in their
        wrap_commands registry field, sorts them so the highest-precedence
        preset (lowest priority number) wraps outermost, then writes the
        fully composed output to every agent directory.

        Called after every install and remove to keep agent files correct
        regardless of installation order.

        Args:
            cmd_name: Full command name (e.g. "fire-phoenix.intent")
        """
        try:
            from ..skills.render import CommandRegistrar
        except ImportError:
            return

        # Collect enabled presets that wrap this command, sorted ascending
        # (lowest priority number = highest precedence = outermost).
        wrap_presets = []
        for pack_id, metadata in self.registry.list_by_priority(include_disabled=False):
            if cmd_name not in metadata.get("wrap_commands", []):
                continue
            pack_dir = self.presets_dir / pack_id
            if not pack_dir.is_dir():
                continue  # corrupted state — skip
            wrap_presets.append((pack_id, pack_dir))

        if not wrap_presets:
            return

        # Derive short name for core resolution fallback.
        short_name = cmd_name
        if short_name.startswith("fire-phoenix."):
            short_name = short_name[len("fire-phoenix.") :]

        resolver = PresetResolver(self.project_root)
        core_file = (
            resolver.resolve_core(cmd_name, "command")
            or resolver.resolve_extension_command_via_manifest(cmd_name)
            or (
                resolver.resolve_extension_command_via_manifest(short_name)
                if short_name != cmd_name
                else None
            )
            or resolver.resolve_core(short_name, "command")
        )
        if core_file is None:
            return

        registrar = CommandRegistrar()
        core_frontmatter, core_body = registrar.parse_frontmatter(
            core_file.read_text(encoding="utf-8")
        )
        replay_aliases: list[str] = []
        seen_aliases: set[str] = set()

        # Apply wraps innermost-first (reverse of ascending list).
        accumulated_body = core_body
        outermost_frontmatter = {}
        outermost_pack_id = wrap_presets[0][0]  # fallback; updated per contributing preset
        for pack_id, pack_dir in reversed(wrap_presets):
            manifest_path = pack_dir / "preset.yml"
            cmd_file: Path | None = None
            if manifest_path.exists():
                try:
                    manifest = PresetManifest(manifest_path)
                except (PresetValidationError, KeyError, TypeError, ValueError):
                    manifest = None
                if manifest is not None:
                    for template in manifest.templates:
                        if template.get("type") != "command" or template.get("name") != cmd_name:
                            continue
                        file_rel = template.get("file")
                        if isinstance(file_rel, str):
                            rel_path = Path(file_rel)
                            if not rel_path.is_absolute():
                                try:
                                    preset_root = pack_dir.resolve()
                                    candidate = (preset_root / rel_path).resolve()
                                    candidate.relative_to(preset_root)
                                except (OSError, ValueError):
                                    candidate = None
                                if candidate is not None:
                                    cmd_file = candidate
                        aliases = template.get("aliases", [])
                        if not isinstance(aliases, list):
                            aliases = []
                        for alias in aliases:
                            if isinstance(alias, str) and alias not in seen_aliases:
                                replay_aliases.append(alias)
                                seen_aliases.add(alias)
                        break
            if cmd_file is None:
                cmd_file = pack_dir / "commands" / f"{cmd_name}.md"
            if not cmd_file.exists():
                continue
            wrap_fm, wrap_body = registrar.parse_frontmatter(cmd_file.read_text(encoding="utf-8"))
            accumulated_body = wrap_body.replace("{CORE_TEMPLATE}", accumulated_body)
            outermost_frontmatter = wrap_fm  # last iteration = outermost preset
            outermost_pack_id = pack_id

        # Build final frontmatter: outermost preset wins; fall back to core for
        # scripts/agent_scripts if the outermost preset does not define them.
        final_frontmatter = dict(outermost_frontmatter)
        final_frontmatter.pop("strategy", None)
        for key in ("scripts", "agent_scripts"):
            if key not in final_frontmatter and key in core_frontmatter:
                final_frontmatter[key] = core_frontmatter[key]

        composed_content = registrar.render_frontmatter(final_frontmatter) + "\n" + accumulated_body

        self._replay_skill_override(cmd_name, composed_content, outermost_pack_id)

        with tempfile.TemporaryDirectory() as tmpdir:
            tmp_path = Path(tmpdir)
            cmd_dir = tmp_path / "commands"
            cmd_dir.mkdir()
            (cmd_dir / f"{cmd_name}.md").write_text(composed_content, encoding="utf-8")
            registrar._ensure_configs()
            for agent_name, agent_config in registrar.AGENT_CONFIGS.items():
                if agent_config.get("extension") == "/SKILL.md":
                    continue
                agent_dir = self.project_root / agent_config["dir"]
                if not agent_dir.exists():
                    continue
                try:
                    registrar.register_commands(
                        agent_name,
                        [
                            {
                                "name": cmd_name,
                                "file": f"commands/{cmd_name}.md",
                                "aliases": replay_aliases,
                            }
                        ],
                        f"preset:{outermost_pack_id}",
                        tmp_path,
                        self.project_root,
                    )
                except ValueError:
                    continue

    def _replay_skill_override(
        self,
        cmd_name: str,
        composed_content: str,
        outermost_pack_id: str,
    ) -> None:
        """Rewrite any active SKILL.md override for a replayed wrap command."""
        skills_dir = self._get_skills_dir()
        if not skills_dir:
            return

        from ..config import SKILL_DESCRIPTIONS, load_init_options
        from ..integrations import get_integration
        from ..skills.render import CommandRegistrar

        init_opts = load_init_options(self.project_root)
        if not isinstance(init_opts, dict):
            init_opts = {}
        selected_ai = init_opts.get("integration")
        if not isinstance(selected_ai, str):
            return

        registrar = CommandRegistrar()
        integration = get_integration(selected_ai)
        agent_config = registrar.AGENT_CONFIGS.get(selected_ai, {})
        create_missing_skills = (
            bool(init_opts.get("ai_skills")) and agent_config.get("extension") != "/SKILL.md"
        )

        raw_short_name = cmd_name
        if raw_short_name.startswith("fire-phoenix."):
            raw_short_name = raw_short_name[len("fire-phoenix.") :]
        # Per ADR-0003, two-segment core commands map to bare skill
        # directories; multi-segment extension commands keep the prefix.
        skill_name = CommandRegistrar.skill_dir_name(cmd_name)
        target_skill_names: list[str] = []
        if (skills_dir / skill_name).is_dir():
            target_skill_names.append(skill_name)
        if not target_skill_names and create_missing_skills:
            missing_skill_dir = skills_dir / skill_name
            if not missing_skill_dir.exists():
                target_skill_names.append(skill_name)
        if not target_skill_names:
            return

        raw_short_name = cmd_name
        if raw_short_name.startswith("fire-phoenix."):
            raw_short_name = raw_short_name[len("fire-phoenix.") :]
        short_name = raw_short_name.replace(".", "-")
        skill_title = self._skill_title_from_command(cmd_name)

        frontmatter, body = registrar.parse_frontmatter(composed_content)
        original_desc = frontmatter.get("description", "")
        enhanced_desc = SKILL_DESCRIPTIONS.get(
            short_name,
            original_desc or f"Spec-kit workflow command: {short_name}",
        )
        body = registrar.resolve_skill_placeholders(
            selected_ai, dict(frontmatter), body, self.project_root
        )

        for target_skill_name in target_skill_names:
            skills_subdir = skills_dir / target_skill_name
            if skills_subdir.exists() and not skills_subdir.is_dir():
                continue
            skills_subdir.mkdir(parents=True, exist_ok=True)
            frontmatter_data = registrar.build_skill_frontmatter(
                selected_ai,
                target_skill_name,
                enhanced_desc,
                f"preset:{outermost_pack_id}",
            )
            frontmatter_text = yaml.safe_dump(
                frontmatter_data, sort_keys=False, allow_unicode=True
            ).strip()
            skill_content = (
                f"---\n{frontmatter_text}\n---\n\n# Speckit {skill_title} Skill\n\n{body}\n"
            )
            if integration is not None and hasattr(integration, "post_process_skill_content"):
                skill_content = integration.post_process_skill_content(skill_content)
            (skills_subdir / "SKILL.md").write_text(skill_content, encoding="utf-8")

    def _get_skills_dir(self) -> Path | None:
        """Return the active skills directory for preset skill overrides.

        Reads ``.fire-phoenix/init-options.yml`` to determine whether skills
        are enabled and which agent was selected, then delegates to
        the module-level ``_get_skills_dir()`` helper for the concrete path.

        Returns:
            The skills directory ``Path``, or ``None`` if skills were not
            enabled.
        """
        from ..config import load_init_options
        from ..installer import _get_skills_dir

        opts = load_init_options(self.project_root)
        if not isinstance(opts, dict):
            opts = {}
        agent = opts.get("integration")
        if not isinstance(agent, str) or not agent:
            return None

        if not bool(opts.get("ai_skills")):
            return None

        skills_dir = _get_skills_dir(self.project_root, agent)
        if not skills_dir.is_dir():
            return None

        return skills_dir

    @staticmethod
    def _skill_title_from_command(cmd_name: str) -> str:
        """Return a human-friendly title for a skill command name."""
        title_name = cmd_name
        if title_name.startswith("fire-phoenix."):
            title_name = title_name[len("fire-phoenix.") :]
        return title_name.replace(".", " ").replace("-", " ").title()

    def _build_extension_skill_restore_index(self) -> dict[str, dict[str, Any]]:
        """Index extension-backed skill restore data by skill directory name."""
        from ..extensions import ExtensionManifest, ValidationError

        resolver = PresetResolver(self.project_root)
        extensions_dir = self.project_root / ".fire-phoenix" / "extensions"
        restore_index: dict[str, dict[str, Any]] = {}

        for _priority, ext_id, _metadata in resolver._get_all_extensions_by_priority():
            ext_dir = extensions_dir / ext_id
            manifest_path = ext_dir / "extension.yml"
            if not manifest_path.is_file():
                continue

            try:
                manifest = ExtensionManifest(manifest_path)
            except (ValidationError, TypeError, AttributeError):
                continue

            ext_root = ext_dir.resolve()
            for cmd_info in manifest.commands:
                cmd_name = cmd_info.get("name")
                cmd_file_rel = cmd_info.get("file")
                if not isinstance(cmd_name, str) or not isinstance(cmd_file_rel, str):
                    continue

                cmd_path = Path(cmd_file_rel)
                if cmd_path.is_absolute():
                    continue

                try:
                    source_file = (ext_root / cmd_path).resolve()
                    source_file.relative_to(ext_root)
                except (OSError, ValueError):
                    continue

                if not source_file.is_file():
                    continue

                restore_info = {
                    "command_name": cmd_name,
                    "source_file": source_file,
                    "source": f"extension:{manifest.id}",
                }
                # Per ADR-0003, two-segment core commands map to bare skill
                # directories; multi-segment extension commands keep the prefix.
                from ..skills.render import CommandRegistrar as _CR

                skill_name = _CR.skill_dir_name(cmd_name)
                restore_index.setdefault(skill_name, restore_info)

        return restore_index

    def _register_skills(
        self,
        manifest: "PresetManifest",
        preset_dir: Path,
    ) -> list[str]:
        """Generate SKILL.md files for preset command overrides.

        For every command template in the preset, checks whether a
        corresponding skill already exists in any detected skills
        directory.  If so, the skill is overwritten with content derived
        from the preset's command file.  This ensures that presets that
        override commands also propagate to the agentskills.io skill
        layer when ``--ai-skills`` was used during project initialisation.

        Args:
            manifest: Preset manifest.
            preset_dir: Installed preset directory.

        Returns:
            List of skill names that were written (for registry storage).
        """
        command_templates = [t for t in manifest.templates if t.get("type") == "command"]
        if not command_templates:
            return []

        # Filter out extension command overrides if the extension isn't installed,
        # matching the same logic used by _register_commands().
        extensions_dir = self.project_root / ".fire-phoenix" / "extensions"
        filtered = []
        for cmd in command_templates:
            parts = cmd["name"].split(".")
            if len(parts) >= 3 and parts[0] == "fire-phoenix":
                ext_id = parts[1]
                if not (extensions_dir / ext_id).is_dir():
                    continue
            filtered.append(cmd)

        if not filtered:
            return []

        skills_dir = self._get_skills_dir()
        if not skills_dir:
            return []

        from ..config import SKILL_DESCRIPTIONS, load_init_options
        from ..integrations import get_integration
        from ..skills.render import CommandRegistrar

        init_opts = load_init_options(self.project_root)
        if not isinstance(init_opts, dict):
            init_opts = {}
        selected_ai = init_opts.get("integration")
        if not isinstance(selected_ai, str):
            return []
        ai_skills_enabled = bool(init_opts.get("ai_skills"))
        registrar = CommandRegistrar()
        integration = get_integration(selected_ai)
        agent_config = registrar.AGENT_CONFIGS.get(selected_ai, {})
        # Native skill agents (e.g. codex, cursor-agent) materialize brand-new
        # preset skills in _register_commands() because their detected agent
        # directory is already the skills directory. This flag is only for
        # command-backed agents that also mirror commands into skills.
        create_missing_skills = ai_skills_enabled and agent_config.get("extension") != "/SKILL.md"

        written: list[str] = []

        for cmd_tmpl in filtered:
            cmd_name = cmd_tmpl["name"]
            cmd_file_rel = cmd_tmpl["file"]
            source_file = preset_dir / cmd_file_rel
            if not source_file.exists():
                continue

            # Derive the short command name (e.g. "specify" from "fire-phoenix.intent")
            raw_short_name = cmd_name
            if raw_short_name.startswith("fire-phoenix."):
                raw_short_name = raw_short_name[len("fire-phoenix.") :]
            short_name = raw_short_name.replace(".", "-")
            # Per ADR-0003, two-segment core commands map to bare skill
            # directories (``intent``); multi-segment extension commands
            # keep the ``fire-phoenix-`` prefix for namespacing.
            skill_name = CommandRegistrar.skill_dir_name(cmd_name)
            skill_title = self._skill_title_from_command(cmd_name)

            # Only overwrite skills that already exist under skills_dir.
            target_skill_names: list[str] = []
            if (skills_dir / skill_name).is_dir():
                target_skill_names.append(skill_name)
            if not target_skill_names and create_missing_skills:
                missing_skill_dir = skills_dir / skill_name
                if not missing_skill_dir.exists():
                    target_skill_names.append(skill_name)
            if not target_skill_names:
                continue

            # Parse the command file
            content = source_file.read_text(encoding="utf-8")
            frontmatter, body = registrar.parse_frontmatter(content)

            if frontmatter.get("strategy") == "wrap":
                body, core_frontmatter = _substitute_core_template(
                    body, cmd_name, self.project_root, registrar
                )
                frontmatter = dict(frontmatter)
                for key in ("scripts", "agent_scripts"):
                    if key not in frontmatter and key in core_frontmatter:
                        frontmatter[key] = core_frontmatter[key]

            original_desc = frontmatter.get("description", "")
            enhanced_desc = SKILL_DESCRIPTIONS.get(
                short_name,
                original_desc or f"Spec-kit workflow command: {short_name}",
            )
            frontmatter = dict(frontmatter)
            frontmatter["description"] = enhanced_desc
            body = registrar.resolve_skill_placeholders(
                selected_ai, frontmatter, body, self.project_root
            )

            for target_skill_name in target_skill_names:
                skills_subdir = skills_dir / target_skill_name
                if skills_subdir.exists() and not skills_subdir.is_dir():
                    continue
                skills_subdir.mkdir(parents=True, exist_ok=True)
                frontmatter_data = registrar.build_skill_frontmatter(
                    selected_ai,
                    target_skill_name,
                    enhanced_desc,
                    f"preset:{manifest.id}",
                )
                frontmatter_text = yaml.safe_dump(
                    frontmatter_data, sort_keys=False, allow_unicode=True
                ).strip()
                skill_content = (
                    f"---\n{frontmatter_text}\n---\n\n# Speckit {skill_title} Skill\n\n{body}\n"
                )
                if integration is not None and hasattr(integration, "post_process_skill_content"):
                    skill_content = integration.post_process_skill_content(skill_content)

                skill_file = skills_subdir / "SKILL.md"
                skill_file.write_text(skill_content, encoding="utf-8")
                written.append(target_skill_name)

        return written

    def _unregister_skills(self, skill_names: list[str], preset_dir: Path) -> None:
        """Restore original SKILL.md files after a preset is removed.

        For each skill that was overridden by the preset, attempts to
        regenerate the skill from the core command template.  If no core
        template exists, the skill directory is removed.

        Args:
            skill_names: List of skill names written by the preset.
            preset_dir: The preset's installed directory (may already be deleted).
        """
        if not skill_names:
            return

        skills_dir = self._get_skills_dir()
        if not skills_dir:
            return

        from ..config import SKILL_DESCRIPTIONS, load_init_options
        from ..integrations import get_integration
        from ..skills.render import CommandRegistrar

        # Locate core command templates from the project's installed templates
        core_templates_dir = self.project_root / ".fire-phoenix" / "templates" / "commands"
        init_opts = load_init_options(self.project_root)
        if not isinstance(init_opts, dict):
            init_opts = {}
        selected_ai = init_opts.get("integration")
        registrar = CommandRegistrar()
        integration = get_integration(selected_ai) if isinstance(selected_ai, str) else None
        extension_restore_index = self._build_extension_skill_restore_index()

        for skill_name in skill_names:
            # Derive command name from skill name (intent -> specify)
            short_name = skill_name
            if short_name.startswith("fire-phoenix-"):
                short_name = short_name[len("fire-phoenix-") :]
            elif short_name.startswith("fire-phoenix."):
                short_name = short_name[len("fire-phoenix.") :]

            skills_subdir = skills_dir / skill_name
            skill_file = skills_subdir / "SKILL.md"
            if not skills_subdir.is_dir():
                continue
            if not skill_file.is_file():
                # Only manage directories that contain the expected skill entrypoint.
                continue

            # Try to find the core command template
            core_file = (
                core_templates_dir / f"{short_name}.md" if core_templates_dir.exists() else None
            )
            if core_file and not core_file.exists():
                core_file = None

            if core_file:
                # Restore from core template
                content = core_file.read_text(encoding="utf-8")
                frontmatter, body = registrar.parse_frontmatter(content)
                if isinstance(selected_ai, str):
                    body = registrar.resolve_skill_placeholders(
                        selected_ai, frontmatter, body, self.project_root
                    )

                original_desc = frontmatter.get("description", "")
                enhanced_desc = SKILL_DESCRIPTIONS.get(
                    short_name,
                    original_desc or f"Spec-kit workflow command: {short_name}",
                )

                frontmatter_data = registrar.build_skill_frontmatter(
                    selected_ai if isinstance(selected_ai, str) else "",
                    skill_name,
                    enhanced_desc,
                    f"agent-skills/{short_name}/{short_name}.md",
                )
                frontmatter_text = yaml.safe_dump(
                    frontmatter_data, sort_keys=False, allow_unicode=True
                ).strip()
                skill_title = self._skill_title_from_command(short_name)
                skill_content = (
                    f"---\n{frontmatter_text}\n---\n\n# Speckit {skill_title} Skill\n\n{body}\n"
                )
                if integration is not None and hasattr(integration, "post_process_skill_content"):
                    skill_content = integration.post_process_skill_content(skill_content)
                skill_file.write_text(skill_content, encoding="utf-8")
                continue

            extension_restore = extension_restore_index.get(skill_name)
            if extension_restore:
                content = extension_restore["source_file"].read_text(encoding="utf-8")
                frontmatter, body = registrar.parse_frontmatter(content)
                if isinstance(selected_ai, str):
                    body = registrar.resolve_skill_placeholders(
                        selected_ai, frontmatter, body, self.project_root
                    )

                command_name = extension_restore["command_name"]
                title_name = self._skill_title_from_command(command_name)

                frontmatter_data = registrar.build_skill_frontmatter(
                    selected_ai if isinstance(selected_ai, str) else "",
                    skill_name,
                    frontmatter.get("description", f"Extension command: {command_name}"),
                    extension_restore["source"],
                )
                frontmatter_text = yaml.safe_dump(
                    frontmatter_data, sort_keys=False, allow_unicode=True
                ).strip()
                skill_content = f"---\n{frontmatter_text}\n---\n\n# {title_name} Skill\n\n{body}\n"
                if integration is not None and hasattr(integration, "post_process_skill_content"):
                    skill_content = integration.post_process_skill_content(skill_content)
                skill_file.write_text(skill_content, encoding="utf-8")
            else:
                # No core or extension template — remove the skill entirely
                shutil.rmtree(skills_subdir)

    def install_from_directory(
        self,
        source_dir: Path,
        fire_phoenix_version: str,
        priority: int = 10,
    ) -> PresetManifest:
        """Install preset from a local directory.

        Args:
            source_dir: Path to preset directory
            fire_phoenix_version: Current fire-phoenix version
            priority: Resolution priority (lower = higher precedence, default 10)

        Returns:
            Installed preset manifest

        Raises:
            PresetValidationError: If manifest is invalid or priority is invalid
            PresetCompatibilityError: If pack is incompatible
        """
        # Validate priority
        if priority < 1:
            raise PresetValidationError("Priority must be a positive integer (1 or higher)")

        manifest_path = source_dir / "preset.yml"
        manifest = PresetManifest(manifest_path)

        self.check_compatibility(manifest, fire_phoenix_version)

        if self.registry.is_installed(manifest.id):
            raise PresetError(
                f"Preset '{manifest.id}' is already installed. "
                f"Use 'fire-phoenix preset remove {manifest.id}' first."
            )

        dest_dir = self.presets_dir / manifest.id
        if dest_dir.exists():
            shutil.rmtree(dest_dir)

        # Roll back a partial install: if any step between the copy and the
        # registry commit fails, unregister whatever was already registered and
        # remove the copied preset, so nothing half-installed is left behind
        # (PRODUCT.md §Failure conditions: no half-installed state).
        registered_commands: dict[str, Any] = {}
        registered_skills: list[Any] = []
        try:
            shutil.copytree(source_dir, dest_dir)

            # Register command overrides with AI agents
            registered_commands = self._register_commands(manifest, dest_dir)

            # Update corresponding skills when --ai-skills was previously used
            registered_skills = self._register_skills(manifest, dest_dir)

            # Detect wrap commands before registry.add() so a read failure doesn't
            # leave a partially-committed registry entry.
            wrap_commands = []
            try:
                from ..skills.render import CommandRegistrar as _CR

                _registrar = _CR()
                for cmd_tmpl in manifest.templates:
                    if cmd_tmpl.get("type") != "command":
                        continue
                    cmd_file = dest_dir / cmd_tmpl["file"]
                    if not cmd_file.exists():
                        continue
                    cmd_fm, _ = _registrar.parse_frontmatter(cmd_file.read_text(encoding="utf-8"))
                    if cmd_fm.get("strategy") == "wrap":
                        wrap_commands.append(cmd_tmpl["name"])
            except ImportError:
                pass

            self.registry.add(
                manifest.id,
                {
                    "version": manifest.version,
                    "source": "local",
                    "manifest_hash": manifest.get_hash(),
                    "enabled": True,
                    "priority": priority,
                    "registered_commands": registered_commands,
                    "registered_skills": registered_skills,
                    "wrap_commands": wrap_commands,
                },
            )
        except Exception:
            # _unregister_skills reads preset files, so it must run before rmtree.
            if registered_skills:
                with contextlib.suppress(Exception):
                    self._unregister_skills(registered_skills, dest_dir)
            if registered_commands:
                with contextlib.suppress(Exception):
                    self._unregister_commands(registered_commands)
            if dest_dir.exists():
                shutil.rmtree(dest_dir, ignore_errors=True)
            raise

        for cmd_name in wrap_commands:
            self._replay_wraps_for_command(cmd_name)

        return manifest

    def install_from_zip(
        self,
        zip_path: Path,
        fire_phoenix_version: str,
        priority: int = 10,
    ) -> PresetManifest:
        """Install preset from ZIP file.

        Args:
            zip_path: Path to preset ZIP file
            fire_phoenix_version: Current fire-phoenix version
            priority: Resolution priority (lower = higher precedence, default 10)

        Returns:
            Installed preset manifest

        Raises:
            PresetValidationError: If manifest is invalid or priority is invalid
            PresetCompatibilityError: If pack is incompatible
        """
        import zipfile

        # Validate priority early
        if priority < 1:
            raise PresetValidationError("Priority must be a positive integer (1 or higher)")

        with tempfile.TemporaryDirectory() as tmpdir:
            temp_path = Path(tmpdir)

            with zipfile.ZipFile(zip_path, "r") as zf:
                temp_path_resolved = temp_path.resolve()
                for member in zf.namelist():
                    member_path = (temp_path / member).resolve()
                    try:
                        member_path.relative_to(temp_path_resolved)
                    except ValueError:
                        raise PresetValidationError(  # noqa: B904
                            f"Unsafe path in ZIP archive: {member} (potential path traversal)"
                        )
                zf.extractall(temp_path)

            pack_dir = temp_path
            manifest_path = pack_dir / "preset.yml"

            if not manifest_path.exists():
                subdirs = [d for d in temp_path.iterdir() if d.is_dir()]
                if len(subdirs) == 1:
                    pack_dir = subdirs[0]
                    manifest_path = pack_dir / "preset.yml"

            if not manifest_path.exists():
                raise PresetValidationError("No preset.yml found in ZIP file")

            return self.install_from_directory(pack_dir, fire_phoenix_version, priority)

    def remove(self, pack_id: str) -> bool:
        """Remove an installed preset.

        Args:
            pack_id: Preset ID

        Returns:
            True if pack was removed
        """
        if not self.registry.is_installed(pack_id):
            return False

        metadata = self.registry.get(pack_id)
        # Restore original skills when preset is removed
        registered_skills = metadata.get("registered_skills", []) if metadata else []
        registered_commands = metadata.get("registered_commands", {}) if metadata else {}
        wrap_commands = metadata.get("wrap_commands", []) if metadata else []
        pack_dir = self.presets_dir / pack_id

        # _unregister_skills must run before directory deletion (reads preset files)
        if registered_skills:
            self._unregister_skills(registered_skills, pack_dir)
            # When _unregister_skills has already handled skill-agent files, strip
            # those entries from registered_commands to avoid double-deletion.
            # (When registered_skills is empty, skill-agent entries in
            # registered_commands are the only deletion path for those files.)
            try:
                from ..skills.render import CommandRegistrar
            except ImportError:
                CommandRegistrar = None  # type: ignore[assignment,misc]
            if CommandRegistrar is not None:
                registered_commands = {
                    agent_name: cmd_names
                    for agent_name, cmd_names in registered_commands.items()
                    if CommandRegistrar.AGENT_CONFIGS.get(agent_name, {}).get("extension")
                    != "/SKILL.md"
                }

        # Delete the preset directory before mutating the registry so a
        # filesystem failure cannot leave files on disk without a registry entry.
        if pack_dir.exists():
            shutil.rmtree(pack_dir)

        # Remove from registry before replaying so _replay_wraps_for_command sees
        # the post-removal registry state.
        self.registry.remove(pack_id)

        # Separate wrap commands from non-wrap commands in registered_commands.
        non_wrap_commands = {
            agent_name: [c for c in cmd_names if c not in wrap_commands]
            for agent_name, cmd_names in registered_commands.items()
        }
        non_wrap_commands = {k: v for k, v in non_wrap_commands.items() if v}

        # Unregister non-wrap command files from AI agents.
        if non_wrap_commands:
            self._unregister_commands(non_wrap_commands)

        # For each wrapped command, either re-compose remaining wraps or delete.
        for cmd_name in wrap_commands:
            # Count only ENABLED wraps — matching _replay_wraps_for_command,
            # which composes from include_disabled=False. Counting disabled
            # presets here (registry.list()) would take the replay branch while
            # replay finds no enabled wraps and returns without rewriting,
            # leaving the removed preset's stale wrap on disk.
            remaining = [
                pid
                for pid, meta in self.registry.list_by_priority(include_disabled=False)
                if cmd_name in meta.get("wrap_commands", [])
            ]
            if remaining:
                self._replay_wraps_for_command(cmd_name)
            else:
                # No wrap presets remain — delete the agent file entirely.
                wrap_agent_commands = {
                    agent_name: [c for c in cmd_names if c == cmd_name]
                    for agent_name, cmd_names in registered_commands.items()
                }
                wrap_agent_commands = {k: v for k, v in wrap_agent_commands.items() if v}
                if wrap_agent_commands:
                    self._unregister_commands(wrap_agent_commands)

        return True

    def list_installed(self) -> list[dict[str, Any]]:
        """List all installed presets with metadata.

        Returns:
            List of preset metadata dictionaries
        """
        result = []

        for pack_id, metadata in self.registry.list().items():
            # Ensure metadata is a dictionary to avoid AttributeError when using .get()
            if not isinstance(metadata, dict):
                metadata = {}
            pack_dir = self.presets_dir / pack_id
            manifest_path = pack_dir / "preset.yml"

            try:
                manifest = PresetManifest(manifest_path)
                result.append(
                    {
                        "id": pack_id,
                        "name": manifest.name,
                        "version": metadata.get("version", manifest.version),
                        "description": manifest.description,
                        "enabled": metadata.get("enabled", True),
                        "installed_at": metadata.get("installed_at"),
                        "template_count": len(manifest.templates),
                        "tags": manifest.tags,
                        "priority": normalize_priority(metadata.get("priority")),
                    }
                )
            except PresetValidationError:
                result.append(
                    {
                        "id": pack_id,
                        "name": pack_id,
                        "version": metadata.get("version", "unknown"),
                        "description": "⚠️ Corrupted preset",
                        "enabled": False,
                        "installed_at": metadata.get("installed_at"),
                        "template_count": 0,
                        "tags": [],
                        "priority": normalize_priority(metadata.get("priority")),
                    }
                )

        return result

    def get_pack(self, pack_id: str) -> PresetManifest | None:
        """Get manifest for an installed preset.

        Args:
            pack_id: Preset ID

        Returns:
            Preset manifest or None if not installed
        """
        if not self.registry.is_installed(pack_id):
            return None

        pack_dir = self.presets_dir / pack_id
        manifest_path = pack_dir / "preset.yml"

        try:
            return PresetManifest(manifest_path)
        except PresetValidationError:
            return None
