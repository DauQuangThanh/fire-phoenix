"""Presets package — facade for catalog/installer/publisher modules.

All historical ``from fire_phoenix_cli.presets import X`` paths keep working
through the star-imports below; the private ``_substitute_core_template``
helper is re-exported explicitly because external callers (``skills/render``,
tests) reach for it by name.
"""

from .catalog import *  # noqa: F401, F403
from .installer import *  # noqa: F401, F403

# Private symbol that external modules and tests import by name.
from .installer import _substitute_core_template  # noqa: F401
from .publisher import *  # noqa: F401, F403
