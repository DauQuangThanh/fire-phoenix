"""Advisory project lock for mutating commands (improving-pro-plan.md §P1-2, F-06).

Pattern: this solves *concurrent or interrupted mutation of ``.fire-phoenix/``
state* in a single-writer CLI, accepting that the guarantee is advisory — it
coordinates fire-phoenix processes with each other, not against arbitrary
external writers.

Interface (contract-first):

    WHEN a mutating command starts, THE CLI SHALL acquire an exclusive lock on
    ``.fire-phoenix/.lock`` and release it on exit.
    WHEN the lock is already held by a live process, THE CLI SHALL fail fast
    with a clear message (no waiting by default).
    WHEN the recorded holder is dead or the lock is older than the stale
    threshold, THE lock SHALL be reclaimed.

Dependency-free by design (no ``filelock``): built on
``os.open(O_CREAT | O_EXCL)``, which is atomic on POSIX and Windows. Adding the
``filelock`` PyPI dependency is the weighed alternative — better cross-platform
coverage at the cost of one more runtime dependency; deferred to preserve the
lean posture (see the decisions.md entry).

Extension point (named, not implemented — §2.5): per-command ``--wait <seconds>``
would surface :class:`ProjectLock`'s existing ``wait`` parameter as a CLI flag.
Today the decorator honors the ``FIRE_PHOENIX_LOCK_WAIT`` environment variable
as the seam where that flag will land.
"""

from __future__ import annotations

import functools
import os
import time
from collections.abc import Callable
from pathlib import Path
from typing import Any

#: A lock older than this (seconds) whose owner cannot be confirmed alive is
#: treated as stale and reclaimed. Guards against a crashed process that never
#: released.
STALE_SECONDS = 3600

#: Re-entrancy registry: resolved lock path -> hold count for THIS process.
#: A guarded command that internally invokes another guarded command (e.g.
#: ``init --integration`` → integration setup) must not deadlock against itself.
_HELD: dict[str, int] = {}


class LockHeldError(RuntimeError):
    """Raised when the project lock is held by another live process."""


def _pid_alive(pid: int) -> bool | None:
    """Liveness of *pid*: ``True`` alive, ``False`` dead, ``None`` unknown.

    ``None`` is a real answer — it means "cannot determine", and the caller
    falls back to the age rule rather than guessing. Previously Windows always
    answered ``True``, so a crashed process blocked every mutating command for a
    full hour (AC-PH-007).
    """
    if pid <= 0:
        return False
    if os.name == "nt":  # pragma: no cover - exercised only on Windows
        return _pid_alive_windows(pid)
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True  # exists but owned by another user
    except OSError:
        return None
    return True


def _pid_alive_windows(pid: int) -> bool | None:  # pragma: no cover - Windows only
    """Windows liveness probe via ``OpenProcess`` + ``GetExitCodeProcess``.

    Returns ``None`` when the probe itself is unavailable, so the caller keeps
    the age-based fallback instead of assuming the holder is alive.
    """
    try:
        import ctypes
        from ctypes import wintypes

        kernel32 = ctypes.windll.kernel32  # type: ignore[attr-defined]
        SYNCHRONIZE = 0x00100000
        PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
        STILL_ACTIVE = 259
        ERROR_INVALID_PARAMETER = 87

        handle = kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION | SYNCHRONIZE, False, pid)
        if not handle:
            # No such process (invalid parameter) => dead. Access denied or any
            # other failure => unknown.
            return False if kernel32.GetLastError() == ERROR_INVALID_PARAMETER else None
        try:
            code = wintypes.DWORD()
            if not kernel32.GetExitCodeProcess(handle, ctypes.byref(code)):
                return None
            return code.value == STILL_ACTIVE
        finally:
            kernel32.CloseHandle(handle)
    except (AttributeError, ImportError, OSError, ValueError):
        # No ctypes/windll on this interpreter, or the call itself failed —
        # "unknown" keeps the age-based fallback (narrow except: AC-MH-006).
        return None


def _pid_start_time(pid: int) -> float | None:
    """Best-effort process start time for *pid*, or ``None`` if unavailable.

    Used to disambiguate PID reuse: a recycled PID passes the liveness probe but
    reports a different start time than the one recorded in the lock
    (AC-PH-007). Only Linux ``/proc`` is read cheaply; other platforms return
    ``None`` and the lock falls back to pid-liveness alone.
    """
    if pid <= 0:
        return None
    try:
        with open(f"/proc/{pid}/stat", encoding="utf-8") as fh:
            content = fh.read()
    except OSError:
        return None
    # Field 22 (1-indexed) is starttime in clock ticks; the executable name in
    # field 2 may contain spaces, so split after its closing parenthesis.
    try:
        tail = content[content.rindex(")") + 1 :].split()
        return float(tail[19])
    except (ValueError, IndexError):
        return None


class ProjectLock:
    """Context manager for an advisory per-project lock."""

    def __init__(
        self,
        project_root: Path | str,
        *,
        wait: float = 0.0,
        poll_interval: float = 0.1,
        stale_seconds: int = STALE_SECONDS,
    ) -> None:
        self.project_root = Path(project_root)
        self.lock_path = self.project_root / ".fire-phoenix" / ".lock"
        self.wait = wait
        self.poll_interval = poll_interval
        self.stale_seconds = stale_seconds
        self._acquired = False
        self._created_dir = False

    # -- acquisition -------------------------------------------------------

    def _try_create(self) -> bool:
        if not self.lock_path.parent.exists():
            self._created_dir = True
        self.lock_path.parent.mkdir(parents=True, exist_ok=True)
        try:
            fd = os.open(self.lock_path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o644)
        except FileExistsError:
            return False
        try:
            # Line 3 (optional) records our process start time so a later holder
            # can detect PID reuse (AC-PH-007). Absent when unavailable.
            start = _pid_start_time(os.getpid())
            payload = f"{os.getpid()}\n{time.time()}\n"
            if start is not None:
                payload += f"{start}\n"
            os.write(fd, payload.encode())
        finally:
            os.close(fd)
        return True

    def _holder(self) -> tuple[int, float]:
        """Return (pid, epoch) recorded in the lock file, or (-1, 0) if unreadable."""
        try:
            lines = self.lock_path.read_text(encoding="utf-8").splitlines()
            return int(lines[0]), float(lines[1])
        except (OSError, ValueError, IndexError):
            return -1, 0.0

    def _holder_start_time(self) -> float | None:
        """Recorded start time of the holder process, if the lock carries one."""
        try:
            lines = self.lock_path.read_text(encoding="utf-8").splitlines()
            return float(lines[2])
        except (OSError, ValueError, IndexError):
            return None

    def _is_stale(self) -> bool:
        pid, _stamp = self._holder()
        # A lock recorded against our own pid that we are not tracking in _HELD
        # is a leftover from an earlier aborted attempt in this process — reclaim.
        if pid == os.getpid():
            return True
        if pid != -1:
            alive = _pid_alive(pid)
            if alive is False:
                return True
            if alive is True:
                # PID reuse check: a recycled PID answers "alive" but its start
                # time disagrees with what the lock recorded.
                recorded_start = self._holder_start_time()
                if recorded_start is not None:
                    current_start = _pid_start_time(pid)
                    if current_start is not None and current_start != recorded_start:
                        return True
                # A confirmed-live holder keeps its lock however old it is. The
                # age rule used to override this, so a legitimate long-running
                # command (e.g. a multi-hour `workflow run`) had its lock stolen
                # and two mutators ran concurrently (AC-PH-007).
                return False
        # Liveness unknown (unreadable pid, or a probe that cannot answer):
        # fall back to the age rule so a foreign/corrupt lock cannot wedge the
        # project permanently.
        try:
            age = time.time() - self.lock_path.stat().st_mtime
        except OSError:
            return False
        return age > self.stale_seconds

    @property
    def _key(self) -> str:
        # Stable, existence-independent identity for the in-process re-entrancy
        # map. Previously this resolved() only when the parent dir existed, so
        # the key computed at acquire() (parent absent — e.g. a bare ``init``
        # that creates ``.fire-phoenix/`` as it locks) differed from the key at
        # release() (parent now present). That left the _HELD entry orphaned
        # (permanently non-zero) and enabled a later re-entrant shortcut that
        # returned "locked" without ever creating a lock file. os.path.abspath
        # is stable regardless of whether the parent exists.
        return os.path.abspath(self.lock_path)

    def acquire(self) -> ProjectLock:
        key = self._key
        if _HELD.get(key, 0) > 0:
            # Re-entrant acquisition within the same process: count and return.
            _HELD[key] += 1
            self._acquired = True
            return self
        deadline = time.monotonic() + self.wait
        while True:
            if self._try_create():
                _HELD[key] = 1
                self._acquired = True
                return self
            if self._is_stale():
                # Atomic steal: rename the stale lock to a unique name before
                # removing it. os.rename is atomic on POSIX, so if two processes
                # both see the lock as stale only ONE wins the rename; the loser
                # gets OSError (source already gone) and retries. The previous
                # check-then-act ``unlink()`` let both processes unlink and then
                # both create — and could delete a fresh lock a third process
                # had just recreated (TOCTOU).
                steal_path = self.lock_path.with_name(
                    f"{self.lock_path.name}.steal.{os.getpid()}.{time.time_ns()}"
                )
                try:
                    os.rename(self.lock_path, steal_path)
                except OSError:
                    # Lost the steal race or already removed — retry the loop.
                    if time.monotonic() >= deadline:
                        pass  # fall through to the deadline error below
                    else:
                        time.sleep(self.poll_interval)
                        continue
                else:
                    try:
                        os.unlink(steal_path)
                    except OSError:
                        pass
                    continue
            if time.monotonic() >= deadline:
                pid, _ = self._holder()
                who = f"process {pid}" if pid > 0 else "another process"
                raise LockHeldError(
                    f"Another fire-phoenix command is running in this project "
                    f"(lock held by {who} at {self.lock_path}). "
                    f"Wait for it to finish, or remove the lock file if it crashed."
                )
            time.sleep(self.poll_interval)

    def _owned_by_us(self) -> bool:
        """True when the on-disk lock still records THIS process as the holder.

        An unreadable lock counts as not ours: better to leave a file behind
        (the age rule reclaims it) than to delete a live holder's lock.
        """
        pid, _ = self._holder()
        return pid == os.getpid()

    def release(self) -> None:
        if not self._acquired:
            return
        key = self._key
        count = _HELD.get(key, 0)
        if count > 1:
            _HELD[key] = count - 1
            self._acquired = False
            return
        _HELD.pop(key, None)
        # Only remove a lock this process owns. After a steal the path may hold
        # ANOTHER process's lock; unlinking it blindly admitted a third mutator
        # (AC-PH-007).
        if self._owned_by_us():
            try:
                self.lock_path.unlink()
            except OSError:
                pass
        # If we created ``.fire-phoenix/`` solely to hold the lock (e.g. a bare
        # ``init <name>`` locking its parent cwd), don't leave an empty dir behind.
        if self._created_dir:
            try:
                self.lock_path.parent.rmdir()
            except OSError:
                pass
        self._acquired = False

    def __enter__(self) -> ProjectLock:
        return self.acquire()

    def __exit__(self, *exc: Any) -> None:
        self.release()


def guarded_mutation(func: Callable[..., Any]) -> Callable[..., Any]:
    """Decorator: hold the project lock for the duration of a mutating command.

    Applied *below* the Typer command decorator so Typer still sees the original
    signature (via ``functools.wraps``). Acquires the lock on ``Path.cwd()`` and
    fails fast with exit code 1 on contention, unless ``FIRE_PHOENIX_LOCK_WAIT``
    (seconds) is set — the seam for a future ``--wait`` flag.
    """

    @functools.wraps(func)
    def wrapper(*args: Any, **kwargs: Any) -> Any:
        cwd = Path.cwd()
        # Only lock inside an existing project. When ``.fire-phoenix/`` is
        # absent there is no state to protect, and creating it here would mask
        # each command's own "not a fire-phoenix project" pre-flight check.
        # (``init`` creates the project and locks its resolved target itself.)
        if not (cwd / ".fire-phoenix").exists():
            return func(*args, **kwargs)
        # A malformed value degrades to "no wait" instead of raising a raw
        # ValueError traceback out of the decorator (AC-PH-011).
        try:
            wait = float(os.environ.get("FIRE_PHOENIX_LOCK_WAIT", "0") or "0")
        except ValueError:
            wait = 0.0
        lock = ProjectLock(cwd, wait=wait)
        try:
            lock.acquire()
        except LockHeldError as exc:
            # Import locally to avoid a hard dependency for non-CLI callers.
            import typer

            from .ui import console

            console.print(f"[red]Error:[/red] {exc}")
            raise typer.Exit(1) from exc
        _surface_install_orphans(cwd)
        try:
            return func(*args, **kwargs)
        finally:
            lock.release()

    return wrapper


def _surface_install_orphans(project_root: Path) -> None:
    """Warn (non-blocking) if a prior install crashed mid-write (F-09).

    Reports orphan files recorded in the install journal but tracked by no
    manifest. Deliberately does NOT auto-delete — the negative constraint
    "never delete user-modified files without confirmation" reserves removal
    for an explicit repair (``journal.repair(remove_orphans=True)``).
    """
    try:
        from .installer.journal import orphans
    except ImportError:
        # Journal support not importable (partial/older install) — skip the
        # non-blocking orphan warning entirely.
        return
    try:
        found = orphans(project_root)
    except OSError:
        # An unreadable journal/manifest on disk. The orphan warning is a
        # best-effort convenience, never a gate, so a read failure degrades to
        # "no warning" instead of aborting the wrapped command.
        return
    if not found:
        return
    from .ui import console

    console.print(
        "[yellow]Warning:[/yellow] a previous install may not have completed. "
        f"{len(found)} orphan file(s) recorded but not in any manifest:"
    )
    for rel in found[:10]:
        console.print(f"  • {rel}")
    console.print("Review these files; they can be removed manually or by a repair pass.")
