"""Install-plan computation: constants, path resolution, asset location.

Owns the "where do things live / which paths get used" half of the
installer — bundled-asset lookup, agent skill-dir resolution, script-type
normalization, and the core constants shared across the installer
subpackage.

No side effects: every function here is a pure read or path computation.
"""

import os
from pathlib import Path
from typing import Any

import typer

from ..ui import console

# Constants
CLAUDE_LOCAL_PATH = Path.home() / ".claude" / "local" / "claude"
CLAUDE_NPM_LOCAL_PATH = Path.home() / ".claude" / "local" / "node_modules" / ".bin" / "claude"
SCRIPT_TYPE_CHOICES = {"sh": "POSIX Shell (bash/zsh)", "ps": "PowerShell"}
INTEGRATION_YAML = ".fire-phoenix/integration.yml"


def _build_agent_config() -> dict[str, dict[str, Any]]:
    """Derive AGENT_CONFIG from INTEGRATION_REGISTRY."""
    from ..integrations import INTEGRATION_REGISTRY

    config: dict[str, dict[str, Any]] = {}
    for key, integration in INTEGRATION_REGISTRY.items():
        if integration.config:
            config[key] = dict(integration.config)
    return config


AGENT_CONFIG = _build_agent_config()


def _locate_core_pack() -> Path | None:
    """Return the filesystem path to the bundled core_pack directory, or None.

    Only present in wheel installs: hatchling's force-include copies
    templates/, scripts/ etc. into fire_phoenix_cli/core_pack/ at build time.

    Source-checkout and editable installs do NOT have this directory.
    Callers that need to work in both environments must check the repo-root
    trees (templates/, scripts/) as a fallback when this returns None.
    """
    # Wheel install: core_pack is a sibling directory of this file
    candidate = Path(__file__).parent.parent / "core_pack"
    if candidate.is_dir():
        return candidate
    return None


def _locate_bundled_extension(extension_id: str) -> Path | None:
    """Return the path to a bundled extension, or None.

    Checks the wheel's ``core_pack/extensions/<id>/`` first, then
    falls back to the source-checkout ``assets/extensions/<id>/`` directory.
    """
    import re as _re

    if not _re.match(r"^[a-z0-9-]+$", extension_id):
        return None

    core = _locate_core_pack()
    if core is not None:
        candidate = core / "extensions" / extension_id
        if (candidate / "extension.yml").is_file():
            return candidate

    # Source-checkout / editable install: look relative to repo root
    repo_root = Path(__file__).parent.parent.parent.parent
    candidate = repo_root / "assets" / "extensions" / extension_id
    if (candidate / "extension.yml").is_file():
        return candidate

    return None


# Single source of truth for the default full-cycle workflow installed by
# ``fire-phoenix init``. Kept as one constant so a rename touches one line
# (the previous 4 hard-coded literals in init_helpers/setup.py drifted when
# the workflow was renamed fire-phoenix → viet-paracel, silently breaking
# init). Deriving from catalog.yml was considered but the catalog ships three
# workflows with no "default" marker, so an explicit constant is clearer.
DEFAULT_BUNDLED_WORKFLOW_ID = "viet-paracel"


def _locate_bundled_workflow(workflow_id: str) -> Path | None:
    """Return the path to a bundled workflow directory, or None.

    Checks the wheel's ``core_pack/workflows/<id>/`` first, then
    falls back to the source-checkout ``assets/workflows/<id>/`` directory.
    """
    import re as _re

    if not _re.match(r"^[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$", workflow_id):
        return None

    core = _locate_core_pack()
    if core is not None:
        candidate = core / "workflows" / workflow_id
        if (candidate / "workflow.yml").is_file():
            return candidate

    # Source-checkout / editable install: look relative to repo root
    repo_root = Path(__file__).parent.parent.parent.parent
    candidate = repo_root / "assets" / "workflows" / workflow_id
    if (candidate / "workflow.yml").is_file():
        return candidate

    return None


def _locate_bundled_preset(preset_id: str) -> Path | None:
    """Return the path to a bundled preset, or None.

    Checks the wheel's ``core_pack/presets/<id>/`` first, then
    falls back to the source-checkout ``assets/presets/<id>/`` directory.
    """
    import re as _re

    if not _re.match(r"^[a-z0-9-]+$", preset_id):
        return None

    core = _locate_core_pack()
    if core is not None:
        candidate = core / "presets" / preset_id
        if (candidate / "preset.yml").is_file():
            return candidate

    # Source-checkout / editable install: look relative to repo root
    repo_root = Path(__file__).parent.parent.parent.parent
    candidate = repo_root / "assets" / "presets" / preset_id
    if (candidate / "preset.yml").is_file():
        return candidate

    return None


def _locate_init_scaffold() -> Path | None:
    """Resolve the bundled greenfield ``assets/init-scaffold/`` directory.

    Checks ``core_pack/init-scaffold/`` first (wheel install) then the
    source-checkout ``assets/init-scaffold/`` directory. Returns the
    path containing the L1-L4 template files (PRODUCT.md / STATUS.md /
    CLAUDE.md / decisions.md) + .gitkeep placeholders for specs/ /
    contracts/ / adr/. Per ``adr/0018``.
    """
    core = _locate_core_pack()
    if core is not None:
        candidate = core / "init-scaffold"
        if candidate.is_dir():
            return candidate
    repo_root = Path(__file__).parent.parent.parent.parent
    candidate = repo_root / "assets" / "init-scaffold"
    return candidate if candidate.is_dir() else None


def _locate_init_scaffold_brownfield() -> Path | None:
    """Resolve the bundled brownfield ``assets/init-scaffold-brownfield/`` directory.

    Mirrors :func:`_locate_init_scaffold` but returns the brownfield
    variant whose templates surface the epistemic OBSERVED / INFERRED /
    UNKNOWN tagging discipline (PRODUCT.md `## Invariants — Recovered
    (INFERRED)` subsection + `### UNKNOWN — needs investigation`;
    STATUS.md `## What was here at init time`; CLAUDE.md `## Brownfield
    context` block; decisions.md `inferred-unconfirmed` Status row).

    Per ``adr/0019`` §A.
    """
    core = _locate_core_pack()
    if core is not None:
        candidate = core / "init-scaffold-brownfield"
        if candidate.is_dir():
            return candidate
    repo_root = Path(__file__).parent.parent.parent.parent
    candidate = repo_root / "assets" / "init-scaffold-brownfield"
    return candidate if candidate.is_dir() else None


def _locate_init_scaffold_migration() -> Path | None:
    """Resolve the bundled migration ``assets/init-scaffold-migration/`` directory.

    Mirrors :func:`_locate_init_scaffold_brownfield` but returns the
    migration variant: brownfield source-archaeology templates PLUS a
    non-waivable parity obligation baked into ``PRODUCT.md`` (``## Parity
    obligation``) and ``STATUS.md`` (``## Open parity obligation``), and a
    migration next-steps recipe in ``CLAUDE.md``.

    Per ``adr/0042`` (migration archetype) — parallels ``adr/0019``.
    """
    core = _locate_core_pack()
    if core is not None:
        candidate = core / "init-scaffold-migration"
        if candidate.is_dir():
            return candidate
    repo_root = Path(__file__).parent.parent.parent.parent
    candidate = repo_root / "assets" / "init-scaffold-migration"
    return candidate if candidate.is_dir() else None


def _locate_custom_agents_source() -> Path | None:
    """Resolve the bundled ``assets/subagents/`` directory.

    Checks ``core_pack/subagents/`` first (wheel install) then the
    source-checkout ``assets/subagents/`` directory.
    """
    core = _locate_core_pack()
    if core is not None:
        candidate = core / "subagents"
        if candidate.is_dir():
            return candidate
    repo_root = Path(__file__).parent.parent.parent.parent
    candidate = repo_root / "assets" / "subagents"
    return candidate if candidate.is_dir() else None


def _locate_hooks_source() -> Path | None:
    """Resolve the bundled ``assets/hooks/`` directory (adr/0040).

    Checks ``core_pack/hooks/`` first (wheel install) then the source-checkout
    ``assets/hooks/`` directory.
    """
    core = _locate_core_pack()
    if core is not None:
        candidate = core / "hooks"
        if candidate.is_dir():
            return candidate
    repo_root = Path(__file__).parent.parent.parent.parent
    candidate = repo_root / "assets" / "hooks"
    return candidate if candidate.is_dir() else None


def _get_skills_dir(project_path: Path, selected_ai: str) -> Path:
    """Resolve the agent-specific skills directory.

    Returns ``project_path / <agent_folder> / "skills"``, falling back
    to ``project_path / ".agents/skills"`` for unknown agents.
    """
    agent_config = AGENT_CONFIG.get(selected_ai, {})
    agent_folder = agent_config.get("folder", "")
    if agent_folder:
        return project_path / agent_folder.rstrip("/") / "skills"
    return project_path / ".agents" / "skills"


def _normalize_script_type(script_type: str, source: str) -> str:
    """Normalize and validate a script type from CLI/config sources."""
    normalized = script_type.strip().lower()
    if normalized in SCRIPT_TYPE_CHOICES:
        return normalized
    console.print(
        f"[red]Error:[/red] Invalid script type {script_type!r} from {source}. "
        f"Expected one of: {', '.join(sorted(SCRIPT_TYPE_CHOICES.keys()))}."
    )
    raise typer.Exit(1)


def _resolve_script_type(project_root: Path, script_type: str | None) -> str:
    """Resolve the script type from the ``--script`` CLI flag, falling
    back to the current platform's default.

    Both ``bash/`` and ``powershell/`` script variants are installed into
    every project by ``fire-phoenix init``, so the choice of variant is made at
    runtime rather than persisted in ``init-options.yml``.
    """
    if script_type:
        return _normalize_script_type(script_type, "--script")
    return "ps" if os.name == "nt" else "sh"


__all__ = [
    "CLAUDE_LOCAL_PATH",
    "CLAUDE_NPM_LOCAL_PATH",
    "SCRIPT_TYPE_CHOICES",
    "INTEGRATION_YAML",
    "AGENT_CONFIG",
    "_build_agent_config",
    "_locate_core_pack",
    "_locate_bundled_extension",
    "_locate_bundled_workflow",
    "DEFAULT_BUNDLED_WORKFLOW_ID",
    "_locate_bundled_preset",
    "_locate_init_scaffold",
    "_locate_init_scaffold_brownfield",
    "_locate_init_scaffold_migration",
    "_locate_custom_agents_source",
    "_get_skills_dir",
    "_normalize_script_type",
    "_resolve_script_type",
]
