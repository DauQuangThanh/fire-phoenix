"""Installer package — facade over plan/render/write/hooks/governance_hooks modules.

Per ADR 0001 §27, the original ``installer.py`` monolith was split into
named modules (``plan``/``render``/``write``/``hooks``); ``governance_hooks``
was added per ``adr/0043`` for the cross-provider guardrail + audit pack. This
package's ``__init__`` re-exports everything the old module exposed, so callers
using ``from fire_phoenix_cli.installer import X`` keep working unchanged.
"""

from .governance_hooks import *  # noqa: F401, F403
from .hooks import *  # noqa: F401, F403
from .plan import *  # noqa: F401, F403
from .render import *  # noqa: F401, F403
from .write import *  # noqa: F401, F403
