"""Cross-provider governance guardrail + audit hook pack (adr/0043, extends adr/0040).

The handbook makes guardrails a first-class *mechanism*
(``handbook/14-governance.md``: "CLAUDE.md (standing) and hook config
(enforced)"), and ``PRODUCT.md`` §Purpose promises the scaffold — *including
governance hooks* — is materialised "regardless of which AI tool the team
uses." ``adr/0040`` shipped the enforced half for Claude only because, at the
time, no other provider had a native hook surface. As of 2026-07-09 every
supported provider does (see ``assets/hooks/MATRIX.md``), so this module
generalises the pack to all of them.

For each installed provider it renders, on by default and merged
non-destructively, a protected-path deny on file-write tools plus a tool-call
audit trail. Script-based providers share one provider-aware
``protect-paths``/``audit-log`` script per platform (the Claude default is
byte-for-byte unchanged); OpenCode, which has no shell hook, gets a declarative
``permission.edit`` deny in ``opencode.json`` plus a Node audit plugin.
"""

from __future__ import annotations

import json
import os
import shutil
from pathlib import Path
from typing import Any

from ..fsutil import atomic_write_text
from ..ui import console
from ..version import get_fire_phoenix_version
from .plan import _locate_hooks_source

_GIT_HOOK_MARKER = "fire-phoenix-managed"
_GIT_HOOKS = ("pre-commit", "post-commit")

_PROTECT_TOKEN = "__FP_PROTECT_CMD__"
_AUDIT_TOKEN = "__FP_AUDIT_CMD__"
_SCRIPT_STEMS = ("protect-paths", "audit-log")

# Per-provider hook wiring. ``template`` is relative to ``assets/hooks/``;
# ``dest`` is relative to the project root; ``arg`` is the provider argument
# passed to protect-paths (``None`` => use the template verbatim, i.e. the
# unchanged adr/0040 Claude pack, whose script defaults to the claude dialect);
# ``folder`` is the provider's config directory (scripts land in
# ``<folder>/hooks/``).
_SCRIPT_HOOK_PROVIDERS: dict[str, dict[str, str | None]] = {
    "claude": {
        "template": "claude/settings.hooks.json",
        "dest": ".claude/settings.json",
        "arg": None,
        "folder": ".claude",
    },
    "copilot": {
        "template": "copilot/hooks.json",
        "dest": ".github/hooks/fire-phoenix.json",
        "arg": "copilot",
        "folder": ".github",
    },
    "cursor-agent": {
        "template": "cursor-agent/hooks.json",
        "dest": ".cursor/hooks.json",
        "arg": "cursor-agent",
        "folder": ".cursor",
    },
    "codex": {
        "template": "codex/hooks.json",
        "dest": ".codex/hooks.json",
        "arg": "codex",
        "folder": ".codex",
    },
}


def _governance_paths(project_path: Path) -> tuple[str, str]:
    """(adr_dir, decisions_file) from context.yml governance (never hardcoded — rule 12)."""
    from ..context import load_context_file

    ctx = load_context_file(project_path)
    gov = ctx.get("governance", {}) or {}
    adr_dir = str(gov.get("adr_dir", "docs/adr")).rstrip("/")
    decisions = str(gov.get("decisions_file", "docs/decisions.md"))
    return adr_dir, decisions


def _governance_prefixes(project_path: Path) -> list[str]:
    """Protected write-tool deny prefixes (adr/0052, supersedes the .fire-phoenix
    line of adr/0043). Under .fire-phoenix/ only the checked-in governance file
    (context.yml) and the tool-call audit trail are hands-off; every other member
    is agent-/CLI-mutable runtime state (adr/0008) and must stay write-allowed."""
    adr_dir, decisions = _governance_paths(project_path)
    return [adr_dir, decisions, ".fire-phoenix/context.yml", ".fire-phoenix/audit"]


def _hook_command(folder: str, stem: str, arg: str | None) -> str:
    """Build the OS-appropriate hook command (parity: bash on posix, pwsh on nt)."""
    base = f"{folder.rstrip('/')}/hooks/{stem}"
    if os.name == "nt":
        cmd = f"powershell -NoProfile -ExecutionPolicy Bypass -File {base}.ps1"
    else:
        cmd = f"bash {base}.sh"
    if arg:
        cmd += f" {arg}"
    return cmd


def _substitute_tokens(obj: Any, mapping: dict[str, str]) -> Any:
    """Recursively replace token string values (e.g. __FP_PROTECT_CMD__)."""
    if isinstance(obj, dict):
        return {k: _substitute_tokens(v, mapping) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_substitute_tokens(v, mapping) for v in obj]
    if isinstance(obj, str):
        return mapping.get(obj, obj)
    return obj


def _copy_scripts(src: Path, hooks_dest: Path, *, force: bool) -> int:
    """Copy the shared bash + PowerShell hook scripts into a provider hooks dir."""
    count = 0
    for sub in ("bash", "powershell"):
        srcdir = src / "scripts" / sub
        if not srcdir.is_dir():
            continue
        for f in sorted(srcdir.iterdir()):
            if not f.is_file():
                continue
            dst = hooks_dest / f.name
            if dst.exists() and not force:
                continue
            shutil.copy2(f, dst)
            if os.name != "nt" and f.suffix == ".sh":
                os.chmod(dst, 0o755)
            count += 1
    return count


def _write_protected_paths(hooks_dest: Path, prefixes: list[str]) -> None:
    conf = hooks_dest / "fire-phoenix-protected-paths.txt"
    lines = [
        "# Fire Phoenix protected governance paths. One prefix per",
        "# line, project-root-relative. Generated at install from",
        "# .fire-phoenix/context.yml governance; re-run init to refresh.",
        *prefixes,
    ]
    conf.write_text("\n".join(lines) + "\n", encoding="utf-8")


def _record(manifest: Any, project_path: Path, path: Path) -> None:
    try:
        manifest.record_existing(path.relative_to(project_path).as_posix())
    except ValueError:
        pass


def _merge_settings_preserving_governance(dest: Path, fp_content: dict[str, Any]) -> Any:
    """Merge *fp_content* into the existing user settings at *dest*.

    Like ``merge_json_files`` (polite: user keys win) EXCEPT that fire-phoenix
    hook entries are APPENDED into any ``hooks.<event>`` array the user already
    has. A plain polite merge preserves the user's list and discards
    fire-phoenix's, silently omitting the governance guardrail for any user who
    already declared that event (task-0144 M5).

    Returns the merged dict, or ``None`` when nothing changed / the file is
    unparseable or not an object (leave it untouched — same contract as
    ``merge_json_files``).
    """
    import copy

    import json5

    try:
        existing = json5.loads(dest.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    if not isinstance(existing, dict):
        return None

    merged = copy.deepcopy(existing)
    for key, val in fp_content.items():
        if key == "hooks" and isinstance(val, dict) and isinstance(merged.get("hooks"), dict):
            hooks = merged["hooks"]
            for event, fp_entries in val.items():
                if not isinstance(fp_entries, list):
                    continue
                arr = hooks.setdefault(event, [])
                if not isinstance(arr, list):
                    continue
                for entry in fp_entries:
                    if entry not in arr:
                        arr.append(entry)
        elif key not in merged:
            merged[key] = val
        # else: user key wins (polite) — do not overwrite.

    return merged if merged != existing else None


def _json_delta(before: Any, after: Any) -> dict[str, Any]:
    """Return only what *after* ADDS relative to *before*.

    The install-time merge is polite (user keys win), so the delta is exactly
    the fire-phoenix contribution. Recording the full fp fragment instead would
    let uninstall strip a user key whose value coincidentally equalled
    fire-phoenix's (AC-PH-001).
    """
    if not isinstance(before, dict) or not isinstance(after, dict):
        return {}
    delta: dict[str, Any] = {}
    for key, new_value in after.items():
        if key not in before:
            delta[key] = new_value
            continue
        old_value = before[key]
        if isinstance(old_value, dict) and isinstance(new_value, dict):
            sub = _json_delta(old_value, new_value)
            if sub:
                delta[key] = sub
        elif isinstance(old_value, list) and isinstance(new_value, list):
            added = [item for item in new_value if item not in old_value]
            if added:
                delta[key] = added
    return delta


def _union_fragments(prior: Any, delta: dict[str, Any]) -> dict[str, Any]:
    """Union a previously recorded fp fragment with a newly added *delta*.

    Keeps the provenance from earlier runs (whose keys are already present on
    disk, so a fresh delta would not see them) without losing new additions.
    """
    if not isinstance(prior, dict):
        return dict(delta)
    result: dict[str, Any] = dict(prior)
    for key, value in delta.items():
        if key not in result:
            result[key] = value
        elif isinstance(result[key], dict) and isinstance(value, dict):
            result[key] = _union_fragments(result[key], value)
        elif isinstance(result[key], list) and isinstance(value, list):
            result[key] = result[key] + [item for item in value if item not in result[key]]
    return result


def _read_json(path: Path) -> Any:
    import json5

    try:
        return json5.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None


def _classify_and_record(
    manifest: Any,
    project_path: Path,
    dest: Path,
    *,
    pre_existing: bool,
    before: Any,
    after: Any,
) -> None:
    """Record *dest* as created-by-fire-phoenix or merged-into-user's-file.

    A file fire-phoenix created on an earlier run stays *created* even though it
    now pre-exists — reclassifying it as merged would leave an empty ``{}``
    behind on uninstall instead of removing it, and makes the manifest differ
    between two runs on a clean state (AC-PH-010).
    """
    try:
        rel_dest = dest.relative_to(project_path).as_posix()
    except ValueError:
        return
    prior_merged = manifest.merged
    fp_created_earlier = rel_dest in manifest.files and rel_dest not in prior_merged
    if not pre_existing or fp_created_earlier:
        _record(manifest, project_path, dest)
        return
    fragment = _union_fragments(prior_merged.get(rel_dest), _json_delta(before, after))
    _record_merged(manifest, project_path, dest, fragment)


def _record_merged(
    manifest: Any, project_path: Path, path: Path, fp_fragment: dict[str, Any]
) -> None:
    """Record a config file fire-phoenix merged into a pre-existing user file,
    so uninstall un-merges the fire-phoenix keys instead of deleting the file
    (PRODUCT.md §Invariants "Never destroy user-authored content")."""
    try:
        manifest.record_merged(path.relative_to(project_path).as_posix(), fp_fragment)
    except ValueError:
        pass


def _load_manifest(key: str, project_path: Path) -> Any:
    from ..integrations.manifest import IntegrationManifest

    try:
        return IntegrationManifest.load(key, project_path)
    except (FileNotFoundError, ValueError):
        return IntegrationManifest(key, project_path, version=get_fire_phoenix_version())


def _install_script_provider(
    project_path: Path, src: Path, key: str, spec: dict[str, str | None], *, force: bool
) -> int:
    manifest = _load_manifest(key, project_path)
    folder = str(spec["folder"])
    hooks_dest = project_path / folder / "hooks"
    hooks_dest.mkdir(parents=True, exist_ok=True)

    written = _copy_scripts(src, hooks_dest, force=force)
    for stem in _SCRIPT_STEMS:
        for ext in (".sh", ".ps1"):
            _record(manifest, project_path, hooks_dest / f"{stem}{ext}")

    _write_protected_paths(hooks_dest, _governance_prefixes(project_path))
    _record(manifest, project_path, hooks_dest / "fire-phoenix-protected-paths.txt")

    tpl = src / str(spec["template"])
    if tpl.is_file():
        content = json.loads(tpl.read_text(encoding="utf-8"))
        arg = spec["arg"]
        if arg is not None:
            mapping = {
                _PROTECT_TOKEN: _hook_command(folder, "protect-paths", arg),
                _AUDIT_TOKEN: _hook_command(folder, "audit-log", None),
            }
            content = _substitute_tokens(content, mapping)
        dest = project_path / str(spec["dest"])
        dest.parent.mkdir(parents=True, exist_ok=True)
        pre_existing = dest.exists()
        before = _read_json(dest) if pre_existing else None
        # Append fire-phoenix hook entries into any hooks arrays the user already
        # has (polite merge alone would drop the guardrail — task-0144 M5).
        merged = _merge_settings_preserving_governance(dest, content) if pre_existing else content
        if merged is not None:
            # Atomic: this rewrites the user's OWN merged settings file; a truncating
            # write_text could corrupt it on an interrupt (B9/task-0101).
            atomic_write_text(dest, json.dumps(merged, indent=2, ensure_ascii=False) + "\n")
        # A pre-existing user file is un-merged on uninstall, never deleted;
        # a file fire-phoenix created is deleted as before.
        _classify_and_record(
            manifest,
            project_path,
            dest,
            pre_existing=pre_existing,
            before=before,
            after=merged if merged is not None else before,
        )

    manifest.save()
    return written


def _install_opencode(project_path: Path, src: Path, *, force: bool) -> int:
    """OpenCode: declarative permission.edit deny (opencode.json) + audit plugin."""
    from .render import merge_json_files

    manifest = _load_manifest("opencode", project_path)
    adr_dir, decisions = _governance_paths(project_path)
    perm = {
        "permission": {
            "edit": {
                "*": "allow",
                f"{adr_dir}/**": "deny",
                decisions: "deny",
                # adr/0052: narrowed from the blanket .fire-phoenix/** to the
                # governance file + audit trail; runtime state stays writable.
                ".fire-phoenix/context.yml": "deny",
                ".fire-phoenix/audit/**": "deny",
            }
        }
    }
    dest = project_path / "opencode.json"
    pre_existing = dest.exists()
    before = _read_json(dest) if pre_existing else None
    merged = merge_json_files(dest, perm) if pre_existing else perm
    if merged is not None:
        # Atomic rewrite of the user's own opencode.json (B9/task-0101).
        atomic_write_text(dest, json.dumps(merged, indent=2, ensure_ascii=False) + "\n")
    # A pre-existing user opencode.json is un-merged on uninstall, never deleted.
    _classify_and_record(
        manifest,
        project_path,
        dest,
        pre_existing=pre_existing,
        before=before,
        after=merged if merged is not None else before,
    )

    written = 0
    plugin_src = src / "opencode" / "plugins" / "fire-phoenix-audit.js"
    if plugin_src.is_file():
        pdir = project_path / ".opencode" / "plugins"
        pdir.mkdir(parents=True, exist_ok=True)
        pdst = pdir / "fire-phoenix-audit.js"
        if not pdst.exists() or force:
            shutil.copy2(plugin_src, pdst)
            written += 1
        _record(manifest, project_path, pdst)

    manifest.save()
    return written


def install_governance_hooks(
    project_path: Path,
    integration_keys: list[str],
    *,
    force: bool = False,
) -> int:
    """Install the guardrail + audit hook pack for every installed provider with
    a native hook surface (adr/0043, extends adr/0040).

    On by default. For each installed provider, renders that provider's native
    protected-path-deny + audit configuration into its canonical config path,
    merged non-destructively. Script-based providers share the provider-aware
    ``protect-paths``/``audit-log`` scripts (copied into ``<folder>/hooks/``;
    the Claude default is byte-for-byte unchanged). OpenCode gets a declarative
    ``permission.edit`` deny in ``opencode.json`` plus a Node audit plugin.

    Returns the number of hook script/plugin files written (0 if the bundled
    ``assets/hooks/`` source is missing or no supported provider is installed).
    """
    src = _locate_hooks_source()
    if src is None:
        return 0
    count = 0
    for key in integration_keys:
        spec = _SCRIPT_HOOK_PROVIDERS.get(key)
        if spec is not None:
            count += _install_script_provider(project_path, src, key, spec, force=force)
        elif key == "opencode":
            count += _install_opencode(project_path, src, force=force)
    return count


def _is_fire_phoenix_git_hook(path: Path) -> bool:
    try:
        return _GIT_HOOK_MARKER in path.read_text(encoding="utf-8")
    except OSError:
        return False


def install_git_hooks(project_path: Path, *, force: bool = False) -> int:
    """Install the provider-agnostic git-hook governance floor (adr/0044).

    Phase B v1 "soft floor": a ``pre-commit`` deny (an existing ADR modified/
    deleted, or a non-append change to the decisions log — additions pass) and a
    ``post-commit`` audit, copied into the project's ``.git/hooks/`` with a
    ``fire-phoenix-git-protected.txt`` sidecar written from ``context.yml``
    governance. POSIX ``sh`` (git runs hooks via ``sh`` on every platform).

    Non-destructive: a pre-existing non-fire-phoenix hook is preserved (the user
    is warned); a fire-phoenix-managed hook (detected by its marker) is
    refreshed. Graceful no-op when the project is not a git repo. Must be called
    AFTER the init auto-commit so the guardrail never blocks init's own commit.

    Returns the number of hook files written.
    """
    git_dir = project_path / ".git"
    if not git_dir.is_dir():
        return 0
    src = _locate_hooks_source()
    if src is None:
        return 0
    git_src = src / "git"
    if not git_src.is_dir():
        return 0

    hooks_dir = git_dir / "hooks"
    hooks_dir.mkdir(parents=True, exist_ok=True)

    adr_dir, decisions = _governance_paths(project_path)
    (hooks_dir / "fire-phoenix-git-protected.txt").write_text(
        f"{adr_dir}\n{decisions}\n", encoding="utf-8"
    )

    written = 0
    for name in _GIT_HOOKS:
        s = git_src / name
        if not s.is_file():
            continue
        d = hooks_dir / name
        if d.exists() and not _is_fire_phoenix_git_hook(d) and not force:
            console.print(
                f"[yellow]Existing '{name}' git hook found — not overwriting. To enable "
                f"the Fire Phoenix governance floor, chain in "
                f"'{git_src.name}/{name}' (see docs/reference/governance-hooks.md).[/yellow]"
            )
            continue
        shutil.copy2(s, d)
        if os.name != "nt":
            os.chmod(d, 0o755)
        written += 1
    return written


__all__ = ["install_governance_hooks", "install_git_hooks"]
