"""Subagent markdown rendering for installation.

``CommandRegistrar`` is the shared registrar that writes command files
(including subagent-target outputs) into agent-specific directories.
Per ADR 0001 §28, shared rendering surface lives in ``skills.render``
(the richer surface) and is re-imported here so subagent callers keep
the ``fire_phoenix_cli.subagents`` import path stable.
"""

from ..skills.render import CommandRegistrar, _build_agent_configs

__all__ = ["CommandRegistrar", "_build_agent_configs"]
