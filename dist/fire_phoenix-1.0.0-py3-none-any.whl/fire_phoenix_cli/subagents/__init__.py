"""Subagent subpackage.

Owns code that consumes ``assets/subagents/*.md`` (custom Claude/AI
subagent definitions): rendering into installed locations (``render``).
Discovery currently lives in ``extensions.py`` / ``presets.py``;
migration into this subpackage will be authored under a dedicated
contract when scheduled.
"""

from .render import CommandRegistrar, _build_agent_configs

__all__ = ["CommandRegistrar", "_build_agent_configs"]
