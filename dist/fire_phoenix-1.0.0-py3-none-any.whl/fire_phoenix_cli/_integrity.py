"""Asset integrity verification for fire-phoenix core_pack bundles.

Verifies bundled assets against pre-computed SHA-256 checksums stored in
``sha256sums.txt``.

Threat model (be precise — see SECURITY.md, F-08):

- **What it protects:** *accidental corruption* — truncated or partial installs,
  a wheel that unpacked incompletely, bit-rot on disk. This is the guarantee, and
  it now runs on every asset-install entrypoint (init, integration, preset,
  extension, and workflow installs), not just init/upgrade.
- **What it does NOT protect:** *tampering*. The ``sha256sums.txt`` file ships
  beside the assets it attests, so an attacker who can modify the assets can
  usually recompute the sums. This is an availability/corruption guard, not a
  tamper-proofing mechanism.
- **Manifest completeness** (``verify_manifest_anchor=True``): the manifest used
  to be its own source of truth, so removing lines removed the files they
  attested — a truncated manifest passed on the lines that survived, and an
  empty one passed outright. Its expected digest and entry count now live in the
  generated ``_integrity_anchor`` module, checked before any asset is hashed.
  That closes the accidental-truncation hole; it is *not* tamper-proofing —
  someone who can rewrite files under ``site-packages`` can rewrite the anchor
  too. What it removes is the ability to defeat the check by editing one data
  file. Completeness is measured against the anchor rather than against the
  disk, so files present but unlisted stay allowed (see
  ``test_verify_asset_integrity_allows_extra_files``).

Tamper-evidence (signing the wheel + ``sha256sums.txt``) belongs at the release
boundary, where an external trust anchor exists — see the sigstore signing step
in ``.github/workflows/release-trigger.yml``.
"""

import hashlib
from pathlib import Path


class AssetCorruptionError(RuntimeError):
    """Raised when a bundled asset fails integrity verification.

    Attributes:
        asset_path: Relative path (within core_pack) of the corrupted file,
                    or 'sha256sums.txt missing' if the checksum file itself is missing.
    """

    def __init__(self, asset_path: str):
        self.asset_path = asset_path
        super().__init__(f"Asset integrity check failed: {asset_path}")


def verify_asset_integrity(core_pack_root: Path, *, verify_manifest_anchor: bool = True) -> None:
    """Verify SHA-256 checksums of all bundled assets.

    Reads sha256sums.txt and computes live hashes for each listed file.
    Files present under ``core_pack_root`` but absent from the manifest are
    allowed — a user's own additions under a scaffold directory must not trip
    the guard.

    Args:
        core_pack_root: Absolute path to the core_pack directory.
        verify_manifest_anchor: Compare the manifest against the generated
            ``_integrity_anchor`` (digest + entry count) before hashing any
            asset, so a truncated or emptied manifest fails instead of passing
            on whatever lines remain. **On by default** — completeness is the
            point, and no production caller should be able to skip it by
            omission. Pass ``False`` only when verifying a core_pack the anchor
            does not describe, i.e. a synthetic tree built by a test that is
            exercising the per-file hashing loop.

    Raises:
        AssetCorruptionError: If any asset hash mismatches, if
                              sha256sums.txt is missing, or if the manifest
                              does not match the anchor when checked.
    """
    sums_file = core_pack_root / "sha256sums.txt"

    # Check that sha256sums.txt exists
    if not sums_file.exists():
        raise AssetCorruptionError("sha256sums.txt missing")

    # Read and parse the checksums file
    try:
        sums_text = sums_file.read_text(encoding="utf-8")
    except Exception as e:
        raise AssetCorruptionError(f"sha256sums.txt (failed to read: {e})") from e

    # Completeness, before any per-file work: the loop below can only attest
    # lines that are present, so a manifest missing lines has to be caught here.
    if verify_manifest_anchor:
        from ._integrity_anchor import ENTRY_COUNT, MANIFEST_SHA256

        actual_digest = hashlib.sha256(sums_text.encode("utf-8")).hexdigest()
        if actual_digest != MANIFEST_SHA256:
            entry_count = len([ln for ln in sums_text.splitlines() if ln.strip()])
            raise AssetCorruptionError(
                f"sha256sums.txt (manifest does not match its anchor: "
                f"{entry_count} entries, expected {ENTRY_COUNT})"
            )

    # Parse each line: <hash>  <relative-path>
    for line_num, line in enumerate(sums_text.splitlines(), start=1):
        line = line.strip()
        if not line:
            # Empty lines are allowed
            continue

        parts = line.split(None, 1)  # Split on whitespace, max 2 parts
        if len(parts) != 2:
            raise AssetCorruptionError(f"sha256sums.txt (malformed line {line_num}: {line!r})")

        expected_hash, rel_path = parts

        # Compute the actual hash of the file
        abs_path = core_pack_root / rel_path
        if not abs_path.exists():
            raise AssetCorruptionError(rel_path)

        try:
            actual_hash = _compute_file_hash(abs_path)
        except Exception as e:
            raise AssetCorruptionError(f"{rel_path} (failed to read: {e})") from e

        # Compare hashes
        if actual_hash != expected_hash:
            raise AssetCorruptionError(rel_path)


def _compute_file_hash(path: Path) -> str:
    """Compute SHA-256 hash of a file, reading in 64KB chunks.

    Args:
        path: Absolute path to the file.

    Returns:
        Hexadecimal digest of the file's SHA-256 hash.
    """
    hasher = hashlib.sha256()
    with open(path, "rb") as f:
        while True:
            chunk = f.read(65536)  # 64 KB chunks
            if not chunk:
                break
            hasher.update(chunk)
    return hasher.hexdigest()
