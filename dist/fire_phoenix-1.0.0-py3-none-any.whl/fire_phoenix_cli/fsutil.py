"""Filesystem safety helpers shared across the installer and state writers.

Two concerns live here, both load-bearing for crash- and concurrency-safety
(improving-pro-plan.md §P1-2, §P1-3):

- :func:`atomic_write_text` / :func:`atomic_write_bytes` — write-to-temp +
  ``os.replace`` so a state file is never observed truncated. An interrupted
  write leaves either the old file or the new file, never a partial one.
- :func:`validate_rel_path` — reject config-derived paths that are absolute or
  escape the project root (directory-traversal guard).

The atomic-write pattern was previously private to ``installer/render.py``;
it is promoted here so ``context.yml``, integration manifests, and workflow
run-state all share one audited implementation.
"""

from __future__ import annotations

import os
import stat
import tempfile
from pathlib import Path


def _preserve_metadata(temp_path: Path, target: Path) -> None:
    """Best-effort copy of mode/owner from an existing target onto the temp file."""
    if not target.exists():
        return
    try:
        existing = target.stat()
        os.chmod(temp_path, stat.S_IMODE(existing.st_mode))
        if hasattr(os, "chown"):
            try:
                os.chown(temp_path, existing.st_uid, existing.st_gid)
            except PermissionError:
                # Owner/group preservation is best-effort without elevated privileges.
                pass
    except OSError:
        # Metadata preservation is best-effort; data safety is what matters.
        pass


def atomic_write_bytes(target: Path | str, data: bytes) -> Path:
    """Atomically write *data* to *target* via a temp file + ``os.replace``.

    The temp file is created in the target's own directory so ``os.replace`` is
    a same-filesystem rename (atomic on POSIX and Windows). On any failure the
    temp file is removed and the original target is left untouched.
    """
    target = Path(target)
    target.parent.mkdir(parents=True, exist_ok=True)
    temp_path: Path | None = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="wb",
            dir=target.parent,
            prefix=f"{target.name}.",
            suffix=".tmp",
            delete=False,
        ) as f:
            temp_path = Path(f.name)
            f.write(data)
            f.flush()
            os.fsync(f.fileno())
        _preserve_metadata(temp_path, target)
        os.replace(temp_path, target)
        return target
    except BaseException:
        if temp_path is not None and temp_path.exists():
            temp_path.unlink()
        raise


def atomic_write_text(target: Path | str, text: str, encoding: str = "utf-8") -> Path:
    """Atomically write *text* to *target*. See :func:`atomic_write_bytes`."""
    return atomic_write_bytes(target, text.encode(encoding))


class PathTraversalError(ValueError):
    """Raised when a config-derived path is absolute or escapes the project root."""


def validate_rel_path(root: Path | str, candidate: str, *, key: str | None = None) -> Path:
    """Return the resolved absolute path of *candidate* under *root*, or raise.

    Rejects absolute paths and any path whose fully resolved form (symlinks
    included) falls outside *root*. Used to validate user-editable
    configuration such as ``paths.*`` and ``governance.*`` (F-07).

    Parameters
    ----------
    root:
        The project root that *candidate* must stay within.
    candidate:
        A relative path taken from configuration or a scaffold name.
    key:
        Optional config key name, included in the error for a clear message.
    """
    label = f" for {key!r}" if key else ""
    if os.path.isabs(candidate):
        raise PathTraversalError(
            f"Absolute paths are not allowed{label}; expected a path relative to the "
            f"project root, got {candidate!r}"
        )
    root_resolved = Path(root).resolve()
    resolved = (root_resolved / candidate).resolve()
    if resolved != root_resolved and root_resolved not in resolved.parents:
        raise PathTraversalError(
            f"Path{label} escapes the project root: {candidate!r} resolves outside {root_resolved}"
        )
    return resolved
