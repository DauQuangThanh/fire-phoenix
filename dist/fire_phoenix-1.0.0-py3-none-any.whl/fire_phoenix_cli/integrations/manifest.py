"""Hash-tracked installation manifest for integrations.

Each installed integration records the files it created together with
their SHA-256 hashes.  On uninstall only files whose hash still matches
the recorded value are removed — modified files are left in place and
reported to the caller.
"""

from __future__ import annotations

import hashlib
import os
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import yaml

from ..fsutil import (
    atomic_write_bytes,
    atomic_write_text,
    validate_rel_path as _shared_validate_rel_path,
)


def _sha256(path: Path) -> str:
    """Return the hex SHA-256 digest of *path*."""
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()


def _deep_unmerge(current: dict[str, Any], fragment: dict[str, Any]) -> dict[str, Any]:
    """Return *current* with the fire-phoenix *fragment* keys stripped back out.

    The install-time merge is *polite* (:func:`installer.render.merge_json_files`):
    it only ever ADDS keys the user did not already have. The inverse therefore
    removes a key only when the user has not changed it since — i.e. the leaf
    value still equals what fire-phoenix put there. A value the user edited is
    always preserved, so this can never delete user-authored content.
    """
    result: dict[str, Any] = {}
    for key, value in current.items():
        if key not in fragment:
            result[key] = value
            continue
        frag_value = fragment[key]
        if isinstance(value, dict) and isinstance(frag_value, dict):
            sub = _deep_unmerge(value, frag_value)
            if sub:
                result[key] = sub
            # sub empty → fire-phoenix fully owned this subtree; drop the key.
        elif isinstance(value, list) and isinstance(frag_value, list):
            # Remove exactly the fire-phoenix entries appended to this list
            # (e.g. hooks arrays fire-phoenix merged into), keeping the user's.
            remainder = [item for item in value if item not in frag_value]
            if remainder:
                result[key] = remainder
            # remainder empty → fire-phoenix owned the whole list; drop the key.
        elif value == frag_value:
            # User hasn't touched the fire-phoenix value → strip it.
            pass
        else:
            # User changed it → keep it.
            result[key] = value
    return result


def _validate_rel_path(rel: Path, root: Path) -> Path:
    """Resolve *rel* against *root* and verify it stays within *root*.

    Thin wrapper over the shared :func:`fsutil.validate_rel_path` (F-07) so the
    manifest and the config loader share one audited traversal guard. Raises
    ``ValueError`` (``PathTraversalError``) if *rel* is absolute or escapes root.
    """
    return _shared_validate_rel_path(root, str(rel))


class IntegrationManifest:
    """Tracks files installed by a single integration.

    Parameters:
        key:          Integration identifier (e.g. ``"claude"``).
        project_root: Absolute path to the project directory.
        version:      CLI version string recorded in the manifest.
    """

    def __init__(
        self,
        key: str,
        project_root: Path,
        version: str = "",
        *,
        journal: Any | None = None,
    ) -> None:
        self.key = key
        self.project_root = project_root.resolve()
        self.version = version
        # Optional write-ahead journal (``installer.journal.InstallJournal``).
        # When a caller owns one — ``init`` does — every file this manifest
        # CREATES is journaled before/with the write, so a crash before
        # :meth:`save` still leaves a recoverable trail (AC-PH-006). Only new
        # files are journaled: rollback must never remove a pre-existing one.
        self._journal = journal
        self._files: dict[str, str] = {}  # rel_path → sha256 hex
        # rel_path → the fire-phoenix-authored JSON fragment that was polite-
        # merged into a PRE-EXISTING user file. Such files are NOT deleted on
        # uninstall; only the fire-phoenix keys are stripped back out, so the
        # user's original content survives (PRODUCT.md §Invariants: "Never
        # destroy user-authored content").
        self._merged: dict[str, Any] = {}
        self._installed_at: str = ""

    # -- Manifest file location -------------------------------------------

    @property
    def manifest_path(self) -> Path:
        """Path to the on-disk manifest YAML."""
        return self.project_root / ".fire-phoenix" / "integrations" / f"{self.key}.manifest.yml"

    # -- Recording files --------------------------------------------------

    def record_file(self, rel_path: str | Path, content: bytes | str) -> Path:
        """Write *content* to *rel_path* (relative to project root) and record its hash.

        Creates parent directories as needed.  Returns the absolute path
        of the written file.

        Raises ``ValueError`` if *rel_path* resolves outside the project root.
        """
        rel = Path(rel_path)
        abs_path = _validate_rel_path(rel, self.project_root)
        abs_path.parent.mkdir(parents=True, exist_ok=True)
        # Journal BEFORE the write, and only for a file we are creating
        # (AC-PH-006 / adr/0061: record actual new writes only).
        if not abs_path.exists():
            self.note_created(abs_path)

        if isinstance(content, str):
            content = content.encode("utf-8")
        # Atomic: a truncate-then-write torn by a crash would later be
        # misread as "modified by user" and block the next upgrade (AC-PH-004).
        atomic_write_bytes(abs_path, content)

        normalized = abs_path.relative_to(self.project_root).as_posix()
        self._files[normalized] = hashlib.sha256(content).hexdigest()
        return abs_path

    def record_existing(self, rel_path: str | Path) -> None:
        """Record the hash of an already-existing file at *rel_path*.

        Raises ``ValueError`` if *rel_path* resolves outside the project root.
        """
        rel = Path(rel_path)
        abs_path = _validate_rel_path(rel, self.project_root)
        normalized = abs_path.relative_to(self.project_root).as_posix()
        self._files[normalized] = _sha256(abs_path)

    def record_merged(
        self,
        rel_path: str | Path,
        fp_fragment: dict[str, Any],
        *,
        sha256_hex: str | None = None,
    ) -> None:
        """Record a file fire-phoenix polite-merged into a *pre-existing* user file.

        *fp_fragment* is the JSON fire-phoenix contributed. On uninstall the
        file is un-merged (fire-phoenix keys stripped) rather than deleted, so
        the user's original content is never lost. The current hash is also
        recorded so :meth:`check_modified` keeps working; pass *sha256_hex* to
        carry a prior manifest's hash instead of re-hashing (a re-hash would
        bless user edits made since install — AC-PH-003).

        Raises ``ValueError`` if *rel_path* resolves outside the project root.
        """
        rel = Path(rel_path)
        abs_path = _validate_rel_path(rel, self.project_root)
        normalized = abs_path.relative_to(self.project_root).as_posix()
        self._files[normalized] = sha256_hex or _sha256(abs_path)
        self._merged[normalized] = fp_fragment

    def record_carried(self, rel_path: str | Path, sha256_hex: str) -> None:
        """Record *rel_path* with a hash carried from a prior manifest, without
        re-hashing the file on disk. Re-hashing an existing file whose content
        diverged from the shipped asset would bless the user's edits, letting a
        later uninstall delete them (AC-PH-003).

        Raises ``ValueError`` if *rel_path* resolves outside the project root.
        """
        rel = Path(rel_path)
        abs_path = _validate_rel_path(rel, self.project_root)
        normalized = abs_path.relative_to(self.project_root).as_posix()
        self._files[normalized] = sha256_hex

    def note_created(self, path: str | Path) -> None:
        """Record in the attached journal (if any) that this run creates *path*.

        No-op without a journal. Safe to call before the write — that ordering
        is what makes the journal a write-ahead record (AC-PH-006).
        """
        if self._journal is None:
            return
        try:
            abs_path = Path(path)
            rel = (
                abs_path.relative_to(self.project_root).as_posix()
                if abs_path.is_absolute()
                else Path(path).as_posix()
            )
            self._journal.record(rel)
        except (ValueError, OSError):
            # Journalling is best-effort recovery metadata; never fail a write
            # because the trail could not be appended.
            pass

    def carry_merged_from(self, other: IntegrationManifest) -> None:
        """Adopt *other*'s polite-merge provenance for entries this manifest has
        not itself classified. A rebuilt manifest (upgrade) must never forget
        which files pre-existed the install (AC-PH-001)."""
        for rel, fragment in other._merged.items():
            self._merged.setdefault(rel, fragment)

    # -- Querying ---------------------------------------------------------

    @property
    def files(self) -> dict[str, str]:
        """Return a copy of the ``{rel_path: sha256}`` mapping."""
        return dict(self._files)

    @property
    def merged(self) -> dict[str, Any]:
        """Return a copy of the ``{rel_path: fp_fragment}`` merge provenance."""
        return dict(self._merged)

    def check_modified(self) -> list[str]:
        """Return relative paths of tracked files whose content changed on disk."""
        modified: list[str] = []
        for rel, expected_hash in self._files.items():
            rel_path = Path(rel)
            # Skip paths that are absolute or attempt to escape the project root
            if rel_path.is_absolute() or ".." in rel_path.parts:
                continue
            abs_path = self.project_root / rel_path
            if not abs_path.exists() and not abs_path.is_symlink():
                continue
            # Treat symlinks and non-regular-files as modified
            if abs_path.is_symlink() or not abs_path.is_file():
                modified.append(rel)
                continue
            if _sha256(abs_path) != expected_hash:
                modified.append(rel)
        return modified

    # -- Uninstall --------------------------------------------------------

    @staticmethod
    def _has_symlinked_parent(path: Path, root: Path) -> bool:
        """True when any directory between *path* and *root* is a symlink.

        A manifest entry routed through a symlinked parent lexically stays
        inside the project root but physically points elsewhere; deleting it
        would act outside the project (AC-PH-009).
        """
        cur = path.parent
        while True:
            if cur.is_symlink():
                return True
            if cur == root or cur == cur.parent:
                return False
            cur = cur.parent

    def uninstall(
        self,
        project_root: Path | None = None,
        *,
        force: bool = False,
        remove_manifest: bool = True,
    ) -> tuple[list[Path], list[Path]]:
        """Remove tracked files whose hash still matches.

        Parameters:
            project_root:    Override for the project root.
            force:           If ``True``, remove files even if modified.
            remove_manifest: If ``False``, keep the on-disk manifest file
                             (used by upgrade's stale sweep, which operates on
                             a synthetic manifest sharing the real key).

        Returns:
            ``(removed, skipped)`` — absolute paths.
        """
        root = (project_root or self.project_root).resolve()
        removed: list[Path] = []
        skipped: list[Path] = []

        for rel, expected_hash in self._files.items():
            # Use non-resolved path for deletion so symlinks themselves
            # are removed, not their targets.
            path = root / rel
            # Validate containment lexically (without following symlinks)
            # by collapsing .. segments via Path resolution on the string parts.
            try:
                normed = Path(os.path.normpath(path))
                normed.relative_to(root)
            except (ValueError, OSError):
                continue
            if self._has_symlinked_parent(path, root):
                skipped.append(path)
                continue
            if not path.exists() and not path.is_symlink():
                continue
            # Skip directories — manifest only tracks files
            if not path.is_file() and not path.is_symlink():
                skipped.append(path)
                continue
            # Merged-into-user files are un-merged, never deleted: strip only
            # the fire-phoenix keys and preserve the file (PRODUCT.md
            # §Invariants "Never destroy user-authored content").
            if rel in self._merged and path.is_file() and not path.is_symlink():
                self._unmerge_file(path, self._merged[rel])
                skipped.append(path)
                continue
            # Never follow symlinks when comparing hashes. Only remove
            # symlinks when forced, to avoid acting on tampered entries.
            if path.is_symlink():
                if not force:
                    skipped.append(path)
                    continue
            else:
                if not force and _sha256(path) != expected_hash:
                    skipped.append(path)
                    continue
            try:
                path.unlink()
            except OSError:
                skipped.append(path)
                continue
            removed.append(path)
            # Clean up empty parent directories up to project root
            parent = path.parent
            while parent != root:
                try:
                    parent.rmdir()  # only succeeds if empty
                except OSError:
                    break
                parent = parent.parent

        # Remove the manifest file itself
        if not remove_manifest:
            return removed, skipped
        manifest = root / ".fire-phoenix" / "integrations" / f"{self.key}.manifest.yml"
        if manifest.exists():
            manifest.unlink()
            parent = manifest.parent
            while parent != root:
                try:
                    parent.rmdir()
                except OSError:
                    break
                parent = parent.parent

        return removed, skipped

    @staticmethod
    def _unmerge_file(path: Path, fp_fragment: dict[str, Any]) -> None:
        """Strip *fp_fragment* keys from the JSON at *path*, preserving the rest.

        Silently leaves the file untouched if it is unparseable JSON or the
        write fails — never deletes it. An empty remainder is written back as
        an empty object rather than removing the file (the file pre-existed).
        """
        import json

        try:
            current = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return
        if not isinstance(current, dict) or not isinstance(fp_fragment, dict):
            return
        remainder = _deep_unmerge(current, fp_fragment)
        if remainder == current:
            return
        try:
            atomic_write_text(path, json.dumps(remainder, indent=2, ensure_ascii=False) + "\n")
        except OSError:
            return

    # -- Persistence ------------------------------------------------------

    def save(self) -> Path:
        """Write the manifest to disk.  Returns the manifest path."""
        self._installed_at = self._installed_at or datetime.now(UTC).isoformat()
        data: dict[str, Any] = {
            "integration": self.key,
            "version": self.version,
            "installed_at": self._installed_at,
            "files": self._files,
        }
        # Additive/back-compatible: only emit `merged` when there are merged
        # files. Manifests written before task-0143 have no `merged` key and
        # load with an empty mapping (every file treated as created).
        if self._merged:
            data["merged"] = self._merged
        path = self.manifest_path
        atomic_write_text(
            path,
            yaml.safe_dump(data, sort_keys=False, default_flow_style=False, allow_unicode=True),
        )
        return path

    @classmethod
    def load(cls, key: str, project_root: Path) -> IntegrationManifest:
        """Load an existing manifest from disk.

        Raises ``FileNotFoundError`` if the manifest does not exist.
        """
        inst = cls(key, project_root)
        path = inst.manifest_path
        try:
            data = yaml.safe_load(path.read_text(encoding="utf-8"))
        except yaml.YAMLError as exc:
            raise ValueError(f"Integration manifest at {path} contains invalid YAML") from exc

        if not isinstance(data, dict):
            raise ValueError(
                f"Integration manifest at {path} must be a YAML mapping, got {type(data).__name__}"
            )

        files = data.get("files", {})
        if not isinstance(files, dict) or not all(
            isinstance(k, str) and isinstance(v, str) for k, v in files.items()
        ):
            raise ValueError(
                f"Integration manifest 'files' at {path} must be a "
                "mapping of string paths to string hashes"
            )

        merged = data.get("merged", {})
        if not isinstance(merged, dict) or not all(
            isinstance(k, str) and isinstance(v, dict) for k, v in merged.items()
        ):
            raise ValueError(
                f"Integration manifest 'merged' at {path} must be a "
                "mapping of string paths to JSON-object fragments"
            )

        inst.version = data.get("version", "")
        inst._installed_at = data.get("installed_at", "")
        inst._files = files
        inst._merged = merged

        stored_key = data.get("integration", "")
        if stored_key and stored_key != key:
            raise ValueError(
                f"Manifest at {path} belongs to integration {stored_key!r}, not {key!r}"
            )

        return inst
