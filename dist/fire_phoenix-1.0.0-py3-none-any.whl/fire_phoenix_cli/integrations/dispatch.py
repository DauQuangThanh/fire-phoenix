"""Subprocess dispatch helpers used by ``IntegrationBase.dispatch_command``.

Right now this owns the timeout-and-kill flow. When a streamed CLI
dispatch exceeds the deadline we SIGTERM with a 5-second grace, then
SIGKILL, and surface exit-code 124 (the canonical "timed out" code GNU
timeout uses).
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    import subprocess


def _kill_on_timeout(
    proc: subprocess.Popen[str],
    command_name: str,
    timeout: int,
) -> dict[str, Any]:
    """Send SIGTERM, wait 5 s grace, then SIGKILL.  Return exit-code 124."""
    import subprocess
    import sys

    proc.terminate()
    try:
        proc.wait(timeout=5)
    except subprocess.TimeoutExpired:
        proc.kill()
        proc.wait()
    print(
        f"Command '{command_name}' timed out after {timeout}s",
        file=sys.stderr,
    )
    return {"exit_code": 124, "stdout": "", "stderr": ""}
