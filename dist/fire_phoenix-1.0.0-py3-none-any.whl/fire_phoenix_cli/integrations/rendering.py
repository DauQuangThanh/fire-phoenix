"""Shared frontmatter and template-rendering helpers.

Provider integrations need to add, remove, or rewrite YAML frontmatter
fields on copied skill/subagent files (Cursor strips ``tools``, etc.).
These helpers are the underlying
text-manipulation primitives — they take a content string and return a
modified string. They do no I/O.

``process_template`` is the larger pipeline that turns a raw shared
command template into agent-ready Markdown (extracts ``{SCRIPT}`` from
frontmatter, substitutes ``__AGENT__``/``__CONTEXT_FILE__``, rewrites
project-relative paths). Provider subclasses call it through the
``IntegrationBase.process_template`` static-method proxy.
"""

from __future__ import annotations

import re

_FRONTMATTER_RE = re.compile(r"\A(---\r?\n)(.*?)(\r?\n---\r?\n)", re.DOTALL)


def _strip_frontmatter_field(content: str, field: str) -> str:
    """Remove a single YAML frontmatter field line from *content*."""
    pattern = re.compile(rf"(?m)^[ \t]*{re.escape(field)}:[ \t]*[^\r\n]*\r?\n?")
    match = _FRONTMATTER_RE.match(content)
    if not match:
        return content
    opening, fm, closing = match.groups()
    body = content[match.end() :]
    fm = pattern.sub("", fm)
    return f"{opening}{fm}{closing}{body}"


def _inject_frontmatter_field(content: str, field: str, value: str) -> str:
    """Inject a YAML field into frontmatter (after existing fields)."""
    match = _FRONTMATTER_RE.match(content)
    if not match:
        return content
    opening, fm, closing = match.groups()
    body = content[match.end() :]
    if f"{field}:" not in fm:
        fm = fm.rstrip() + f"\n{field}: {value}"
    return f"{opening}{fm}{closing}{body}"


def _strip_frontmatter(content: str) -> str:
    """Remove the entire YAML frontmatter block, returning only the body."""
    match = _FRONTMATTER_RE.match(content)
    if not match:
        return content
    return content[match.end() :]


def _ensure_mdc_frontmatter(content: str) -> str:
    """Ensure ``.mdc`` content has YAML frontmatter with ``alwaysApply: true``.

    If frontmatter is missing, prepend it.  If frontmatter exists but
    ``alwaysApply`` is absent or not ``true``, inject/fix it.

    Uses string/regex manipulation to preserve comments and formatting
    in existing frontmatter.
    """

    leading_ws = len(content) - len(content.lstrip())
    leading = content[:leading_ws]
    stripped = content[leading_ws:]

    if not stripped.startswith("---"):
        return "---\nalwaysApply: true\n---\n\n" + content

    # Match frontmatter block: ---\n...\n---
    match = re.match(
        r"^(---[ \t]*\r?\n)(.*?)(\r?\n---[ \t]*)(\r?\n|$)(.*)",
        stripped,
        re.DOTALL,
    )
    if not match:
        return "---\nalwaysApply: true\n---\n\n" + content

    opening, fm_text, closing, sep, rest = match.groups()
    newline = "\r\n" if "\r\n" in opening else "\n"

    # Already correct?
    if re.search(r"(?m)^[ \t]*alwaysApply[ \t]*:[ \t]*true[ \t]*(?:#.*)?$", fm_text):
        return content

    # alwaysApply exists but wrong value — fix in place while preserving
    # indentation and any trailing inline comment.
    if re.search(r"(?m)^[ \t]*alwaysApply[ \t]*:", fm_text):
        fm_text = re.sub(
            r"(?m)^([ \t]*)alwaysApply[ \t]*:.*?([ \t]*(?:#.*)?)$",
            r"\1alwaysApply: true\2",
            fm_text,
            count=1,
        )
    elif fm_text.strip():
        fm_text = fm_text + newline + "alwaysApply: true"
    else:
        fm_text = "alwaysApply: true"

    return f"{leading}{opening}{fm_text}{closing}{sep}{rest}"


def process_template(
    content: str,
    agent_name: str,
    script_type: str,
    arg_placeholder: str = "$ARGUMENTS",
    context_file: str = "",
) -> str:
    """Process a raw command template into agent-ready content.

    Performs the same transformations as the release script:
    1. Extract ``scripts.<script_type>`` value from YAML frontmatter
    2. Replace ``{SCRIPT}`` with the extracted script command
    3. Strip ``scripts:`` section from frontmatter
    4. Replace ``{ARGS}`` and ``$ARGUMENTS`` with *arg_placeholder*
    5. Replace ``__AGENT__`` with *agent_name*
    6. Replace ``__CONTEXT_FILE__`` with *context_file*
    7. Rewrite paths: ``scripts/`` → ``.fire-phoenix/scripts/`` etc.
    """
    # 1. Extract script command from frontmatter
    script_command = ""
    script_pattern = re.compile(rf"^\s*{re.escape(script_type)}:\s*(.+)$", re.MULTILINE)
    # Find the scripts: block
    in_scripts = False
    for line in content.splitlines():
        if line.strip() == "scripts:":
            in_scripts = True
            continue
        if in_scripts and line and not line[0].isspace():
            in_scripts = False
        if in_scripts:
            m = script_pattern.match(line)
            if m:
                script_command = m.group(1).strip()
                break

    # 2. Replace {SCRIPT}
    if script_command:
        content = content.replace("{SCRIPT}", script_command)

    # 3. Strip scripts: section from frontmatter
    lines = content.splitlines(keepends=True)
    output_lines: list[str] = []
    in_frontmatter = False
    skip_section = False
    dash_count = 0
    for line in lines:
        stripped = line.rstrip("\n\r")
        if stripped == "---":
            dash_count += 1
            if dash_count == 1:
                in_frontmatter = True
            else:
                in_frontmatter = False
            skip_section = False
            output_lines.append(line)
            continue
        if in_frontmatter:
            if stripped == "scripts:":
                skip_section = True
                continue
            if skip_section:
                if line[0:1].isspace():
                    continue  # skip indented content under scripts
                skip_section = False
        output_lines.append(line)
    content = "".join(output_lines)

    # 4. Replace {ARGS} and $ARGUMENTS
    content = content.replace("{ARGS}", arg_placeholder)
    content = content.replace("$ARGUMENTS", arg_placeholder)

    # 5. Replace __AGENT__
    content = content.replace("__AGENT__", agent_name)

    # 6. Replace __CONTEXT_FILE__
    content = content.replace("__CONTEXT_FILE__", context_file)

    # 7. Rewrite paths — delegate to the shared implementation in
    #    CommandRegistrar so extension-local paths are preserved and
    #    boundary rules stay consistent across the codebase.
    from fire_phoenix_cli.skills.render import CommandRegistrar

    content = CommandRegistrar.rewrite_project_relative_paths(content)

    return content
