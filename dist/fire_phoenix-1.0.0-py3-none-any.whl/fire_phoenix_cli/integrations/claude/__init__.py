"""Claude Code integration."""

from __future__ import annotations

import re
from pathlib import Path  # noqa: F401

from ..manifest import IntegrationManifest  # noqa: F401
from ..skills_integration import SkillsIntegration

# Note injected into hook sections so Claude maps dot-notation command
# names (from extensions.yml) to the hyphenated skill names it uses.
_HOOK_COMMAND_NOTE = (
    "- When constructing slash commands from hook command names, "
    "replace dots (`.`) with hyphens (`-`). "
    "For example, `fire-phoenix.git.commit` → `/fire-phoenix-git-commit`.\n"
)


class ClaudeIntegration(SkillsIntegration):
    """Integration for Claude Code skills."""

    key = "claude"
    config = {
        "name": "Claude Code",
        "folder": ".claude/",
        "skills_subdir": "skills",
        "install_url": "https://docs.anthropic.com/en/docs/claude-code/setup",
        "requires_cli": True,
    }
    registrar_config = {
        "dir": ".claude/skills",
        "format": "markdown",
        "args": "$ARGUMENTS",
        "extension": "/SKILL.md",
    }
    context_file = "CLAUDE.md"

    supports_argument_hints = True
    supports_handoffs = True
    supports_multi_context_files = False

    def unattended_permission_args(self) -> list[str]:
        """Grant tool permissions for an unattended (``--auto``) headless run.

        ``claude -p`` cannot show permission prompts, so Bash/Write/Edit are
        blocked by default and the agent can only emit text (this is the defect
        that stranded workflow steps). ``--permission-mode bypassPermissions``
        (equiv. ``--dangerously-skip-permissions``) lets the agent run its
        creation scripts and write artefacts unattended. Only ever applied when
        the user opts into ``--auto``; refuses to start as root (Claude Code's
        own guard). See ``decisions.md`` (2026-07-10, workflow run mode).
        """
        return ["--permission-mode", "bypassPermissions"]

    @staticmethod
    def _inject_frontmatter_flag(content: str, key: str, value: str = "true") -> str:
        """Insert ``key: value`` before the closing ``---`` if not already present."""
        lines = content.splitlines(keepends=True)

        # Pre-scan: bail out if already present in frontmatter
        dash_count = 0
        for line in lines:
            stripped = line.rstrip("\n\r")
            if stripped == "---":
                dash_count += 1
                if dash_count == 2:
                    break
                continue
            if dash_count == 1 and stripped.startswith(f"{key}:"):
                return content

        # Inject before the closing --- of frontmatter
        out: list[str] = []
        dash_count = 0
        injected = False
        for line in lines:
            stripped = line.rstrip("\n\r")
            if stripped == "---":
                dash_count += 1
                if dash_count == 2 and not injected:
                    if line.endswith("\r\n"):
                        eol = "\r\n"
                    elif line.endswith("\n"):
                        eol = "\n"
                    else:
                        eol = ""
                    out.append(f"{key}: {value}{eol}")
                    injected = True
            out.append(line)
        return "".join(out)

    @staticmethod
    def _inject_hook_command_note(content: str) -> str:
        """Insert a dot-to-hyphen note before each hook output instruction.

        Targets the line ``- For each executable hook, output the following``
        and inserts the note on the line before it, matching its indentation.
        Skips if the note is already present.
        """
        if "replace dots" in content:
            return content

        def repl(m: re.Match[str]) -> str:
            indent = m.group(1)
            instruction = m.group(2)
            eol = m.group(3)
            return indent + _HOOK_COMMAND_NOTE.rstrip("\n") + eol + indent + instruction + eol

        return re.sub(
            r"(?m)^(\s*)(- For each executable hook, output the following[^\r\n]*)(\r\n|\n|$)",
            repl,
            content,
        )

    def post_process_skill_content(self, content: str) -> str:
        """Inject Claude-specific frontmatter flags and hook notes."""
        updated = self._inject_frontmatter_flag(content, "user-invocable")
        updated = self._inject_frontmatter_flag(updated, "disable-model-invocation", "false")
        updated = self._inject_hook_command_note(updated)
        return updated

    # Per task-0005, ClaudeIntegration no longer post-processes installed
    # SKILL.md files from agent-skills/ bundles. Source bundles are the
    # canonical artefact — agentskills.io-spec compliant and shipped verbatim
    # (see contracts/task-0005-rename-skill-md-and-remove-transformer.md).
    # Source bundles MAY declare Claude-specific frontmatter (user-invocable,
    # disable-model-invocation, argument-hint) directly if desired — they
    # propagate verbatim.
    #
    # ``post_process_skill_content`` (and its private helpers
    # ``_inject_frontmatter_flag`` / ``_inject_hook_command_note``) is
    # retained because the preset and extension generators — a different
    # code path from setup() — still call it on dynamically-generated
    # SKILL.md content. Concrete callers:
    #   - src/fire_phoenix_cli/presets/installer.py:414-415, 649-650,
    #     745-746, 778-779
    #   - src/fire_phoenix_cli/extensions/manager.py:382-383
    # ``SkillsIntegration.setup()`` is inherited unchanged and does NOT
    # invoke ``post_process_skill_content`` itself.
