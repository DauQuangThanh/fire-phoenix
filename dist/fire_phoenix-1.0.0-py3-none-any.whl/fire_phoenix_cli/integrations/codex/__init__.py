"""Codex CLI integration — skills-based agent.

Codex uses the ``.codex/skills/fire-phoenix-<name>/SKILL.md`` layout.
Custom subagents install to ``.codex/agents/`` as TOML files — Codex
custom agents are TOML, not Markdown (see
https://developers.openai.com/codex/subagents).
"""

from __future__ import annotations

import re

import yaml

from ..base import IntegrationOption
from ..skills_integration import SkillsIntegration

_FRONTMATTER_RE = re.compile(r"\A---\r?\n(.*?)\r?\n---\r?\n?", re.DOTALL)


def _toml_basic_string(value: str) -> str:
    """Serialise *value* as a single-line TOML basic string."""
    escaped = (
        value.replace("\\", "\\\\")
        .replace("\r", "")
        .replace("\t", "\\t")
        .replace("\n", "\\n")
        .replace('"', '\\"')
    )
    return f'"{escaped}"'


def _toml_multiline_basic(value: str) -> str:
    """Serialise *value* as a TOML multiline basic string (triple-quoted).

    Backslashes are escaped (``\\`` is TOML's escape char) and any run of
    three-or-more double-quotes is broken up so it can't be read as the
    closing delimiter. A newline follows the opening ``\"\"\"`` (TOML trims
    the first newline) for readability.
    """
    body = value.replace("\\", "\\\\")
    body = re.sub(r'"{3,}', lambda m: m.group(0).replace('"', '\\"'), body)
    return '"""\n' + body + '\n"""'


class CodexIntegration(SkillsIntegration):
    """Integration for OpenAI Codex CLI."""

    key = "codex"
    config = {
        "name": "Codex CLI",
        "folder": ".codex/",
        "skills_subdir": "skills",
        "install_url": "https://github.com/openai/codex",
        "requires_cli": True,
    }
    registrar_config = {
        "dir": ".codex/skills",
        "format": "markdown",
        "args": "$ARGUMENTS",
        "extension": "/SKILL.md",
    }
    context_file = "AGENTS.md"

    # adr/0039: Codex documents no custom-agent size limit (verified against
    # developers.openai.com/codex, 2026-07-07), so no cap is declared — the
    # former 8,000-char ceiling was TBD-source and emitted 13 spurious
    # warnings per init. Inherits the base default (None). If OpenAI ever
    # documents a real limit, restore it and apply the adr/0034 reference-
    # extraction pattern.
    subagent_char_limit = None

    def custom_agent_filename(self, src_name: str) -> str:
        """Codex custom agents are TOML files (``.codex/agents/<name>.toml``)."""
        if src_name.endswith(".md"):
            return src_name[: -len(".md")] + ".toml"
        return src_name

    def build_exec_args(
        self,
        prompt: str,
        *,
        model: str | None = None,
        output_json: bool = True,
    ) -> list[str] | None:
        # Codex uses ``codex exec "prompt"`` for non-interactive mode.
        args: list[str] = ["codex", "exec", prompt]
        if model:
            args.extend(["--model", model])
        if output_json:
            args.append("--json")
        return args

    supports_argument_hints = False
    supports_handoffs = True
    supports_multi_context_files = False

    def transform_custom_agent_content(self, content: str) -> str:
        """Render a Claude-format subagent into a Codex custom-agent TOML.

        Codex custom agents are TOML files with three required keys —
        ``name``, ``description``, ``developer_instructions``. The source
        body becomes ``developer_instructions``; ``color`` / ``tools`` /
        ``model`` are dropped (Codex infers model from the parent session).
        """
        match = _FRONTMATTER_RE.match(content)
        if match:
            try:
                fm = yaml.safe_load(match.group(1)) or {}
            except yaml.YAMLError:
                fm = {}
            body = content[match.end() :]
        else:
            fm = {}
            body = content

        name = str(fm.get("name", "")).strip()
        description = str(fm.get("description", "")).strip()
        instructions = body.strip()

        lines: list[str] = []
        if name:
            lines.append(f"name = {_toml_basic_string(name)}")
        if description:
            lines.append(f"description = {_toml_basic_string(description)}")
        lines.append(f"developer_instructions = {_toml_multiline_basic(instructions)}")
        return "\n".join(lines) + "\n"

    @classmethod
    def options(cls) -> list[IntegrationOption]:
        return [
            IntegrationOption(
                "--skills",
                is_flag=True,
                default=True,
                help="Install as agent skills (default for Codex)",
            ),
        ]
