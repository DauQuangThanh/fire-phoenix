"""Managed-block / TREE-block text surgery for agent context files.

Pure-text helpers extracted from ``base.py`` so the reconciliation logic
that regenerates the fire-phoenix managed section of an agent context file
(``CLAUDE.md`` / ``AGENTS.md`` / ``.mdc`` …) lives in one focused module.

The functions here are deliberately free of ``self`` — they take the marker
literals and the target ``context_file`` as explicit arguments, so
``IntegrationBase`` (and any future caller) can drive them without inheriting
state. Behaviour is byte-for-byte identical to the former methods: the
envelope layout, the three on-disk marker arrangements, the imports-header
handling, and the project-structure-map (TREE) sub-block preservation are all
governed by ``adr/0063`` and its amendments and MUST NOT drift here.
"""

from __future__ import annotations

from .bootstrap import build_context_section, build_imports_header


def managed_block_anchor() -> str:
    """The managed prose's start anchor (``adr/0063`` + amendments).

    The trailing managed prose begins at its first non-empty line (today
    ``"## Safe handling of source changes"``), derived from the live
    template so it tracks content edits. Used to locate where the prose
    starts when stripping it out from the wrapped envelope, leaving the
    body above it intact.
    """
    for line in build_context_section().splitlines():
        if line.strip():
            return line
    return ""


def extract_tree_block(content: str, tree_start: str, tree_end: str) -> str | None:
    """Return the inner text of the project-structure-map sub-block.

    The sub-block is the text between *tree_start* and *tree_end* (adr/0063
    3rd amendment). It lives inside the managed prose but holds
    project-specific content, so it is preserved across regeneration by
    ``IntegrationBase.upsert_context_section``.

    Returns the inner text (markers excluded, surrounding newlines
    stripped), or ``None`` when the sub-block is absent — so a caller can
    distinguish "no tree block on disk" (leave the fresh placeholder) from
    "empty tree block" (preserve the emptiness).
    """
    s = content.find(tree_start)
    if s == -1:
        return None
    e = content.find(tree_end, s + len(tree_start))
    if e == -1:
        return None
    return content[s + len(tree_start) : e].strip("\n")


def inject_tree_block(prose: str, tree_inner: str, tree_start: str, tree_end: str) -> str:
    """Return *prose* with its tree sub-block inner replaced by *tree_inner*.

    Used to re-inject the preserved project-structure map into freshly
    rendered managed prose. If *prose* carries no tree markers (a template
    without the sub-block) it is returned unchanged — the caller then
    keeps whatever the template shipped.
    """
    s = prose.find(tree_start)
    if s == -1:
        return prose
    e = prose.find(tree_end, s + len(tree_start))
    if e == -1:
        return prose
    return f"{prose[: s + len(tree_start)]}\n{tree_inner}\n{prose[e:]}"


def strip_managed_block(
    content: str,
    context_file: str | None,
    start_marker: str,
    end_marker: str,
    anchor: str | None = None,
) -> str:
    """Return *content* with every fire-phoenix managed element removed.

    The managed elements are the ``START``/``END`` envelope markers, the
    context-file imports header, and the managed prose block. What
    remains is the user / scaffold body, preserved verbatim. Handles the
    three on-disk arrangements (``adr/0063`` + its two amendments):

    - **Wrapped envelope** (current, 2nd amendment): ``START`` first, then
      imports header, then body, then managed prose, then ``END`` at EOF.
      The body is *inside* the markers but preserved — only the leading
      ``START``+imports and the trailing ``[anchor … END]`` prose are cut.
    - **END-only** (``adr/0063`` 1st amendment, ``v0.25``–``v0.27``): no
      ``START``; imports header at top, prose + ``END`` at EOF.
    - **Legacy two-marker** (``v0.24``): a compact ``START``…``END`` block
      at the top with the body *after* ``END`` (stripped as a region).

    *anchor* is the managed prose's first line (defaults to the live
    template's). *context_file* is the provider's relative context-file path
    — it selects the ``.mdc`` (no imports header) branch and drives the
    imports-header derivation. Returns *content* unchanged when no managed
    element is found, or when the prose anchor cannot be located (never
    drops body).
    """
    anchor = anchor if anchor is not None else managed_block_anchor()
    is_mdc = context_file is not None and context_file.endswith(".mdc")
    imports_header = "" if is_mdc or not context_file else build_imports_header(context_file)

    start_idx = content.find(start_marker)
    end_idx = content.find(end_marker, start_idx if start_idx != -1 else 0)

    def _consume_end(idx: int) -> int:
        end_of = idx + len(end_marker)
        if end_of < len(content) and content[end_of] == "\r":
            end_of += 1
        if end_of < len(content) and content[end_of] == "\n":
            end_of += 1
        return end_of

    # No END marker at all.
    if end_idx == -1:
        if start_idx != -1:
            # Corrupt start-only legacy: drop from START through EOF.
            return content[:start_idx]
        return content

    # Is END the last meaningful content? → wrapped envelope or END-only.
    if content[_consume_end(end_idx) :].strip() == "":
        # 1. Cut the trailing managed prose [anchor … END].
        cut = None
        if anchor:
            nl_marker = "\n" + anchor
            a = content.rfind(nl_marker, 0, end_idx)
            if a != -1:
                cut = a + 1
            elif content.lstrip().startswith(anchor):
                cut = content.find(anchor)
        if cut is not None:
            body = content[:cut]
        elif start_idx != -1:
            # START present but the prose anchor is not locatable (a renamed
            # managed-prose heading — the documented re-decision trigger — or
            # a hand-built block). In the wrapped-envelope layout the user
            # body sits INSIDE the markers, so we CANNOT drop the whole
            # [START … END] span (that deletes the body — a top-of-file START
            # would return ""). Keep everything up to END (body + any orphaned
            # prose) and remove only the envelope markers + imports header
            # below. Never drop the user body (PRODUCT.md §Invariants: "Never
            # destroy user-authored content").
            body = content[:end_idx]
        else:
            # END-only, no START — cannot locate the block start; leave
            # content intact rather than risk dropping user body.
            return content
        # 2. Remove the START marker line (file top for non-.mdc, or right
        #    after .mdc frontmatter — so search rather than assume line 0).
        si = body.find(start_marker)
        if si != -1:
            after = si + len(start_marker)
            if after < len(body) and body[after] == "\r":
                after += 1
            if after < len(body) and body[after] == "\n":
                after += 1
            body = body[:si] + body[after:]
        # 3. Remove the imports header if it leads the remaining body.
        if imports_header and body.lstrip().startswith(imports_header):
            ih = body.find(imports_header)
            body = body[:ih] + body[ih + len(imports_header) :]
        return body

    # END is not the last content → legacy two-marker, body AFTER END.
    if start_idx != -1 and end_idx > start_idx:
        return content[:start_idx] + content[_consume_end(end_idx) :]
    # END mid-file without START (unusual) — cut [anchor … END] in place.
    if anchor:
        nl_marker = "\n" + anchor
        a = content.rfind(nl_marker, 0, end_idx)
        if a != -1:
            return content[: a + 1] + content[_consume_end(end_idx) :]
        if content.startswith(anchor):
            return content[_consume_end(end_idx) :]
    return content
