"""Integration catalog — discovery, validation, and upgrade support.

Provides:
- ``IntegrationCatalogEntry`` — single catalog source metadata.
- ``IntegrationCatalog``      — fetches, caches, and searches integration
  catalogs (built-in + community).
- ``IntegrationDescriptor``   — loads and validates ``integration.yml``.
"""

from __future__ import annotations

import hashlib
import os
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import yaml

from packaging import version as pkg_version

from ..catalog_base import CatalogBase

# ---------------------------------------------------------------------------
# Errors
# ---------------------------------------------------------------------------


class IntegrationCatalogError(Exception):
    """Raised when a catalog operation fails."""


class IntegrationDescriptorError(Exception):
    """Raised when an integration.yml descriptor is invalid."""


# ---------------------------------------------------------------------------
# IntegrationCatalogEntry
# ---------------------------------------------------------------------------


@dataclass
class IntegrationCatalogEntry:
    """Represents a single catalog source in the catalog stack."""

    url: str
    name: str
    priority: int
    install_allowed: bool
    description: str = ""


# ---------------------------------------------------------------------------
# IntegrationCatalog
# ---------------------------------------------------------------------------


class IntegrationCatalog(CatalogBase):
    """Read-only view over the bundled integration catalog (F-18, offline-only)."""

    catalog_kind = "integrations"
    error_class = IntegrationCatalogError

    def _make_entry(self, **kwargs: Any) -> IntegrationCatalogEntry:
        return IntegrationCatalogEntry(**kwargs)

    def _get_merged_integrations(self, force_refresh: bool = False) -> list[dict[str, Any]]:
        """Merged, annotated integration dicts (delegates to CatalogBase)."""
        return self._merged_list(force_refresh)

    def get_integration_info(self, integration_id: str) -> dict[str, Any] | None:
        """Return catalog metadata for a single integration, or None."""
        return self.get_info(integration_id)


# ---------------------------------------------------------------------------
# IntegrationDescriptor  (integration.yml)
# ---------------------------------------------------------------------------


class IntegrationDescriptor:
    """Loads and validates an ``integration.yml`` descriptor.

    The descriptor mirrors ``extension.yml`` and ``preset.yml``::

        schema_version: "1.0"
        integration:
          id: "my-agent"
          name: "My Agent"
          version: "1.0.0"
          description: "Integration for My Agent"
          author: "my-org"
        requires:
          fire_phoenix_version: ">=0.6.0"
          tools: [...]
        provides:
          commands: [...]
          scripts: [...]
    """

    SCHEMA_VERSION = "1.0"
    REQUIRED_TOP_LEVEL = ["schema_version", "integration", "requires", "provides"]

    def __init__(self, descriptor_path: Path) -> None:
        self.path = descriptor_path
        self.data = self._load(descriptor_path)
        self._validate()

    # -- Loading ----------------------------------------------------------

    @staticmethod
    def _load(path: Path) -> dict:
        try:
            with open(path, encoding="utf-8") as fh:
                return yaml.safe_load(fh) or {}
        except yaml.YAMLError as exc:
            raise IntegrationDescriptorError(f"Invalid YAML in {path}: {exc}")  # noqa: B904
        except FileNotFoundError:
            raise IntegrationDescriptorError(f"Descriptor not found: {path}")  # noqa: B904
        except (OSError, UnicodeError) as exc:
            raise IntegrationDescriptorError(f"Unable to read descriptor {path}: {exc}")  # noqa: B904

    # -- Validation -------------------------------------------------------

    def _validate(self) -> None:
        if not isinstance(self.data, dict):
            raise IntegrationDescriptorError(
                f"Descriptor root must be a YAML mapping, got {type(self.data).__name__}"
            )
        for field in self.REQUIRED_TOP_LEVEL:
            if field not in self.data:
                raise IntegrationDescriptorError(f"Missing required field: {field}")

        if self.data["schema_version"] != self.SCHEMA_VERSION:
            raise IntegrationDescriptorError(
                f"Unsupported schema version: {self.data['schema_version']} "
                f"(expected {self.SCHEMA_VERSION})"
            )

        integ = self.data["integration"]
        if not isinstance(integ, dict):
            raise IntegrationDescriptorError("'integration' must be a mapping")
        for field in ("id", "name", "version", "description"):
            if field not in integ:
                raise IntegrationDescriptorError(f"Missing integration.{field}")
            if not isinstance(integ[field], str):
                raise IntegrationDescriptorError(
                    f"integration.{field} must be a string, got {type(integ[field]).__name__}"
                )

        if not re.match(r"^[a-z0-9-]+$", integ["id"]):
            raise IntegrationDescriptorError(
                f"Invalid integration ID '{integ['id']}': "
                "must be lowercase alphanumeric with hyphens only"
            )

        try:
            pkg_version.Version(integ["version"])
        except (pkg_version.InvalidVersion, TypeError):
            raise IntegrationDescriptorError(f"Invalid version '{integ['version']}'")  # noqa: B904

        requires = self.data["requires"]
        if not isinstance(requires, dict):
            raise IntegrationDescriptorError("'requires' must be a mapping")
        if "fire_phoenix_version" not in requires:
            raise IntegrationDescriptorError("Missing requires.fire-phoenix_version")
        if (
            not isinstance(requires["fire_phoenix_version"], str)
            or not requires["fire_phoenix_version"].strip()
        ):
            raise IntegrationDescriptorError(
                "requires.fire-phoenix_version must be a non-empty string"
            )
        tools = requires.get("tools")
        if tools is not None:
            if not isinstance(tools, list):
                raise IntegrationDescriptorError("requires.tools must be a list")
            for tool in tools:
                if not isinstance(tool, dict):
                    raise IntegrationDescriptorError("Each requires.tools entry must be a mapping")
                tool_name = tool.get("name")
                if not isinstance(tool_name, str) or not tool_name.strip():
                    raise IntegrationDescriptorError(
                        "requires.tools entry 'name' must be a non-empty string"
                    )

        provides = self.data["provides"]
        if not isinstance(provides, dict):
            raise IntegrationDescriptorError("'provides' must be a mapping")
        commands = provides.get("commands", [])
        scripts = provides.get("scripts", [])
        if "commands" in provides and not isinstance(commands, list):
            raise IntegrationDescriptorError("Invalid provides.commands: expected a list")
        if "scripts" in provides and not isinstance(scripts, list):
            raise IntegrationDescriptorError("Invalid provides.scripts: expected a list")
        if not commands and not scripts:
            raise IntegrationDescriptorError(
                "Integration must provide at least one command or script"
            )
        for cmd in commands:
            if not isinstance(cmd, dict):
                raise IntegrationDescriptorError("Each command entry must be a mapping")
            if "name" not in cmd or "file" not in cmd:
                raise IntegrationDescriptorError("Command entry missing 'name' or 'file'")
            cmd_name = cmd["name"]
            cmd_file = cmd["file"]
            if not isinstance(cmd_name, str) or not cmd_name.strip():
                raise IntegrationDescriptorError("Command entry 'name' must be a non-empty string")
            if not isinstance(cmd_file, str) or not cmd_file.strip():
                raise IntegrationDescriptorError("Command entry 'file' must be a non-empty string")
            if (
                os.path.isabs(cmd_file)
                or ".." in Path(cmd_file).parts
                or Path(cmd_file).drive
                or Path(cmd_file).anchor
            ):
                raise IntegrationDescriptorError(
                    f"Command entry 'file' must be a relative path without '..': {cmd_file}"
                )
        for script_entry in scripts:
            if not isinstance(script_entry, str) or not script_entry.strip():
                raise IntegrationDescriptorError("Script entry must be a non-empty string")
            if (
                os.path.isabs(script_entry)
                or ".." in Path(script_entry).parts
                or Path(script_entry).drive
                or Path(script_entry).anchor
            ):
                raise IntegrationDescriptorError(
                    f"Script entry must be a relative path without '..': {script_entry}"
                )

    # -- Property accessors -----------------------------------------------

    @property
    def id(self) -> str:
        return self.data["integration"]["id"]

    @property
    def name(self) -> str:
        return self.data["integration"]["name"]

    @property
    def version(self) -> str:
        return self.data["integration"]["version"]

    @property
    def description(self) -> str:
        return self.data["integration"]["description"]

    @property
    def requires_fire_phoenix_version(self) -> str:
        return self.data["requires"]["fire_phoenix_version"]

    @property
    def commands(self) -> list[dict[str, Any]]:
        return self.data.get("provides", {}).get("commands", [])

    @property
    def scripts(self) -> list[str]:
        return self.data.get("provides", {}).get("scripts", [])

    @property
    def tools(self) -> list[dict[str, Any]]:
        return self.data.get("requires", {}).get("tools") or []

    def get_hash(self) -> str:
        """SHA-256 hash of the descriptor file."""
        with open(self.path, "rb") as fh:
            return f"sha256:{hashlib.sha256(fh.read()).hexdigest()}"
