"""``MarkdownIntegration`` — covers the standard Markdown-format providers.

Subclasses set ``key``, ``config``, ``registrar_config`` (and optionally
``context_file``) and inherit everything else. ``setup()`` processes
command templates through the shared ``rendering.process_template``
pipeline and upserts the managed context section.
"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING, Any

from .base import IntegrationBase

if TYPE_CHECKING:
    from .manifest import IntegrationManifest


class MarkdownIntegration(IntegrationBase):
    """Concrete base for integrations that use standard Markdown commands.

    Subclasses only need to set ``key``, ``config``, ``registrar_config``
    (and optionally ``context_file``).  Everything else is inherited.

    ``setup()`` processes command templates (replacing ``{SCRIPT}``,
    ``{ARGS}``, ``__AGENT__``, rewriting paths) and upserts the
    managed context section into the agent context file.
    """

    def build_exec_args(
        self,
        prompt: str,
        *,
        model: str | None = None,
        output_json: bool = True,
    ) -> list[str] | None:
        if not self.config or not self.config.get("requires_cli"):
            return None
        args = [self.key, "-p", prompt]
        if model:
            args.extend(["--model", model])
        if output_json:
            args.extend(["--output-format", "json"])
        return args

    def setup(
        self,
        project_root: Path,
        manifest: IntegrationManifest,
        parsed_options: dict[str, Any] | None = None,
        **opts: Any,
    ) -> list[Path]:
        templates = self.list_command_templates()
        if not templates:
            return []

        project_root_resolved = project_root.resolve()
        if manifest.project_root != project_root_resolved:
            raise ValueError(
                f"manifest.project_root ({manifest.project_root}) does not match "
                f"project_root ({project_root_resolved})"
            )

        dest = self.commands_dest(project_root).resolve()
        try:
            dest.relative_to(project_root_resolved)
        except ValueError as exc:
            raise ValueError(
                f"Integration destination {dest} escapes project root {project_root_resolved}"
            ) from exc
        dest.mkdir(parents=True, exist_ok=True)

        script_type = opts.get("script_type", "sh")
        arg_placeholder = (
            self.registrar_config.get("args", "$ARGUMENTS")
            if self.registrar_config
            else "$ARGUMENTS"
        )
        created: list[Path] = []

        for src_file in templates:
            raw = src_file.read_text(encoding="utf-8")
            processed = self.process_template(
                raw,
                self.key,
                script_type,
                arg_placeholder,
                context_file=self.context_file or "",
            )
            # adr/0039 / PAR-04: gate capability sections (## Handoffs) the
            # provider can't use on the core install path.
            processed = self.gate_unsupported_sections(processed)
            base_name = self.command_base_name(src_file)
            # adr/0039 / PAR-03: the skill folder IS the skill name and the
            # file IS `SKILL.md`, matching the `<name>/SKILL.md` layout that
            # OpenCode (this base's only user) discovers — the previous
            # `fire-phoenix.<name>/fire-phoenix.<name>.md` layout was
            # undiscoverable (opencode.ai/docs/skills, verified 2026-07-07).
            # Content is still process_template-resolved (unlike the verbatim
            # SkillsIntegration providers) — only the layout changes.
            skill_dir = dest / base_name
            dst_file = self.write_file_and_record(
                processed, skill_dir / "SKILL.md", project_root, manifest
            )
            created.append(dst_file)

            from fire_phoenix_cli.skill_assets import bundle_skill_assets

            created.extend(
                bundle_skill_assets(skill_dir, src_file.parent.name, project_root, manifest)
            )

        # adr/0056: the caller owns the managed-section upsert (init's
        # post-scaffold phase / the standalone commands after setup()).

        return created
