"""Module entrypoint so ``python -m fire_phoenix_cli`` works the same as the ``fire-phoenix`` console script."""

from . import main

if __name__ == "__main__":
    main()
