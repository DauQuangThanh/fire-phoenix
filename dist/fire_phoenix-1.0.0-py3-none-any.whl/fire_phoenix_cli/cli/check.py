"""Health check commands for fire-phoenix projects.

Provides:
- `fire-phoenix check --skills` — validate installed skill files
- `fire-phoenix check --integrations` — check integration configs exist
- `fire-phoenix check --context` — validate .fire-phoenix/context.yml schema
- `fire-phoenix check` (no subcommand) — run all three checks in sequence

The validators live in sibling modules (`check_skills`, `check_integrations`,
`check_context`) alongside `check_common` and the `check_ac`/`check_trace`/
`check_approval`/`check_drift` families; this module owns only the Typer wiring
so every file stays under the 500-LOC ceiling (adr/0005 + adr/0058; D-05).
"""

from pathlib import Path

import typer
from rich.panel import Panel
from rich.table import Table

from . import app
from .check_common import CheckFinding, _render_findings, console
from .check_context import check_context
from .check_integrations import check_integrations
from .check_skills import check_skills

# Sub-app so `fire-phoenix check ...` groups the health-check commands under a single
# subcommand namespace. Registered with the main app at the bottom of this
# module so decorators fire at import time.
check_app = typer.Typer(
    name="check",
    help="Run health checks on the fire-phoenix project",
    add_completion=False,
    invoke_without_command=True,
)


@check_app.callback(invoke_without_command=True)
def check_all(ctx: typer.Context) -> None:
    """Run all health checks in sequence.

    If no subcommand is specified, runs --skills, --integrations, and --context.
    """
    if ctx.invoked_subcommand is not None:
        # A subcommand was specified, let it handle execution
        return

    # No subcommand — run all checks
    project_root = Path.cwd()
    console.print("[bold]fire-phoenix check — running all health checks[/bold]\n")

    exit_codes = []
    all_findings: list[CheckFinding] = []

    console.print("[bold]Checking skills...[/bold]")
    code, findings = check_skills(project_root)
    exit_codes.append(code)
    all_findings.extend(findings)
    console.print()

    console.print("[bold]Checking integrations...[/bold]")
    code, findings = check_integrations(project_root)
    exit_codes.append(code)
    all_findings.extend(findings)
    console.print()

    console.print("[bold]Checking context...[/bold]")
    code, findings = check_context(project_root)
    exit_codes.append(code)
    all_findings.extend(findings)
    console.print()

    # Render findings table if any
    if all_findings:
        table = Table(title="Findings", show_lines=True)
        table.add_column("File", style="cyan")
        table.add_column("Check", style="bold")
        table.add_column("Issue")
        table.add_column("Suggested Fix", style="green")
        for f in all_findings:
            table.add_row(f.file, f.check, f.actual, f.fix)
        console.print(table)
        console.print()

    # Exit code is max of all subchecks
    max_exit_code = max(exit_codes) if exit_codes else 0

    if max_exit_code == 0:
        console.print(
            Panel(
                "[green bold]ALL CHECKS PASSED[/green bold]",
                style="green",
            )
        )
    else:
        console.print(
            Panel(
                "[red bold]FAILURES DETECTED[/red bold]",
                style="red",
            )
        )

    raise typer.Exit(max_exit_code)


@check_app.command()
def skills() -> None:
    """Validate all skill files in integration directories."""
    exit_code, findings = check_skills(Path.cwd())
    if findings:
        _render_findings(findings)
    raise typer.Exit(exit_code)


@check_app.command()
def integrations() -> None:
    """Check that integration config files exist."""
    exit_code, findings = check_integrations(Path.cwd())
    if findings:
        _render_findings(findings)
    raise typer.Exit(exit_code)


@check_app.command()
def context() -> None:
    """Validate .fire-phoenix/context.yml schema."""
    exit_code, findings = check_context(Path.cwd())
    if findings:
        _render_findings(findings)
    raise typer.Exit(exit_code)


@check_app.command("trace")
def trace_cmd(
    feature: str | None = typer.Option(
        None, "--feature", help="Filter to contracts citing a feature slug"
    ),
    since: str | None = typer.Option(
        None, "--since", help="Git ref to look back from (default: all history)"
    ),
    json_output: bool = typer.Option(
        False, "--json", help="Emit JSON instead of writing a Markdown report"
    ),
) -> None:
    """Walk the 5-link audit chain (intent → spec → contract → commit). Per `adr/0025`."""
    from fire_phoenix_cli.cli.check_trace import run_trace

    raise typer.Exit(
        run_trace(feature=feature, since=since, json_output=json_output, project_root=Path.cwd())
    )


@check_app.command("ac")
def ac_cmd(
    epic: str | None = typer.Option(
        None, "--epic", help="Filter to one epic (substring match on the spec filename)"
    ),
    json_output: bool = typer.Option(
        False, "--json", help="Emit JSON instead of writing a Markdown report"
    ),
) -> None:
    """Report AC→test coverage per epic (COVERED / ORPHAN-AC / ORPHAN-CITATION). Per `adr/0032`."""
    from fire_phoenix_cli.cli.check_ac import run_ac_coverage

    raise typer.Exit(run_ac_coverage(epic=epic, json_output=json_output, project_root=Path.cwd()))


@check_app.command("approval")
def approval_cmd(
    change_id: str | None = typer.Option(
        None, "--change", help="Check one change delta by id (default: all active deltas)"
    ),
    json_output: bool = typer.Option(False, "--json", help="Emit JSON instead of Rich output"),
    allow_unclassified: bool = typer.Option(
        False,
        "--allow-unclassified",
        help="Pass changes with no recorded lane instead of failing closed (audited escape)",
    ),
) -> None:
    """Enforce graduated approval by lane: Critical needs dev/tester/PO. Per `adr/0050`."""
    from fire_phoenix_cli.cli.check_approval import run_approval_check

    raise typer.Exit(
        run_approval_check(
            change_id=change_id,
            json_output=json_output,
            project_root=Path.cwd(),
            allow_unclassified=allow_unclassified,
        )
    )


@check_app.command("drift")
def drift_cmd(
    since: str | None = typer.Option(None, "--since", help="Git ref to look back from"),
    json_output: bool = typer.Option(
        False, "--json", help="Emit JSON instead of writing a Markdown report"
    ),
) -> None:
    """Detect behavioural changes merged without paired intent amendments. Per `adr/0027`."""
    from fire_phoenix_cli.cli.check_drift import run_drift

    raise typer.Exit(run_drift(since=since, json_output=json_output))


# Register the check_app as a subcommand of the main app so users invoke
# `fire-phoenix check`, `fire-phoenix check skills`, `fire-phoenix check integrations`, `fire-phoenix check context`, `fire-phoenix check trace`, `fire-phoenix check ac`, `fire-phoenix check drift`.
app.add_typer(check_app, name="check")
