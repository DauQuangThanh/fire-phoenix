"""Shared bundled-asset integrity guard for install entrypoints (F-08).

One helper so every asset-install path — init, integration, preset, extension,
and workflow installs — verifies the bundled ``core_pack`` the same way and
prints the same recovery guidance. Previously only init and integration upgrade
checked, leaving preset/extension/workflow installs able to write from a
corrupt bundle.
"""

from __future__ import annotations

import typer

from fire_phoenix_cli.ui import console


def verify_core_pack_or_exit() -> None:
    """Verify bundled assets; abort with ``typer.Exit(1)`` on corruption.

    No-op when the core_pack cannot be located (e.g. an editable checkout that
    ships no ``sha256sums.txt``) — matching the existing init/upgrade behavior.
    """
    from fire_phoenix_cli._integrity import AssetCorruptionError, verify_asset_integrity
    from fire_phoenix_cli.installer import _locate_core_pack

    core_pack = _locate_core_pack()
    if not core_pack:
        return
    try:
        verify_asset_integrity(core_pack)
    except AssetCorruptionError as exc:
        console.print(f"[red]Error:[/red] Bundled asset integrity check failed: {exc}")
        console.print(
            "The fire-phoenix installation may be corrupted. Reinstall with: "
            "uv tool install fire-phoenix --force"
        )
        raise typer.Exit(1) from exc
