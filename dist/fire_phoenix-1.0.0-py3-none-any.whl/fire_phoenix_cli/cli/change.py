"""`fire-phoenix change ...` — the mechanical executor for change-delta verbs.

``archive`` (task-0095) folds a change's ``spec-delta.md`` into the living baseline
(one file per capability; last-fold-wins with flagged conflicts) and moves the
change to the archive. ``analyze`` + ``status`` (task-0097, closing the adr/0049 §9
re-verification gaps vs. Spec Kit / OpenSpec) add a read-only cross-artifact
consistency gate and a deterministic state-query. All are deterministic mechanics
the interactive ``change`` skill invokes — not the LLM classifier.
"""

from __future__ import annotations

import datetime
from pathlib import Path
from typing import Any

import typer
import yaml
from rich.console import Console

from fire_phoenix_cli._lock import guarded_mutation
from fire_phoenix_cli.changes import analyze_change, change_status, fold_change

from . import app

change_app = typer.Typer(name="change", help="Change-delta workflow executor (adr/0049).")
app.add_typer(change_app, name="change")

_CONSOLE = Console()


def _docs_dir(project_root: Path) -> str:
    ctx = project_root / ".fire-phoenix" / "context.yml"
    if ctx.is_file():
        try:
            data: dict[str, Any] = yaml.safe_load(ctx.read_text(encoding="utf-8")) or {}
            return (data.get("paths") or {}).get("docs", "docs")
        except (OSError, yaml.YAMLError):
            pass
    return "docs"


def run_archive(*, change_id: str, project_root: Path, date: str | None = None) -> int:
    """Fold + archive a change delta.

    Exit code (B10/task-0101):

    * ``0`` — folded cleanly, no conflicts.
    * ``3`` — folded (last-fold-wins applied) but one or more conflicts were flagged;
      surfaced so CI/automation can gate on a fold that overwrote a baseline capability
      instead of the previous always-green ``0``.
    * ``1`` — no such change, or the archive destination already exists (collision).
    """
    docs = project_root / _docs_dir(project_root)
    change_dir = docs / "changes" / change_id
    if not change_dir.is_dir():
        _CONSOLE.print(f"[red]✗[/red] no change delta at {change_dir}")
        return 1
    stamp = date or datetime.date.today().strftime("%Y%m%d")
    try:
        result = fold_change(
            change_dir,
            docs / "baseline",
            archive_root=docs / "changes" / "archive",
            date=stamp,
        )
    except FileExistsError as exc:
        _CONSOLE.print(f"[red]✗[/red] {exc}")
        return 1
    _CONSOLE.print(
        f"[green]✓[/green] folded {len(result.folded)} capability(ies) into baseline; "
        f"archived to {result.archived_to}"
    )
    for c in result.conflicts:
        _CONSOLE.print(
            f"[yellow]⚠[/yellow] conflict on {c.cap_id} ({c.kind}) — applied last-fold-wins; "
            f"resolve via baseline/.conflicts/{c.cap_id}.md (approver)"
        )
    return 3 if result.conflicts else 0


@change_app.command("archive")
@guarded_mutation
def archive_cmd(
    change_id: str = typer.Argument(..., help="Change delta id under {docs}/changes/"),
) -> None:
    """Fold a change's spec-delta into the baseline and archive it. Per `adr/0049` §4.1.

    Holds the project lock: fold-on-archive is a destructive baseline mutation
    (B8/task-0101).
    """
    raise typer.Exit(run_archive(change_id=change_id, project_root=Path.cwd()))


def run_analyze(*, change_id: str, project_root: Path) -> int:
    """Read-only cross-artifact consistency gate for a change delta (task-0097)."""
    change_dir = project_root / _docs_dir(project_root) / "changes" / change_id
    if not change_dir.is_dir():
        _CONSOLE.print(f"[red]✗[/red] no change delta at {change_dir}")
        return 1
    result = analyze_change(change_dir)
    if not result.findings:
        _CONSOLE.print(f"[green]✓[/green] {change_id}: no consistency findings")
        return 0
    _colour = {"CRITICAL": "red", "HIGH": "red", "MEDIUM": "yellow", "LOW": "bright_black"}
    for f in result.findings:
        c = _colour.get(f.severity, "white")
        _CONSOLE.print(f"[{c}]{f.severity}[/{c}] {f.kind}: {f.detail}")
    return result.exit_code


@change_app.command("analyze")
def analyze_cmd(
    change_id: str = typer.Argument(..., help="Change delta id under {docs}/changes/"),
) -> None:
    """Cross-artifact consistency gate (coverage / orphans / placeholders). Read-only."""
    raise typer.Exit(run_analyze(change_id=change_id, project_root=Path.cwd()))


def run_status(*, change_id: str | None, project_root: Path) -> int:
    """Report a delta's artifact presence, lane, and next verb (task-0097)."""
    docs = project_root / _docs_dir(project_root)
    changes = docs / "changes"
    if change_id is None:
        # No id → list active deltas.
        active = (
            sorted(d.name for d in changes.iterdir() if d.is_dir() and d.name != "archive")
            if changes.is_dir()
            else []
        )
        if not active:
            _CONSOLE.print("no active change deltas")
            return 0
        for cid in active:
            st = change_status(changes / cid, docs / "baseline")
            _CONSOLE.print(f"[bold]{cid}[/bold] (lane: {st.lane or '—'}) → next: {st.next_verb}")
        return 0
    change_dir = changes / change_id
    if not change_dir.is_dir():
        _CONSOLE.print(f"[red]✗[/red] no change delta at {change_dir}")
        return 1
    st = change_status(change_dir, docs / "baseline")
    _CONSOLE.print(f"[bold]{st.change_id}[/bold]  lane: {st.lane or '—'}")
    for name, ok in st.present.items():
        mark = "[green]✓[/green]" if ok else "[bright_black]·[/bright_black]"
        _CONSOLE.print(f"  {mark} {name}")
    _CONSOLE.print(f"  baseline capabilities: {st.baseline_capabilities}")
    _CONSOLE.print(f"  next verb: [cyan]{st.next_verb}[/cyan]")
    return 0


@change_app.command("status")
def status_cmd(
    change_id: str | None = typer.Argument(None, help="Change delta id (default: list active)"),
) -> None:
    """Report delta artifact presence, lane, and next verb (state query)."""
    raise typer.Exit(run_status(change_id=change_id, project_root=Path.cwd()))
