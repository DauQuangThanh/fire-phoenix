"""`fire-phoenix check integrations` — verify integration install dirs.

Confirms every configured integration is registered, its skill/command install
directory exists, and flags orphaned skill dirs that belong to no configured
integration. Extracted from `check.py` per D-05 (adr/0005 + adr/0058).
"""

from __future__ import annotations

from pathlib import Path

from fire_phoenix_cli.integrations import get_integration

from .check_common import (
    INTEGRATION_INSTALL_DIRS,
    CheckFinding,
    _get_installed_integrations,
    _get_integration_install_dir,
    console,
)


def check_integrations(project_root: Path | None = None) -> tuple[int, list[CheckFinding]]:
    """Check that integration config files exist.

    Returns (exit_code, findings_list).
    """
    if project_root is None:
        project_root = Path.cwd()

    findings: list[CheckFinding] = []
    integrations = _get_installed_integrations(project_root)
    if not integrations:
        console.print("[yellow]No integrations configured[/yellow]")
        return 0, findings

    expected_dirs: dict[str, Path] = {}

    for integration_key in integrations:
        integration = get_integration(integration_key)
        if not integration:
            findings.append(
                CheckFinding(
                    file=integration_key,
                    check="integrations",
                    expected="Registered integration",
                    actual=f"Unknown integration: {integration_key}",
                    fix=f"Remove '{integration_key}' from .fire-phoenix/integration.yml",
                )
            )
            continue

        skill_dir = _get_integration_install_dir(integration_key)
        if not skill_dir:
            findings.append(
                CheckFinding(
                    file=integration_key,
                    check="integrations",
                    expected="Install directory determinable",
                    actual="Cannot determine install dir",
                    fix=f"Run fire-phoenix integration install {integration_key}",
                )
            )
            continue

        expected_dirs[integration_key] = skill_dir
        full_path = project_root / skill_dir
        if full_path.exists():
            console.print(f"  [green]✓[/green] {integration_key}: {skill_dir}")
        else:
            findings.append(
                CheckFinding(
                    file=str(skill_dir),
                    check="integrations",
                    expected="Directory exists",
                    actual="MISSING",
                    fix=f"Run fire-phoenix integration install {integration_key}",
                )
            )

    # Scan for orphaned integration files. Only a directory that is itself a
    # skill/command install dir can be an "orphan"; init also deploys sibling
    # directories (e.g. `.claude/agents/`) that are NOT skill dirs and must
    # never be flagged — doing so made `check integrations` exit 1 on a
    # freshly initialized project.
    known_skill_leaves = {Path(p).name for p in INTEGRATION_INSTALL_DIRS.values()}
    known_skill_leaves.update(d.name for d in expected_dirs.values())
    for _expected_key, expected_dir in expected_dirs.items():
        parent_dir = project_root / expected_dir.parent
        if not parent_dir.exists():
            continue
        for item in parent_dir.iterdir():
            if not item.is_dir():
                continue
            if item.name not in known_skill_leaves:
                # Not a skill/command dir (e.g. agents/, references/) — init
                # infrastructure, not an orphan.
                continue
            is_configured = any(item.name == dir_path.name for dir_path in expected_dirs.values())
            if not is_configured:
                findings.append(
                    CheckFinding(
                        file=str(item.relative_to(project_root)),
                        check="integrations",
                        expected="Belongs to a configured integration",
                        actual="Orphaned directory",
                        fix="Remove manually or run fire-phoenix integration uninstall",
                    )
                )

    console.print()
    if not findings:
        console.print("[green]Integrations: OK[/green]")
    else:
        console.print("[red]Integrations: Issues found[/red]")

    return (0 if not findings else 1), findings
