"""`fire-phoenix check approval` — enforce graduated approval by change-lane and mode.

Per ``adr/0050`` (migration stage 3, task-0094): a **Critical**-lane change cannot
pass without recorded dev/tester/PO confirmations in the project's decisions file;
Mechanical/Routine/Consequential changes pass on the single-approver floor
(``adr/0012``), which is enforced by the existing sign-off process, not here.

Per ``adr/0054`` (lane-graduated autonomous approval, BC-IMP-Plan B-01): when the
effective mode is **AUTO** (``FIRE_PHOENIX_AGENT_MODE=auto`` — current practice
per ``adr/0046``; mode-source unification is B-02), a **Mechanical/Routine**
change is accepted only as a **POLICY approval**: a valid autonomy envelope must
exist and permit the change's lane, and the approval row carries provenance
(envelope path, envelope version, mode). No envelope, an invalid envelope, or an
unpermitted lane FAILS CLOSED with the missing element named. **Consequential and
Critical never take the policy path** — the ceiling is structural (adr/0054
negative constraints), regardless of envelope contents.

The lane is read from ``{paths.docs}/changes/<id>/lane`` (written by the
``change new`` skill). The three confirmations are matched in the decisions file
within a heading that names the change id and reads ``Critical sign-off``:

    ## <date> — <change-id> Critical sign-off (adr/0050)
    - Dev (feasibility): <name> — confirmed
    - Tester (testability): <name> — confirmed
    - PO (business fit): <name> — confirmed

The autonomy envelope (minimal contract per adr/0054; full schema is B-05) is a
YAML file resolved from ``governance.autonomy_envelope_file`` in
``.fire-phoenix/context.yml``, defaulting to ``{paths.docs}/autonomy-envelope.yml``,
with required fields ``version`` and ``permitted_lanes``.

Read-only; no network. Exit 0 = all lanes satisfied; 1 = a Critical change lacks
its confirmations or an AUTO-mode Mechanical/Routine change lacks a valid
envelope grant.
"""

from __future__ import annotations

import json
import os
import re
from pathlib import Path
from typing import Any

import yaml
from rich.console import Console

from .check_common import _load_context, _resolve_docs_dir

_CONSOLE = Console()

# Role tokens required for a Critical sign-off (adr/0050 three-amigos, required).
_ROLE_PATTERNS = {
    "dev": re.compile(r"^\s*[-*]\s*dev\b.*confirm", re.IGNORECASE),
    "tester": re.compile(r"^\s*[-*]\s*tester\b.*confirm", re.IGNORECASE),
    "po": re.compile(r"^\s*[-*]\s*po\b.*confirm", re.IGNORECASE),
}

# Lanes eligible for AUTO-mode policy approval (adr/0054). Consequential and
# Critical are NEVER members — the methodology ceiling is structural, not a
# configuration surface. Raising it is a re-decision (adr/0054 trigger #1).
_POLICY_LANES = frozenset({"mechanical", "routine"})

# Default envelope location, docs-rooted like the governance defaults (adr/0026).
_DEFAULT_ENVELOPE_NAME = "autonomy-envelope.yml"


def _resolve_decisions_file(project_root: Path, context: dict[str, Any]) -> Path:
    """Resolve the decisions file (governance.decisions_file), with fallbacks."""
    gov = context.get("governance") or {}
    candidates = [
        gov.get("decisions_file"),
        f"{_resolve_docs_dir(context)}/decisions.md",
        "decisions.md",
    ]
    for rel in candidates:
        if rel:
            p = project_root / rel
            if p.is_file():
                return p
    return project_root / "decisions.md"


def _effective_mode() -> str:
    """The run's effective mode: ``"auto"`` or ``"interactive"`` (the default).

    Read from ``FIRE_PHOENIX_AGENT_MODE``, the mode the workflow engine exports
    end-to-end (adr/0046). Anything other than ``auto`` — including unset — is
    HITL. Unifying the mode sources into one axis is BC-IMP-Plan B-02; when it
    lands, only this function changes.
    """
    raw = os.environ.get("FIRE_PHOENIX_AGENT_MODE", "").strip().lower()
    return "auto" if raw == "auto" else "interactive"


def _resolve_envelope_rel(context: dict[str, Any]) -> str:
    """Project-relative path of the autonomy envelope (adr/0054).

    ``governance.autonomy_envelope_file`` when set; else the docs-rooted
    default ``{paths.docs}/autonomy-envelope.yml``.
    """
    gov = context.get("governance") or {}
    configured = gov.get("autonomy_envelope_file")
    if configured:
        return str(configured)
    return f"{_resolve_docs_dir(context)}/{_DEFAULT_ENVELOPE_NAME}"


def _load_envelope(envelope_path: Path, envelope_rel: str) -> tuple[dict[str, Any] | None, str]:
    """Load and validate the minimal envelope contract (adr/0054).

    Returns ``(envelope, "")`` on success or ``(None, reason)`` naming exactly
    what is missing — the caller FAILS CLOSED on any reason; there is no
    fall-through to approved.
    """
    if not envelope_path.is_file():
        return None, f"no autonomy envelope at {envelope_rel}"
    try:
        data = yaml.safe_load(envelope_path.read_text(encoding="utf-8"))
    except (OSError, yaml.YAMLError) as exc:
        return None, f"envelope {envelope_rel} is not readable YAML ({exc.__class__.__name__})"
    if not isinstance(data, dict):
        return None, f"envelope {envelope_rel} must be a YAML mapping"
    missing = [key for key in ("version", "permitted_lanes") if not data.get(key)]
    if missing:
        return None, f"envelope {envelope_rel} missing required field(s): {', '.join(missing)}"
    lanes = data["permitted_lanes"]
    if not isinstance(lanes, list) or not all(isinstance(lane, str) for lane in lanes):
        return None, f"envelope {envelope_rel}: permitted_lanes must be a list of lane names"
    return data, ""


def _lane_of(change_dir: Path) -> str | None:
    lane_file = change_dir / "lane"
    if not lane_file.is_file():
        return None
    raw = lane_file.read_text(encoding="utf-8").strip().lower()
    if not raw:
        return None
    # Classify on the leading lane token so an annotation ("critical (security)",
    # "critical-security") is not silently downgraded off the Critical lane
    # (B5/task-0100). The four lanes are single words with no internal hyphens.
    return re.split(r"[\s(\-]+", raw, maxsplit=1)[0] or None


def _critical_confirmations(decisions_text: str, change_id: str) -> dict[str, bool]:
    """Which of dev/tester/PO are confirmed in the change's Critical sign-off block.

    Scans from a heading naming ``<change-id>`` + ``critical sign-off`` up to the
    next heading, matching the three role bullets.
    """
    found = {role: False for role in _ROLE_PATTERNS}
    lines = decisions_text.splitlines()
    in_block = False
    # Match the change id as a WHOLE token — not a hyphen/word-delimited prefix
    # of another id — so `login` is not credited with `login-flow`'s sign-off
    # block (B4/task-0100). `\b` treats `-` as a boundary, hence the explicit
    # `[\w-]` guards on both sides.
    head_re = re.compile(
        rf"^#{{1,6}}\s+.*(?<![\w-]){re.escape(change_id)}(?![\w-]).*critical sign-off",
        re.IGNORECASE,
    )
    for line in lines:
        if re.match(r"^#{1,6}\s", line):
            in_block = bool(head_re.match(line))
            continue
        if in_block:
            for role, pat in _ROLE_PATTERNS.items():
                if pat.match(line):
                    found[role] = True
    return found


def _change_dirs(project_root: Path, context: dict[str, Any]) -> list[Path]:
    changes = project_root / _resolve_docs_dir(context) / "changes"
    if not changes.is_dir():
        return []
    return sorted(d for d in changes.iterdir() if d.is_dir() and d.name != "archive")


def run_approval_check(
    *,
    change_id: str | None,
    json_output: bool,
    project_root: Path,
    allow_unclassified: bool = False,
) -> int:
    context = _load_context(project_root)
    decisions_text = ""
    decisions = _resolve_decisions_file(project_root, context)
    if decisions.is_file():
        decisions_text = decisions.read_text(encoding="utf-8")

    # adr/0054: in AUTO mode, Mechanical/Routine approval is policy-based and
    # requires a valid envelope. Resolved once per run; HITL never loads it.
    mode = _effective_mode()
    envelope_rel = _resolve_envelope_rel(context)
    envelope: dict[str, Any] | None = None
    envelope_error = ""
    if mode == "auto":
        envelope, envelope_error = _load_envelope(project_root / envelope_rel, envelope_rel)

    if change_id:
        target = project_root / _resolve_docs_dir(context) / "changes" / change_id
        if not target.is_dir():
            # A named change that does not exist must ERROR, not report success —
            # a typo'd `--change` id used to fall through to NO-LANE → exit 0,
            # a false "approved" signal (B3/task-0100).
            msg = f"change {change_id!r} not found under changes/"
            if json_output:
                print(json.dumps({"rows": [], "failures": 1, "error": msg}, indent=2))
            else:
                _CONSOLE.print(f"[red]✗[/red] {msg}")
            return 2
        targets = [target]
    else:
        targets = _change_dirs(project_root, context)

    rows: list[dict[str, Any]] = []
    failures = 0
    for change_dir in targets:
        cid = change_dir.name
        lane = _lane_of(change_dir)
        if lane is None:
            # An unclassified change (no `lane` file — e.g. the classifier crashed
            # before writing it) FAILS CLOSED: the gate cannot certify a change it
            # cannot classify, since it might be Critical (B2/task-0100, adr/0050).
            # `--allow-unclassified` is the single audited escape.
            if allow_unclassified:
                rows.append({"change": cid, "lane": None, "status": "UNCLASSIFIED-ALLOWED"})
            else:
                failures += 1
                rows.append({"change": cid, "lane": None, "status": "UNCLASSIFIED"})
            continue
        if lane != "critical":
            if mode == "auto" and lane in _POLICY_LANES:
                # adr/0054 policy path: no human token — a valid envelope that
                # permits the lane approves, with provenance. Anything short of
                # that FAILS CLOSED (never a silent fall-through to approved).
                permitted = (
                    []
                    if envelope is None
                    else [str(entry).strip().lower() for entry in envelope["permitted_lanes"]]
                )
                if envelope is None:
                    failures += 1
                    rows.append(
                        {
                            "change": cid,
                            "lane": lane,
                            "status": "NO-ENVELOPE",
                            "detail": envelope_error,
                        }
                    )
                elif lane not in permitted:
                    failures += 1
                    rows.append(
                        {
                            "change": cid,
                            "lane": lane,
                            "status": "LANE-NOT-PERMITTED",
                            "detail": (
                                f"lane {lane!r} not in envelope permitted_lanes "
                                f"{envelope['permitted_lanes']!r} ({envelope_rel})"
                            ),
                        }
                    )
                else:
                    rows.append(
                        {
                            "change": cid,
                            "lane": lane,
                            "status": "OK-POLICY",
                            # Provenance answers the AUTO audit question (adr/0054):
                            # which policy approved, under which envelope version.
                            "approval": {
                                "type": "policy",
                                "envelope": envelope_rel,
                                "envelope_version": str(envelope["version"]),
                                "mode": mode,
                            },
                        }
                    )
            else:
                # HITL floor (adr/0012 via adr/0050) — also AUTO Consequential,
                # whose escalation/parking is B-06, not this gate (adr/0054).
                rows.append({"change": cid, "lane": lane, "status": "OK-FLOOR"})
            continue
        confs = _critical_confirmations(decisions_text, cid)
        missing = [r for r, ok in confs.items() if not ok]
        if missing:
            failures += 1
            rows.append(
                {"change": cid, "lane": lane, "status": "MISSING-APPROVAL", "missing": missing}
            )
        else:
            rows.append({"change": cid, "lane": lane, "status": "OK-CRITICAL"})

    if json_output:
        print(json.dumps({"rows": rows, "failures": failures}, indent=2))
    else:
        for r in rows:
            if r["status"] == "MISSING-APPROVAL":
                _CONSOLE.print(
                    f"[red]✗[/red] {r['change']} (critical): missing "
                    f"{', '.join(r['missing'])} confirmation(s) — adr/0050"
                )
            elif r["status"] == "OK-CRITICAL":
                _CONSOLE.print(
                    f"[green]✓[/green] {r['change']} (critical): dev/tester/PO confirmed"
                )
            elif r["status"] == "OK-FLOOR":
                _CONSOLE.print(
                    f"[green]✓[/green] {r['change']} ({r['lane']}): single-approver floor"
                )
            elif r["status"] == "OK-POLICY":
                prov = r["approval"]
                _CONSOLE.print(
                    f"[green]✓[/green] {r['change']} ({r['lane']}): policy approval — "
                    f"envelope {prov['envelope']} v{prov['envelope_version']}, "
                    f"mode {prov['mode']} — adr/0054"
                )
            elif r["status"] in ("NO-ENVELOPE", "LANE-NOT-PERMITTED"):
                _CONSOLE.print(
                    f"[red]✗[/red] {r['change']} ({r['lane']}): AUTO mode requires a valid "
                    f"autonomy envelope grant — {r['detail']}. Provide/fix the envelope "
                    f"or run in HITL. adr/0054"
                )
            elif r["status"] == "UNCLASSIFIED":
                _CONSOLE.print(
                    f"[red]✗[/red] {r['change']}: no lane recorded — unclassified changes "
                    f"fail closed (pass --allow-unclassified to override). adr/0050"
                )
            elif r["status"] == "UNCLASSIFIED-ALLOWED":
                _CONSOLE.print(
                    f"[yellow]•[/yellow] {r['change']}: unclassified, allowed by "
                    f"--allow-unclassified"
                )
    return 1 if failures else 0
