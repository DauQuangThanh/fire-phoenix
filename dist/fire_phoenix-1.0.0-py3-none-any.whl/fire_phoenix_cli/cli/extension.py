"""Extension management commands (`fire-phoenix extension ...`).

This module is a thin Typer wiring layer. Each subcommand body lives in its own
file under ``cli/extension_commands/`` and is registered here. The split keeps
per-command modules small and diff-friendly, while preserving the exact CLI
surface (subcommand names, flags, help strings, output) the rest of the project
depends on.

The ``_locate_bundled_extension`` import below is intentional — tests patch
``fire_phoenix_cli.cli.extension._locate_bundled_extension`` to exercise the
``extension add`` offline-lookup path, so the symbol must remain bound on this
module.
"""

from __future__ import annotations

import typer

from fire_phoenix_cli.installer import (  # noqa: F401  — explicit re-export; test patch target
    _locate_bundled_extension as _locate_bundled_extension,
)

# Shared helpers (extracted in earlier Phase 6 work).
# BannerGroup and _version_callback are kept for Typer command-registration parity.
from fire_phoenix_cli.ui import (
    BannerGroup,  # noqa: F401  — Typer command-registration parity
    _version_callback,  # noqa: F401  — Typer command-registration parity
)

# The main Typer app created in fire_phoenix_cli.cli.__init__
from . import app
from .extension_commands.add import extension_add
from .extension_commands.disable import extension_disable
from .extension_commands.enable import extension_enable
from .extension_commands.info import extension_info
from .extension_commands.list_cmd import extension_list
from .extension_commands.remove import extension_remove
from .extension_commands.search import extension_search
from .extension_commands.set_priority import extension_set_priority
from .extension_commands.update import extension_update

extension_app = typer.Typer(
    name="extension",
    help="Manage fire-phoenix extensions",
    add_completion=False,
)

app.add_typer(extension_app, name="extension")

# Register extension subcommands.
extension_app.command("list")(extension_list)
extension_app.command("add")(extension_add)
extension_app.command("remove")(extension_remove)
extension_app.command("search")(extension_search)
extension_app.command("info")(extension_info)
extension_app.command("update")(extension_update)
extension_app.command("enable")(extension_enable)
extension_app.command("disable")(extension_disable)
extension_app.command("set-priority")(extension_set_priority)
