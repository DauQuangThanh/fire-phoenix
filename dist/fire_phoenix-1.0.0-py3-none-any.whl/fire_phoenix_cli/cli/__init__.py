"""CLI subpackage for fire-phoenix commands.

This module creates and configures the main Typer app,
delegating to submodules and command groups from the parent package.
"""

import sys

import typer

from fire_phoenix_cli.ui import Align, BannerGroup, show_banner

# Create the main Typer app
app = typer.Typer(
    name="fire-phoenix",
    help="Setup tool for fire-phoenix intent-driven development projects",
    add_completion=False,
    invoke_without_command=True,
    cls=BannerGroup,
)


@app.callback()
def callback(
    ctx: typer.Context,
    show_version: bool = typer.Option(
        False,
        "--version",
        "-V",
        callback=lambda v: __import__(
            "fire_phoenix_cli.ui", fromlist=["_version_callback"]
        )._version_callback(v),
        is_eager=True,
        help="Show version and exit.",
    ),
):
    """Show banner when no subcommand is provided."""
    if ctx.invoked_subcommand is None and "--help" not in sys.argv and "-h" not in sys.argv:
        show_banner()
        from rich.console import Console

        console = Console(highlight=False)
        console.print(Align.center("[dim]Run 'fire-phoenix --help' for usage information[/dim]"))
        console.print()


# Import command submodules. These must be imported AFTER `app`
# is defined so the decorators register on the same app instance.
# Each submodule imports AGENT_CONFIG directly from
# ``fire_phoenix_cli.installer`` (not from the package facade), so the
# load order here is independent of the top-level package's __init__.
from . import (  # noqa: E402
    change,  # noqa: F401, E402
    check,  # noqa: F401, E402
    extension,  # noqa: F401, E402
    init,  # noqa: F401, E402
    integration,  # noqa: F401, E402
    metrics,  # noqa: F401, E402
    preset,  # noqa: F401, E402
    version,  # noqa: F401, E402
    workflow,  # noqa: F401, E402
)


def main() -> None:
    """Console-script entry point (pyproject.toml -> fire-phoenix = 'fire_phoenix_cli:main').

    Top-level exception boundary (AC-PH-011): Typer handles its own
    ``typer.Exit``/``UsageError``, but anything else — an ``OSError`` from a
    read-only checkout, a ``yaml.YAMLError`` from hand-edited state, a
    ``PathTraversalError`` from hostile config — used to reach the user as a raw
    traceback. Surface a single actionable line and a non-zero exit instead.
    ``FIRE_PHOENIX_DEBUG`` re-raises so developers keep the traceback.
    """
    import os

    try:
        app()
    except (typer.Exit, SystemExit):
        raise
    except KeyboardInterrupt:
        from fire_phoenix_cli.ui import console

        console.print("\n[yellow]Interrupted.[/yellow]")
        # 130 = terminated by SIGINT, the shell convention.
        raise SystemExit(130) from None
    except Exception as exc:
        if os.environ.get("FIRE_PHOENIX_DEBUG"):
            raise
        from fire_phoenix_cli.ui import console

        console.print(f"[red]Error:[/red] {type(exc).__name__}: {exc}")
        console.print(
            "[dim]Set FIRE_PHOENIX_DEBUG=1 for the full traceback, or report this at "
            "https://github.com/DauQuangThanh/fire-phoenix/issues[/dim]"
        )
        raise SystemExit(1) from None
