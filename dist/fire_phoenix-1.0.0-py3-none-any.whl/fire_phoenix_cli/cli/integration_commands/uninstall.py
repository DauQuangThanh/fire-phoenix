"""``fire-phoenix integration uninstall`` — remove an installed integration."""

from pathlib import Path

import typer

from fire_phoenix_cli._lock import guarded_mutation
from fire_phoenix_cli.config import load_init_options, save_init_options
from fire_phoenix_cli.installer import (
    _read_integration_json,
    _remove_integration_from_json,
)
from fire_phoenix_cli.integrations.base import other_installed_share_context_file
from fire_phoenix_cli.ui import console

from ._common import integration_app


@integration_app.command("uninstall")
@guarded_mutation
def integration_uninstall(
    key: str = typer.Argument(
        None, help="Integration key to uninstall (default: current integration)"
    ),
    force: bool = typer.Option(False, "--force", help="Remove files even if modified"),
    all_integrations: bool = typer.Option(
        False, "--all", help="Uninstall all installed integrations"
    ),
):
    """Uninstall an integration, safely preserving modified files."""
    from fire_phoenix_cli.integrations import get_integration
    from fire_phoenix_cli.integrations.manifest import IntegrationManifest

    project_root = Path.cwd()

    fire_phoenix_dir = project_root / ".fire-phoenix"
    if not fire_phoenix_dir.exists():
        console.print("[red]Error:[/red] Not a fire-phoenix project (no .fire-phoenix/ directory)")
        console.print("Run this command from a fire-phoenix project root")
        raise typer.Exit(1)

    current = _read_integration_json(project_root)
    installed_keys = current.get("integrations", [])
    # Compat: fall back to singular field for pre-migration files.
    if not installed_keys and current.get("integration"):
        installed_keys = [current["integration"]]

    # --all: uninstall every installed integration in sequence
    if all_integrations:
        if not installed_keys:
            console.print("[yellow]No integrations are currently installed.[/yellow]")
            raise typer.Exit(0)
        for k in list(installed_keys):
            console.print(f"\n[bold]Uninstalling {k}…[/bold]")
            integration_uninstall(key=k, force=force, all_integrations=False)
        return

    if key is None:
        if not installed_keys:
            console.print("[yellow]No integration is currently installed.[/yellow]")
            raise typer.Exit(0)
        if len(installed_keys) == 1:
            key = installed_keys[0]
        else:
            console.print(
                "[red]Error:[/red] Multiple integrations installed. Specify which one to uninstall:"
            )
            for k in installed_keys:
                console.print(f"  - {k}")
            console.print("Or use [cyan]fire-phoenix integration uninstall --all[/cyan]")
            raise typer.Exit(1)

    if key not in installed_keys:
        console.print(f"[red]Error:[/red] Integration '{key}' is not installed.")
        if installed_keys:
            console.print(f"Installed integrations: {', '.join(installed_keys)}")
        raise typer.Exit(1)

    integration = get_integration(key)

    manifest_path = project_root / ".fire-phoenix" / "integrations" / f"{key}.manifest.yml"
    if not manifest_path.exists():
        console.print(
            f"[yellow]No manifest found for integration '{key}'. Nothing to uninstall.[/yellow]"
        )
        # Remove ONLY this key from the registry — the deprecated
        # `_remove_integration_json` deleted the entire integration.yml,
        # wiping every other installed integration.
        _remove_integration_from_json(project_root, key)
        # Clear integration-related keys from init-options.yml
        opts = load_init_options(project_root)
        if opts.get("integration") == key:
            opts.pop("integration", None)
            opts.pop("ai_skills", None)
            opts.pop("context_file", None)
            save_init_options(project_root, opts)
        # `return` (not `raise typer.Exit(0)`) so a missing manifest for one
        # key does not abort an enclosing `--all` loop (which invokes this
        # function recursively); a direct single-key call still exits 0.
        return

    try:
        manifest = IntegrationManifest.load(key, project_root)
    except (ValueError, FileNotFoundError) as exc:
        console.print(f"[red]Error:[/red] Integration manifest for '{key}' is unreadable.")
        console.print(f"Manifest: {manifest_path}")
        console.print(
            f"To recover, delete the unreadable manifest, run "
            f"[cyan]fire-phoenix integration uninstall {key}[/cyan] to clear stale metadata, "
            f"then run [cyan]fire-phoenix integration install {key}[/cyan] to regenerate."
        )
        console.print(f"[dim]Details:[/dim] {exc}")
        raise typer.Exit(1)  # noqa: B904

    removed, skipped = manifest.uninstall(project_root, force=force)

    # Remove managed context section from the agent context file — but ONLY if no
    # other still-installed integration shares that context file, else we would
    # strip a block those providers depend on (B6/task-0101).
    if integration and not other_installed_share_context_file(
        project_root, key, integration.context_file
    ):
        integration.remove_context_section(project_root)

    _remove_integration_from_json(project_root, key)

    # Update init-options.yml to remove the integration
    opts = load_init_options(project_root)
    integrations_list = opts.get("integrations", [])
    if key in integrations_list:
        integrations_list.remove(key)
        opts["integrations"] = integrations_list
    # Compat: clear old singular field
    if opts.get("integration") == key:
        opts.pop("integration", None)
    opts.pop("ai_skills", None)
    opts.pop("context_file", None)
    save_init_options(project_root, opts)

    name = (integration.config or {}).get("name", key) if integration else key
    console.print(f"\n[green]✓[/green] Integration '{name}' uninstalled")
    if removed:
        console.print(f"  Removed {len(removed)} file(s)")
    if skipped:
        console.print(f"\n[yellow]⚠[/yellow]  {len(skipped)} modified file(s) were preserved:")
        for path in skipped:
            rel = path.relative_to(project_root) if path.is_absolute() else path
            console.print(f"    {rel}")
