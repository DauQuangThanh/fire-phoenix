"""``fire-phoenix integration switch`` — replace one integration with another."""

import copy
import os
from pathlib import Path
from typing import Any

import typer

from fire_phoenix_cli._lock import guarded_mutation
from fire_phoenix_cli.config import load_init_options, save_init_options
from fire_phoenix_cli.installer import (
    _add_integration_to_json,
    _install_shared_infra,
    _read_integration_json,
    _remove_integration_from_json,
    _resolve_script_type,
    ensure_executable_scripts,
)
from fire_phoenix_cli.ui import console
from fire_phoenix_cli.version import get_fire_phoenix_version

from ._common import (
    _parse_integration_options,
    _update_init_options_for_integration,
    integration_app,
)


@integration_app.command("switch")
@guarded_mutation
def integration_switch(
    target: str = typer.Argument(
        help="Integration key to switch to (or <from> <to> when multiple installed)"
    ),
    source: str | None = typer.Argument(
        None, help="Integration key to replace (required when multiple installed)"
    ),
    script: str | None = typer.Option(
        None,
        "--script",
        help="Script type: sh or ps (default: from init-options.yml or platform default)",
    ),
    force: bool = typer.Option(
        False, "--force", help="Force removal of modified files during uninstall"
    ),
    integration_options: str | None = typer.Option(
        None, "--integration-options", help="Options for the target integration"
    ),
):
    """Switch from one integration to another.

    With one integration installed: ``fire-phoenix integration switch <to>``
    With multiple installed: ``fire-phoenix integration switch <from> <to>``
    """
    from fire_phoenix_cli.integrations import INTEGRATION_REGISTRY, get_integration
    from fire_phoenix_cli.integrations.manifest import IntegrationManifest

    # When two positional args: first=source, second=target
    if source is not None:
        # Two args: switch <from> <to>
        actual_source = target
        actual_target = source
        target = actual_target
        source = actual_source

    project_root = Path.cwd()

    fire_phoenix_dir = project_root / ".fire-phoenix"
    if not fire_phoenix_dir.exists():
        console.print("[red]Error:[/red] Not a fire-phoenix project (no .fire-phoenix/ directory)")
        console.print("Run this command from a fire-phoenix project root")
        raise typer.Exit(1)

    target_integration = get_integration(target)
    if target_integration is None:
        console.print(f"[red]Error:[/red] Unknown integration '{target}'")
        available = ", ".join(sorted(INTEGRATION_REGISTRY.keys()))
        console.print(f"Available integrations: {available}")
        raise typer.Exit(1)

    current = _read_integration_json(project_root)
    installed_keys = current.get("integrations", [])
    if not installed_keys and current.get("integration"):
        installed_keys = [current["integration"]]

    if target in installed_keys:
        console.print(
            f"[yellow]Integration '{target}' is already installed. Nothing to switch.[/yellow]"
        )
        raise typer.Exit(0)

    # Determine which integration to replace
    installed_key = source
    if installed_key is None:
        if len(installed_keys) == 1:
            installed_key = installed_keys[0]
        elif len(installed_keys) > 1:
            console.print(
                "[red]Error:[/red] Multiple integrations installed. Specify which to replace:"
            )
            console.print(f"  fire-phoenix integration switch <from> {target}")
            for k in installed_keys:
                console.print(f"  - {k}")
            raise typer.Exit(1)

    if installed_key and installed_key not in installed_keys:
        console.print(f"[red]Error:[/red] Integration '{installed_key}' is not installed.")
        raise typer.Exit(1)

    selected_script = _resolve_script_type(project_root, script)

    # Snapshot the pre-switch init-options so a failed target install can
    # restore the source integration's metadata exactly (see the Phase 2
    # rollback). Captured before any Phase 1 mutation.
    init_options_snapshot = copy.deepcopy(load_init_options(project_root))

    # Phase 1: Uninstall current integration (if any)
    if installed_key:
        current_integration = get_integration(installed_key)
        manifest_path = (
            project_root / ".fire-phoenix" / "integrations" / f"{installed_key}.manifest.yml"
        )

        if current_integration and manifest_path.exists():
            console.print(f"Uninstalling current integration: [cyan]{installed_key}[/cyan]")
            try:
                old_manifest = IntegrationManifest.load(installed_key, project_root)
            except (ValueError, FileNotFoundError) as exc:
                console.print(
                    f"[red]Error:[/red] Could not read integration manifest for '{installed_key}': {manifest_path}"
                )
                console.print(f"[dim]{exc}[/dim]")
                console.print(
                    f"To recover, delete the unreadable manifest at {manifest_path}, "
                    f"run [cyan]fire-phoenix integration uninstall {installed_key}[/cyan], then retry."
                )
                raise typer.Exit(1)  # noqa: B904
            removed, skipped = old_manifest.uninstall(project_root, force=force)
            # Preserve a shared context block another installed provider needs (B6/task-0101).
            from fire_phoenix_cli.integrations.base import other_installed_share_context_file

            if not other_installed_share_context_file(
                project_root, installed_key, current_integration.context_file
            ):
                current_integration.remove_context_section(project_root)
            if removed:
                console.print(f"  Removed {len(removed)} file(s)")
            if skipped:
                console.print(f"  [yellow]⚠[/yellow]  {len(skipped)} modified file(s) preserved")
        elif not current_integration and manifest_path.exists():
            # Integration removed from registry but manifest exists — use manifest-only uninstall
            console.print(f"Uninstalling unknown integration '{installed_key}' via manifest")
            try:
                old_manifest = IntegrationManifest.load(installed_key, project_root)
                removed, skipped = old_manifest.uninstall(project_root, force=force)
                if removed:
                    console.print(f"  Removed {len(removed)} file(s)")
                if skipped:
                    console.print(
                        f"  [yellow]⚠[/yellow]  {len(skipped)} modified file(s) preserved"
                    )
            except (ValueError, FileNotFoundError) as exc:
                console.print(
                    f"[yellow]Warning:[/yellow] Could not read manifest for '{installed_key}': {exc}"
                )
        else:
            console.print(
                f"[red]Error:[/red] Integration '{installed_key}' is installed but has no manifest."
            )
            console.print(
                f"Run [cyan]fire-phoenix integration uninstall {installed_key}[/cyan] to clear metadata, "
                f"then retry [cyan]fire-phoenix integration switch {target}[/cyan]."
            )
            raise typer.Exit(1)

        # Clear the source integration from metadata
        _remove_integration_from_json(project_root, installed_key)
        opts = load_init_options(project_root)
        integrations_list = opts.get("integrations", [])
        if installed_key in integrations_list:
            integrations_list.remove(installed_key)
            opts["integrations"] = integrations_list
        opts.pop("integration", None)
        opts.pop("ai_skills", None)
        opts.pop("context_file", None)
        save_init_options(project_root, opts)

    # Ensure shared infrastructure is present (safe to run unconditionally;
    # _install_shared_infra merges missing files without overwriting).
    _install_shared_infra(project_root)
    if os.name != "nt":
        ensure_executable_scripts(project_root)

    # Phase 2: Install target integration
    console.print(f"Installing integration: [cyan]{target}[/cyan]")
    manifest = IntegrationManifest(
        target_integration.key, project_root, version=get_fire_phoenix_version()
    )

    parsed_options: dict[str, Any] | None = None
    if integration_options:
        parsed_options = _parse_integration_options(target_integration, integration_options)

    try:
        target_integration.setup(
            project_root,
            manifest,
            parsed_options=parsed_options,
            script_type=selected_script,
            raw_options=integration_options,
        )
        # adr/0056: setup() no longer upserts the managed context section.
        target_integration.upsert_context_section(project_root)
        manifest.save()
        _add_integration_to_json(project_root, target_integration.key)
        _update_init_options_for_integration(project_root, target_integration)

    except Exception as e:
        # Attempt rollback of any files written by the target setup.
        try:
            target_integration.teardown(project_root, manifest, force=True)
        except Exception as rollback_err:
            console.print(
                f"[yellow]Warning:[/yellow] Failed to roll back integration '{target}': {rollback_err}"
            )
        _remove_integration_from_json(project_root, target_integration.key)

        # Compensating restore: Phase 1 already uninstalled the source, so a
        # failed target install would otherwise leave the project with NEITHER
        # integration. Re-setup the source and restore its metadata so `switch`
        # is transactional — on failure the pre-switch state is recovered.
        if installed_key:
            source_integration = get_integration(installed_key)
            if source_integration is not None:
                try:
                    restore_manifest = IntegrationManifest(
                        installed_key, project_root, version=get_fire_phoenix_version()
                    )
                    source_integration.setup(
                        project_root, restore_manifest, script_type=selected_script
                    )
                    # adr/0056: restore the source's managed context section too.
                    source_integration.upsert_context_section(project_root)
                    restore_manifest.save()
                    _add_integration_to_json(project_root, installed_key)
                    save_init_options(project_root, init_options_snapshot)
                    console.print(
                        f"[green]↩[/green] Restored previous integration '{installed_key}'"
                    )
                except Exception as restore_err:
                    console.print(
                        f"[yellow]Warning:[/yellow] Could not restore previous integration "
                        f"'{installed_key}': {restore_err}"
                    )
                    console.print(
                        f"To recover, run [cyan]fire-phoenix integration install {installed_key}[/cyan]."
                    )

        console.print(f"[red]Error:[/red] Failed to install integration '{target}': {e}")
        raise typer.Exit(1)  # noqa: B904

    name = (target_integration.config or {}).get("name", target)
    console.print(f"\n[green]✓[/green] Switched to integration '{name}'")
