"""``fire-phoenix integration install`` — add an integration to an existing project."""

import os
from pathlib import Path
from typing import Any

import typer

from fire_phoenix_cli._lock import guarded_mutation
from fire_phoenix_cli.installer import (
    _add_integration_to_json,
    _install_shared_infra,
    _read_integration_json,
    _remove_integration_from_json,
    _resolve_script_type,
    ensure_executable_scripts,
    install_context_reference,
    install_custom_agents,
    install_subagent_references,
)
from fire_phoenix_cli.ui import console
from fire_phoenix_cli.version import get_fire_phoenix_version

from ._common import (
    _parse_integration_options,
    _update_init_options_for_integration,
    integration_app,
)


@integration_app.command("install")
@guarded_mutation
def integration_install(
    key: str = typer.Argument(help="Integration key to install (e.g. claude, copilot)"),
    script: str | None = typer.Option(
        None,
        "--script",
        help="Script type: sh or ps (default: from init-options.yml or platform default)",
    ),
    integration_options: str | None = typer.Option(
        None,
        "--integration-options",
        help='Options for the integration (e.g. --integration-options="--commands-dir .myagent/cmds")',
    ),
):
    """Install an integration into an existing project."""
    from fire_phoenix_cli.integrations import INTEGRATION_REGISTRY, get_integration
    from fire_phoenix_cli.integrations.manifest import IntegrationManifest

    project_root = Path.cwd()

    fire_phoenix_dir = project_root / ".fire-phoenix"
    if not fire_phoenix_dir.exists():
        console.print("[red]Error:[/red] Not a fire-phoenix project (no .fire-phoenix/ directory)")
        console.print("Run this command from a fire-phoenix project root")
        raise typer.Exit(1)

    integration = get_integration(key)
    if integration is None:
        console.print(f"[red]Error:[/red] Unknown integration '{key}'")
        available = ", ".join(sorted(INTEGRATION_REGISTRY.keys()))
        console.print(f"Available integrations: {available}")
        raise typer.Exit(1)

    current = _read_integration_json(project_root)
    installed_keys = current.get("integrations", [])

    if key in installed_keys:
        console.print(f"[yellow]Integration '{key}' is already installed.[/yellow]")
        raise typer.Exit(0)

    selected_script = _resolve_script_type(project_root, script)

    # Ensure shared infrastructure is present (safe to run unconditionally;
    # _install_shared_infra merges missing files without overwriting).
    _install_shared_infra(project_root)
    if os.name != "nt":
        ensure_executable_scripts(project_root)

    manifest = IntegrationManifest(
        integration.key, project_root, version=get_fire_phoenix_version()
    )

    # Build parsed options from --integration-options
    parsed_options: dict[str, Any] | None = None
    if integration_options:
        parsed_options = _parse_integration_options(integration, integration_options)

    try:
        integration.setup(
            project_root,
            manifest,
            parsed_options=parsed_options,
            script_type=selected_script,
            raw_options=integration_options,
        )
        # adr/0056: setup() no longer upserts the managed context section —
        # do it explicitly (no scaffold in the standalone install path).
        integration.upsert_context_section(project_root)
        manifest.save()
        # PAR-01: deploy the role subagents (and shared references) for the
        # new provider, mirroring what `init` does — otherwise a provider
        # added post-init silently lacks the entire subagent layer, breaking
        # the multi-AI-symmetry invariant. Both calls are idempotent /
        # preserve-existing and fold subagent paths into the saved manifest.
        install_custom_agents(project_root, [integration.key])
        install_subagent_references(project_root)
        install_context_reference(project_root)
        _add_integration_to_json(project_root, integration.key)
        _update_init_options_for_integration(project_root, integration)

    except Exception as e:
        # Attempt rollback of any files written by setup
        try:
            integration.teardown(project_root, manifest, force=True)
        except Exception as rollback_err:
            # Suppress so the original setup error remains the primary failure
            console.print(
                f"[yellow]Warning:[/yellow] Failed to roll back integration changes: {rollback_err}"
            )
        # PAR-02: remove ONLY the failing key. `_remove_integration_json`
        # deletes the whole registry, erasing every other provider's
        # registration; `_remove_integration_from_json` removes just this key.
        _remove_integration_from_json(project_root, integration.key)
        console.print(f"[red]Error:[/red] Failed to install integration: {e}")
        raise typer.Exit(1)  # noqa: B904

    name = (integration.config or {}).get("name", key)
    console.print(f"\n[green]✓[/green] Integration '{name}' installed successfully")
