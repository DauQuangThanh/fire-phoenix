"""``fire-phoenix integration upgrade`` — reinstall with diff-aware file handling."""

import os
from pathlib import Path
from typing import Any

import typer

from fire_phoenix_cli._lock import guarded_mutation
from fire_phoenix_cli.installer import (
    _add_integration_to_json,
    _install_shared_infra,
    _read_integration_json,
    _resolve_script_type,
    ensure_executable_scripts,
    install_context_reference,
    install_custom_agents,
    install_governance_hooks,
    install_subagent_references,
)
from fire_phoenix_cli.ui import console
from fire_phoenix_cli.version import get_fire_phoenix_version

from ._common import (
    _parse_integration_options,
    _update_init_options_for_integration,
    integration_app,
)


@integration_app.command("upgrade")
@guarded_mutation
def integration_upgrade(
    key: str | None = typer.Argument(
        None, help="Integration key to upgrade (default: current integration)"
    ),
    force: bool = typer.Option(False, "--force", help="Force upgrade even if files are modified"),
    all_integrations: bool = typer.Option(
        False, "--all", help="Upgrade all installed integrations"
    ),
    script: str | None = typer.Option(
        None,
        "--script",
        help="Script type: sh or ps (default: from init-options.yml or platform default)",
    ),
    integration_options: str | None = typer.Option(
        None, "--integration-options", help="Options for the integration"
    ),
):
    """Upgrade an integration by reinstalling with diff-aware file handling.

    Compares manifest hashes to detect locally modified files and
    blocks the upgrade unless --force is used.
    """
    from fire_phoenix_cli.integrations import get_integration
    from fire_phoenix_cli.integrations.manifest import IntegrationManifest

    project_root = Path.cwd()

    fire_phoenix_dir = project_root / ".fire-phoenix"
    if not fire_phoenix_dir.exists():
        console.print("[red]Error:[/red] Not a fire-phoenix project (no .fire-phoenix/ directory)")
        console.print("Run this command from a fire-phoenix project root")
        raise typer.Exit(1)

    current = _read_integration_json(project_root)
    installed_keys = current.get("integrations", [])
    if not installed_keys and current.get("integration"):
        installed_keys = [current["integration"]]

    # --all: upgrade every installed integration in sequence, stop at first failure
    if all_integrations:
        if not installed_keys:
            console.print("[yellow]No integrations are currently installed.[/yellow]")
            raise typer.Exit(0)
        for k in list(installed_keys):
            console.print(f"\n[bold]Upgrading {k}…[/bold]")
            integration_upgrade(
                key=k,
                force=force,
                all_integrations=False,
                script=script,
                integration_options=integration_options,
            )
        return

    if key is None:
        if not installed_keys:
            console.print("[yellow]No integration is currently installed.[/yellow]")
            raise typer.Exit(0)
        if len(installed_keys) == 1:
            key = installed_keys[0]
        else:
            console.print(
                "[red]Error:[/red] Multiple integrations installed. Specify which one to upgrade:"
            )
            for k in installed_keys:
                console.print(f"  - {k}")
            console.print("Or use [cyan]fire-phoenix integration upgrade --all[/cyan]")
            raise typer.Exit(1)

    if key not in installed_keys:
        console.print(f"[red]Error:[/red] Integration '{key}' is not installed.")
        console.print(f"Use [cyan]fire-phoenix integration install {key}[/cyan] to install it.")
        raise typer.Exit(1)

    integration = get_integration(key)
    if integration is None:
        console.print(f"[red]Error:[/red] Unknown integration '{key}'")
        raise typer.Exit(1)

    manifest_path = project_root / ".fire-phoenix" / "integrations" / f"{key}.manifest.yml"
    if not manifest_path.exists():
        console.print(
            f"[yellow]No manifest found for integration '{key}'. Nothing to upgrade.[/yellow]"
        )
        console.print(
            f"Run [cyan]fire-phoenix integration install {key}[/cyan] to perform a fresh install."
        )
        raise typer.Exit(0)

    try:
        old_manifest = IntegrationManifest.load(key, project_root)
    except (ValueError, FileNotFoundError) as exc:
        console.print(f"[red]Error:[/red] Integration manifest for '{key}' is unreadable: {exc}")
        raise typer.Exit(1)  # noqa: B904

    # Detect modified files via manifest hashes
    modified = old_manifest.check_modified()
    if modified and not force:
        console.print(
            f"[yellow]⚠[/yellow]  {len(modified)} file(s) have been modified since installation:"
        )
        for rel in modified:
            console.print(f"    {rel}")
        console.print(
            "\nUse [cyan]--force[/cyan] to overwrite modified files, or resolve manually."
        )
        raise typer.Exit(1)

    selected_script = _resolve_script_type(project_root, script)

    # Verify asset integrity before reading the bundle (F-08).
    from ..integrity_guard import verify_core_pack_or_exit

    verify_core_pack_or_exit()

    # Ensure shared infrastructure is up to date; --force overwrites existing files.
    _install_shared_infra(project_root, force=force)
    if os.name != "nt":
        ensure_executable_scripts(project_root)

    # Phase 1: Install new files (overwrites existing; old-only files remain)
    console.print(f"Upgrading integration: [cyan]{key}[/cyan]")
    new_manifest = IntegrationManifest(key, project_root, version=get_fire_phoenix_version())

    parsed_options: dict[str, Any] | None = None
    if integration_options:
        parsed_options = _parse_integration_options(integration, integration_options)

    try:
        integration.setup(
            project_root,
            new_manifest,
            parsed_options=parsed_options,
            script_type=selected_script,
            raw_options=integration_options,
        )
        # adr/0056: refresh the managed context section explicitly (setup()
        # no longer does it; upgrade has no scaffold — marker-block only).
        integration.upsert_context_section(project_root)
        new_manifest.save()
        # SAF-01: `setup()` records skills + context but NOT the role
        # subagents, so they live only in the OLD manifest. Re-install them
        # (mirroring `init`) and reload the manifest so the subagent paths
        # are part of `new_manifest` BEFORE the stale computation below —
        # otherwise Phase 2 treats all 14 subagents as stale and deletes them.
        install_custom_agents(project_root, [key], force=force)
        install_subagent_references(project_root)
        install_context_reference(project_root)
        # AC-PH-002: the governance guardrail pack was init-only, so every
        # upgrade silently uninstalled it (its files fell out of the rebuilt
        # manifest and Phase 2 swept them). Re-run it here, before the reload,
        # so the pack is both present and manifest-tracked.
        install_governance_hooks(project_root, [key], force=force)
        new_manifest = IntegrationManifest.load(key, project_root)
        # AC-PH-001: the rebuilt manifest must not forget which files
        # pre-existed the install and were polite-merged — losing `merged:`
        # turns a later uninstall into an unlink() of the user's own config.
        new_manifest.carry_merged_from(old_manifest)
        new_manifest.save()
        # Append (idempotent) — must NOT rewrite the registry to ``[key]``,
        # which erased every other installed integration on upgrade.
        _add_integration_to_json(project_root, key)
        _update_init_options_for_integration(project_root, integration)
    except Exception as exc:
        # Don't teardown — setup overwrites in-place, so teardown would
        # delete files that were working before the upgrade.  Just report.
        console.print(f"[red]Error:[/red] Failed to upgrade integration: {exc}")
        console.print("[yellow]The previous integration files may still be in place.[/yellow]")
        raise typer.Exit(1)  # noqa: B904

    # Phase 2: Remove stale files from old manifest that are not in the new one
    old_files = old_manifest.files
    new_files = new_manifest.files
    stale_keys = set(old_files) - set(new_files)
    if stale_keys:
        stale_manifest = IntegrationManifest(key, project_root, version="stale-cleanup")
        stale_manifest._files = {k: old_files[k] for k in stale_keys}
        # AC-PH-001: a stale entry the user polite-merged into is un-merged,
        # never unlinked; and the sweep honours the same hash guard as any
        # uninstall (force=True here force-deleted user-modified files).
        # `remove_manifest=False`: this synthetic manifest shares the real
        # integration key, so removing "its" manifest file would delete the
        # freshly written one.
        stale_manifest._merged = {
            k: old_manifest._merged[k] for k in stale_keys if k in old_manifest._merged
        }
        stale_removed, stale_skipped = stale_manifest.uninstall(
            project_root, force=force, remove_manifest=False
        )
        if stale_removed:
            console.print(f"  Removed {len(stale_removed)} stale file(s) from previous install")
        if stale_skipped:
            console.print(
                f"  Kept {len(stale_skipped)} stale file(s) that were modified locally "
                "(use --force to remove)"
            )

    name = (integration.config or {}).get("name", key)
    console.print(f"\n[green]✓[/green] Integration '{name}' upgraded successfully")
