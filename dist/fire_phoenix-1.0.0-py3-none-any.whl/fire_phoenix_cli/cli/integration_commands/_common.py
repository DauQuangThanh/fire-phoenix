"""Shared helpers and the ``integration_app`` Typer group.

The Typer subcommand group lives here so per-command modules can register
against a single instance. ``_parse_integration_options`` is re-exported
from ``cli/integration.py`` as public API (see ``fire_phoenix_cli.__init__``).
"""

import shlex
from pathlib import Path
from typing import Any

import typer

from fire_phoenix_cli.cli import app
from fire_phoenix_cli.config import load_init_options, save_init_options
from fire_phoenix_cli.ui import console

integration_app = typer.Typer(
    name="integration",
    help="Manage AI agent integrations",
    add_completion=False,
)

app.add_typer(integration_app, name="integration")


def _parse_integration_options(integration: Any, raw_options: str) -> dict[str, Any] | None:
    """Parse --integration-options string into a dict matching the integration's declared options.

    Returns ``None`` when no options are provided.
    """
    parsed: dict[str, Any] = {}
    tokens = shlex.split(raw_options)
    declared_options = list(integration.options())
    declared = {opt.name.lstrip("-"): opt for opt in declared_options}
    allowed = ", ".join(sorted(opt.name for opt in declared_options))
    i = 0
    while i < len(tokens):
        token = tokens[i]
        if not token.startswith("-"):
            console.print(f"[red]Error:[/red] Unexpected integration option value '{token}'.")
            if allowed:
                console.print(f"Allowed options: {allowed}")
            raise typer.Exit(1)
        name = token.lstrip("-")
        value: str | None = None
        # Handle --name=value syntax
        if "=" in name:
            name, value = name.split("=", 1)
        opt = declared.get(name)
        if not opt:
            console.print(f"[red]Error:[/red] Unknown integration option '{token}'.")
            if allowed:
                console.print(f"Allowed options: {allowed}")
            raise typer.Exit(1)
        key = name.replace("-", "_")
        if opt.is_flag:
            if value is not None:
                console.print(
                    f"[red]Error:[/red] Option '{opt.name}' is a flag and does not accept a value."
                )
                raise typer.Exit(1)
            parsed[key] = True
            i += 1
        elif value is not None:
            parsed[key] = value
            i += 1
        elif i + 1 < len(tokens) and not tokens[i + 1].startswith("-"):
            parsed[key] = tokens[i + 1]
            i += 2
        else:
            console.print(f"[red]Error:[/red] Option '{opt.name}' requires a value.")
            raise typer.Exit(1)
    return parsed or None


def _update_init_options_for_integration(
    project_root: Path,
    integration: Any,
) -> None:
    """Update ``init-options.yml`` to reflect *integration* as the active one."""
    from fire_phoenix_cli.integrations.skills_integration import SkillsIntegration

    opts = load_init_options(project_root)
    # Multi-integration: append to list, keep singular for compat
    integrations_list = opts.get("integrations", [])
    if integration.key not in integrations_list:
        integrations_list.append(integration.key)
    opts["integrations"] = integrations_list
    opts["integration"] = integration.key
    opts["context_file"] = integration.context_file
    # Legacy projects may still carry a persisted "script" entry. Drop it —
    # script variant is selected at runtime from the current platform.
    opts.pop("script", None)
    if isinstance(integration, SkillsIntegration):
        opts["ai_skills"] = True
    else:
        opts.pop("ai_skills", None)
    save_init_options(project_root, opts)
