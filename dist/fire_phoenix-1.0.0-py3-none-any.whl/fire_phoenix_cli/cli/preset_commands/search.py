"""`fire-phoenix preset search` — search for presets in the catalog."""

from __future__ import annotations

import typer

from fire_phoenix_cli.cli._project import require_fire_phoenix_project
from fire_phoenix_cli.ui import console

from ..preset import preset_app


@preset_app.command("search")
def preset_search(
    query: str = typer.Argument(None, help="Search query"),
    tag: str = typer.Option(None, "--tag", help="Filter by tag"),
    author: str = typer.Option(None, "--author", help="Filter by author"),
) -> None:
    """Search for presets in the catalog."""
    from fire_phoenix_cli.presets import PresetCatalog, PresetError

    project_root = require_fire_phoenix_project()

    catalog = PresetCatalog(project_root)

    try:
        results = catalog.search(query=query, tag=tag, author=author)
    except PresetError as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1)  # noqa: B904

    if not results:
        console.print("[yellow]No presets found matching your criteria.[/yellow]")
        return

    console.print(f"\n[bold cyan]Presets ({len(results)} found):[/bold cyan]\n")
    for pack in results:
        console.print(
            f"  [bold]{pack.get('name', pack['id'])}[/bold] ({pack['id']}) v{pack.get('version', '?')}"
        )
        console.print(f"    {pack.get('description', '')}")
        if pack.get("tags"):
            tags_str = ", ".join(pack["tags"])
            console.print(f"    [dim]Tags: {tags_str}[/dim]")
        console.print()
