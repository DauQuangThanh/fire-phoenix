"""`fire-phoenix preset disable` — disable a preset without removing it."""

from __future__ import annotations

import typer

from fire_phoenix_cli._lock import guarded_mutation
from fire_phoenix_cli.cli._project import require_fire_phoenix_project
from fire_phoenix_cli.ui import console

from ..preset import preset_app


@preset_app.command("disable")
@guarded_mutation
def preset_disable(
    preset_id: str = typer.Argument(help="Preset ID to disable"),
) -> None:
    """Disable a preset without removing it."""
    from fire_phoenix_cli.presets import PresetManager

    project_root = require_fire_phoenix_project()

    manager = PresetManager(project_root)

    # Check if preset is installed
    if not manager.registry.is_installed(preset_id):
        console.print(f"[red]Error:[/red] Preset '{preset_id}' is not installed")
        raise typer.Exit(1)

    # Get current metadata
    metadata = manager.registry.get(preset_id)
    if metadata is None or not isinstance(metadata, dict):
        console.print(
            f"[red]Error:[/red] Preset '{preset_id}' not found in registry (corrupted state)"
        )
        raise typer.Exit(1)

    if not metadata.get("enabled", True):
        console.print(f"[yellow]Preset '{preset_id}' is already disabled[/yellow]")
        raise typer.Exit(0)

    # Disable the preset
    manager.registry.update(preset_id, {"enabled": False})

    console.print(f"[green]✓[/green] Preset '{preset_id}' disabled")
    console.print("\nTemplates from this preset will be skipped during resolution.")
    console.print(
        "[dim]Note: Previously registered commands/skills remain active until preset removal.[/dim]"
    )
    console.print(f"To re-enable: fire-phoenix preset enable {preset_id}")
