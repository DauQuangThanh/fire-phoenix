"""`fire-phoenix preset resolve` — show which template will be resolved for a given name."""

from __future__ import annotations

import typer

from fire_phoenix_cli.cli._project import require_fire_phoenix_project
from fire_phoenix_cli.ui import console

from ..preset import preset_app


@preset_app.command("resolve")
def preset_resolve(
    template_name: str = typer.Argument(..., help="Template name to resolve (e.g., spec-template)"),
) -> None:
    """Show which template will be resolved for a given name."""
    from fire_phoenix_cli.presets import PresetResolver

    project_root = require_fire_phoenix_project()

    resolver = PresetResolver(project_root)
    result = resolver.resolve_with_source(template_name)

    if result:
        console.print(f"  [bold]{template_name}[/bold]: {result['path']}")
        console.print(f"    [dim](from: {result['source']})[/dim]")
    else:
        console.print(f"  [yellow]{template_name}[/yellow]: not found")
        console.print("    [dim]No template with this name exists in the resolution stack[/dim]")
