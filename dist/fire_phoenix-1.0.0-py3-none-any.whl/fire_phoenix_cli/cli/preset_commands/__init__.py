"""Per-command modules for `fire-phoenix preset ...`.

This package decomposes the previously monolithic cli/preset.py into one
module per subcommand. The Typer app declarations live in cli/preset.py;
each submodule registers its command(s) on those apps at import time.

Submodules must be imported AFTER the Typer apps are constructed in
cli/preset.py, which performs the explicit imports.
"""
