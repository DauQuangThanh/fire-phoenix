"""`fire-phoenix check skills` — validate installed skill files.

Validates every ``SKILL.md`` under each installed integration's skill dir for
agentskills.io compliance (frontmatter fields, name/description shape, required
body sections, no hardcoded paths, standard placeholders only). Extracted from
`check.py` per D-05 (adr/0005 + adr/0058).
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any

import yaml

from .check_common import (
    CheckFinding,
    _get_installed_integrations,
    _get_integration_install_dir,
    console,
)

# Allowed top-level frontmatter fields per agentskills.io
ALLOWED_FRONTMATTER_FIELDS = {
    "name",
    "description",
    "license",
    "compatibility",
    "metadata",
    "allowed-tools",
}

# Standard placeholder vocabulary (Phase 5.3)
STANDARD_PLACEHOLDERS = {
    "{context.paths.intents}",
    "{context.paths.plans}",
    "{context.paths.tasks}",
    "{context.paths.templates}",
    "{context.paths.scripts}",
    "{context.current.feature}",
    "{context.current.intent}",
    "{context.current.plan}",
    "{context.current.tasks}",
    "{context.current.checklist}",
    "{context.current.branch}",
    "{context.preferences.confirm_before_write}",
}

# Required body sections per Phase 5.4
REQUIRED_BODY_SECTIONS = {
    "## Inputs",
    "## Outputs",
    "## Context Update",
}


def _extract_frontmatter_and_body(content: str) -> tuple[dict[str, Any], str]:
    """Extract YAML frontmatter and Markdown body."""
    lines = content.split("\n")
    if not lines or not lines[0].startswith("---"):
        return {}, content

    end_idx = None
    for i in range(1, len(lines)):
        if lines[i].startswith("---"):
            end_idx = i
            break

    if end_idx is None:
        return {}, content

    fm_text = "\n".join(lines[1:end_idx])
    body_text = "\n".join(lines[end_idx + 1 :])

    try:
        fm = yaml.safe_load(fm_text) or {}
    except yaml.YAMLError:
        fm = {}

    return fm, body_text


def _validate_skill_file(skill_path: Path) -> tuple[bool, str]:
    """Validate a single skill file for agentskills.io compliance.

    Returns (is_valid, message).
    """
    try:
        content = skill_path.read_text(encoding="utf-8")
    except Exception as e:
        return False, f"Failed to read: {e}"

    fm, body = _extract_frontmatter_and_body(content)

    # Check: has name and description
    if "name" not in fm:
        return False, "Missing 'name' field"
    if "description" not in fm:
        return False, "Missing 'description' field"

    # Check: only allowed frontmatter fields
    non_standard = set(fm.keys()) - ALLOWED_FRONTMATTER_FIELDS
    if non_standard:
        return False, f"Non-standard frontmatter fields: {non_standard}"

    # Check: name format
    name = fm.get("name", "")
    if not (1 <= len(name) <= 64):
        return False, f"Name length {len(name)} not in range 1-64"
    if not re.match(r"^[a-z0-9]+(-[a-z0-9]+)*$", name):
        return False, f"Name format invalid: {name}"

    # Check: description length
    desc = fm.get("description", "")
    if not (1 <= len(desc) <= 1024):
        return False, f"Description length {len(desc)} not in range 1-1024"

    # Check: has required body sections
    missing_sections = []
    for section in REQUIRED_BODY_SECTIONS:
        if section not in body:
            missing_sections.append(section)
    if missing_sections:
        return False, f"Missing body sections: {missing_sections}"

    # Check: no handoffs in frontmatter
    if "handoffs" in fm:
        return False, "Handoffs must be in body (## Handoffs), not frontmatter"

    # Check: no hardcoded paths
    hardcoded_patterns = [
        r"\.specify/specs/",
        r"\.specify/plans/",
        r"\.specify/taskify/",
        r"\.specify/templates/",
        r"\.specify/scripts/",
        r"\.fire-phoenix/specs/",
        r"\.fire-phoenix/plans/",
        r"\.fire-phoenix/tasks/",
        r"\.fire-phoenix/templates/",
        r"\.fire-phoenix/scripts/",
    ]
    for pattern in hardcoded_patterns:
        if re.search(pattern, body):
            return False, f"Hardcoded path found: {pattern}"

    # Check: only standard placeholders
    found_placeholders = set(re.findall(r"\{context\.\S+?\}", body))
    non_standard = found_placeholders - STANDARD_PLACEHOLDERS
    if non_standard:
        return False, f"Non-standard placeholders: {non_standard}"

    # Check: metadata has author and version
    metadata = fm.get("metadata", {})
    if "author" not in metadata:
        return False, "Missing metadata.author"
    if "version" not in metadata:
        return False, "Missing metadata.version"

    return True, "OK"


def check_skills(project_root: Path | None = None) -> tuple[int, list[CheckFinding]]:
    """Validate all skill files in integration directories.

    Returns (exit_code, findings_list).
    """
    if project_root is None:
        project_root = Path.cwd()

    findings: list[CheckFinding] = []
    integrations = _get_installed_integrations(project_root)
    if not integrations:
        console.print("[yellow]No integrations configured[/yellow]")
        return 0, findings

    total = 0
    passed = 0

    for integration_key in integrations:
        skill_dir = _get_integration_install_dir(integration_key)
        if not skill_dir:
            findings.append(
                CheckFinding(
                    file=integration_key,
                    check="skills",
                    expected="Known integration key",
                    actual=f"Unknown integration: {integration_key}",
                    fix=f"Run fire-phoenix integration install {integration_key}",
                )
            )
            continue

        full_skill_dir = project_root / skill_dir
        if not full_skill_dir.exists():
            findings.append(
                CheckFinding(
                    file=str(skill_dir),
                    check="skills",
                    expected="Skill directory exists",
                    actual="Directory not found",
                    fix=f"Run fire-phoenix integration install {integration_key}",
                )
            )
            continue

        for subdir in full_skill_dir.iterdir():
            if not subdir.is_dir():
                continue
            skill_file = subdir / "SKILL.md"
            if skill_file.exists():
                total += 1
                is_valid, message = _validate_skill_file(skill_file)
                if is_valid:
                    passed += 1
                else:
                    findings.append(
                        CheckFinding(
                            file=str(skill_file.relative_to(project_root)),
                            check="skills",
                            expected="Valid SKILL.md",
                            actual=message,
                            fix=f"Run fire-phoenix integration upgrade {integration_key} --force",
                        )
                    )

    # Print summary
    console.print()
    summary = f"Skills: {passed}/{total} passed" if total else "No skill files found"
    if not findings:
        console.print(f"[green]{summary}[/green]")
    else:
        console.print(f"[red]{summary}[/red]")

    return (0 if not findings else 1), findings
