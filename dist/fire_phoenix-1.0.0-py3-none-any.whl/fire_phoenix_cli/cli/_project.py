"""Shared project-root guard for the domain CLI command groups.

The ``preset`` / ``workflow`` / ``extension`` command groups each carried their
own copy of this guard; they are consolidated here so the "is this a
fire-phoenix project?" check is defined once. The ``hint`` flag preserves each
group's original error output — preset and extension emit the guidance line,
workflow historically did not.
"""

from __future__ import annotations

from pathlib import Path

import typer

from fire_phoenix_cli.ui import console


def require_fire_phoenix_project(*, hint: bool = True) -> Path:
    """Return the current directory, or exit 1 if it is not a project root.

    A fire-phoenix project root contains a ``.fire-phoenix/`` directory. When
    ``hint`` is true (the default) a second line points the user at the project
    root; callers that historically emitted only the error line pass
    ``hint=False`` to keep their output byte-identical.
    """
    project_root = Path.cwd()
    if not (project_root / ".fire-phoenix").exists():
        console.print("[red]Error:[/red] Not a fire-phoenix project (no .fire-phoenix/ directory)")
        if hint:
            console.print("Run this command from a fire-phoenix project root")
        raise typer.Exit(1)
    return project_root
