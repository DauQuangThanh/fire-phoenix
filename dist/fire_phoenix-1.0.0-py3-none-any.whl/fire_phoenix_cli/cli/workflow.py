"""Typer wiring for `fire-phoenix workflow ...`.

Per Tier 2 R2 decomposition: each subcommand body lives in
`cli/workflow_commands/<name>.py`; this module only constructs the Typer apps and
registers the command callbacks. Decorators fire at import time, which is why
`cli/__init__.py` imports this module explicitly.
"""

import typer

# BannerGroup and _version_callback are kept for Typer command-registration parity.
from fire_phoenix_cli.ui import (
    BannerGroup,  # noqa: F401 — Typer command-registration parity
    _version_callback,  # noqa: F401 — Typer command-registration parity
)

# The main Typer app created in fire_phoenix_cli.cli.__init__
from . import app
from .workflow_commands import (
    workflow_add,
    workflow_info,
    workflow_list,
    workflow_remove,
    workflow_resume,
    workflow_run,
    workflow_search,
    workflow_status,
)

workflow_app = typer.Typer(
    name="workflow",
    help="Manage and run automation workflows",
    add_completion=False,
)

app.add_typer(workflow_app, name="workflow")

# Register subcommands.
workflow_app.command("run")(workflow_run)
workflow_app.command("resume")(workflow_resume)
workflow_app.command("status")(workflow_status)
workflow_app.command("list")(workflow_list)
workflow_app.command("add")(workflow_add)
workflow_app.command("remove")(workflow_remove)
workflow_app.command("search")(workflow_search)
workflow_app.command("info")(workflow_info)
