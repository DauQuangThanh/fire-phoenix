"""Deterministic, read-only project probe for brownfield/migration ``init``.

adr/0068 (AC-BF-004/005). ``fire-phoenix init`` is CLI, not
AI: this module records only *mechanical OBSERVED facts* readable from disk —
file-extension counts, manifest filenames, commands declared verbatim in
manifests, test-dir presence, git history age, candidate docs dirs. Zero
inference happens here; capability recovery, intent reconstruction, and
quality judgment belong to the post-init skills/subagents
(``/inventory-existing``, ``technical-analyst``).

Hard rules (plan §Design principles + AC negative constraints):

- never executes project code, never reaches the network (``git`` is invoked
  read-only against local metadata only);
- never writes — consumers substitute the findings into the scaffold
  (``STATUS.md`` snapshot sentinels) and ``context.yml`` (``commands:``,
  ``paths.existing_docs``);
- never aborts ``init``: any failure degrades to the pre-W5 ``{TBD-source}``
  placeholders / ``UNKNOWN`` markers.
"""

from __future__ import annotations

import json
import os
import subprocess
import tomllib
from dataclasses import dataclass, field
from datetime import date
from pathlib import Path
from typing import Any

import yaml

# Directories never descended into during the language walk. A fixed list —
# no .gitignore parsing — so the probe stays deterministic and fast.
_SKIP_DIRS = {
    ".git",
    ".hg",
    ".svn",
    ".venv",
    "venv",
    ".tox",
    "__pycache__",
    "node_modules",
    "vendor",
    "dist",
    "build",
    "target",
    ".fire-phoenix",
    ".idea",
    ".vscode",
    ".pytest_cache",
    ".mypy_cache",
    ".ruff_cache",
}

# Extension → language label for the histogram. Deliberately coarse: the
# probe answers "what is this repo written in", not "classify every file".
_EXT_LANGUAGES = {
    ".py": "Python",
    ".ts": "TypeScript",
    ".tsx": "TypeScript",
    ".js": "JavaScript",
    ".jsx": "JavaScript",
    ".mjs": "JavaScript",
    ".vue": "Vue",
    ".go": "Go",
    ".java": "Java",
    ".kt": "Kotlin",
    ".rb": "Ruby",
    ".rs": "Rust",
    ".cs": "C#",
    ".php": "PHP",
    ".c": "C",
    ".cpp": "C++",
    ".swift": "Swift",
    ".scala": "Scala",
    ".dart": "Dart",
    ".sh": "Shell",
    ".ps1": "PowerShell",
    ".sql": "SQL",
}

_MANIFESTS = (
    "package.json",
    "pyproject.toml",
    "setup.py",
    "requirements.txt",
    "go.mod",
    "Cargo.toml",
    "pom.xml",
    "build.gradle",
    "build.gradle.kts",
    "Gemfile",
    "composer.json",
    "Makefile",
)

_INTEGRATION_MARKERS = (
    "Dockerfile",
    "docker-compose.yml",
    "docker-compose.yaml",
    ".github/workflows",
    ".gitlab-ci.yml",
    "Jenkinsfile",
    "terraform",
    "kubernetes",
    "helm",
    ".circleci",
)

_METHODOLOGY_ARTEFACTS = (
    "README.md",
    "CLAUDE.md",
    "AGENTS.md",
    "CONTRIBUTING.md",
    "ARCHITECTURE.md",
    "docs",
)

_TEST_DIRS = ("tests", "test", "__tests__", "spec")

# Candidate legacy docs roots, most conventional first. `docs` itself is the
# scaffold default — still reported so `paths.existing_docs` records that the
# tree pre-existed the IDD scaffold.
_DOCS_DIR_CANDIDATES = ("docs", "doc", "documentation", "wiki")

# STATUS.md snapshot sentinels (brownfield + migration scaffolds). The
# fallback strings are the pre-W5 placeholder texts, so a probe miss (or a
# direct test caller passing no probe) renders exactly what shipped before.
_SENTINEL_FALLBACKS: dict[str, str] = {
    "<<INIT_DATE>>": "{TBD-source — YYYY-MM-DD}",
    "<<INIT_LANGUAGES>>": "{TBD-source — OBSERVED from filesystem}",
    "<<INIT_METHOD_ARTEFACTS>>": (
        "{TBD-source — README.md / AGENTS.md / CLAUDE.md / docs/ / etc. "
        "(each tagged OBSERVED with file path)}"
    ),
    "<<INIT_TESTS>>": "{TBD-source — tests/ test/ __tests__/ spec/ layout if any}",
    "<<INIT_BUILD_TOOLING>>": (
        "{TBD-source — pyproject.toml / package.json / pom.xml / Cargo.toml / go.mod / etc.}"
    ),
    "<<INIT_GIT_AGE>>": "{TBD-source — first commit date + total commits}",
    "<<INIT_INTEGRATIONS>>": (
        "{TBD-source — Dockerfile, .github/workflows/, terraform/, kubernetes/, etc.}"
    ),
}


@dataclass
class ProbeResult:
    """Mechanical OBSERVED facts about a pre-existing project."""

    languages: dict[str, int] = field(default_factory=dict)  # label → file count
    manifests: list[str] = field(default_factory=list)
    methodology_artefacts: list[str] = field(default_factory=list)
    test_dirs: list[str] = field(default_factory=list)
    integrations: list[str] = field(default_factory=list)
    git_summary: str | None = None
    commands: dict[str, str | None] = field(
        default_factory=lambda: {"build": None, "test": None, "lint": None}
    )
    existing_docs: str | None = None


def _read_existing_context_values(project_path: Path) -> dict[str, Any]:
    """Raw, forgiving read of a pre-existing ``.fire-phoenix/context.yml``.

    Used on re-init (adr/0068) so values the CLI flags did
    not explicitly override — ``language:``, ``preferences:``,
    ``archetype:``, ``commands:`` — survive instead of being reset to
    prompt/CLI/probe defaults. Returns ``{}`` when the file is absent or
    unreadable; strict schema rejection stays in the orchestrator.
    """
    ctx_path = project_path / ".fire-phoenix" / "context.yml"
    try:
        data = yaml.safe_load(ctx_path.read_text(encoding="utf-8")) or {}
    except (OSError, yaml.YAMLError):
        return {}
    return data if isinstance(data, dict) else {}


def resolve_probe_values(
    project_path: Path, archetype: str
) -> tuple[ProbeResult | None, dict[str, str | None], str | None]:
    """Run the probe and merge its findings under any recorded values.

    Returns ``(probe_result, commands, existing_docs)`` for the orchestrator:
    the probe runs only for brownfield/migration (greenfield has nothing to
    observe) and never aborts init (AC-BF-005); values a user (or a prior
    init) recorded in ``context.yml`` win over fresh probe findings — the
    probe only fills what is still unset (AC-BF-003).
    """
    probe_result: ProbeResult | None = None
    if archetype in ("brownfield", "migration"):
        try:
            probe_result = probe_project(project_path)
        except Exception:  # noqa: BLE001 — allowlist: deliberate broad-except (see tests/test_except_hygiene.py)
            # Brownfield/migration probe is pure best-effort inference over an
            # unknown existing tree; ANY failure must degrade to "no findings"
            # and never abort init (AC-BF-005). Deliberately broad.
            probe_result = None

    existing = _read_existing_context_values(project_path)
    probe_commands = dict(probe_result.commands) if probe_result else {}
    existing_commands = existing.get("commands") or {}
    commands = {
        key: existing_commands.get(key) or probe_commands.get(key)
        for key in ("build", "test", "lint")
    }
    existing_docs = (existing.get("paths") or {}).get("existing_docs") or (
        probe_result.existing_docs if probe_result else None
    )
    return probe_result, commands, existing_docs


def probe_project(project_path: Path) -> ProbeResult:
    """Collect the OBSERVED snapshot. Never raises — partial results are fine."""
    result = ProbeResult()
    try:
        result.languages = _scan_languages(project_path)
    except OSError:
        pass
    result.manifests = [m for m in _MANIFESTS if (project_path / m).is_file()]
    result.methodology_artefacts = [
        a for a in _METHODOLOGY_ARTEFACTS if (project_path / a).exists()
    ]
    result.test_dirs = [f"{d}/" for d in _TEST_DIRS if (project_path / d).is_dir()]
    result.integrations = [m for m in _INTEGRATION_MARKERS if (project_path / m).exists()]
    result.git_summary = _git_summary(project_path)
    result.commands = _detect_commands(project_path)
    result.existing_docs = _detect_existing_docs(project_path)
    return result


def _scan_languages(project_path: Path) -> dict[str, int]:
    counts: dict[str, int] = {}
    for _root, dirnames, filenames in os.walk(project_path):
        dirnames[:] = [d for d in dirnames if d not in _SKIP_DIRS]
        for name in filenames:
            lang = _EXT_LANGUAGES.get(Path(name).suffix.lower())
            if lang:
                counts[lang] = counts.get(lang, 0) + 1
    return dict(sorted(counts.items(), key=lambda kv: kv[1], reverse=True))


def _git_summary(project_path: Path) -> str | None:
    """``first commit <date>, <N> commits`` from LOCAL git metadata, or None."""

    def _git(*args: str) -> str | None:
        try:
            proc = subprocess.run(  # noqa: S603 — fixed argv, no shell
                ["git", "-C", str(project_path), *args],
                capture_output=True,
                text=True,
                timeout=10,
            )
        except (OSError, subprocess.SubprocessError):
            return None
        return proc.stdout.strip() if proc.returncode == 0 else None

    count = _git("rev-list", "--count", "HEAD")
    if not count:
        return None
    root_sha = _git("rev-list", "--max-parents=0", "HEAD")
    first_date = None
    if root_sha:
        first_date = _git("show", "-s", "--format=%as", root_sha.splitlines()[-1])
    if first_date:
        return f"first commit {first_date}, {count} commits"
    return f"{count} commits"


def _detect_commands(project_path: Path) -> dict[str, str | None]:
    """Commands declared VERBATIM in manifests — never guessed conventions.

    Sources, in precedence order (first hit per key wins):
    ``package.json`` ``scripts.{build,test,lint}`` → ``npm run <name>``;
    ``Makefile`` targets ``build``/``test``/``lint`` → ``make <name>``;
    ``pyproject.toml`` declared tool tables → the tool's own entry command
    (``[tool.pytest.ini_options]`` → ``pytest``, ``[tool.ruff]`` →
    ``ruff check .``). Anything else stays ``None`` for the user to fill.
    """
    commands: dict[str, str | None] = {"build": None, "test": None, "lint": None}

    pkg = project_path / "package.json"
    if pkg.is_file():
        try:
            scripts = (json.loads(pkg.read_text(encoding="utf-8")) or {}).get("scripts") or {}
            for key in commands:
                if not commands[key] and isinstance(scripts.get(key), str):
                    commands[key] = f"npm run {key}"
        except (OSError, ValueError):
            pass

    makefile = project_path / "Makefile"
    if makefile.is_file():
        try:
            targets = {
                line.split(":", 1)[0].strip()
                for line in makefile.read_text(encoding="utf-8", errors="replace").splitlines()
                if ":" in line and not line.startswith(("\t", " ", "#", "."))
            }
            for key in commands:
                if not commands[key] and key in targets:
                    commands[key] = f"make {key}"
        except OSError:
            pass

    pyproject = project_path / "pyproject.toml"
    if pyproject.is_file():
        try:
            data = tomllib.loads(pyproject.read_text(encoding="utf-8"))
            tool = data.get("tool") or {}
            if not commands["test"] and "pytest" in tool:
                commands["test"] = "pytest"
            if not commands["lint"] and "ruff" in tool:
                commands["lint"] = "ruff check ."
        except (OSError, ValueError):
            pass

    return commands


def _detect_existing_docs(project_path: Path) -> str | None:
    """First conventional docs dir that already exists and has content."""
    for candidate in _DOCS_DIR_CANDIDATES:
        d = project_path / candidate
        try:
            if d.is_dir() and any(d.iterdir()):
                return candidate
        except OSError:
            continue
    return None


def build_status_sentinels(result: ProbeResult | None) -> dict[str, str]:
    """Map the ``<<INIT_*>>`` STATUS.md sentinels to probe findings.

    ``None`` (probe not run — greenfield, or a direct scaffold caller) or any
    empty finding falls back to the pre-W5 ``{TBD-source}`` placeholder /
    ``UNKNOWN`` marker, so degraded runs still complete (AC-BF-005).
    """
    sentinels = dict(_SENTINEL_FALLBACKS)
    if result is None:
        return sentinels

    sentinels["<<INIT_DATE>>"] = f"OBSERVED: {date.today().isoformat()}"

    if result.languages:
        top = ", ".join(f"{lang} ({n} files)" for lang, n in list(result.languages.items())[:6])
        sentinels["<<INIT_LANGUAGES>>"] = f"OBSERVED: {top}"
    else:
        sentinels["<<INIT_LANGUAGES>>"] = "OBSERVED: no recognised source files found"

    if result.methodology_artefacts:
        listing = ", ".join(f"`{a}`" for a in result.methodology_artefacts)
        sentinels["<<INIT_METHOD_ARTEFACTS>>"] = f"OBSERVED: {listing}"
    else:
        sentinels["<<INIT_METHOD_ARTEFACTS>>"] = "OBSERVED: none found at project root"

    sentinels["<<INIT_TESTS>>"] = (
        f"OBSERVED: {', '.join(f'`{d}`' for d in result.test_dirs)}"
        if result.test_dirs
        else "OBSERVED: no conventional test directory found"
    )
    sentinels["<<INIT_BUILD_TOOLING>>"] = (
        f"OBSERVED: {', '.join(f'`{m}`' for m in result.manifests)}"
        if result.manifests
        else "OBSERVED: no recognised build manifest found"
    )
    sentinels["<<INIT_GIT_AGE>>"] = (
        f"OBSERVED: {result.git_summary}"
        if result.git_summary
        else "UNKNOWN — not a git repository (or git unavailable)"
    )
    sentinels["<<INIT_INTEGRATIONS>>"] = (
        f"OBSERVED: {', '.join(f'`{i}`' for i in result.integrations)}"
        if result.integrations
        else "OBSERVED: none of the conventional markers found"
    )
    return sentinels
