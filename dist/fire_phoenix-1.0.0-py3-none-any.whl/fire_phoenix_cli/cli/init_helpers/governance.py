"""Governance/path sentinel resolution for ``fire-phoenix init`` (adr/0020 + adr/0026).

The scaffold templates embed ``<<…>>`` sentinels for every governance and
paths value declared in ``.fire-phoenix/context.yml``. This module owns
the mapping from canonical scaffold source filenames to governance-keys,
the documented docs/-rooted fallbacks (adr/0026), and the
:func:`_build_sentinel_map` helper that produces the 12-entry substitution
dictionary :func:`init_helpers.scaffold._scaffold_l1_l4` consumes.
"""

from pathlib import Path

# Mapping from canonical source filename to the governance: key that holds the
# destination filename. CLAUDE.md is intentionally absent — it's fixed.
_GOVERNANCE_FILE_KEY: dict[str, str] = {
    "PRODUCT.md": "product_file",
    "STATUS.md": "status_file",
    "decisions.md": "decisions_file",
}
# Canonical source dirs → governance: key that holds the destination dir name.
_GOVERNANCE_DIR_KEY: dict[str, str] = {
    "specs": "specs_dir",
    "contracts": "contracts_dir",
    "adr": "adr_dir",
}
# Documented default destination names (per adr/0026). Used as the scaffold
# fallback when ``governance`` is partially populated or absent. In the
# normal init path, ``init`` resolves ``resolved_governance`` to a complete
# dict before calling _scaffold_l1_l4, so these fallbacks only fire for
# direct test callers passing an empty governance dict.
_GOVERNANCE_FILE_DEFAULTS: dict[str, str] = {
    "PRODUCT.md": "docs/PRODUCT.md",
    "STATUS.md": "docs/STATUS.md",
    "decisions.md": "docs/decisions.md",
}
_GOVERNANCE_DIR_DEFAULTS: dict[str, str] = {
    "specs": "docs/specs",
    "contracts": "docs/contracts",
    "adr": "docs/adr",
}


def _build_sentinel_map(governance: dict, paths: dict) -> dict[str, str]:
    """Resolve the 12 path/governance sentinels per adr/0020.

    Caller passes the ``governance:`` and ``paths:`` blocks straight from
    ``.fire-phoenix/context.yml``. Missing keys fall back to the documented
    defaults so the function tolerates partially-populated dicts. Governance
    fallbacks are docs/-rooted per adr/0026.
    """
    return {
        "<<PRODUCT_FILE>>": governance.get("product_file", "docs/PRODUCT.md"),
        "<<STATUS_FILE>>": governance.get("status_file", "docs/STATUS.md"),
        "<<DECISIONS_FILE>>": governance.get("decisions_file", "docs/decisions.md"),
        "<<SPECS_DIR>>": governance.get("specs_dir", "docs/specs"),
        "<<CONTRACTS_DIR>>": governance.get("contracts_dir", "docs/contracts"),
        "<<ADR_DIR>>": governance.get("adr_dir", "docs/adr"),
        "<<DOCS_DIR>>": paths.get("docs", "docs"),
        "<<INTENTS_DIR>>": paths.get("intents", "docs/intents"),
        "<<PLANS_DIR>>": paths.get("plans", "docs/plans"),
        "<<TASKS_DIR>>": paths.get("tasks", "docs/tasks"),
        "<<TEMPLATES_DIR>>": paths.get("templates", "templates"),
        "<<SCRIPTS_DIR>>": paths.get("scripts", "scripts"),
    }


def _resolve_paths_and_governance(
    *,
    context_path: Path,
    docs_dir: str | None,
    intents_dir: str | None,
    plans_dir: str | None,
    tasks_dir: str | None,
    templates_dir: str | None,
    scripts_dir: str | None,
    product_file: str | None,
    status_file: str | None,
    decisions_file: str | None,
    specs_dir: str | None,
    contracts_dir: str | None,
    adr_dir: str | None,
) -> tuple[dict[str, str], dict[str, str], list[str]]:
    """Resolve every governance / paths value per adr/0020.

    Precedence: CLI flag (if passed) > existing v2.0 context.yml value
    (if file already exists) > documented default (docs/-rooted for
    governance per adr/0026).

    Returns ``(resolved_governance, resolved_paths_block, existing_integrations)``.
    """
    import yaml

    existing_paths: dict[str, str] = {}
    existing_governance: dict[str, str] = {}
    existing_integrations: list[str] = []
    if context_path.exists():
        existing_yaml = yaml.safe_load(context_path.read_text(encoding="utf-8")) or {}
        existing_paths = existing_yaml.get("paths", {}) or {}
        existing_governance = existing_yaml.get("governance", {}) or {}
        existing_integrations = existing_yaml.get("integrations", []) or []

    def _resolve(flag_val: str | None, existing_key: str, defaults_dict: dict, default: str) -> str:
        if flag_val is not None:
            return flag_val
        return defaults_dict.get(existing_key, default)

    resolved_paths_block = {
        "docs": _resolve(docs_dir, "docs", existing_paths, "docs"),
        "intents": _resolve(intents_dir, "intents", existing_paths, "docs/intents"),
        "plans": _resolve(plans_dir, "plans", existing_paths, "docs/plans"),
        "tasks": _resolve(tasks_dir, "tasks", existing_paths, "docs/tasks"),
        "templates": _resolve(templates_dir, "templates", existing_paths, "templates"),
        "scripts": _resolve(scripts_dir, "scripts", existing_paths, "scripts"),
    }
    # Documented governance defaults are docs/-rooted per adr/0026.
    # Existing v2.0 context.yml values (root-rooted or otherwise) take
    # precedence — no auto-rewrite of explicit user state.
    resolved_governance = {
        "product_file": _resolve(
            product_file, "product_file", existing_governance, "docs/PRODUCT.md"
        ),
        "status_file": _resolve(status_file, "status_file", existing_governance, "docs/STATUS.md"),
        "decisions_file": _resolve(
            decisions_file, "decisions_file", existing_governance, "docs/decisions.md"
        ),
        "specs_dir": _resolve(specs_dir, "specs_dir", existing_governance, "docs/specs"),
        "contracts_dir": _resolve(
            contracts_dir, "contracts_dir", existing_governance, "docs/contracts"
        ),
        "adr_dir": _resolve(adr_dir, "adr_dir", existing_governance, "docs/adr"),
    }
    return resolved_governance, resolved_paths_block, existing_integrations
