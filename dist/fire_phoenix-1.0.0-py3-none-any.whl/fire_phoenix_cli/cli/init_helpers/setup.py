"""Integration + shared-infra + custom-agents + workflow install (adr/0020 + adr/0031).

These four phases ran inline in the monolithic ``init()``; here they're
extracted into small functions the orchestrator threads together. Each
function takes its inputs explicitly and returns the data the caller
needs to drive the next phase + the StepTracker.
"""

from pathlib import Path
from typing import TYPE_CHECKING, Any

import yaml

from fire_phoenix_cli.fsutil import atomic_write_text
from fire_phoenix_cli.installer import _install_shared_infra
from fire_phoenix_cli.ui import console
from fire_phoenix_cli.version import get_fire_phoenix_version

if TYPE_CHECKING:
    from fire_phoenix_cli.installer.journal import InstallJournal


def _install_integrations(
    project_path: Path,
    selected_ais: list[str],
    resolved_integrations: dict[str, Any],
    *,
    runtime_script_type: str,
    integration_options: str | None,
    tracker,
    journal: "InstallJournal | None" = None,
) -> tuple[list[str], list[tuple[str, Path]], dict[Path, str]]:
    """Run the per-integration ``setup`` loop and persist ``integration.yml``.

    Returns ``(installed_keys, install_conflicts, written_paths)``.

    Each integration is asked to render its native artefacts into
    ``project_path``; conflicts (two integrations claiming the same
    destination) are collected but not fatal — the second writer is
    skipped and surfaced via the conflicts panel later.
    """
    from ...integrations.manifest import IntegrationManifest

    tracker.start("integrations")

    install_conflicts: list[tuple[str, Path]] = []  # (integration_key, destination_path)
    written_paths: dict[Path, str] = {}  # dest -> integration key that wrote it
    installed_keys: list[str] = []

    for integration_key in selected_ais:
        resolved_integration = resolved_integrations[integration_key]
        manifest = IntegrationManifest(
            resolved_integration.key,
            project_path,
            version=get_fire_phoenix_version(),
            # AC-PH-006: attach init's journal so files written during setup()
            # are recoverable if the run dies before manifest.save().
            journal=journal,
        )

        # adr/0056: setup() no longer upserts the managed context section;
        # the orchestrator's post-scaffold phase does, so the scaffold writes
        # the rich project-memory body first.
        resolved_integration.setup(
            project_path,
            manifest,
            parsed_options=None,
            script_type=runtime_script_type,
            raw_options=integration_options,
        )
        manifest.save()
        installed_keys.append(integration_key)

        # Track written paths for conflict detection
        for rel_path in manifest.files.keys():
            dest_path = project_path / rel_path
            if dest_path in written_paths:
                install_conflicts.append((integration_key, dest_path))
            else:
                written_paths[dest_path] = integration_key

    # Write .fire-phoenix/integration.yml. ``integration`` (singular) keeps
    # parity with ``fire-phoenix integration install/uninstall`` which operate
    # on a single key; ``integrations`` (plural) tracks the full
    # multi-select list for ``fire-phoenix upgrade`` and similar tooling.
    integration_yaml = project_path / ".fire-phoenix" / "integration.yml"
    integration_yaml.parent.mkdir(parents=True, exist_ok=True)
    atomic_write_text(
        integration_yaml,
        yaml.safe_dump(
            {
                "integration": installed_keys[0] if installed_keys else None,
                "integrations": installed_keys,
                "version": get_fire_phoenix_version(),
            },
            sort_keys=False,
            default_flow_style=False,
            allow_unicode=True,
        ),
    )

    tracker.complete("integrations", f"{len(installed_keys)} installed")
    return installed_keys, install_conflicts, written_paths


def _verify_and_install_shared_infra(
    project_path: Path,
    *,
    force: bool,
    tracker,
    verify: bool = True,
) -> None:
    """Verify asset integrity then install shared infra (scripts/templates).

    Aborts via ``typer.Exit(1)`` if the bundled assets fail the integrity
    check — a corrupt wheel must not produce a partial install.

    *verify* exists for callers that already verified BEFORE their first write
    (``init`` does, per AC-PH-005) so the ~1k-file hash sweep runs once.
    """
    from ..integrity_guard import verify_core_pack_or_exit

    if verify:
        verify_core_pack_or_exit()

    tracker.start("shared-infra")
    _install_shared_infra(project_path, tracker=tracker, force=force)
    tracker.complete("shared-infra", ".fire-phoenix/ created")


def _install_bundled_custom_agents(
    project_path: Path,
    installed_keys: list[str],
    *,
    force: bool,
    journal: "InstallJournal | None" = None,
) -> None:
    """Deploy bundled custom-agent files into every installed integration.

    *journal* (adr/0061 Stage 2): when ``init`` owns a journal it is passed
    through so the custom-agent writes join init's single recovery journal
    instead of being cleared per-integration.
    """
    from fire_phoenix_cli.installer import (
        install_context_reference,
        install_custom_agents,
        install_subagent_references,
    )

    custom_agents_results = install_custom_agents(
        project_path,
        installed_keys,
        force=force,
        journal=journal,
    )
    total_custom_agents = sum(custom_agents_results.values())
    if total_custom_agents:
        console.print(
            f"[cyan]Installed {total_custom_agents} custom agent file(s) "
            f"across {len(custom_agents_results)} integration(s).[/cyan]"
        )
    if custom_agents_results:
        # Shared mode-conditional references the subagent bodies point
        # at (adr/0034 AC-006) — one copy for all integrations.
        refs_count = install_subagent_references(project_path)
        if refs_count:
            console.print(
                f"[cyan]Installed {refs_count} shared subagent reference "
                f"file(s) to .fire-phoenix/references/subagents/.[/cyan]"
            )
    # The context.yml key/enum reference is provider-independent (like
    # context.yml itself), so install it regardless of the custom-agent set.
    if install_context_reference(project_path):
        console.print(
            "[cyan]Installed the context.yml key/enum reference to "
            ".fire-phoenix/references/context-schema.md.[/cyan]"
        )


def _install_governance_hooks(
    project_path: Path,
    installed_keys: list[str],
    *,
    force: bool,
) -> None:
    """Install the guardrail + audit hook pack for every installed provider (adr/0043, extends adr/0040)."""
    from fire_phoenix_cli.installer import install_governance_hooks

    written = install_governance_hooks(project_path, installed_keys, force=force)
    if written:
        console.print(
            f"[cyan]Installed the governance hook pack ({written} file(s)) — protected-path "
            f"deny + audit trail wired into each selected AI's native hook config, on by "
            f"default (adr/0043).[/cyan]"
        )


def _install_git_hooks(project_path: Path) -> None:
    """Install the provider-agnostic git-hook governance floor (adr/0044, Phase B)."""
    from fire_phoenix_cli.installer import install_git_hooks

    written = install_git_hooks(project_path)
    if written:
        console.print(
            f"[cyan]Installed the git-hook governance floor ({written} hook(s)) into "
            f".git/hooks/ — pre-commit protected-path deny + post-commit audit (adr/0044). "
            f"Bypass with 'git commit --no-verify'; hooks are per-clone.[/cyan]"
        )


def _install_git_extension(
    project_path: Path,
    *,
    no_git: bool,
    should_init_git: bool,
    tracker,
) -> None:
    """Initialise the git repo (if needed) and install the bundled git extension.

    Behaviour matches the previous inline implementation — every step
    short-circuits on missing prerequisites and feeds tracker messages
    into one summary string so the user sees the full sequence in
    a single ``git`` tracker line.
    """
    from fire_phoenix_cli.installer import (
        _locate_bundled_extension,
        init_git_repo,
        is_git_repo,
    )

    if no_git:
        tracker.skip("git", "--no-git flag")
        return

    tracker.start("git")
    git_messages: list[str] = []
    git_has_error = False
    # Step 1: Initialize git repo if needed
    if is_git_repo(project_path):
        git_messages.append("existing repo detected")
    elif should_init_git:
        # adr/0031: cli/init.py authors its own auto-commit at
        # the end of the flow (after scaffold + integrations +
        # workflow + chmod). Suppress init_git_repo's built-in
        # commit to avoid producing two "Initial commit" entries
        # per init invocation.
        success, error_msg = init_git_repo(project_path, quiet=True, commit_initial=False)
        if success:
            git_messages.append("initialized")
        else:
            git_has_error = True
            # Sanitize multi-line error_msg to single line for tracker
            if error_msg:
                sanitized = error_msg.replace("\n", " ").strip()
                git_messages.append(f"init failed: {sanitized[:120]}")
            else:
                git_messages.append("init failed")
    else:
        git_messages.append("git not available")
    # Step 2: Install bundled git extension
    try:
        from fire_phoenix_cli.extensions import ExtensionManager

        bundled_path = _locate_bundled_extension("git")
        if bundled_path:
            manager = ExtensionManager(project_path)
            if manager.registry.is_installed("git"):
                git_messages.append("extension already installed")
            else:
                manager.install_from_directory(bundled_path, get_fire_phoenix_version())
                git_messages.append("extension installed")
        else:
            git_has_error = True
            git_messages.append("bundled extension not found")
    except Exception as ext_err:
        git_has_error = True
        sanitized_ext = str(ext_err).replace("\n", " ").strip()
        git_messages.append(f"extension install failed: {sanitized_ext[:120]}")
    summary = "; ".join(git_messages)
    if git_has_error:
        tracker.error("git", summary)
    else:
        tracker.complete("git", summary)


def _install_bundled_workflow(project_path: Path, *, tracker) -> None:
    """Install the bundled default full-cycle workflow into the project.

    The workflow id comes from ``DEFAULT_BUNDLED_WORKFLOW_ID`` (single source
    of truth) rather than a literal, so a workflow rename can never again
    silently break init. Idempotent — a workflow already present is reported
    as ``already installed`` and no copy happens. Any unhandled exception
    during install is sanitized to a single tracker error line.
    """
    from fire_phoenix_cli.installer import (
        DEFAULT_BUNDLED_WORKFLOW_ID,
        _locate_bundled_workflow,
    )

    wf_id = DEFAULT_BUNDLED_WORKFLOW_ID
    try:
        bundled_wf = _locate_bundled_workflow(wf_id)
        if bundled_wf:
            from ...workflows.catalog import WorkflowRegistry
            from ...workflows.engine import WorkflowDefinition

            wf_registry = WorkflowRegistry(project_path)
            if wf_registry.is_installed(wf_id):
                tracker.complete("workflow", "already installed")
            else:
                import shutil as _shutil

                dest_wf = project_path / ".fire-phoenix" / "workflows" / wf_id
                dest_wf.mkdir(parents=True, exist_ok=True)
                _shutil.copy2(
                    bundled_wf / "workflow.yml",
                    dest_wf / "workflow.yml",
                )
                definition = WorkflowDefinition.from_yaml(dest_wf / "workflow.yml")
                wf_registry.add(
                    wf_id,
                    {
                        "name": definition.name,
                        "version": definition.version,
                        "description": definition.description,
                        "source": "bundled",
                    },
                )
                tracker.complete("workflow", f"{wf_id} installed")
        else:
            tracker.skip("workflow", "bundled workflow not found")
    except Exception as wf_err:
        sanitized_wf = str(wf_err).replace("\n", " ").strip()
        tracker.error("workflow", f"install failed: {sanitized_wf[:120]}")


def _install_preset(project_path: Path, preset: str | None) -> None:
    """Install an optional preset bundle. No-op when ``preset`` is falsy.

    Catches install errors and surfaces them via ``console.print`` rather
    than aborting init — preset failures must not kill the whole flow.
    """
    if not preset:
        return
    try:
        from fire_phoenix_cli.installer import _locate_bundled_preset
        from fire_phoenix_cli.presets import PresetManager

        preset_manager = PresetManager(project_path)
        fire_phoenix_ver = get_fire_phoenix_version()

        # Try local directory first, then bundled, then catalog
        local_path = Path(preset).resolve()
        if local_path.is_dir() and (local_path / "preset.yml").exists():
            preset_manager.install_from_directory(local_path, fire_phoenix_ver)
        else:
            bundled_path = _locate_bundled_preset(preset)
            if bundled_path:
                preset_manager.install_from_directory(bundled_path, fire_phoenix_ver)
            else:
                from fire_phoenix_cli.extensions import REINSTALL_COMMAND

                console.print(
                    f"[yellow]Warning:[/yellow] Preset '{preset}' is not bundled with fire-phoenix "
                    f"and fire-phoenix is offline-only; skipping. "
                    f"If this preset should be bundled, try reinstalling: {REINSTALL_COMMAND}"
                )
    except Exception as preset_err:
        console.print(f"[yellow]Warning:[/yellow] Failed to install preset: {preset_err}")
