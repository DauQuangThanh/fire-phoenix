"""Roll back a failed in-place ``init`` by removing exactly this run's new files.

Extracted from :mod:`fire_phoenix_cli.cli.init`, whose stated job is the Typer
command definition plus helper threading — this is neither. Re-exported from
that module so ``patch("fire_phoenix_cli.cli.init._rollback_partial_state")``
keeps resolving.
"""

from __future__ import annotations

from pathlib import Path

from rich.panel import Panel

from fire_phoenix_cli.ui import console


def _rollback_partial_state(project_path: Path) -> None:
    """Remove this run's journaled new files after a failed in-place init.

    An existing project / ``--here`` cannot be ``rmtree``'d, so instead we
    remove precisely the files this run journaled — those it CREATED this run
    (never a preserve-existing or pre-existing file — init only journals actual
    new writes) and that no manifest tracks (manifest-tracked installs are
    complete and left for ``integration uninstall``). This gives an in-place
    init the same "no partial state" guarantee fresh-dir init gets from
    ``rmtree``, without ever touching a user's own files. The removed set is
    reported so the rollback is visible.
    """
    from fire_phoenix_cli.installer.journal import repair

    try:
        # `repair` returns only the orphans it REMOVED (an entry whose unlink
        # failed stays journaled), so the panel cannot overstate the rollback.
        removed = repair(project_path, remove_orphans=True)
    except OSError:
        return
    if not removed:
        return
    lines = "\n".join(f"  • {p}" for p in removed)
    console.print(
        Panel(
            "Rolled back this run's partial writes (an existing project cannot\n"
            "be removed wholesale, so only the files THIS init created were\n"
            "removed — pre-existing files were left untouched):\n\n"
            f"{lines}",
            title="Partial init rolled back",
            border_style="yellow",
        )
    )
