"""Pre-init dirty-snapshot + auto-commit (adr/0031).

Co-locates the three ``git`` subprocess pathways exercised by ``init``:

1. :func:`_capture_pre_init_dirty` — porcelain snapshot taken before any
   scaffold write happens, so the auto-commit step can detect pre-existing
   user changes and refuse to fold them into the framework commit.
2. :func:`_auto_commit_initial` — stages everything and creates the
   ``Initial commit from Fire Phoenix Framework`` commit, honouring the
   user's git config for AUTHOR/COMMITTER. Skips on ``--no-git``, when no
   repo exists, or when the working tree was dirty before init started.
"""

import subprocess
import sys
from pathlib import Path

_AUTO_COMMIT_MESSAGE = "Initial commit from Fire Phoenix Framework (Author: Dau Quang Thanh)"


def _capture_pre_init_dirty(project_path: Path) -> set[str]:
    """Snapshot ``git status --porcelain`` BEFORE init mutates the tree.

    Per adr/0031 §Decision item 2: when ``--here`` runs on an existing repo
    with uncommitted user changes, auto-commit must skip — never fold the
    user's in-flight work into "Initial commit from Fire Phoenix Framework".

    Returns the set of dirty file paths (one per line of porcelain output),
    or an empty set if the directory isn't a git repo or git is unavailable.
    """
    if not project_path.exists() or not (project_path / ".git").exists():
        return set()
    try:
        result = subprocess.run(  # noqa: S603 — trusted argv
            ["git", "-C", str(project_path), "status", "--porcelain"],
            capture_output=True,
            text=True,
            timeout=10,
            check=False,
        )
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return set()
    if result.returncode != 0:
        return set()
    return {line for line in result.stdout.splitlines() if line.strip()}


def _has_git_identity(project_path: Path) -> bool:
    """True only if BOTH user.name and user.email resolve for this repo.

    Checks the effective config (repo + global + system). Used to decide
    whether the auto-commit needs a neutral fallback identity.
    """
    for key in ("user.name", "user.email"):
        try:
            result = subprocess.run(  # noqa: S603 — trusted argv
                ["git", "-C", str(project_path), "config", "--get", key],
                capture_output=True,
                text=True,
                timeout=10,
                check=False,
            )
        except (FileNotFoundError, subprocess.TimeoutExpired):
            return False
        if result.returncode != 0 or not result.stdout.strip():
            return False
    return True


def _auto_commit_initial(
    project_path: Path,
    pre_init_dirty: set[str],
    tracker,
    no_git: bool,
) -> None:
    """Stage everything and create the "Initial commit from Fire Phoenix" commit.

    Per adr/0031 §Decision item 2. Honours the user's git config for AUTHOR
    and COMMITTER — Thanh is credited in the message body only.

    Skip cases:
    - ``--no-git`` was passed (existing flag covers both git-init AND commit).
    - The directory isn't a git repo after init (e.g. init_git_repo failed).
    - The working tree had uncommitted user changes BEFORE init started
      (would otherwise silently fold them into "Initial commit ...").
    """
    if no_git:
        tracker.skip("commit", "--no-git flag")
        return
    if not (project_path / ".git").exists():
        tracker.skip("commit", "no git repo at project root")
        return
    if pre_init_dirty:
        tracker.skip(
            "commit",
            f"pre-existing uncommitted changes ({len(pre_init_dirty)} file(s)) — auto-commit declined",
        )
        sys._fire_phoenix_commit_skipped_dirty = True  # type: ignore[attr-defined]
        return

    tracker.start("commit")
    try:
        add_result = subprocess.run(  # noqa: S603
            ["git", "-C", str(project_path), "add", "-A"],
            capture_output=True,
            text=True,
            timeout=30,
            check=False,
        )
        if add_result.returncode != 0:
            tracker.error("commit", f"git add failed: {add_result.stderr.strip()[:160]}")
            return
        # Honour a configured identity; supply a NEUTRAL fallback only when the
        # machine has none. Without this, `git commit` exits 128 on a box with
        # no user.name/user.email and init silently produced no commit (the
        # failure was swallowed to a tracker error + exit 0). The `-c` flags
        # apply to this invocation only and never override real config.
        commit_argv = ["git", "-C", str(project_path)]
        if not _has_git_identity(project_path):
            commit_argv += [
                "-c",
                "user.name=Fire Phoenix",
                "-c",
                "user.email=fire-phoenix@users.noreply.localhost",
            ]
        commit_argv += ["commit", "-m", _AUTO_COMMIT_MESSAGE]
        commit_result = subprocess.run(  # noqa: S603
            commit_argv,
            capture_output=True,
            text=True,
            timeout=30,
            check=False,
        )
        if commit_result.returncode != 0:
            stderr = commit_result.stderr.strip()
            # "nothing to commit" can happen if every scaffolded file was
            # already committed in a prior run — treat as a clean no-op.
            if (
                "nothing to commit" in stderr.lower()
                or "nothing to commit" in commit_result.stdout.lower()
            ):
                tracker.complete("commit", "no-op (nothing to commit)")
                return
            tracker.error("commit", f"git commit failed: {stderr[:160]}")
            return
        tracker.complete("commit", "1 commit created")
    except (FileNotFoundError, subprocess.TimeoutExpired) as exc:
        tracker.error("commit", f"git unavailable: {exc}")
