"""Phase-extracted helpers for ``cli/init.py``.

Per CLAUDE.md §Conventions "no file > 500 LOC". The monolithic ``init()``
body was decomposed into per-phase modules so the Typer command in
``cli/init.py`` reduces to a thin orchestrator. Behaviour is unchanged —
flag handling, prompts, scaffolding, integration setup, auto-commit and
panel rendering all preserve their adr/0018, adr/0020, adr/0026, adr/0030
and adr/0031 contracts.

Public submodules:

* :mod:`prompts` — language + role-level interactive prompts.
* :mod:`governance` — governance/path sentinel map + resolution.
* :mod:`scaffold` — L1-L4 + .gitignore + CODEOWNERS scaffolding.
* :mod:`git` — pre-init dirty snapshot + auto-commit.
* :mod:`setup` — integration / shared-infra / custom-agents / workflow.
* :mod:`panels` — Next-Steps and Enhancement-Skills panel rendering.
"""
