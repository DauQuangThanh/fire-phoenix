"""Interactive prompts for ``fire-phoenix init`` (adr/0030).

Language prompts use free-text with a documented default; role-level
prompts use arrow-key single-select so users pick from the canonical
enum. Both helpers short-circuit to the default on non-TTY stdin so
``CliRunner.invoke()`` and CI runs don't block on a never-arriving read.

Dependency lookup (``select_with_arrows`` for the arrow-key picker,
``sys.stdin`` for the TTY check) is routed through the
:mod:`fire_phoenix_cli.cli.init` module's namespace. Tests patch those
attributes on the init module (``monkeypatch.setattr(init_module,
"select_with_arrows", …)``) and this indirection preserves that contract
after the helper extraction.
"""

import typer


def _prompt_with_default(text: str, default: str) -> str:
    """Free-text prompt with a default value; returns the default on non-TTY.

    Per adr/0030: interactive init prompts must short-circuit to documented
    defaults when stdin is not a TTY (e.g. test fixtures using
    ``CliRunner.invoke()`` without ``input=`` get the default silently
    without blocking on a never-arriving stdin read).

    Used for the language prompts (free-form strings — English, Vietnamese,
    fr-CA, etc.). Role-level prompts use :func:`_select_role_level` instead
    so the user picks from the canonical enum via arrow keys per adr/0030
    §Decision.
    """
    from fire_phoenix_cli.cli import init as _init_module

    if not _init_module.sys.stdin.isatty():
        return default
    raw = typer.prompt(text, default=default, show_default=True)
    return raw or default


# Per-level one-liner descriptions shown next to each slug during arrow-key
# selection. Lifted from docs/reference/role-levels.md (the canonical
# reference) so users see what each level means while choosing. Keep these
# short — they sit inside a single-line table cell at prompt time.
_NON_TECH_ROLE_LEVEL_DESCRIPTIONS: dict[str, str] = {
    "non-technical": "No code or jargon; speak in outcomes and workflows",
    "familiar": "Knows common terms (API, database, deploy); define jargon on first use",
    "fluent": "Comfortable with architecture concepts; can read specs without translation",
    "technical": "Reads code/specs freely; full technical vocabulary, no softening",
}
_TECH_ROLE_LEVEL_DESCRIPTIONS: dict[str, str] = {
    "junior": "Hand-hold on architecture; suggest one path; explain trade-offs in detail",
    "mid": "Assume implementation literacy; offer ≥2 options on non-obvious choices",
    "senior": "Defer more on judgment; surface edge cases; brief on the what, dwell on the why",
    "staff": "Terse; challenge premises; expect pushback; skip obvious caveats",
}


def _select_role_level(
    prompt_text: str,
    descriptions: dict[str, str],
    default: str,
) -> str:
    """Single-select role-level prompt (arrow keys; ↑/↓ + Enter) per adr/0030.

    On non-TTY (CliRunner / CI / scripted) returns the default silently —
    matching :func:`_prompt_with_default`'s non-interactive behaviour.

    Looks up ``select_with_arrows`` and ``sys`` via the
    :mod:`fire_phoenix_cli.cli.init` module so tests that patch
    ``init.select_with_arrows`` or ``init.sys.stdin.isatty`` still drive
    this helper.
    """
    from fire_phoenix_cli.cli import init as _init_module

    if not _init_module.sys.stdin.isatty():
        return default
    return _init_module.select_with_arrows(
        descriptions, prompt_text=prompt_text, default_key=default
    )
