"""Post-install panels for ``fire-phoenix init``.

Four families of panel:

1. Notice panels — auto-commit-skipped, .gitignore-preserved,
   agent-folder-security. Each fires only when its trigger flag is set.
2. Next-Steps panel — brownfield vs. greenfield recipe per adr/0019 §D.
3. Enhancement-Skills panel — optional skills offered right after Next Steps.
4. Recommended-Subagents panel — curated subagents per project type
   (task-0069), rendered last. Skipped when the primary integration
   doesn't install subagents.

Skill display mode is determined per-integration: Skills integrations
(claude, codex, cursor-agent) show skill invocation syntax; everything
else falls back to slash-command syntax.
"""

import sys
from typing import Any

from rich.panel import Panel

from fire_phoenix_cli.installer import AGENT_CONFIG
from fire_phoenix_cli.ui import console

# Curated subagent recommendations surfaced in the post-init panel.
# Tuples of (name, one-line description). Curated per project type to
# keep the panel scannable while highlighting the workflow-relevant
# subset of the 15 shipped subagents. Per task-0069; both variants
# surface bug-fixer, code-security-reviewer, and technical-analyst so
# the maintenance, security, and reverse-engineering roles are always
# visible.
_GREENFIELD_SUBAGENTS: tuple[tuple[str, str], ...] = (
    (
        "business-analyst",
        "Authors L1 PRODUCT.md invariants, requirements, user stories & acceptance criteria",
    ),
    ("architect", "Tech-stack choice, system architecture, ADRs, C4 diagrams"),
    ("developer", "Module/class design, API contracts, DB schemas, implementation planning"),
    ("tester", "Test cases from user stories, execution tracking, bug reporting"),
    (
        "code-quality-reviewer",
        "Code quality review (SOLID/DRY/KISS, code smells) + intent-conformance review (code vs intent & acceptance criteria)",
    ),
    ("bug-fixer", "Burn down the bug backlog, resolve quality debt & security/safety findings"),
    (
        "code-security-reviewer",
        "Security review, OWASP Top 10, auth & dependency audit, system-safety assessment",
    ),
    (
        "technical-analyst",
        "Reverse-engineer code into architecture & API docs; align the shared context baseline for agent handover",
    ),
)
_BROWNFIELD_SUBAGENTS: tuple[tuple[str, str], ...] = (
    (
        "technical-analyst",
        "Reverse-engineer the codebase & align the context baseline so agents can pick up in-flight work",
    ),
    ("architect", "System architecture analysis + ADR authoring for legacy systems"),
    ("developer", "Refactoring plans, incremental redesign, API extraction"),
    ("bug-fixer", "Burn down the bug backlog, resolve quality debt & security/safety findings"),
    ("tester", "Test coverage for legacy code, regression suite construction"),
    (
        "code-security-reviewer",
        "Security review, OWASP Top 10, auth & dependency audit, system-safety assessment",
    ),
)


def _render_auto_commit_skipped_notice() -> None:
    """Render the adr/0031 notice when auto-commit was skipped due to a dirty tree."""
    if not getattr(sys, "_fire_phoenix_commit_skipped_dirty", False):
        return
    commit_notice = Panel(
        "Skipped auto-commit: the working tree had uncommitted changes when "
        "fire-phoenix init started. Fire Phoenix never folds pre-existing "
        "user work into the [bold]Initial commit from Fire Phoenix Framework[/bold] "
        "commit.\n\n"
        "Review with [cyan]git status[/cyan], then commit the fire-phoenix "
        "scaffold yourself when you're ready.",
        title="[yellow]Auto-commit skipped[/yellow]",
        border_style="yellow",
        padding=(1, 2),
    )
    console.print()
    console.print(commit_notice)
    sys._fire_phoenix_commit_skipped_dirty = False  # type: ignore[attr-defined]


def _render_gitignore_preserved_notice() -> None:
    """Render the adr/0030 notice when an existing .gitignore was preserved.

    The user-context.yml entry didn't get added automatically, so we
    surface the one line they need to add themselves.
    """
    if not getattr(sys, "_fire_phoenix_gitignore_preserved", False):
        return
    gitignore_notice = Panel(
        "An existing [cyan].gitignore[/cyan] was preserved. fire-phoenix uses a per-user "
        "file at [cyan].fire-phoenix/user-context.yml[/cyan] that carries personal state "
        "(active work cursor, preference overrides) and should NOT be committed.\n\n"
        "Add this line to your [cyan].gitignore[/cyan]:\n"
        "    [bold].fire-phoenix/user-context.yml[/bold]",
        title="[yellow].gitignore Notice[/yellow]",
        border_style="yellow",
        padding=(1, 2),
    )
    console.print()
    console.print(gitignore_notice)
    # Reset the flag so subsequent init invocations in the same process
    # don't repeat the notice (relevant under tests that share a process).
    sys._fire_phoenix_gitignore_preserved = False  # type: ignore[attr-defined]


def _render_agent_folder_security_notice(primary_ai: str) -> None:
    """Render the agent-folder security notice for the primary integration.

    Only fires when the agent advertises a ``folder`` in its config —
    integrations without a per-project folder skip silently.
    """
    agent_config = AGENT_CONFIG.get(primary_ai)
    if not agent_config:
        return
    agent_folder = agent_config["folder"]
    if not agent_folder:
        return
    security_notice = Panel(
        f"Some agents may store credentials, auth tokens, or other identifying and private artifacts in the agent folder within your project.\n"
        f"Consider adding [cyan]{agent_folder}[/cyan] (or parts of it) to [cyan].gitignore[/cyan] to prevent accidental credential leakage.",
        title="[yellow]Agent Folder Security[/yellow]",
        border_style="yellow",
        padding=(1, 2),
    )
    console.print()
    console.print(security_notice)


def _render_next_steps_and_enhancements(
    *,
    here: bool,
    project_name: str | None,
    selected_ais: list[str],
    resolved_integrations: dict[str, Any],
    archetype: str,
) -> None:
    """Render the Next-Steps + Enhancement-Skills panels.

    Skill-mode detection follows adr/0003 + task-0021 §B: codex skills are
    keystroke-invoked (``$<name>``); every other integration uses bare
    slash-command syntax (``/<name>``).
    """
    from ...integrations.skills_integration import SkillsIntegration as _SkillsInt

    steps_lines: list[str] = []
    if not here:
        steps_lines.append(f"1. Go to the project folder: [cyan]cd {project_name}[/cyan]")
        step_num = 2
    else:
        steps_lines.append("1. You're already in the project directory!")
        step_num = 2

    primary_ai = selected_ais[0]
    primary_integration = resolved_integrations[primary_ai]
    _is_skills_integration = isinstance(primary_integration, _SkillsInt)

    codex_skill_mode = primary_ai == "codex" and _is_skills_integration
    claude_skill_mode = primary_ai == "claude" and _is_skills_integration
    cursor_agent_skill_mode = primary_ai == "cursor-agent" and _is_skills_integration
    native_skill_mode = codex_skill_mode or claude_skill_mode or cursor_agent_skill_mode

    if codex_skill_mode:
        steps_lines.append(
            f"{step_num}. Start Codex in this project directory; fire-phoenix skills were installed to [cyan].agents/skills[/cyan]"
        )
        step_num += 1
    if claude_skill_mode:
        steps_lines.append(
            f"{step_num}. Start Claude in this project directory; fire-phoenix skills were installed to [cyan].claude/skills[/cyan]"
        )
        step_num += 1
    if cursor_agent_skill_mode:
        steps_lines.append(
            f"{step_num}. Start Cursor Agent in this project directory; fire-phoenix skills were installed to [cyan].cursor/skills[/cyan]"
        )
        step_num += 1
    usage_label = "skills" if native_skill_mode else "slash commands"

    def _display_cmd(name: str) -> str:
        # Per adr/0003 + task-0021 §B. Codex skills are keystroke-invoked
        # ($<name>); every other integration uses slash-command bare /<name>
        # matching the installed .<integration>/skills/<name>/ folder.
        if codex_skill_mode:
            return f"${name}"
        return f"/{name}"

    steps_lines.append(f"{step_num}. Start using {usage_label} with your AI agent:")

    if archetype == "migration":
        # Migration recipe per adr/0042: recover, map risk + seams, then
        # per-slice parity → cutover under the non-waivable parity obligation.
        steps_lines.append(
            f"   {step_num}.1 [cyan]{_display_cmd('inventory-existing')}[/] - Enumerate the source system (OBSERVED-only)"
        )
        steps_lines.append(
            f"   {step_num}.2 [cyan]{_display_cmd('recover-intent')}[/] / [cyan]{_display_cmd('recover-spec')}[/] - Recover L1 intent + L2 specs from the source"
        )
        steps_lines.append(
            f"   {step_num}.3 [cyan]{_display_cmd('risk-map')}[/] then [cyan]{_display_cmd('seam-analysis')}[/] - Rank code risk, then order strangler-fig slices"
        )
        steps_lines.append(
            f"   {step_num}.4 [cyan]{_display_cmd('characterise-behaviour')}[/] + [cyan]{_display_cmd('parity-ledger')}[/] + [cyan]{_display_cmd('reconciliation-harness')}[/] - Per slice: pin behaviour, prove parity + data"
        )
        steps_lines.append(
            f"   {step_num}.5 [cyan]{_display_cmd('cutover-plan')}[/] - Gated cutover (approver + decommission); the ledger never closes while the old path is live"
        )
    elif archetype == "brownfield":
        # Brownfield recipe per adr/0019 §D: inventory first, then
        # behaviour pinning, then intent recovery, then standard flow.
        steps_lines.append(
            f"   {step_num}.1 [cyan]{_display_cmd('inventory-existing')}[/] - Enumerate what's already here (OBSERVED-only)"
        )
        steps_lines.append(
            f"   {step_num}.2 [cyan]{_display_cmd('characterise-behaviour')}[/] <module> - Pin OBSERVED behaviour BEFORE any change"
        )
        steps_lines.append(
            f"   {step_num}.3 [cyan]{_display_cmd('intent')}[/] - Capture recovered intent (tag INFERRED until promoted)"
        )
        steps_lines.append(
            f"   {step_num}.4 [cyan]{_display_cmd('plan')}[/] - Create implementation plan"
        )
        steps_lines.append(
            f"   {step_num}.5 [cyan]{_display_cmd('taskify')}[/] - Generate actionable tasks"
        )
        steps_lines.append(
            f"   {step_num}.6 [cyan]{_display_cmd('implement')}[/] - Execute implementation"
        )
    else:
        steps_lines.append(
            f"   {step_num}.1 [cyan]{_display_cmd('standardize')}[/] [bright_black](optional)[/bright_black] - Establish project principles (industry-standard defaults apply if skipped)"
        )
        steps_lines.append(
            f"   {step_num}.2 [cyan]{_display_cmd('intent')}[/] - Capture intent for the next change"
        )
        steps_lines.append(
            f"   {step_num}.3 [cyan]{_display_cmd('plan')}[/] - Create implementation plan"
        )
        steps_lines.append(
            f"   {step_num}.4 [cyan]{_display_cmd('taskify')}[/] - Generate actionable tasks"
        )
        steps_lines.append(
            f"   {step_num}.5 [cyan]{_display_cmd('implement')}[/] - Execute implementation"
        )

    steps_panel = Panel(
        "\n".join(steps_lines),
        title=(
            "Next Steps (Migration)"
            if archetype == "migration"
            else "Next Steps (Brownfield)"
            if archetype == "brownfield"
            else "Next Steps"
        ),
        border_style="cyan",
        padding=(1, 2),
    )
    console.print()
    console.print(steps_panel)

    enhancement_intro = (
        "Optional skills that you can use for your intents/specs [bright_black](improve quality & confidence)[/bright_black]"
        if native_skill_mode
        else "Optional commands that you can use for your intents/specs [bright_black](improve quality & confidence)[/bright_black]"
    )
    enhancement_lines = [
        enhancement_intro,
        "",
        f"○ [cyan]{_display_cmd('clarify-intent')}[/] [bright_black](optional)[/bright_black] - Ask structured questions to de-risk ambiguous areas before planning (run before [cyan]{_display_cmd('plan')}[/] if used)",
        f"○ [cyan]{_display_cmd('verify-tasks')}[/] [bright_black](optional)[/bright_black] - Cross-artifact consistency & alignment report (after [cyan]{_display_cmd('taskify')}[/], before [cyan]{_display_cmd('implement')}[/])",
        f"○ [cyan]{_display_cmd('checklist')}[/] [bright_black](optional)[/bright_black] - Generate quality checklists to validate requirements completeness, clarity, and consistency (after [cyan]{_display_cmd('plan')}[/])",
    ]
    enhancements_title = "Enhancement Skills" if native_skill_mode else "Enhancement Commands"
    enhancements_panel = Panel(
        "\n".join(enhancement_lines), title=enhancements_title, border_style="cyan", padding=(1, 2)
    )
    console.print()
    console.print(enhancements_panel)

    _render_subagent_guidelines_panel(archetype=archetype, primary_integration=primary_integration)


def _render_subagent_guidelines_panel(
    *,
    archetype: str,
    primary_integration: Any,
) -> None:
    """Render the curated subagent guidelines panel (task-0069).

    Surfaces a workflow-curated subset of the 15 shipped role-based
    subagents per project type (greenfield vs. brownfield); both variants
    include bug-fixer, code-security-reviewer, and technical-analyst.
    Skipped when the
    primary integration does not install subagents
    (``custom_agents_dest(...) is None``); displaying subagent names in
    that case would mislead the user about what's actually available
    in their project tree.
    """
    # An integration that returns None for custom_agents_dest doesn't
    # install subagents (e.g. its config sets ``agents_subdir: null``).
    # We probe with a dummy path; the helper only inspects integration
    # config, never the filesystem.
    from pathlib import Path

    if primary_integration.custom_agents_dest(Path(".")) is None:
        return

    # Migration reuses the brownfield subagent set (source understanding).
    subagents = _GREENFIELD_SUBAGENTS if archetype == "greenfield" else _BROWNFIELD_SUBAGENTS
    lines = [
        "Role-based AI authoring aids invoked by name [bright_black](exact @<role> syntax varies by integration)[/bright_black]",
        "",
    ]
    for name, description in subagents:
        lines.append(f"○ [cyan]@{name}[/] [bright_black]—[/bright_black] {description}")

    panel = Panel(
        "\n".join(lines),
        title="Recommended Subagents",
        border_style="cyan",
        padding=(1, 2),
    )
    console.print()
    console.print(panel)


def _render_install_conflicts(
    install_conflicts: list[tuple[str, Any]],
    written_paths: dict[Any, str],
    project_path: Any,
) -> None:
    """Surface multi-integration write conflicts after the integration loop."""
    if not install_conflicts:
        return
    console.print()
    conflict_lines = ["[yellow]Installation Conflicts:[/yellow]"]
    for integration_key, dest_path in install_conflicts:  # noqa: B007
        conflict_lines.append(
            f"  ○ [yellow]{dest_path.relative_to(project_path)}[/yellow] — skipped (already written by {written_paths.get(dest_path, 'unknown')})"
        )
    console.print("\n".join(conflict_lines))
    console.print()
