"""Version command implementation."""

import platform

from rich.panel import Panel
from rich.table import Table

from fire_phoenix_cli.ui import console, show_banner
from fire_phoenix_cli.version import get_fire_phoenix_version

from . import app


@app.command()
def version():
    """Display version and system information."""
    show_banner()

    cli_version = get_fire_phoenix_version()

    info_table = Table(show_header=False, box=None, padding=(0, 2))
    info_table.add_column("Key", style="cyan", justify="right")
    info_table.add_column("Value", style="white")

    info_table.add_row("CLI Version", cli_version)
    info_table.add_row("", "")
    info_table.add_row("Python", platform.python_version())
    info_table.add_row("Platform", platform.system())
    info_table.add_row("Architecture", platform.machine())
    info_table.add_row("OS Version", platform.version())

    panel = Panel(
        info_table,
        title="[bold cyan]fire-phoenix Information[/bold cyan]",
        border_style="cyan",
        padding=(1, 2),
    )

    console.print(panel)
    console.print()
