"""Shared helpers for `fire-phoenix workflow ...` subcommands.

Per Tier 2 R2 decomposition: extract common project-root resolution and
status colour mapping used across the workflow CLI command modules.
"""

from typing import Any

from fire_phoenix_cli.ui import console

# Status colours reused by `workflow run`, `workflow resume`, `workflow status`.
STATUS_COLORS: dict[str, str] = {
    "completed": "green",
    "paused": "yellow",
    "needs_input": "yellow",
    "failed": "red",
    "aborted": "red",
    "running": "blue",
    "created": "dim",
}

# Per-step status colours used inside a single run's step list.
# Note: deliberately omits "running" — matches the original behaviour in `workflow status`.
STEP_STATUS_COLORS: dict[str, str] = {
    "completed": "green",
    "failed": "red",
    "paused": "yellow",
    "needs_input": "yellow",
}

# Run-summary status colours used by `workflow status` (no run_id branch).
RUN_SUMMARY_COLORS: dict[str, str] = {
    "completed": "green",
    "failed": "red",
    "paused": "yellow",
    "needs_input": "yellow",
    "running": "blue",
}


def print_needs_input(state: object) -> None:
    """Print run-this-then-resume guidance for a ``needs_input`` run (adr/0047).

    An interactive ``command`` step paused the run: it needs the user to run the
    command in their own agent session, then resume. Surfaces the exact
    invocation (from the paused step's output) and the resume command.
    """
    step_id = getattr(state, "current_step_id", None)
    results = getattr(state, "step_results", {}) or {}
    invocation = None
    if step_id and step_id in results:
        invocation = (results[step_id].get("output") or {}).get("invocation")
    console.print("\n[bold]Next:[/bold] run this in your agent, then resume the workflow:")
    if invocation:
        console.print(f"  [cyan]{invocation}[/cyan]")
    console.print(
        f"\nResume with: [cyan]fire-phoenix workflow resume {getattr(state, 'run_id', '')}[/cyan]"
    )


def on_step_start(step_id: str, label: str, step_type: str = "command") -> None:
    """Default per-step progress printer used by `workflow run` / `workflow resume`.

    Kept for backward compatibility; ``ProgressReporter`` is the richer
    default wired by the CLI.
    """
    from rich.markup import escape

    console.print(f"  ▸ [cyan]{escape(step_id)}[/cyan] [dim]{escape(str(label))}[/dim] …")


class ProgressReporter:
    """Live per-step progress for ``workflow run`` / ``workflow resume``.

    - When fire-phoenix **owns the terminal** (``animate=True`` — an unattended
      ``--auto`` run whose captured agent output can't corrupt the spinner line),
      long-running ``command`` / ``shell`` steps get an animated spinner while
      they execute (rich runs it on a background thread).
    - When it does **not** own the terminal (``animate=False`` — interactive
      runs where the agent CLI is attached to this same terminal, ``--stream``,
      or non-TTY/under an agent), every step gets a static ``▸`` line and **no
      spinner**, so fire-phoenix never renders competing animation over the
      agent's own UI. This is integration-agnostic — it holds for every agent
      CLI, because the decision is about who owns the terminal, not which CLI.
    - Gate and control-flow steps always get a plain ``▸`` line and no spinner.
    - Every step closes with a ``✓`` / ``✗`` / ``⏸`` line and its elapsed
      time; failures also print the error / captured stderr.
    """

    _SPINNABLE = {"command", "shell"}
    _ICONS = {
        "completed": ("✓", "green"),
        "failed": ("✗", "red"),
        "aborted": ("✗", "red"),
        "paused": ("⏸", "yellow"),
        "needs_input": ("⏸", "yellow"),
    }

    def __init__(self, animate: bool = True) -> None:
        # rich Status when a spinner is active, else None; Any avoids importing
        # the rich type just for the annotation.
        self._status: Any = None
        #: Only animate a spinner when fire-phoenix exclusively owns the
        #: terminal. False in interactive/streamed/non-TTY (agent-attached)
        #: runs, so nothing overlaps the agent's own output.
        self._animate = animate

    def start(self, step_id: str, label: str, step_type: str = "command") -> None:
        from rich.markup import escape

        text = f"[cyan]{escape(step_id)}[/cyan] [dim]{escape(str(label))}[/dim] …"
        if step_type in self._SPINNABLE and self._animate:
            self._status = console.status(f"  {text}", spinner="dots")
            self._status.start()
        else:
            self._status = None
            console.print(f"  ▸ {text}")

    def complete(
        self,
        step_id: str,
        status: str,
        elapsed: float = 0.0,
        error: str | None = None,
        output: dict | None = None,
    ) -> None:
        from rich.markup import escape

        if self._status is not None:
            self._status.stop()
            self._status = None

        icon, color = self._ICONS.get(status, ("•", "white"))
        console.print(
            f"  [{color}]{icon}[/{color}] [cyan]{escape(step_id)}[/cyan] "
            f"[{color}]{escape(status)}[/{color}] [dim]({elapsed:.1f}s)[/dim]"
        )

        summary = self._summarize_agent_output((output or {}).get("stdout") or "")
        if summary:
            for line in summary.splitlines():
                console.print(f"    {line}", markup=False, highlight=False)

        if status in ("failed", "aborted"):
            detail = (
                self._summarize_agent_output((output or {}).get("stderr") or "")
                or (error or "").strip()
            )
            if detail:
                console.print(f"    error: {detail}", style="red", markup=False, highlight=False)

    @staticmethod
    def _summarize_agent_output(raw: str) -> str:
        """Reduce an agent CLI's captured output to the human-readable summary.

        Command steps dispatch to the agent CLI with ``--output-format json``
        (so the caller gets a clean exit code), which returns a large machine
        payload. Users care about the agent's final message and any
        approve/reject prompt — not the token counts, cost, and permission
        traces. Extract the ``result`` text from the JSON (whole-string or
        the last JSONL line); if the output isn't JSON, fall back to the raw
        text capped to a few lines so the terminal isn't flooded.
        """
        import json

        raw = (raw or "").strip()
        if not raw:
            return ""

        def _from_obj(obj: object) -> str | None:
            if isinstance(obj, dict):
                for key in ("result", "response", "text", "content", "message"):
                    val = obj.get(key)
                    if isinstance(val, str) and val.strip():
                        return val.strip()
            return None

        # Whole payload as one JSON object …
        try:
            found = _from_obj(json.loads(raw))
            if found:
                return found
        except (ValueError, TypeError):
            pass

        # … or JSONL, where the final `type: result` line carries the summary.
        for line in reversed(raw.splitlines()):
            line = line.strip()
            if not line:
                continue
            try:
                found = _from_obj(json.loads(line))
            except (ValueError, TypeError):
                found = None
            if found:
                return found

        # Not JSON — show at most the first 10 lines of plain text.
        lines = raw.splitlines()
        if len(lines) > 10:
            return "\n".join(lines[:10] + [f"… ({len(lines) - 10} more lines)"])
        return raw


def print_run_failure(state) -> None:
    """Surface the cause of a failed run without the user opening state.json.

    Per-step failures are already reported by ``ProgressReporter``; this
    covers the pre-step case (e.g. an unmet ``requires`` pre-flight, where
    no step ran) by echoing the last logged error.
    """
    from rich.markup import escape

    if getattr(state, "step_results", None):
        return
    for entry in reversed(getattr(state, "log_entries", []) or []):
        if entry.get("error"):
            event = escape(str(entry.get("event", "error")))
            console.print(f"  [red]{event}: {escape(str(entry['error']))}[/red]")
            return
