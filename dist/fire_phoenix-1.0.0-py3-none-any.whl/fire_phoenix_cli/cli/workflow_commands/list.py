"""`fire-phoenix workflow list` — list installed workflows."""

from fire_phoenix_cli.cli._project import require_fire_phoenix_project
from fire_phoenix_cli.ui import console


def workflow_list() -> None:
    """List installed workflows."""
    from fire_phoenix_cli.workflows.catalog import WorkflowRegistry

    project_root = require_fire_phoenix_project(hint=False)

    registry = WorkflowRegistry(project_root)
    installed = registry.list()

    if not installed:
        console.print("[yellow]No workflows installed.[/yellow]")
        console.print("\nInstall a workflow with:")
        console.print("  [cyan]fire-phoenix workflow add <workflow-id>[/cyan]")
        return

    console.print("\n[bold cyan]Installed Workflows:[/bold cyan]\n")
    for wf_id, wf_data in installed.items():
        console.print(
            f"  [bold]{wf_data.get('name', wf_id)}[/bold] ({wf_id}) v{wf_data.get('version', '?')}"
        )
        desc = wf_data.get("description", "")
        if desc:
            console.print(f"    {desc}")
        console.print()
