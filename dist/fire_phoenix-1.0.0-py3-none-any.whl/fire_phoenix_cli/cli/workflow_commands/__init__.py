"""Per-command modules for `fire-phoenix workflow ...`.

This package was extracted from a former monolithic `cli/workflow.py` (Tier 2 R2).
Each module owns one subcommand's body; `cli/workflow.py` stays thin and only
wires the Typer apps together. (The remote `workflow catalog` surface was
removed per adr/0062 — offline-only.)
"""

from .add import workflow_add
from .info import workflow_info
from .list import workflow_list
from .remove import workflow_remove
from .resume import workflow_resume
from .run import workflow_run
from .search import workflow_search
from .status import workflow_status

__all__ = [
    "workflow_add",
    "workflow_info",
    "workflow_list",
    "workflow_remove",
    "workflow_resume",
    "workflow_run",
    "workflow_search",
    "workflow_status",
]
