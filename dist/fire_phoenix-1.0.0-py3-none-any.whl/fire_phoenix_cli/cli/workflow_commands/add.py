"""`fire-phoenix workflow add` — install a workflow from local path or bundled catalog."""

import shutil
from pathlib import Path

import typer
import yaml

from fire_phoenix_cli.cli._project import require_fire_phoenix_project
from fire_phoenix_cli.installer import _locate_bundled_workflow
from fire_phoenix_cli.ui import console


def workflow_add(
    source: str = typer.Argument(..., help="Workflow ID, URL, or local path"),
) -> None:
    """Install a workflow from catalog, URL, or local path."""
    from fire_phoenix_cli.workflows.catalog import (
        WorkflowCatalog,
        WorkflowCatalogError,
        WorkflowRegistry,
    )
    from fire_phoenix_cli.workflows.engine import WorkflowDefinition

    project_root = require_fire_phoenix_project(hint=False)
    registry = WorkflowRegistry(project_root)
    workflows_dir = project_root / ".fire-phoenix" / "workflows"

    def _validate_and_install_local(yaml_path: Path, source_label: str) -> None:
        """Validate and install a workflow from a local YAML file."""
        try:
            definition = WorkflowDefinition.from_yaml(yaml_path)
        except (ValueError, yaml.YAMLError) as exc:
            console.print(f"[red]Error:[/red] Invalid workflow YAML: {exc}")
            raise typer.Exit(1)  # noqa: B904
        if not definition.id or not definition.id.strip():
            console.print("[red]Error:[/red] Workflow definition has an empty or missing 'id'")
            raise typer.Exit(1)

        from fire_phoenix_cli.workflows.engine import validate_workflow

        errors = validate_workflow(definition)
        if errors:
            console.print("[red]Error:[/red] Workflow validation failed:")
            for err in errors:
                console.print(f"  • {err}")
            raise typer.Exit(1)

        dest_dir = workflows_dir / definition.id
        dest_dir.mkdir(parents=True, exist_ok=True)
        shutil.copy2(yaml_path, dest_dir / "workflow.yml")
        registry.add(
            definition.id,
            {
                "name": definition.name,
                "version": definition.version,
                "description": definition.description,
                "source": source_label,
            },
        )
        console.print(f"[green]✓[/green] Workflow '{definition.name}' ({definition.id}) installed")

    # fire-phoenix is offline-only: reject URL sources up-front.
    if source.startswith("http://") or source.startswith("https://"):
        console.print(
            "[red]Error:[/red] fire-phoenix is offline-only; workflows can only be installed "
            "from a local path or the bundled catalog."
        )
        raise typer.Exit(1)

    # Try as a local file/directory
    source_path = Path(source)
    if source_path.exists():
        if source_path.is_file() and source_path.suffix in (".yml", ".yaml"):
            _validate_and_install_local(source_path, str(source_path))
            return
        elif source_path.is_dir():
            wf_file = source_path / "workflow.yml"
            if not wf_file.exists():
                console.print(f"[red]Error:[/red] No workflow.yml found in {source}")
                raise typer.Exit(1)
            _validate_and_install_local(wf_file, str(source_path))
            return

    # Look up in the bundled catalog and install from a bundled workflow
    # directory if one exists. fire-phoenix is offline-only, so there is no
    # fallback to downloading the workflow from a remote URL.
    catalog = WorkflowCatalog(project_root)
    try:
        info = catalog.get_workflow_info(source)
    except WorkflowCatalogError as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(1)  # noqa: B904

    if not info:
        console.print(f"[red]Error:[/red] Workflow '{source}' not found in catalog")
        raise typer.Exit(1)

    # Verify the bundle before installing a bundled workflow from it (F-08).
    from ..integrity_guard import verify_core_pack_or_exit

    verify_core_pack_or_exit()

    bundled_workflow = _locate_bundled_workflow(source)
    if bundled_workflow is None:
        console.print(f"[red]Error:[/red] Workflow '{source}' is not bundled with fire-phoenix.")
        console.print(
            "fire-phoenix is offline-only; only bundled workflows can be installed from the catalog."
        )
        raise typer.Exit(1)

    bundled_yaml = bundled_workflow / "workflow.yml"
    if not bundled_yaml.exists():
        console.print(f"[red]Error:[/red] Bundled workflow '{source}' is missing workflow.yml")
        raise typer.Exit(1)
    _validate_and_install_local(bundled_yaml, f"bundled:{source}")
