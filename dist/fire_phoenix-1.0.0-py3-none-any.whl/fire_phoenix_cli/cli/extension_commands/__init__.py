"""Per-subcommand modules for ``fire-phoenix extension``.

The parent module ``cli/extension.py`` wires the Typer apps and registers each
function exported here as a subcommand. Keeping one command per file caps the
blast radius of edits and makes the decomposition lint-/diff-friendly.
"""
