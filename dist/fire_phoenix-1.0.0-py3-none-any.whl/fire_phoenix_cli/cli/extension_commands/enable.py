"""``fire-phoenix extension enable`` — enable a disabled extension."""

from __future__ import annotations

import typer

from fire_phoenix_cli._lock import guarded_mutation
from fire_phoenix_cli.cli._project import require_fire_phoenix_project
from fire_phoenix_cli.ui import console

from ._common import _resolve_installed_extension


@guarded_mutation
def extension_enable(
    extension: str = typer.Argument(help="Extension ID or name to enable"),
):
    """Enable a disabled extension."""
    from fire_phoenix_cli.extensions import ExtensionManager, HookExecutor

    project_root = require_fire_phoenix_project()

    manager = ExtensionManager(project_root)
    hook_executor = HookExecutor(project_root)

    # Resolve extension ID from argument (handles ambiguous names)
    installed = manager.list_installed()
    extension_id, display_name = _resolve_installed_extension(extension, installed, "enable")

    # Update registry
    metadata = manager.registry.get(extension_id)  # type: ignore[arg-type]
    if metadata is None or not isinstance(metadata, dict):
        console.print(
            f"[red]Error:[/red] Extension '{extension_id}' not found in registry (corrupted state)"
        )
        raise typer.Exit(1)

    if metadata.get("enabled", True):
        console.print(f"[yellow]Extension '{display_name}' is already enabled[/yellow]")
        raise typer.Exit(0)

    manager.registry.update(extension_id, {"enabled": True})  # type: ignore[arg-type]

    # Enable hooks in extensions.yml
    config = hook_executor.get_project_config()
    if "hooks" in config:
        for hook_name in config["hooks"]:
            for hook in config["hooks"][hook_name]:
                if hook.get("extension") == extension_id:
                    hook["enabled"] = True
        hook_executor.save_project_config(config)

    console.print(f"[green]✓[/green] Extension '{display_name}' enabled")
