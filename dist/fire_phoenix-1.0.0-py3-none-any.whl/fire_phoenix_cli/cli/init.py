"""The `fire-phoenix init` project-bootstrap command.

The heavy lifting (prompts, governance/path resolution, scaffolding, the
integration loop, auto-commit, install-phase orchestration, and post-
install panels) lives in :mod:`fire_phoenix_cli.cli.init_helpers`. This
module owns the Typer command definition and threads the helper bundles
together in the order adr/0020 requires (context.yml first, then
integrations, then scaffold).

Test-seam re-exports: every name tests reach for via
``patch("fire_phoenix_cli.cli.init.<X>")`` or ``init_module.<X>`` is
re-imported here so the original patching contract survives the
decomposition. ``multi_select_integrations`` and ``select_with_arrows``
are also surfaced at module level — :mod:`init_helpers.validation` and
:mod:`init_helpers.prompts` look them up through this module so a
monkey-patch on ``init.<name>`` reaches the helper.
"""

# This module is auto-migrated from the former monolithic fire_phoenix_cli/__init__.py.
# All @app.command() / @<group>_app.command() decorators fire at import time,
# which is why cli/__init__.py imports this module explicitly.

import os
import shutil
import sys as sys  # explicit re-export — helpers reach it via init.sys so tests can patch it
from pathlib import Path

import typer
from rich.live import Live
from rich.panel import Panel

from fire_phoenix_cli._lock import LockHeldError, ProjectLock

# Shared helpers (extracted in earlier Phase 6 work).
# BannerGroup and _version_callback are kept for Typer command-registration parity.
from fire_phoenix_cli.ui import (  # noqa: F401  — re-exports kept for Typer registration + init.<name> test patching
    BannerGroup,
    _version_callback,
    console,
    multi_select_integrations as multi_select_integrations,
    select_with_arrows as select_with_arrows,
    show_banner,
)

# The main Typer app created in fire_phoenix_cli.cli.__init__
from . import app  # noqa: E402

# Phase-extracted helpers. Names below are re-exported at module level so
# external callers (notably tests using ``patch("fire_phoenix_cli.cli.init.X")``
# or ``init_module.X``) keep their existing handles after the decomposition.
from .init_helpers.git import (
    _AUTO_COMMIT_MESSAGE,  # noqa: F401  — re-export for downstream tools
    _auto_commit_initial,  # noqa: F401  — re-export for tests
    _capture_pre_init_dirty,
)
from .init_helpers.governance import (
    _GOVERNANCE_DIR_DEFAULTS,  # noqa: F401  — re-export for tests
    _GOVERNANCE_DIR_KEY,  # noqa: F401  — re-export for tests
    _GOVERNANCE_FILE_DEFAULTS,  # noqa: F401  — re-export for tests
    _GOVERNANCE_FILE_KEY,  # noqa: F401  — re-export for tests
    _build_sentinel_map,  # noqa: F401  — re-export for tests
    _resolve_paths_and_governance,  # noqa: F401  — re-export for tests
)
from .init_helpers.orchestrator import (
    _build_context_kwargs,  # noqa: F401  — re-export for tests
    _build_tracker,
    _resolve_languages_and_roles,
    _run_install_phases,
)
from .init_helpers.panels import (
    _render_agent_folder_security_notice,
    _render_auto_commit_skipped_notice,
    _render_gitignore_preserved_notice,
    _render_install_conflicts,  # noqa: F401  — re-export for tests
    _render_next_steps_and_enhancements,
)
from .init_helpers.probe import _read_existing_context_values
from .init_helpers.prompts import (
    _NON_TECH_ROLE_LEVEL_DESCRIPTIONS,  # noqa: F401  — re-export for tests
    _TECH_ROLE_LEVEL_DESCRIPTIONS,  # noqa: F401  — re-export for tests
    _prompt_with_default,  # noqa: F401  — re-export for tests
    _select_role_level,  # noqa: F401  — re-export for tests
)
from .init_helpers.rollback import (  # noqa: F401  — explicit re-export; patch target
    _rollback_partial_state as _rollback_partial_state,
)
from .init_helpers.scaffold import (
    _CANONICAL_SCAFFOLD_FILES,  # noqa: F401  — re-export for tests
    _scaffold_artefacts,  # noqa: F401  — re-export for tests
    _scaffold_codeowners,  # noqa: F401  — re-export for tests
    _scaffold_gitignore,  # noqa: F401  — re-export for tests
    _scaffold_l1_l4,  # noqa: F401  — re-export for tests
)
from .init_helpers.setup import (
    _install_bundled_custom_agents,  # noqa: F401  — re-export for tests
    _install_bundled_workflow,  # noqa: F401  — re-export for tests
    _install_git_extension,  # noqa: F401  — re-export for tests
    _install_integrations,  # noqa: F401  — re-export for tests
    _install_preset,  # noqa: F401  — re-export for tests
    _verify_and_install_shared_infra,  # noqa: F401  — re-export for tests
)
from .init_helpers.validation import (
    _check_agent_tool,
    _check_git_tool,
    _print_setup_panel,
    _resolve_project_path,
    _select_ais_and_resolve,
    _validate_branch_numbering,
    _validate_integration_flag,
    _validate_project_name_and_here,
    _validate_role_levels,
    _validate_scaffold_flags,
)


@app.command()
def init(
    project_name: str = typer.Argument(
        None,
        help="Name for your new project directory (optional if using --here, or use '.' for current directory)",
    ),
    ignore_agent_tools: bool = typer.Option(
        False, "--ignore-agent-tools", help="Skip checks for AI agent tools like Claude Code"
    ),
    no_git: bool = typer.Option(False, "--no-git", help="Skip git repository initialization"),
    here: bool = typer.Option(
        False,
        "--here",
        help="Initialize project in the current directory instead of creating a new one",
    ),
    force: bool = typer.Option(
        False, "--force", help="Force merge/overwrite when using --here (skip confirmation)"
    ),
    preset: str = typer.Option(
        None, "--preset", help="Install a preset during initialization (by preset ID)"
    ),
    branch_numbering: str = typer.Option(
        None,
        "--branch-numbering",
        help="Branch numbering strategy: 'sequential' (001, 002, …, 1000, … — expands past 999 automatically) or 'timestamp' (YYYYMMDD-HHMMSS)",
    ),
    integration: list[str] = typer.Option(
        None,
        "--integration",
        help="Install integrations non-interactively. Repeatable, and each value may be a comma-separated list — `--integration claude --integration copilot` and `--integration claude,copilot` are equivalent. Omit to use the interactive multi-select picker.",
    ),
    integration_options: str = typer.Option(
        None,
        "--integration-options",
        help='Options for the integration (e.g. --integration-options="--commands-dir .myagent/cmds")',
    ),
    no_scaffold: bool = typer.Option(
        False,
        "--no-scaffold",
        help="Skip the L1-L4 IDD artefact scaffold (product/status/decisions files + specs/contracts/adr dirs) AND the .gitignore scaffold. Default destinations are docs/-rooted; CLAUDE.md stays at root.",
    ),
    archetype: str = typer.Option(
        None,
        "--archetype",
        help=(
            "Project archetype: greenfield | brownfield (source "
            "archaeology with OBSERVED/INFERRED/UNKNOWN epistemic tagging) | "
            "migration (brownfield source + greenfield target + a non-waivable "
            "parity obligation). Omitted: the archetype recorded in an "
            "existing .fire-phoenix/context.yml, else greenfield. An explicit "
            "non-greenfield archetype is mutually exclusive with "
            "--no-scaffold."
        ),
    ),
    # ---------------------------------------------------------------------
    # Governance: block CLI flags (adr/0020). Each, if passed, is persisted
    # to .fire-phoenix/context.yml and substituted into scaffold templates.
    # Omitted flags use the documented defaults.
    # ---------------------------------------------------------------------
    product_file: str = typer.Option(
        None,
        "--product-file",
        help="Filename for the L1 product intent file (default: docs/PRODUCT.md).",
    ),
    status_file: str = typer.Option(
        None,
        "--status-file",
        help="Filename for the L1 in-flight status file (default: docs/STATUS.md).",
    ),
    decisions_file: str = typer.Option(
        None,
        "--decisions-file",
        help="L4 decisions index filename (default: docs/decisions.md).",
    ),
    specs_dir: str = typer.Option(
        None,
        "--specs-dir",
        help="Directory holding L2 epic specs (default: docs/specs).",
    ),
    contracts_dir: str = typer.Option(
        None,
        "--contracts-dir",
        help="Directory holding L3 task contracts (default: docs/contracts).",
    ),
    adr_dir: str = typer.Option(
        None,
        "--adr-dir",
        help="Directory holding L4 numbered ADRs (default: docs/adr).",
    ),
    # ---------------------------------------------------------------------
    # Paths: block CLI flags (adr/0020). Same semantics: persisted to
    # context.yml; omitted flags use the documented defaults.
    # ---------------------------------------------------------------------
    docs_dir: str = typer.Option(
        None,
        "--docs-dir",
        help="Root documentation directory (default: docs).",
    ),
    intents_dir: str = typer.Option(
        None,
        "--intents-dir",
        help="Directory for skill-output intent files (default: docs/intents).",
    ),
    plans_dir: str = typer.Option(
        None,
        "--plans-dir",
        help="Directory for skill-output plan files (default: docs/plans).",
    ),
    tasks_dir: str = typer.Option(
        None,
        "--tasks-dir",
        help="Directory for skill-output tasks files (default: docs/tasks).",
    ),
    templates_dir: str = typer.Option(
        None,
        "--templates-dir",
        help="Directory pointer for skill templates subfolder (default: templates).",
    ),
    scripts_dir: str = typer.Option(
        None,
        "--scripts-dir",
        help="Directory pointer for skill scripts subfolder (default: scripts).",
    ),
    # ---------------------------------------------------------------------
    # Language + role-level flags (adr/0030). Bypass the corresponding
    # interactive prompt; documented defaults apply when omitted in
    # non-interactive (non-TTY) invocations.
    # ---------------------------------------------------------------------
    lang_output: str = typer.Option(
        None,
        "--lang-output",
        help="Language for written artefacts (default: English). Persisted to language.output in both context.yml and user-context.yml.",
    ),
    lang_interaction: str = typer.Option(
        None,
        "--lang-interaction",
        help="Language for questions and confirmations (default: English). Persisted to language.interaction in both files.",
    ),
    non_tech_role_level: str = typer.Option(
        None,
        "--non-tech-role-level",
        help="Technical fluency of non-tech roles (BA, PM, Scrum Master). One of: non-technical | familiar | fluent | technical. Default: non-technical.",
    ),
    tech_role_level: str = typer.Option(
        None,
        "--tech-role-level",
        help="Career-ladder level of tech roles (engineer, tech lead, architect). One of: junior | mid | senior | staff. Default: mid.",
    ),
):
    """
    Initialize a new fire-phoenix project.

    Scaffolds the project entirely from assets bundled inside the `fire-phoenix`
    package — no network access is required or performed.

    This command will:
    1. Check that required tools are installed (git is optional)
    2. Let you choose one or more AI providers (multi-select)
    3. Copy bundled templates, scripts, and context file into the project
    4. Initialize a fresh git repository (unless `--no-git`)
    5. Set up each selected AI provider's skills / commands

    Examples:
        fire-phoenix init my-project                       # interactive multi-select
        fire-phoenix init my-project --integration claude  # one integration, non-interactive
        fire-phoenix init my-project --integration claude,copilot   # or repeat the flag
        fire-phoenix init .                                # initialize in current directory
        fire-phoenix init --here --force                   # merge into non-empty current dir
        fire-phoenix init my-project --preset healthcare-compliance
    """

    show_banner()

    # Upfront flag validation — every helper here raises typer.Exit on
    # failure so we never touch disk with bad input.
    _validate_scaffold_flags(archetype, no_scaffold)
    ai_keys, _resolved = _validate_integration_flag(integration)
    # The Typer Argument types ``project_name`` as ``str`` but ``"."`` normalises
    # to ``None`` (matches ``--here``), matching the pre-extraction inline logic.
    project_name, here = _validate_project_name_and_here(project_name, here)  # type: ignore[assignment]
    _validate_branch_numbering(branch_numbering)
    _validate_role_levels(non_tech_role_level, tech_role_level)

    # adr/0031: snapshot the working tree's dirty state BEFORE any scaffold
    # writes happen. If --here lands on an existing repo with uncommitted
    # user changes, _auto_commit_initial declines to roll them into the
    # "Initial commit from Fire Phoenix Framework" commit.
    pre_init_dirty: set[str] = set()
    project_path, project_name, dir_existed_before = _resolve_project_path(
        project_name, here=here, force=force
    )

    # Clear the process-global notice flags at the start of every run so state
    # from a prior init in the same process (e.g. a failure that never reached
    # the notice-render step) cannot leak a spurious notice into this one.
    sys._fire_phoenix_gitignore_preserved = False  # type: ignore[attr-defined]
    sys._fire_phoenix_commit_skipped_dirty = False  # type: ignore[attr-defined]

    if dir_existed_before:
        pre_init_dirty = _capture_pre_init_dirty(project_path)

    # adr/0068: values recorded in a pre-existing
    # context.yml survive re-init unless a CLI flag explicitly overrides them.
    # Precedence everywhere below: CLI flag > existing context.yml > default.
    existing_context_values = _read_existing_context_values(project_path)
    archetype = archetype or existing_context_values.get("archetype") or "greenfield"
    _validate_scaffold_flags(archetype, no_scaffold=False)  # enum check on the resolved value

    selected_ais, resolved_integrations = _select_ais_and_resolve(ai_keys, integration_options)

    _print_setup_panel(project_path, here=here)

    should_init_git = _check_git_tool(no_git)
    _check_agent_tool(selected_ais, ignore_agent_tools)

    # Script variant is selected at runtime from the current platform. Both
    # bash/ and powershell/ are always bundled into each skill folder, so
    # downstream tools can pick whichever they need.
    runtime_script_type = "ps" if os.name == "nt" else "sh"

    console.print(f"[cyan]Selected AI providers:[/cyan] {', '.join(selected_ais)}")

    (
        resolved_lang_output,
        resolved_lang_interaction,
        resolved_non_tech_role_level,
        resolved_tech_role_level,
    ) = _resolve_languages_and_roles(
        lang_output=lang_output,
        lang_interaction=lang_interaction,
        non_tech_role_level=non_tech_role_level,
        tech_role_level=tech_role_level,
        existing_context=existing_context_values,
    )

    tracker = _build_tracker(selected_ais, no_scaffold=no_scaffold)
    sys._fire_phoenix_tracker_active = True  # type: ignore[attr-defined]

    # F-06: hold the project lock across the mutating install phase
    # (acquired AFTER path resolution so it never pollutes the empty-dir
    # pre-flight above).
    _project_lock = ProjectLock(project_path)
    try:
        _project_lock.acquire()
    except LockHeldError as _exc:
        console.print(f"[red]Error:[/red] {_exc}")
        raise typer.Exit(1) from _exc

    def _rollback_after_abort() -> None:
        """Restore the pre-init state after any aborted run (AC-PH-004): remove a
        fresh dir wholesale; for ``--here`` drop only this run's writes (adr/0061).
        """
        if not here and project_path.exists() and not dir_existed_before:
            shutil.rmtree(project_path, ignore_errors=True)
        else:
            _rollback_partial_state(project_path)

    try:
        with Live(tracker.render(), console=console, refresh_per_second=8, transient=True) as live:
            tracker.attach_refresh(lambda: live.update(tracker.render()))
            try:
                _run_install_phases(
                    project_path=project_path,
                    selected_ais=selected_ais,
                    resolved_integrations=resolved_integrations,
                    runtime_script_type=runtime_script_type,
                    integration_options=integration_options,
                    no_git=no_git,
                    should_init_git=should_init_git,
                    no_scaffold=no_scaffold,
                    archetype=archetype,
                    force=force,
                    pre_init_dirty=pre_init_dirty,
                    resolved_lang_output=resolved_lang_output,
                    resolved_lang_interaction=resolved_lang_interaction,
                    resolved_non_tech_role_level=resolved_non_tech_role_level,
                    resolved_tech_role_level=resolved_tech_role_level,
                    here=here,
                    branch_numbering=branch_numbering,
                    preset=preset,
                    docs_dir=docs_dir,
                    intents_dir=intents_dir,
                    plans_dir=plans_dir,
                    tasks_dir=tasks_dir,
                    templates_dir=templates_dir,
                    scripts_dir=scripts_dir,
                    product_file=product_file,
                    status_file=status_file,
                    decisions_file=decisions_file,
                    specs_dir=specs_dir,
                    contracts_dir=contracts_dir,
                    adr_dir=adr_dir,
                    tracker=tracker,
                )
            except (typer.Exit, SystemExit) as abort:
                # AC-PH-004: an internal abort (e.g. the corrupt-bundle guard) used
                # to skip rollback entirely, shipping a half-populated project dir.
                if getattr(abort, "exit_code", getattr(abort, "code", 1)):
                    _rollback_after_abort()
                raise
            except KeyboardInterrupt:  # AC-PH-004: Ctrl-C had no rollback at all.
                console.print("\n[yellow]Interrupted — rolling back.[/yellow]")
                _rollback_after_abort()
                raise
            except Exception as e:
                tracker.error("final", str(e))
                console.print(
                    Panel(f"Initialization failed: {e}", title="Failure", border_style="red")
                )
                if os.environ.get("FIRE_PHOENIX_DEBUG"):
                    _env_pairs = [
                        ("Python", sys.version.split()[0]),
                        ("Platform", sys.platform),
                        ("CWD", str(Path.cwd())),
                    ]
                    _label_width = max(len(k) for k, _ in _env_pairs)
                    env_lines = [
                        f"{k.ljust(_label_width)} → [bright_black]{v}[/bright_black]"
                        for k, v in _env_pairs
                    ]
                    console.print(
                        Panel(
                            "\n".join(env_lines), title="Debug Environment", border_style="magenta"
                        )
                    )
                _rollback_after_abort()
                raise typer.Exit(1)  # noqa: B904

    finally:
        _project_lock.release()
    console.print(tracker.render())
    console.print("\n[bold green]Project ready.[/bold green]")

    # adr/0031: when auto-commit was skipped because the working tree
    # had pre-existing uncommitted changes, surface a notice so the
    # user knows the scaffold is staged but not committed.
    _render_auto_commit_skipped_notice()

    # adr/0030: when an existing .gitignore was preserved, the new
    # .fire-phoenix/user-context.yml entry didn't get added automatically.
    # Surface a one-line notice so the user adds it themselves.
    _render_gitignore_preserved_notice()

    # Agent folder security notice (for primary agent)
    _render_agent_folder_security_notice(selected_ais[0])

    _render_next_steps_and_enhancements(
        here=here,
        project_name=project_name,
        selected_ais=selected_ais,
        resolved_integrations=resolved_integrations,
        archetype=archetype,
    )
