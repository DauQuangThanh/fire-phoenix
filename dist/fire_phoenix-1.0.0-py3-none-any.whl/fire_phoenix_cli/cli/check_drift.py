"""`fire-phoenix check drift` — behaviour-without-intent surface.

Walks `git log --name-only`, classifies each commit's touched paths as
**behavioural** (paths under `src/`, `assets/agent-skills/`,
`assets/subagents/`) or **intent** (paths under `governance.contracts_dir`,
`governance.specs_dir`, `governance.adr_dir`, or the `PRODUCT.md` literal),
and surfaces commits that carry behavioural changes without a matching
intent update or amendment marker on a touched contract.

A commit is flagged `DRIFTED` when:
- ≥ 1 behavioural path changed, AND
- zero intent paths changed, AND
- none of the touched contract files carry an amendment marker
  (`## Amendments` heading OR `## YYYY-MM-DD — <note>` dated marker).

Default output is a Markdown table written to
`{context.paths.docs}/drift/<timestamp>.md`. `--json` switches to a
JSON envelope on stdout.

Offline: only `git log` (local objects) and local file reads. Per
`PRODUCT.md` §Invariants and `adr/0027`.
"""

from __future__ import annotations

import json
import re
import subprocess
from dataclasses import asdict, dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import yaml
from rich.console import Console
from rich.table import Table

from fire_phoenix_cli.context import SchemaVersionError, load_context_file

from . import app
from .check_common import _load_context, _resolve_docs_dir

# Behavioural and intent path-prefix sets. Kept in sync with `adr/0027`
# §Decision. The intent set is augmented at runtime with the
# governance dirs from `.fire-phoenix/context.yml`.
_BEHAVIOURAL_PREFIXES_DEFAULT = (
    "src/",
    "assets/agent-skills/",
    "assets/subagents/",
)

_INTENT_PREFIXES_DEFAULT = (
    "contracts/",
    "specs/",
    "adr/",
)

_INTENT_FILES_DEFAULT = ("PRODUCT.md",)

# Amendment marker regexes. Two accepted shapes:
#   (a) an `## Amendments` heading (case-insensitive);
#   (b) one or more `## YYYY-MM-DD — <note>` dated markers.
# Either suffices to pass R8 / drift's contract-amendment probe.
_AMENDMENT_HEADING_RE = re.compile(r"^##\s+Amendments\b", re.IGNORECASE | re.MULTILINE)
_AMENDMENT_DATED_RE = re.compile(r"^##\s+\d{4}-\d{2}-\d{2}\s+[—-]", re.MULTILINE)

console = Console()


@dataclass
class DriftRow:
    """One row of the drift matrix.

    Attributes:
        commit_sha: 40-char SHA of the commit.
        commit_date: ISO-ish commit date (from `%ci`).
        subject: Commit subject line.
        behavioural: Behavioural files touched in this commit.
        intent: Intent files touched in this commit.
        status: "OK" or "DRIFTED".
        diagnostic: Short reason when status is DRIFTED, empty otherwise.
    """

    commit_sha: str
    commit_date: str
    subject: str
    behavioural: list[str] = field(default_factory=list)
    intent: list[str] = field(default_factory=list)
    status: str = "OK"
    diagnostic: str = ""


def _resolve_governance(project_root: Path) -> tuple[tuple[str, ...], tuple[str, ...]]:
    """Read governance dirs from context; return (intent_prefixes, intent_files)."""
    try:
        context = load_context_file(project_root)
    except (SchemaVersionError, OSError, yaml.YAMLError, ValueError):
        # SchemaVersionError (wrong schema_version), OSError (unreadable file),
        # yaml.YAMLError (malformed YAML), ValueError (PathTraversalError /
        # UnicodeDecodeError) all degrade to the built-in governance defaults.
        # A non-config bug is not in this set and MUST surface.
        return _INTENT_PREFIXES_DEFAULT, _INTENT_FILES_DEFAULT

    governance = context.get("governance") if isinstance(context, dict) else None
    if not isinstance(governance, dict):
        return _INTENT_PREFIXES_DEFAULT, _INTENT_FILES_DEFAULT

    intent_prefixes: list[str] = []
    for key in ("contracts_dir", "specs_dir", "adr_dir"):
        value = governance.get(key)
        if isinstance(value, str) and value.strip():
            intent_prefixes.append(value.strip().rstrip("/") + "/")

    intent_files: list[str] = []
    product_file = governance.get("product_file")
    if isinstance(product_file, str) and product_file.strip():
        intent_files.append(product_file.strip())
    else:
        intent_files.append("PRODUCT.md")

    return (
        tuple(intent_prefixes) if intent_prefixes else _INTENT_PREFIXES_DEFAULT,
        tuple(intent_files) if intent_files else _INTENT_FILES_DEFAULT,
    )


def _run_git_log(project_root: Path, since: str | None) -> list[tuple[str, str, str, list[str]]]:
    """Run `git log --name-only` and return [(sha, date, subject, files), ...].

    Returns an empty list if the repository has no commits in the
    window or no `.git` directory.
    """
    if not (project_root / ".git").exists():
        return []

    # Separator chosen to be unlikely in a commit subject: `COMMIT␟`.
    # We use a plain `COMMIT ` prefix and three space-separated fields:
    # `COMMIT <sha> <ci-date> <subject…>`. Subject may contain spaces;
    # parsing splits on the first 3 whitespace runs.
    cmd = [
        "git",
        "log",
        "--name-only",
        "--pretty=format:COMMIT %H %ci %s",
    ]
    if since:
        cmd.append(f"--since={since}")

    try:
        result = subprocess.run(
            cmd,
            cwd=project_root,
            capture_output=True,
            text=True,
            check=False,
            timeout=30,
        )
    except (subprocess.SubprocessError, FileNotFoundError):
        return []

    if result.returncode != 0:
        return []

    commits: list[tuple[str, str, str, list[str]]] = []
    current_sha: str | None = None
    current_date: str = ""
    current_subject: str = ""
    current_files: list[str] = []
    # A commit header is `COMMIT <40-hex-sha> …`; require the hex sha so a
    # tracked file whose path merely starts with "COMMIT " (printed by
    # `--name-only`) is not misparsed as a new commit header.
    commit_header = re.compile(r"^COMMIT [0-9a-f]{7,40} ")
    for raw in result.stdout.splitlines():
        if commit_header.match(raw):
            if current_sha is not None:
                commits.append((current_sha, current_date, current_subject, current_files))
            # Parse: `COMMIT <sha> <date1> <date2> <date3> <subject>`.
            # `%ci` expands to e.g. `2026-06-10 14:32:01 +0700` — three
            # whitespace-separated tokens. So skip 1 (COMMIT) + 1 (sha) +
            # 3 (date) = 5 tokens, the rest is subject.
            parts = raw.split(None, 5)
            if len(parts) >= 5:
                current_sha = parts[1]
                current_date = " ".join(parts[2:5])
                current_subject = parts[5] if len(parts) >= 6 else ""
            else:
                # Malformed line; skip.
                current_sha = None
            current_files = []
        elif raw.strip() and current_sha is not None:
            current_files.append(raw.strip())
    if current_sha is not None:
        commits.append((current_sha, current_date, current_subject, current_files))
    return commits


def _classify(
    fpath: str,
    intent_prefixes: tuple[str, ...],
    intent_files: tuple[str, ...],
) -> str | None:
    """Return 'behavioural', 'intent', or None for an untracked path."""
    for prefix in _BEHAVIOURAL_PREFIXES_DEFAULT:
        if fpath.startswith(prefix):
            return "behavioural"
    for prefix in intent_prefixes:
        if fpath.startswith(prefix):
            return "intent"
    if fpath in intent_files:
        return "intent"
    return None


def _has_amendment_marker(text: str) -> bool:
    """True iff the contract body carries an amendment marker."""
    if _AMENDMENT_HEADING_RE.search(text):
        return True
    if _AMENDMENT_DATED_RE.search(text):
        return True
    return False


def _contract_has_marker(
    project_root: Path,
    contract_rel: str,
    intent_prefixes: tuple[str, ...],
) -> bool:
    """Read a touched contract and report whether it carries a marker.

    Only files under a configured intent prefix that looks like a
    contracts dir are inspected — we approximate "looks like contracts
    dir" as any prefix containing 'contract'.
    """
    is_contract = any(
        "contract" in p.lower() and contract_rel.startswith(p) for p in intent_prefixes
    )
    if not is_contract:
        return False
    contract_path = project_root / contract_rel
    if not contract_path.exists():
        return False
    try:
        text = contract_path.read_text(encoding="utf-8")
    except OSError:
        return False
    return _has_amendment_marker(text)


def _build_rows(
    project_root: Path,
    since: str | None,
) -> list[DriftRow]:
    """Build the drift matrix for the project.

    Walks git log, classifies each commit's files, and emits one row
    per commit that touched at least one tracked path.
    """
    if not (project_root / ".git").exists():
        return [
            DriftRow(
                commit_sha="",
                commit_date="",
                subject="Not a git repository",
                status="OK",
                diagnostic="No .git directory; drift detection skipped.",
            )
        ]

    intent_prefixes, intent_files = _resolve_governance(project_root)
    commits = _run_git_log(project_root, since)
    if not commits:
        return []

    rows: list[DriftRow] = []
    for sha, date, subject, files in commits:
        behavioural: list[str] = []
        intent: list[str] = []
        for fpath in files:
            classification = _classify(fpath, intent_prefixes, intent_files)
            if classification == "behavioural":
                behavioural.append(fpath)
            elif classification == "intent":
                intent.append(fpath)

        # Only commits touching at least one tracked path produce a row.
        if not behavioural and not intent:
            continue

        status = "OK"
        diagnostic = ""
        if behavioural and not intent:
            # Behavioural-only commit — no intent file touched, so no
            # amendment marker can satisfy the §C4 condition.
            status = "DRIFTED"
            diagnostic = "behavioural change with no intent update"
        elif behavioural and intent:
            # Mixed commit. Intent was updated alongside behaviour;
            # treat as OK. Annotate when a contract marker is present.
            any_marker = any(_contract_has_marker(project_root, c, intent_prefixes) for c in intent)
            diagnostic = "marker-present" if any_marker else ""

        rows.append(
            DriftRow(
                commit_sha=sha,
                commit_date=date,
                subject=subject,
                behavioural=behavioural,
                intent=intent,
                status=status,
                diagnostic=diagnostic,
            )
        )

    return rows


def _render_markdown(rows: list[DriftRow]) -> str:
    """Render the drift matrix as a Markdown table."""
    header = (
        "| Commit | Date | Subject | Status | Behavioural | Intent | Notes |\n"
        "|---|---|---|---|---|---|---|\n"
    )
    if not rows:
        return header + "| _(no commits in window)_ |  |  |  |  |  |  |\n"

    body_lines: list[str] = []
    for row in rows:
        sha_short = row.commit_sha[:8] if row.commit_sha else "—"
        date = row.commit_date.split()[0] if row.commit_date else "—"
        subject = (row.subject or "").replace("|", "\\|")
        if len(subject) > 80:
            subject = subject[:77] + "..."
        beh = ", ".join(row.behavioural) if row.behavioural else "—"
        if len(beh) > 120:
            beh = beh[:117] + "..."
        intent = ", ".join(row.intent) if row.intent else "—"
        if len(intent) > 120:
            intent = intent[:117] + "..."
        notes = (row.diagnostic or "").replace("|", "\\|")
        body_lines.append(
            f"| `{sha_short}` | {date} | {subject} | {row.status} | {beh} | {intent} | {notes} |"
        )
    return header + "\n".join(body_lines) + "\n"


def _render_console_table(rows: list[DriftRow]) -> Table:
    """Render the drift matrix as a Rich table for stdout."""
    table = Table(title="Drift matrix", show_lines=False)
    table.add_column("Commit", style="dim")
    table.add_column("Date")
    table.add_column("Subject", style="cyan")
    table.add_column("Status", style="bold")
    table.add_column("Behavioural")
    table.add_column("Intent")
    for row in rows:
        status_style = "green" if row.status == "OK" else "red"
        date = row.commit_date.split()[0] if row.commit_date else "—"
        subject = row.subject or "—"
        if len(subject) > 60:
            subject = subject[:57] + "..."
        beh = ", ".join(row.behavioural) if row.behavioural else "—"
        intent = ", ".join(row.intent) if row.intent else "—"
        table.add_row(
            (row.commit_sha[:8] if row.commit_sha else "—"),
            date,
            subject,
            f"[{status_style}]{row.status}[/{status_style}]",
            beh,
            intent,
        )
    return table


def _write_markdown_report(project_root: Path, rows: list[DriftRow]) -> Path:
    """Write the Markdown report to `{paths.docs}/drift/<timestamp>.md`."""
    docs_dir = _resolve_docs_dir(_load_context(project_root))
    timestamp = datetime.now(UTC).strftime("%Y%m%d-%H%M%S")
    out_dir = project_root / docs_dir / "drift"
    out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / f"{timestamp}.md"

    total = len(rows)
    ok = sum(1 for r in rows if r.status == "OK")
    drifted = sum(1 for r in rows if r.status == "DRIFTED")

    header = (
        f"# Drift matrix — {timestamp} UTC\n\n"
        f"Generated by `fire-phoenix check drift` per `adr/0027-drift-detection.md`.\n\n"
        f"- Total rows: {total}\n"
        f"- OK: {ok}\n"
        f"- DRIFTED: {drifted}\n\n"
        f"## Matrix\n\n"
    )
    out_path.write_text(header + _render_markdown(rows), encoding="utf-8")
    return out_path


def _summary(rows: list[DriftRow]) -> dict[str, int]:
    """Return the summary aggregate for the matrix."""
    return {
        "total": len(rows),
        "ok": sum(1 for r in rows if r.status == "OK"),
        "drifted": sum(1 for r in rows if r.status == "DRIFTED"),
    }


def run_drift(
    since: str | None,
    json_output: bool,
    project_root: Path | None = None,
) -> int:
    """Walk merged commits, classify, and report drift between behaviour and intent.

    Args:
        since: Optional `git log --since=<ref>` value (e.g. `"30 days ago"`).
        json_output: If True, emit JSON to stdout. Otherwise write a
            Markdown report to `{paths.docs}/drift/<timestamp>.md`.
        project_root: Project root (defaults to `Path.cwd()`).

    Returns:
        Exit code: `0` if no `DRIFTED` row (or no commits in window),
        `1` if any `DRIFTED` row exists.
    """
    if project_root is None:
        project_root = Path.cwd()

    rows = _build_rows(project_root, since)
    summary = _summary(rows)

    if json_output:
        payload: dict[str, Any] = {
            "rows": [asdict(r) for r in rows],
            "summary": summary,
        }
        print(json.dumps(payload, indent=2, ensure_ascii=False))
    else:
        if rows:
            console.print(_render_console_table(rows))
        out_path = _write_markdown_report(project_root, rows)
        try:
            rel = out_path.relative_to(project_root)
        except ValueError:
            rel = out_path
        console.print(f"\n[bold]Report written:[/bold] {rel}")
        console.print(
            f"[dim]Total: {summary['total']} | OK: {summary['ok']} | "
            f"DRIFTED: {summary['drifted']}[/dim]"
        )

    return 0 if summary["drifted"] == 0 else 1


__all__ = ["run_drift", "DriftRow"]

# Suppress unused-import lint for the package-level `app` import; kept
# for parity with sibling modules whose `app` reference is implicit via
# decorators on the shared Typer group.
_ = app
