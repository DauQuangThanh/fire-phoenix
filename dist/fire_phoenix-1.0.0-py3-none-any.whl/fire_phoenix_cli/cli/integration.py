"""Integration management commands (`fire-phoenix integration ...`).

This module is a thin shim — the per-command implementations live under
``cli/integration_commands/``. Importing this module triggers the registration
of every ``integration_app`` subcommand against the top-level Typer app.
"""

# Importing the package executes its ``__init__`` which in turn imports
# every per-command module, firing each @integration_app.command() decorator.
from . import integration_commands  # noqa: F401
from .integration_commands._common import integration_app  # noqa: F401
