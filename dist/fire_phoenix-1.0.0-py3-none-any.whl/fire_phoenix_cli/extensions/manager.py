"""Extension lifecycle orchestration.

Owns :class:`ExtensionManager`, which threads together the registry,
manifest resolver, command registrar, hook executor, and on-disk
install steps so that a single ``install_from_directory()`` /
``install_from_zip()`` / ``remove()`` call leaves the project in a
consistent state.

Heavy lifting (config / hook persistence, command file writes) lives in
:mod:`.installer`; pure data structures live in :mod:`.registry`;
manifest parsing and validation live in :mod:`.resolver`.
"""

from __future__ import annotations

import contextlib
import shutil
import tempfile
import zipfile
from collections.abc import Callable
from pathlib import Path
from typing import Any

import pathspec
from packaging.specifiers import InvalidSpecifier, SpecifierSet

from packaging import version as pkg_version

from .installer import CommandRegistrar, HookExecutor
from .registry import ExtensionRegistry, normalize_priority
from .resolver import (
    CORE_COMMAND_NAMES,
    EXTENSION_COMMAND_NAME_PATTERN,
    CompatibilityError,
    ExtensionError,
    ExtensionManifest,
    ValidationError,
)


class ExtensionManager:
    """Manages extension lifecycle: installation, removal, updates."""

    def __init__(self, project_root: Path):
        """Initialize extension manager.

        Args:
            project_root: Path to project root directory
        """
        self.project_root = project_root
        self.extensions_dir = project_root / ".fire-phoenix" / "extensions"
        self.registry = ExtensionRegistry(self.extensions_dir)

    @staticmethod
    def _collect_manifest_command_names(manifest: ExtensionManifest) -> dict[str, str]:
        """Collect command and alias names declared by a manifest.

        Performs install-time validation for extension-specific constraints:
        - primary commands must use the canonical `fire-phoenix.{extension}.{command}` shape
        - primary commands must use this extension's namespace
        - command namespaces must not shadow core commands
        - duplicate command/alias names inside one manifest are rejected
        - aliases are validated for type and uniqueness only (no pattern enforcement)

        Args:
            manifest: Parsed extension manifest

        Returns:
            Mapping of declared command/alias name -> kind ("command"/"alias")

        Raises:
            ValidationError: If any declared name is invalid
        """
        if manifest.id in CORE_COMMAND_NAMES:
            raise ValidationError(
                f"Extension ID '{manifest.id}' conflicts with core command namespace '{manifest.id}'"
            )

        declared_names: dict[str, str] = {}

        for cmd in manifest.commands:
            primary_name = cmd["name"]
            aliases = cmd.get("aliases", [])

            if aliases is None:
                aliases = []
            if not isinstance(aliases, list):
                raise ValidationError(f"Aliases for command '{primary_name}' must be a list")

            for kind, name in [("command", primary_name)] + [("alias", alias) for alias in aliases]:
                if not isinstance(name, str):
                    raise ValidationError(
                        f"{kind.capitalize()} for command '{primary_name}' must be a string"
                    )

                # Enforce canonical pattern only for primary command names;
                # aliases are free-form to preserve community extension compat.
                if kind == "command":
                    match = EXTENSION_COMMAND_NAME_PATTERN.match(name)
                    if match is None:
                        raise ValidationError(
                            f"Invalid {kind} '{name}': "
                            "must follow pattern 'fire-phoenix.{extension}.{command}'"
                        )

                    namespace = match.group(1)
                    if namespace != manifest.id:
                        raise ValidationError(
                            f"{kind.capitalize()} '{name}' must use extension namespace '{manifest.id}'"
                        )

                    if namespace in CORE_COMMAND_NAMES:
                        raise ValidationError(
                            f"{kind.capitalize()} '{name}' conflicts with core command namespace '{namespace}'"
                        )

                if name in declared_names:
                    raise ValidationError(
                        f"Duplicate command or alias '{name}' in extension manifest"
                    )

                declared_names[name] = kind

        return declared_names

    def _get_installed_command_name_map(
        self,
        exclude_extension_id: str | None = None,
    ) -> dict[str, str]:
        """Return registered command and alias names for installed extensions."""
        installed_names: dict[str, str] = {}

        for ext_id in self.registry.keys():
            if ext_id == exclude_extension_id:
                continue

            manifest = self.get_extension(ext_id)
            if manifest is None:
                continue

            for cmd in manifest.commands:
                cmd_name = cmd.get("name")
                if isinstance(cmd_name, str):
                    installed_names.setdefault(cmd_name, ext_id)

                aliases = cmd.get("aliases", [])
                if not isinstance(aliases, list):
                    continue

                for alias in aliases:
                    if isinstance(alias, str):
                        installed_names.setdefault(alias, ext_id)

        return installed_names

    def _validate_install_conflicts(self, manifest: ExtensionManifest) -> None:
        """Reject installs that would shadow core or installed extension commands."""
        declared_names = self._collect_manifest_command_names(manifest)
        installed_names = self._get_installed_command_name_map(exclude_extension_id=manifest.id)

        collisions = [
            f"{name} (already provided by extension '{installed_names[name]}')"
            for name in sorted(declared_names)
            if name in installed_names
        ]
        if collisions:
            raise ValidationError(
                "Extension commands conflict with installed extensions:\n- "
                + "\n- ".join(collisions)
            )

    @staticmethod
    def _load_extensionignore(source_dir: Path) -> Callable[[str, list[str]], set[str]] | None:
        """Load .extensionignore and return an ignore function for shutil.copytree.

        The .extensionignore file uses .gitignore-compatible patterns (one per line).
        Lines starting with '#' are comments. Blank lines are ignored.
        The .extensionignore file itself is always excluded.

        Pattern semantics mirror .gitignore:
        - '*' matches anything except '/'
        - '**' matches zero or more directories
        - '?' matches any single character except '/'
        - Trailing '/' restricts a pattern to directories only
        - Patterns with '/' (other than trailing) are anchored to the root
        - '!' negates a previously excluded pattern

        Args:
            source_dir: Path to the extension source directory

        Returns:
            An ignore function compatible with shutil.copytree, or None
            if no .extensionignore file exists.
        """
        ignore_file = source_dir / ".extensionignore"
        if not ignore_file.exists():
            return None

        lines: list[str] = ignore_file.read_text(encoding="utf-8").splitlines()

        # Normalise backslashes in patterns so Windows-authored files work
        normalised: list[str] = []
        for line in lines:
            stripped = line.strip()
            if stripped and not stripped.startswith("#"):
                normalised.append(stripped.replace("\\", "/"))
            else:
                # Preserve blanks/comments so pathspec line numbers stay stable
                normalised.append(line)

        # Always ignore the .extensionignore file itself
        normalised.append(".extensionignore")

        spec = pathspec.GitIgnoreSpec.from_lines(normalised)

        def _ignore(directory: str, entries: list[str]) -> set[str]:
            ignored: set[str] = set()
            rel_dir = Path(directory).relative_to(source_dir)
            for entry in entries:
                rel_path = str(rel_dir / entry) if str(rel_dir) != "." else entry
                # Normalise to forward slashes for consistent matching
                rel_path_fwd = rel_path.replace("\\", "/")

                entry_full = Path(directory) / entry
                if entry_full.is_dir():
                    # Append '/' so directory-only patterns (e.g. tests/) match
                    if spec.match_file(rel_path_fwd + "/"):
                        ignored.add(entry)
                else:
                    if spec.match_file(rel_path_fwd):
                        ignored.add(entry)
            return ignored

        return _ignore

    def _get_skills_dir(self) -> Path | None:
        """Return the active skills directory for extension skill registration.

        Reads ``.fire-phoenix/init-options.yml`` to determine whether skills
        are enabled and which agent was selected, then delegates to
        the module-level ``_get_skills_dir()`` helper for the concrete path.

        Returns:
            The skills directory ``Path``, or ``None`` if skills were not
            enabled.
        """
        from ..config import load_init_options
        from ..installer import _get_skills_dir as resolve_skills_dir

        opts = load_init_options(self.project_root)
        if not isinstance(opts, dict):
            opts = {}

        agent = opts.get("integration")
        if not isinstance(agent, str) or not agent:
            return None

        if not bool(opts.get("ai_skills")):
            return None

        skills_dir = resolve_skills_dir(self.project_root, agent)
        if not skills_dir.is_dir():
            return None

        return skills_dir

    def _register_extension_skills(
        self,
        manifest: ExtensionManifest,
        extension_dir: Path,
    ) -> list[str]:
        """Generate SKILL.md files for extension commands as agent skills.

        For every command in the extension manifest, creates a SKILL.md
        file in the agent's skills directory following the agentskills.io
        specification.  This is only done when ``--ai-skills`` was used
        during project initialisation.

        Args:
            manifest: Extension manifest.
            extension_dir: Installed extension directory.

        Returns:
            List of skill names that were created (for registry storage).
        """
        skills_dir = self._get_skills_dir()
        if not skills_dir:
            return []

        import yaml

        from ..config import load_init_options
        from ..integrations import get_integration
        from ..skills.render import CommandRegistrar

        written: list[str] = []
        opts = load_init_options(self.project_root)
        if not isinstance(opts, dict):
            opts = {}
        selected_ai = opts.get("integration")
        if not isinstance(selected_ai, str) or not selected_ai:
            return []
        registrar = CommandRegistrar()
        integration = get_integration(selected_ai)

        for cmd_info in manifest.commands:
            cmd_name = cmd_info["name"]
            cmd_file_rel = cmd_info["file"]

            # Guard against path traversal: reject absolute paths and ensure
            # the resolved file stays within the extension directory.
            cmd_path = Path(cmd_file_rel)
            if cmd_path.is_absolute():
                continue
            try:
                ext_root = extension_dir.resolve()
                source_file = (ext_root / cmd_path).resolve()
                source_file.relative_to(ext_root)  # raises ValueError if outside
            except (OSError, ValueError):
                continue

            if not source_file.is_file():
                continue

            # Derive skill name from command name using the same naming
            # convention as core command registration: two-segment core
            # commands use bare skill directories (per ADR-0003); multi-
            # segment extension commands keep the ``fire-phoenix-`` prefix.
            skill_name = registrar.skill_dir_name(cmd_name)
            short_name_raw = cmd_name
            if short_name_raw.startswith("fire-phoenix."):
                short_name_raw = short_name_raw[len("fire-phoenix.") :]

            # Check if skill already exists before creating the directory
            skills_subdir = skills_dir / skill_name
            skill_file = skills_subdir / "SKILL.md"
            if skill_file.exists():
                # Do not overwrite user-customized skills
                continue

            # Create skill directory; track whether we created it so we can clean
            # up safely if reading the source file subsequently fails.
            created_now = not skills_subdir.exists()
            skills_subdir.mkdir(parents=True, exist_ok=True)

            # Parse the command file — guard against IsADirectoryError / decode errors
            try:
                content = source_file.read_text(encoding="utf-8")
            except (OSError, UnicodeDecodeError):
                if created_now:
                    try:
                        skills_subdir.rmdir()  # undo the mkdir; dir is empty at this point
                    except OSError:
                        pass  # best-effort cleanup
                continue
            frontmatter, body = registrar.parse_frontmatter(content)
            frontmatter = registrar._adjust_script_paths(frontmatter)
            body = registrar.resolve_skill_placeholders(
                selected_ai, frontmatter, body, self.project_root
            )

            original_desc = frontmatter.get("description", "")
            description = original_desc or f"Extension command: {cmd_name}"

            frontmatter_data = registrar.build_skill_frontmatter(
                selected_ai,
                skill_name,
                description,
                f"extension:{manifest.id}",
            )
            frontmatter_text = yaml.safe_dump(
                frontmatter_data, sort_keys=False, allow_unicode=True
            ).strip()

            # Derive a human-friendly title from the command name
            short_name = cmd_name
            if short_name.startswith("fire-phoenix."):
                short_name = short_name[len("fire-phoenix.") :]
            title_name = short_name.replace(".", " ").replace("-", " ").title()

            skill_content = f"---\n{frontmatter_text}\n---\n\n# {title_name} Skill\n\n{body}\n"
            if integration is not None and hasattr(integration, "post_process_skill_content"):
                skill_content = integration.post_process_skill_content(skill_content)

            skill_file.write_text(skill_content, encoding="utf-8")
            written.append(skill_name)

        return written

    def _unregister_extension_skills(self, skill_names: list[str], extension_id: str) -> None:
        """Remove SKILL.md directories for extension skills.

        Called during extension removal to clean up skill files that
        were created by ``_register_extension_skills()``.

        If ``_get_skills_dir()`` returns ``None`` (e.g. the user removed
        init-options.yml or toggled ai_skills after installation), we
        fall back to scanning all known agent skills directories so that
        orphaned skill directories are still cleaned up.  In that case
        each candidate directory is verified against the SKILL.md
        ``metadata.source`` field before removal to avoid accidentally
        deleting user-created skills with the same name.

        Args:
            skill_names: List of skill names to remove.
            extension_id: Extension ID used to verify ownership during
                fallback candidate scanning.
        """
        if not skill_names:
            return

        skills_dir = self._get_skills_dir()

        if skills_dir:
            # Fast path: we know the exact skills directory
            for skill_name in skill_names:
                # Guard against path traversal from a corrupted registry entry:
                # reject names that are absolute, contain path separators, or
                # resolve to a path outside the skills directory.
                sn_path = Path(skill_name)
                if sn_path.is_absolute() or len(sn_path.parts) != 1:
                    continue
                try:
                    skills_subdir = (skills_dir / skill_name).resolve()
                    skills_subdir.relative_to(skills_dir.resolve())  # raises if outside
                except (OSError, ValueError):
                    continue
                if not skills_subdir.is_dir():
                    continue
                # Safety check: only delete if SKILL.md exists and its
                # metadata.source matches exactly this extension — mirroring
                # the fallback branch — so a corrupted registry entry cannot
                # delete an unrelated user skill.
                skill_md = skills_subdir / "SKILL.md"
                if not skill_md.is_file():
                    continue
                try:
                    import yaml as _yaml

                    raw = skill_md.read_text(encoding="utf-8")
                    source = ""
                    if raw.startswith("---"):
                        parts = raw.split("---", 2)
                        if len(parts) >= 3:
                            fm = _yaml.safe_load(parts[1]) or {}
                            source = (
                                fm.get("metadata", {}).get("source", "")
                                if isinstance(fm, dict)
                                else ""
                            )
                    if source != f"extension:{extension_id}":
                        continue
                except (OSError, UnicodeDecodeError, Exception):
                    continue
                shutil.rmtree(skills_subdir)
        else:
            # Fallback: scan all possible agent skills directories
            from ..config import DEFAULT_SKILLS_DIR
            from ..installer import AGENT_CONFIG

            candidate_dirs: set[Path] = set()
            for cfg in AGENT_CONFIG.values():
                folder = cfg.get("folder", "")
                if folder:
                    candidate_dirs.add(self.project_root / folder.rstrip("/") / "skills")
            candidate_dirs.add(self.project_root / DEFAULT_SKILLS_DIR)

            for skills_candidate in candidate_dirs:
                if not skills_candidate.is_dir():
                    continue
                for skill_name in skill_names:
                    # Same path-traversal guard as the fast path above
                    sn_path = Path(skill_name)
                    if sn_path.is_absolute() or len(sn_path.parts) != 1:
                        continue
                    try:
                        skills_subdir = (skills_candidate / skill_name).resolve()
                        skills_subdir.relative_to(skills_candidate.resolve())  # raises if outside
                    except (OSError, ValueError):
                        continue
                    if not skills_subdir.is_dir():
                        continue
                    # Safety check: only delete if SKILL.md exists and its
                    # metadata.source matches exactly this extension.  If the
                    # file is missing or unreadable we skip to avoid deleting
                    # unrelated user-created directories.
                    skill_md = skills_subdir / "SKILL.md"
                    if not skill_md.is_file():
                        continue
                    try:
                        import yaml as _yaml

                        raw = skill_md.read_text(encoding="utf-8")
                        source = ""
                        if raw.startswith("---"):
                            parts = raw.split("---", 2)
                            if len(parts) >= 3:
                                fm = _yaml.safe_load(parts[1]) or {}
                                source = (
                                    fm.get("metadata", {}).get("source", "")
                                    if isinstance(fm, dict)
                                    else ""
                                )
                        # Only remove skills explicitly created by this extension
                        if source != f"extension:{extension_id}":
                            continue
                    except (OSError, UnicodeDecodeError, Exception):
                        # If we can't verify, skip to avoid accidental deletion
                        continue
                    shutil.rmtree(skills_subdir)

    def check_compatibility(self, manifest: ExtensionManifest, fire_phoenix_version: str) -> bool:
        """Check if extension is compatible with current fire-phoenix version.

        Args:
            manifest: Extension manifest
            fire_phoenix_version: Current fire-phoenix version

        Returns:
            True if compatible

        Raises:
            CompatibilityError: If extension is incompatible
        """
        required = manifest.requires_fire_phoenix_version
        current = pkg_version.Version(fire_phoenix_version)

        # Parse version specifier (e.g., ">=0.1.0,<2.0.0")
        try:
            specifier = SpecifierSet(required)
            if current not in specifier:
                raise CompatibilityError(
                    f"Extension requires fire-phoenix {required}, "
                    f"but {fire_phoenix_version} is installed.\n"
                    f"Upgrade fire-phoenix with: uv tool install fire-phoenix --force"
                )
        except InvalidSpecifier:
            raise CompatibilityError(f"Invalid version specifier: {required}")  # noqa: B904

        return True

    def install_from_directory(
        self,
        source_dir: Path,
        fire_phoenix_version: str,
        register_commands: bool = True,
        priority: int = 10,
    ) -> ExtensionManifest:
        """Install extension from a local directory.

        Args:
            source_dir: Path to extension directory
            fire_phoenix_version: Current fire-phoenix version
            register_commands: If True, register commands with AI agents
            priority: Resolution priority (lower = higher precedence, default 10)

        Returns:
            Installed extension manifest

        Raises:
            ValidationError: If manifest is invalid or priority is invalid
            CompatibilityError: If extension is incompatible
        """
        # Validate priority
        if priority < 1:
            raise ValidationError("Priority must be a positive integer (1 or higher)")

        # Load and validate manifest
        manifest_path = source_dir / "extension.yml"
        manifest = ExtensionManifest(manifest_path)

        # Check compatibility
        self.check_compatibility(manifest, fire_phoenix_version)

        # Check if already installed
        if self.registry.is_installed(manifest.id):
            raise ExtensionError(
                f"Extension '{manifest.id}' is already installed. "
                f"Use 'fire-phoenix extension remove {manifest.id}' first."
            )

        # Reject manifests that would shadow core commands or installed extensions.
        self._validate_install_conflicts(manifest)

        # Install extension
        dest_dir = self.extensions_dir / manifest.id
        if dest_dir.exists():
            shutil.rmtree(dest_dir)

        ignore_fn = self._load_extensionignore(source_dir)

        # Roll back a partial install: if any step between the copy and the
        # registry commit fails, unregister what was registered and remove the
        # copied extension so nothing half-installed remains (PRODUCT.md
        # §Failure conditions: no half-installed state).
        registered_commands: dict[str, Any] = {}
        registered_skills: list[Any] = []
        try:
            shutil.copytree(source_dir, dest_dir, ignore=ignore_fn)

            # Register commands with AI agents
            if register_commands:
                registrar = CommandRegistrar()
                # Register for all detected agents
                registered_commands = registrar.register_commands_for_all_agents(
                    manifest, dest_dir, self.project_root
                )

            # Auto-register extension commands as agent skills when --ai-skills
            # was used during project initialisation (feature parity).
            registered_skills = self._register_extension_skills(manifest, dest_dir)

            # Register hooks
            hook_executor = HookExecutor(self.project_root)
            hook_executor.register_hooks(manifest)

            # Update registry
            self.registry.add(
                manifest.id,
                {
                    "version": manifest.version,
                    "source": "local",
                    "manifest_hash": manifest.get_hash(),
                    "enabled": True,
                    "priority": priority,
                    "registered_commands": registered_commands,
                    "registered_skills": registered_skills,
                },
            )
        except Exception:
            if registered_commands:
                with contextlib.suppress(Exception):
                    CommandRegistrar().unregister_commands(registered_commands, self.project_root)
            if registered_skills:
                with contextlib.suppress(Exception):
                    self._unregister_extension_skills(
                        [s for s in registered_skills if isinstance(s, str)], manifest.id
                    )
            if dest_dir.exists():
                shutil.rmtree(dest_dir, ignore_errors=True)
            raise

        return manifest

    def install_from_zip(
        self,
        zip_path: Path,
        fire_phoenix_version: str,
        priority: int = 10,
    ) -> ExtensionManifest:
        """Install extension from ZIP file.

        Args:
            zip_path: Path to extension ZIP file
            fire_phoenix_version: Current fire-phoenix version
            priority: Resolution priority (lower = higher precedence, default 10)

        Returns:
            Installed extension manifest

        Raises:
            ValidationError: If manifest is invalid or priority is invalid
            CompatibilityError: If extension is incompatible
        """
        # Validate priority early
        if priority < 1:
            raise ValidationError("Priority must be a positive integer (1 or higher)")

        with tempfile.TemporaryDirectory() as tmpdir:
            temp_path = Path(tmpdir)

            # Extract ZIP safely (prevent Zip Slip attack)
            with zipfile.ZipFile(zip_path, "r") as zf:
                # Validate all paths first before extracting anything
                temp_path_resolved = temp_path.resolve()
                for member in zf.namelist():
                    member_path = (temp_path / member).resolve()
                    # Use is_relative_to for safe path containment check
                    try:
                        member_path.relative_to(temp_path_resolved)
                    except ValueError:
                        raise ValidationError(  # noqa: B904
                            f"Unsafe path in ZIP archive: {member} (potential path traversal)"
                        )
                # Only extract after all paths are validated
                zf.extractall(temp_path)

            # Find extension directory (may be nested)
            extension_dir = temp_path
            manifest_path = extension_dir / "extension.yml"

            # Check if manifest is in a subdirectory. Locate the ONE subdir that
            # actually holds extension.yml rather than requiring exactly one
            # top-level entry — a second entry (macOS __MACOSX/, a top-level
            # README/LICENSE beside the package dir) must not block recovery.
            if not manifest_path.exists():
                candidates = [
                    d
                    for d in temp_path.iterdir()
                    if d.is_dir()
                    and not d.name.startswith(("__MACOSX", "."))
                    and (d / "extension.yml").exists()
                ]
                if len(candidates) == 1:
                    extension_dir = candidates[0]
                    manifest_path = extension_dir / "extension.yml"

            if not manifest_path.exists():
                raise ValidationError("No extension.yml found in ZIP file")

            # Install from extracted directory
            return self.install_from_directory(
                extension_dir, fire_phoenix_version, priority=priority
            )

    def remove(self, extension_id: str, keep_config: bool = False) -> bool:
        """Remove an installed extension.

        Args:
            extension_id: Extension ID
            keep_config: If True, preserve config files (don't delete extension dir)

        Returns:
            True if extension was removed
        """
        if not self.registry.is_installed(extension_id):
            return False

        # Get registered commands and skills before removal
        metadata = self.registry.get(extension_id)
        registered_commands = metadata.get("registered_commands", {}) if metadata else {}
        raw_skills = metadata.get("registered_skills", []) if metadata else []
        # Normalize: must be a list of plain strings to avoid corrupted-registry errors
        if isinstance(raw_skills, list):
            registered_skills = [s for s in raw_skills if isinstance(s, str)]
        else:
            registered_skills = []

        extension_dir = self.extensions_dir / extension_id

        # Unregister commands from all AI agents
        if registered_commands:
            registrar = CommandRegistrar()
            registrar.unregister_commands(registered_commands, self.project_root)

        # Unregister agent skills
        self._unregister_extension_skills(registered_skills, extension_id)

        if keep_config:
            # Preserve config files, only remove non-config files
            if extension_dir.exists():
                for child in extension_dir.iterdir():
                    # Keep top-level *-config.yml and *-config.local.yml files
                    if child.is_file() and (
                        child.name.endswith("-config.yml")
                        or child.name.endswith("-config.local.yml")
                    ):
                        continue
                    if child.is_dir():
                        shutil.rmtree(child)
                    else:
                        child.unlink()
        else:
            # Backup config files before deleting
            if extension_dir.exists():
                # Use subdirectory per extension to avoid name accumulation
                # (e.g., jira-jira-config.yml on repeated remove/install cycles)
                backup_dir = self.extensions_dir / ".backup" / extension_id
                backup_dir.mkdir(parents=True, exist_ok=True)

                # Backup both primary and local override config files
                config_files = list(extension_dir.glob("*-config.yml")) + list(
                    extension_dir.glob("*-config.local.yml")
                )
                for config_file in config_files:
                    backup_path = backup_dir / config_file.name
                    shutil.copy2(config_file, backup_path)

            # Remove extension directory
            if extension_dir.exists():
                shutil.rmtree(extension_dir)

        # Unregister hooks
        hook_executor = HookExecutor(self.project_root)
        hook_executor.unregister_hooks(extension_id)

        # Update registry
        self.registry.remove(extension_id)

        return True

    def list_installed(self) -> list[dict[str, Any]]:
        """List all installed extensions with metadata.

        Returns:
            List of extension metadata dictionaries
        """
        result = []

        for ext_id, metadata in self.registry.list().items():
            # Ensure metadata is a dictionary to avoid AttributeError when using .get()
            if not isinstance(metadata, dict):
                metadata = {}
            ext_dir = self.extensions_dir / ext_id
            manifest_path = ext_dir / "extension.yml"

            try:
                manifest = ExtensionManifest(manifest_path)
                result.append(
                    {
                        "id": ext_id,
                        "name": manifest.name,
                        "version": metadata.get("version", "unknown"),
                        "description": manifest.description,
                        "enabled": metadata.get("enabled", True),
                        "priority": normalize_priority(metadata.get("priority")),
                        "installed_at": metadata.get("installed_at"),
                        "command_count": len(manifest.commands),
                        "hook_count": len(manifest.hooks),
                    }
                )
            except ValidationError:
                # Corrupted extension
                result.append(
                    {
                        "id": ext_id,
                        "name": ext_id,
                        "version": metadata.get("version", "unknown"),
                        "description": "⚠️ Corrupted extension",
                        "enabled": False,
                        "priority": normalize_priority(metadata.get("priority")),
                        "installed_at": metadata.get("installed_at"),
                        "command_count": 0,
                        "hook_count": 0,
                    }
                )

        return result

    def get_extension(self, extension_id: str) -> ExtensionManifest | None:
        """Get manifest for an installed extension.

        Args:
            extension_id: Extension ID

        Returns:
            Extension manifest or None if not installed
        """
        if not self.registry.is_installed(extension_id):
            return None

        ext_dir = self.extensions_dir / extension_id
        manifest_path = ext_dir / "extension.yml"

        try:
            return ExtensionManifest(manifest_path)
        except ValidationError:
            return None


__all__ = ["ExtensionManager"]
