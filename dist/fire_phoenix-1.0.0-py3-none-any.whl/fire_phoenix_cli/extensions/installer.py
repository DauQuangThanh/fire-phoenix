"""Disk-write side of extension installation.

Groups the helpers that read / mutate state outside the registry JSON:

- :class:`ConfigManager` — layered config (defaults → project → local → env)
  read off ``.fire-phoenix/extensions/<id>/`` files.
- :class:`HookExecutor` — registration, condition evaluation and on-disk
  storage of extension hooks in ``.fire-phoenix/extensions.yml``.
- :class:`CommandRegistrar` — wraps the shared agent command registrar
  to write extension command files into AI-agent skill folders, tagged
  with extension provenance comments.

All three are imported by :mod:`.manager` and are wired through
``extensions/__init__.py`` so callers using
``from fire_phoenix_cli.extensions import HookExecutor`` keep working.
"""

from __future__ import annotations

import os
import re
from pathlib import Path
from typing import Any

import yaml

from .resolver import ExtensionError, ExtensionManifest


class CommandRegistrar:
    """Handles registration of extension commands with AI agents.

    Wraps the shared CommandRegistrar in agents.py to add extension-specific
    functionality. Extension-specific methods accept ExtensionManifest objects
    and add context comments identifying the extension source.
    """

    # Re-export AGENT_CONFIGS at class level for direct attribute access
    from ..skills.render import CommandRegistrar as _AgentRegistrar

    AGENT_CONFIGS = _AgentRegistrar.AGENT_CONFIGS

    def __init__(self):
        from ..skills.render import CommandRegistrar as _Registrar

        self._registrar = _Registrar()

    # Delegate static/utility methods
    @staticmethod
    def parse_frontmatter(content: str) -> tuple[dict, str]:
        from ..skills.render import CommandRegistrar as _Registrar

        return _Registrar.parse_frontmatter(content)

    @staticmethod
    def render_frontmatter(fm: dict) -> str:
        from ..skills.render import CommandRegistrar as _Registrar

        return _Registrar.render_frontmatter(fm)

    def _render_markdown_command(self, frontmatter, body, ext_id):
        # Add extension context comments to identify source
        context_note = (
            f"\n<!-- Extension: {ext_id} -->\n<!-- Config: .fire-phoenix/extensions/{ext_id}/ -->\n"
        )
        return self._registrar.render_frontmatter(frontmatter) + "\n" + context_note + body

    def _render_toml_command(self, frontmatter, body, ext_id):
        # Add extension context comments to identify source
        base = self._registrar.render_toml_command(frontmatter, body, ext_id)
        context_lines = f"# Extension: {ext_id}\n# Config: .fire-phoenix/extensions/{ext_id}/\n"
        return base.rstrip("\n") + "\n" + context_lines

    def register_commands_for_agent(
        self, agent_name: str, manifest: ExtensionManifest, extension_dir: Path, project_root: Path
    ) -> list[str]:
        """Register extension commands for a specific agent."""
        if agent_name not in self.AGENT_CONFIGS:
            raise ExtensionError(f"Unsupported agent: {agent_name}")
        context_note = f"\n<!-- Extension: {manifest.id} -->\n<!-- Config: .fire-phoenix/extensions/{manifest.id}/ -->\n"
        return self._registrar.register_commands(
            agent_name,
            manifest.commands,
            manifest.id,
            extension_dir,
            project_root,
            context_note=context_note,
        )

    def register_commands_for_all_agents(
        self, manifest: ExtensionManifest, extension_dir: Path, project_root: Path
    ) -> dict[str, list[str]]:
        """Register extension commands for all detected agents."""
        context_note = f"\n<!-- Extension: {manifest.id} -->\n<!-- Config: .fire-phoenix/extensions/{manifest.id}/ -->\n"
        return self._registrar.register_commands_for_all_agents(
            manifest.commands, manifest.id, extension_dir, project_root, context_note=context_note
        )

    def unregister_commands(
        self, registered_commands: dict[str, list[str]], project_root: Path
    ) -> None:
        """Remove previously registered command files from agent directories."""
        self._registrar.unregister_commands(registered_commands, project_root)

    def register_commands_for_claude(
        self, manifest: ExtensionManifest, extension_dir: Path, project_root: Path
    ) -> list[str]:
        """Register extension commands for Claude Code agent."""
        return self.register_commands_for_agent("claude", manifest, extension_dir, project_root)


class ConfigManager:
    """Manages layered configuration for extensions.

    Configuration layers (in order of precedence from lowest to highest):
    1. Defaults (from extension.yml)
    2. Project config (.fire-phoenix/extensions/{ext-id}/{ext-id}-config.yml)
    3. Local config (.fire-phoenix/extensions/{ext-id}/local-config.yml) - gitignored
    4. Environment variables (FIRE_PHOENIX_{EXT_ID}_{KEY})
    """

    def __init__(self, project_root: Path, extension_id: str):
        """Initialize config manager for an extension.

        Args:
            project_root: Root directory of the fire-phoenix project
            extension_id: ID of the extension
        """
        self.project_root = project_root
        self.extension_id = extension_id
        self.extension_dir = project_root / ".fire-phoenix" / "extensions" / extension_id

    def _load_yaml_config(self, file_path: Path) -> dict[str, Any]:
        """Load configuration from YAML file.

        Args:
            file_path: Path to YAML file

        Returns:
            Configuration dictionary
        """
        if not file_path.exists():
            return {}

        try:
            data = yaml.safe_load(file_path.read_text(encoding="utf-8"))
        except (yaml.YAMLError, OSError, UnicodeError):
            return {}
        # Coerce a non-mapping (top-level list/scalar) to the default so callers
        # that index into the config never crash.
        return data if isinstance(data, dict) else {}

    def _get_extension_defaults(self) -> dict[str, Any]:
        """Get default configuration from extension manifest.

        Returns:
            Default configuration dictionary
        """
        manifest_path = self.extension_dir / "extension.yml"
        if not manifest_path.exists():
            return {}

        manifest_data = self._load_yaml_config(manifest_path)
        return manifest_data.get("config", {}).get("defaults", {})

    def _get_project_config(self) -> dict[str, Any]:
        """Get project-level configuration.

        Returns:
            Project configuration dictionary
        """
        config_file = self.extension_dir / f"{self.extension_id}-config.yml"
        return self._load_yaml_config(config_file)

    def _get_local_config(self) -> dict[str, Any]:
        """Get local configuration (gitignored, machine-specific).

        Returns:
            Local configuration dictionary
        """
        config_file = self.extension_dir / "local-config.yml"
        return self._load_yaml_config(config_file)

    def _get_env_config(self) -> dict[str, Any]:
        """Get configuration from environment variables.

        Environment variables follow the pattern:
        FIRE_PHOENIX_{EXT_ID}_{SECTION}_{KEY}

        For example:
        - FIRE_PHOENIX_JIRA_CONNECTION_URL
        - FIRE_PHOENIX_JIRA_PROJECT_KEY

        Returns:
            Configuration dictionary from environment variables
        """

        env_config = {}  # type: ignore[var-annotated]
        ext_id_upper = self.extension_id.replace("-", "_").upper()
        prefix = f"FIRE_PHOENIX_{ext_id_upper}_"

        for key, value in os.environ.items():
            if not key.startswith(prefix):
                continue

            # Remove prefix and split into parts
            config_path = key[len(prefix) :].lower().split("_")

            # Build nested dict
            current = env_config
            for part in config_path[:-1]:
                if part not in current:
                    current[part] = {}
                current = current[part]

            # Set the final value
            current[config_path[-1]] = value

        return env_config

    def _merge_configs(self, base: dict[str, Any], override: dict[str, Any]) -> dict[str, Any]:
        """Recursively merge two configuration dictionaries.

        Args:
            base: Base configuration
            override: Configuration to merge on top

        Returns:
            Merged configuration
        """
        result = base.copy()

        for key, value in override.items():
            if key in result and isinstance(result[key], dict) and isinstance(value, dict):
                # Recursive merge for nested dicts
                result[key] = self._merge_configs(result[key], value)
            else:
                # Override value
                result[key] = value

        return result

    def get_config(self) -> dict[str, Any]:
        """Get final merged configuration for the extension.

        Merges configuration layers in order:
        defaults -> project -> local -> env

        Returns:
            Final merged configuration dictionary
        """
        # Start with defaults
        config = self._get_extension_defaults()

        # Merge project config
        config = self._merge_configs(config, self._get_project_config())

        # Merge local config
        config = self._merge_configs(config, self._get_local_config())

        # Merge environment config
        config = self._merge_configs(config, self._get_env_config())

        return config

    def get_value(self, key_path: str, default: Any = None) -> Any:
        """Get a specific configuration value by dot-notation path.

        Args:
            key_path: Dot-separated path to config value (e.g., "connection.url")
            default: Default value if key not found

        Returns:
            Configuration value or default

        Example:
            >>> config = ConfigManager(project_root, "jira")
            >>> url = config.get_value("connection.url")
            >>> timeout = config.get_value("connection.timeout", 30)
        """
        config = self.get_config()
        keys = key_path.split(".")

        current = config
        for key in keys:
            if not isinstance(current, dict) or key not in current:
                return default
            current = current[key]

        return current

    def has_value(self, key_path: str) -> bool:
        """Check if a configuration value exists.

        Args:
            key_path: Dot-separated path to config value

        Returns:
            True if value exists (even if None), False otherwise
        """
        config = self.get_config()
        keys = key_path.split(".")

        current = config
        for key in keys:
            if not isinstance(current, dict) or key not in current:
                return False
            current = current[key]

        return True


class HookExecutor:
    """Manages extension hook execution."""

    def __init__(self, project_root: Path):
        """Initialize hook executor.

        Args:
            project_root: Root directory of the fire-phoenix project
        """
        self.project_root = project_root
        self.extensions_dir = project_root / ".fire-phoenix" / "extensions"
        self.config_file = project_root / ".fire-phoenix" / "extensions.yml"
        self._init_options_cache: dict[str, Any] | None = None

    def _load_init_options(self) -> dict[str, Any]:
        """Load persisted init options used to determine invocation style.

        Uses the shared helper from fire_phoenix_cli and caches values per executor
        instance to avoid repeated filesystem reads during hook rendering.
        """
        if self._init_options_cache is None:
            from ..config import load_init_options

            payload = load_init_options(self.project_root)
            self._init_options_cache = payload if isinstance(payload, dict) else {}
        return self._init_options_cache

    @staticmethod
    def _skill_name_from_command(command: Any) -> str:
        """Map a command id like ``fire-phoenix.plan`` to the bare skill name ``plan``.

        Per ``adr/0003`` + ``task-0021`` §B: installed skills carry their bare
        name (``.<integration>/skills/<name>/``) so the slash command emitted
        by ``_render_hook_invocation`` is ``/<name>``, matching the disk
        layout. The ``fire-phoenix.`` command-id prefix is the catalog-id
        namespace; the slash command is bare.
        """
        if not isinstance(command, str):
            return ""
        command_id = command.strip()
        if not command_id.startswith("fire-phoenix."):
            return ""
        return command_id[len("fire-phoenix.") :].replace(".", "-")

    def _render_hook_invocation(self, command: Any) -> str:
        """Render an agent-specific invocation string for a hook command."""
        if not isinstance(command, str):
            return ""

        command_id = command.strip()
        if not command_id:
            return ""

        init_options = self._load_init_options()
        selected_ai = init_options.get("integration")
        codex_skill_mode = selected_ai == "codex" and bool(init_options.get("ai_skills"))
        claude_skill_mode = selected_ai == "claude" and bool(init_options.get("ai_skills"))
        cursor_skill_mode = selected_ai == "cursor-agent" and bool(init_options.get("ai_skills"))

        skill_name = self._skill_name_from_command(command_id)
        if codex_skill_mode and skill_name:
            return f"${skill_name}"
        if claude_skill_mode and skill_name:
            return f"/{skill_name}"
        if cursor_skill_mode and skill_name:
            return f"/{skill_name}"

        return f"/{command_id}"

    def get_project_config(self) -> dict[str, Any]:
        """Load project-level extension configuration.

        Returns:
            Extension configuration dictionary
        """
        if not self.config_file.exists():
            return {
                "installed": [],
                "settings": {"auto_execute_hooks": True},
                "hooks": {},
            }

        default = {
            "installed": [],
            "settings": {"auto_execute_hooks": True},
            "hooks": {},
        }
        try:
            data = yaml.safe_load(self.config_file.read_text(encoding="utf-8"))
        except (yaml.YAMLError, OSError, UnicodeError):
            return default
        # A non-mapping (top-level list/scalar) would crash register_hooks /
        # get_hooks_for_event; fall back to the default instead.
        return data if isinstance(data, dict) else default

    def save_project_config(self, config: dict[str, Any]):
        """Save project-level extension configuration.

        Args:
            config: Configuration dictionary to save
        """
        self.config_file.parent.mkdir(parents=True, exist_ok=True)
        self.config_file.write_text(
            yaml.dump(config, default_flow_style=False, sort_keys=False, allow_unicode=True),
            encoding="utf-8",
        )

    def register_hooks(self, manifest: ExtensionManifest):
        """Register extension hooks in project config.

        Args:
            manifest: Extension manifest with hooks to register
        """
        if not hasattr(manifest, "hooks") or not manifest.hooks:
            return

        config = self.get_project_config()

        # Ensure hooks dict exists
        if "hooks" not in config:
            config["hooks"] = {}

        # Register each hook
        for hook_name, hook_config in manifest.hooks.items():
            if hook_name not in config["hooks"]:
                config["hooks"][hook_name] = []

            # Add hook entry
            hook_entry = {
                "extension": manifest.id,
                "command": hook_config.get("command"),
                "enabled": True,
                "optional": hook_config.get("optional", True),
                "prompt": hook_config.get("prompt", f"Execute {hook_config.get('command')}?"),
                "description": hook_config.get("description", ""),
                "condition": hook_config.get("condition"),
            }

            # Check if already registered
            existing = [h for h in config["hooks"][hook_name] if h.get("extension") == manifest.id]

            if not existing:
                config["hooks"][hook_name].append(hook_entry)
            else:
                # Update existing
                for i, h in enumerate(config["hooks"][hook_name]):
                    if h.get("extension") == manifest.id:
                        config["hooks"][hook_name][i] = hook_entry

        self.save_project_config(config)

    def unregister_hooks(self, extension_id: str):
        """Remove extension hooks from project config.

        Args:
            extension_id: ID of extension to unregister
        """
        config = self.get_project_config()

        if "hooks" not in config:
            return

        # Remove hooks for this extension
        for hook_name in config["hooks"]:
            config["hooks"][hook_name] = [
                h for h in config["hooks"][hook_name] if h.get("extension") != extension_id
            ]

        # Clean up empty hook arrays
        config["hooks"] = {name: hooks for name, hooks in config["hooks"].items() if hooks}

        self.save_project_config(config)

    def get_hooks_for_event(self, event_name: str) -> list[dict[str, Any]]:
        """Get all registered hooks for a specific event.

        Args:
            event_name: Name of the event (e.g., 'after_taskify')

        Returns:
            List of hook configurations
        """
        config = self.get_project_config()
        hooks = config.get("hooks", {}).get(event_name, [])

        # Filter to enabled hooks only
        return [h for h in hooks if h.get("enabled", True)]

    def should_execute_hook(self, hook: dict[str, Any]) -> bool:
        """Determine if a hook should be executed based on its condition.

        Args:
            hook: Hook configuration

        Returns:
            True if hook should execute, False otherwise
        """
        condition = hook.get("condition")

        if not condition:
            return True

        # Parse and evaluate condition
        try:
            return self._evaluate_condition(condition, hook.get("extension"))
        except (ValueError, KeyError, TypeError, AttributeError):
            # F-21: expected evaluation failures (bad expression, missing key,
            # type mismatch) default to not executing the hook — safe-off. A
            # genuinely unexpected error is no longer swallowed.
            return False

    def _evaluate_condition(self, condition: str, extension_id: str | None) -> bool:
        """Evaluate a hook condition expression.

        Supported condition patterns:
        - "config.key.path is set" - checks if config value exists
        - "config.key.path == 'value'" - checks if config equals value
        - "config.key.path != 'value'" - checks if config not equals value
        - "env.VAR_NAME is set" - checks if environment variable exists
        - "env.VAR_NAME == 'value'" - checks if env var equals value

        Args:
            condition: Condition expression string
            extension_id: Extension ID for config lookup

        Returns:
            True if condition is met, False otherwise
        """

        condition = condition.strip()

        # Pattern: "config.key.path is set"
        if match := re.match(r"config\.([a-z0-9_.]+)\s+is\s+set", condition, re.IGNORECASE):
            key_path = match.group(1)
            if not extension_id:
                return False

            config_manager = ConfigManager(self.project_root, extension_id)
            return config_manager.has_value(key_path)

        # Pattern: "config.key.path == 'value'" or "config.key.path != 'value'"
        if match := re.match(
            r'config\.([a-z0-9_.]+)\s*(==|!=)\s*["\']([^"\']+)["\']', condition, re.IGNORECASE
        ):
            key_path = match.group(1)
            operator = match.group(2)
            expected_value = match.group(3)

            if not extension_id:
                return False

            config_manager = ConfigManager(self.project_root, extension_id)
            actual_value = config_manager.get_value(key_path)

            # Normalize boolean values to lowercase for comparison
            # (YAML True/False vs condition strings 'true'/'false')
            if isinstance(actual_value, bool):
                normalized_value = "true" if actual_value else "false"
            else:
                normalized_value = str(actual_value)

            if operator == "==":
                return normalized_value == expected_value
            else:  # !=
                return normalized_value != expected_value

        # Pattern: "env.VAR_NAME is set"
        if match := re.match(r"env\.([A-Z0-9_]+)\s+is\s+set", condition, re.IGNORECASE):
            var_name = match.group(1).upper()
            return var_name in os.environ

        # Pattern: "env.VAR_NAME == 'value'" or "env.VAR_NAME != 'value'"
        if match := re.match(
            r'env\.([A-Z0-9_]+)\s*(==|!=)\s*["\']([^"\']+)["\']', condition, re.IGNORECASE
        ):
            var_name = match.group(1).upper()
            operator = match.group(2)
            expected_value = match.group(3)

            actual_value = os.environ.get(var_name, "")

            if operator == "==":
                return actual_value == expected_value
            else:  # !=
                return actual_value != expected_value

        # Unknown condition format, default to False for safety
        return False

    def format_hook_message(self, event_name: str, hooks: list[dict[str, Any]]) -> str:
        """Format hook execution message for display in command output.

        Args:
            event_name: Name of the event
            hooks: List of hooks to execute

        Returns:
            Formatted message string
        """
        if not hooks:
            return ""

        lines = ["\n## Extension Hooks\n"]
        lines.append(f"Hooks available for event '{event_name}':\n")

        for hook in hooks:
            extension = hook.get("extension")
            command = hook.get("command")
            invocation = self._render_hook_invocation(command)
            command_text = (
                command if isinstance(command, str) and command.strip() else "<missing command>"
            )
            display_invocation = invocation or (
                f"/{command_text}" if command_text != "<missing command>" else "/<missing command>"
            )
            optional = hook.get("optional", True)
            prompt = hook.get("prompt", "")
            description = hook.get("description", "")

            if optional:
                lines.append(f"\n**Optional Hook**: {extension}")
                lines.append(f"Command: `{display_invocation}`")
                if description:
                    lines.append(f"Description: {description}")
                lines.append(f"\nPrompt: {prompt}")
                lines.append(f"To execute: `{display_invocation}`")
            else:
                lines.append(f"\n**Automatic Hook**: {extension}")
                lines.append(f"Executing: `{display_invocation}`")
                lines.append(f"EXECUTE_COMMAND: {command_text}")
                lines.append(f"EXECUTE_COMMAND_INVOCATION: {display_invocation}")

        return "\n".join(lines)

    def check_hooks_for_event(self, event_name: str) -> dict[str, Any]:
        """Check for hooks registered for a specific event.

        This method is designed to be called by AI agents after core commands complete.

        Args:
            event_name: Name of the event (e.g., 'after_spec', 'after_taskify')

        Returns:
            Dictionary with hook information:
            - has_hooks: bool - Whether hooks exist for this event
            - hooks: List[Dict] - List of hooks (with condition evaluation applied)
            - message: str - Formatted message for display
        """
        hooks = self.get_hooks_for_event(event_name)

        if not hooks:
            return {"has_hooks": False, "hooks": [], "message": ""}

        # Filter hooks by condition
        executable_hooks = []
        for hook in hooks:
            if self.should_execute_hook(hook):
                executable_hooks.append(hook)

        if not executable_hooks:
            return {
                "has_hooks": False,
                "hooks": [],
                "message": f"# No executable hooks for event '{event_name}' (conditions not met)",
            }

        return {
            "has_hooks": True,
            "hooks": executable_hooks,
            "message": self.format_hook_message(event_name, executable_hooks),
        }

    def execute_hook(self, hook: dict[str, Any]) -> dict[str, Any]:
        """Execute a single hook command.

        Note: This returns information about how to execute the hook.
        The actual execution is delegated to the AI agent.

        Args:
            hook: Hook configuration

        Returns:
            Dictionary with execution information:
            - command: str - Command to execute
            - extension: str - Extension ID
            - optional: bool - Whether hook is optional
            - description: str - Hook description
        """
        return {
            "command": hook.get("command"),
            "invocation": self._render_hook_invocation(hook.get("command")),
            "extension": hook.get("extension"),
            "optional": hook.get("optional", True),
            "description": hook.get("description", ""),
            "prompt": hook.get("prompt", ""),
        }

    def enable_hooks(self, extension_id: str):
        """Enable all hooks for an extension.

        Args:
            extension_id: Extension ID
        """
        config = self.get_project_config()

        if "hooks" not in config:
            return

        # Enable all hooks for this extension
        for hook_name in config["hooks"]:
            for hook in config["hooks"][hook_name]:
                if hook.get("extension") == extension_id:
                    hook["enabled"] = True

        self.save_project_config(config)

    def disable_hooks(self, extension_id: str):
        """Disable all hooks for an extension.

        Args:
            extension_id: Extension ID
        """
        config = self.get_project_config()

        if "hooks" not in config:
            return

        # Disable all hooks for this extension
        for hook_name in config["hooks"]:
            for hook in config["hooks"][hook_name]:
                if hook.get("extension") == extension_id:
                    hook["enabled"] = False

        self.save_project_config(config)


__all__ = [
    "CommandRegistrar",
    "ConfigManager",
    "HookExecutor",
]
