"""Extensions package — facade over catalog/installer/manager/registry/resolver.

Per ADR 0001 §24, the original ``extensions.py`` monolith was split into
five named modules. This package's ``__init__`` re-exports everything
the old module exposed, so callers using
``from fire_phoenix_cli.extensions import X`` keep working unchanged.
"""

from .catalog import *  # noqa: F401, F403
from .installer import *  # noqa: F401, F403
from .manager import *  # noqa: F401, F403
from .registry import *  # noqa: F401, F403
from .resolver import *  # noqa: F401, F403
