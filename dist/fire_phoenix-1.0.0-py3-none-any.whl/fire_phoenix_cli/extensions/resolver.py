"""Manifest parsing, version checks, and naming/conflict-detection helpers.

Holds the static "resolution" layer of the extensions subsystem:

- Exceptions: :class:`ExtensionError`, :class:`ValidationError`,
  :class:`CompatibilityError`.
- Manifest model: :class:`ExtensionManifest`.
- Naming/pattern constants and core-command discovery used to reject
  installs that would shadow core skills or collide with other
  extensions.
- :func:`version_satisfies` for SpecifierSet checks.

No disk writes happen here beyond reading the manifest file.
"""

from __future__ import annotations

import hashlib
import re
from pathlib import Path
from typing import Any

import yaml
from packaging.specifiers import InvalidSpecifier, SpecifierSet

from packaging import version as pkg_version

_FALLBACK_CORE_COMMAND_NAMES = frozenset(
    {
        # IDD core skills
        "verify-tasks",
        "feature-checklist",
        "clarify-intent",
        "standardize",
        "implement",
        "plan",
        "intent",
        "taskify",
        "tasks-to-issues",
        # Project management
        "project-planning",
        "risk-register",
        "status-report",
        "change-control",
        # Waterfall lifecycle
        "work-breakdown-structure",
        "traceability-matrix",
        "baseline",
        "phase-gate",
        "user-acceptance-test-plan",
        "data-migration-plan",
        "handover",
        # Product-owner
        "backlog",
        "acceptance-criteria",
        "roadmap",
        # Scrum-master
        "sprint-planning",
        "standup",
        "retrospective",
        # Architect
        "architecture-intake",
        "technology-research",
        "adr-author",
        "c4-diagrams",
        # Developer
        "development-design",
        "unit-tests",
        # Test-architect
        "test-strategy",
        "test-framework",
        "quality-gates",
        # Tester
        "test-cases",
        "test-execution",
        "bug-report",
        # Bug-fixer
        "bug-triage",
        "regression-tests",
        "change-log",
        # Code-quality-reviewer
        "quality-review",
        "intent-review",
        "review-agent-skills",
        # Code-security-reviewer
        "security-review",
        "dependency-audit",
        # DevOps
        "cicd-pipeline",
        "infrastructure-plan",
        "containerization",
        "observability-plan",
        "deployment-strategy",
        # Operate & Evolve (handbook ch. 09, task-0033)
        "slo-define",
        "runbook-author",
        "incident-postmortem",
        # Archetype skills (handbook ch. 11 brownfield + ch. 13 migration, task-0035)
        "characterise-behaviour",
        "parity-ledger",
        # Brownfield archaeology (adr/0019, task-0036)
        "inventory-existing",
        # Technical-analyst
        "codebase-scan",
        "architecture-extraction",
        "api-docs",
        "dependency-map",
        # UX
        "wireframes",
        "vue-spa-mockup",
        "react-spa-mockup",
        # Office round-trip
        "docx-markdown",
        "pptx-markdown",
        "xlsx-markdown",
    }
)
EXTENSION_COMMAND_NAME_PATTERN = re.compile(r"^fire-phoenix\.([a-z0-9-]+)\.([a-z0-9-]+)$")
# Hook phase names must follow the pattern: before|after + underscore + skill-name
HOOK_PHASE_PATTERN = re.compile(r"^(before|after)_[a-z][a-z0-9-]*$")

REINSTALL_COMMAND = "uv tool install fire-phoenix --force --from git+https://github.com/DauQuangThanh/fire-phoenix.git"


def _load_core_command_names() -> frozenset[str]:
    """Discover bundled core command names from the packaged skill bundles.

    Prefer the wheel-time ``core_pack`` bundle when present, and fall back to
    the source checkout when running from the repository. If neither is
    available, use the baked-in fallback set so validation still works.

    Source layout: ``assets/agent-skills/<name>/`` (per ADR-0003 the bare
    folder name IS the canonical core command name). Underscore-prefixed
    directories are developer scaffolding and are excluded from the
    installer wheel — they must not count as core commands. (The
    canonical skill template lives at repo-level
    ``templates/agent-skill-template/``, outside ``assets/``.)

    Legacy layout (``templates/commands/<name>.md`` flat files) is also
    accepted as a transitional fallback.
    """
    # Bundle-style sources (assets/agent-skills/<name>/ directories).
    # NB: this module now lives in src/fire_phoenix_cli/extensions/, so the
    # wheel-time ``core_pack`` is one parent up and the repo checkout is
    # four parents up (mirroring presets/catalog.py + installer/plan.py).
    bundle_dirs = [
        Path(__file__).parent.parent / "core_pack" / "assets" / "agent-skills",
        Path(__file__).resolve().parent.parent.parent.parent / "assets" / "agent-skills",
    ]
    for bundles_dir in bundle_dirs:
        if not bundles_dir.is_dir():
            continue
        command_names = {
            p.name for p in bundles_dir.iterdir() if p.is_dir() and not p.name.startswith("_")
        }
        if command_names:
            return frozenset(command_names)

    # Legacy flat-file sources (templates/commands/<name>.md).
    legacy_dirs = [
        Path(__file__).parent.parent / "core_pack" / "commands",
        Path(__file__).resolve().parent.parent.parent.parent / "templates" / "commands",
    ]
    for commands_dir in legacy_dirs:
        if not commands_dir.is_dir():
            continue
        command_names = {
            command_file.stem
            for command_file in commands_dir.iterdir()
            if command_file.is_file() and command_file.suffix == ".md"
        }
        if command_names:
            return frozenset(command_names)

    return _FALLBACK_CORE_COMMAND_NAMES


CORE_COMMAND_NAMES = _load_core_command_names()


class ExtensionError(Exception):
    """Base exception for extension-related errors."""

    pass


class ValidationError(ExtensionError):
    """Raised when extension manifest validation fails."""

    pass


class CompatibilityError(ExtensionError):
    """Raised when extension is incompatible with current environment."""

    pass


class ExtensionManifest:
    """Represents and validates an extension manifest (extension.yml)."""

    SCHEMA_VERSION = "1.0"
    REQUIRED_FIELDS = ["schema_version", "extension", "requires", "provides"]

    def __init__(self, manifest_path: Path):
        """Load and validate extension manifest.

        Args:
            manifest_path: Path to extension.yml file

        Raises:
            ValidationError: If manifest is invalid
        """
        self.path = manifest_path
        self.warnings: list[str] = []
        self.data = self._load_yaml(manifest_path)
        self._validate()

    def _load_yaml(self, path: Path) -> dict:
        """Load YAML file safely."""
        try:
            with open(path, encoding="utf-8") as f:
                data = yaml.safe_load(f)
        except yaml.YAMLError as e:
            raise ValidationError(f"Invalid YAML in {path}: {e}")  # noqa: B904
        except FileNotFoundError:
            raise ValidationError(f"Manifest not found: {path}")  # noqa: B904
        if not isinstance(data, dict):
            raise ValidationError(
                f"Manifest must be a YAML mapping, got {type(data).__name__}: {path}"
            )
        return data

    def _validate(self):
        """Validate manifest structure and required fields."""
        # Check required top-level fields
        for field in self.REQUIRED_FIELDS:
            if field not in self.data:
                raise ValidationError(f"Missing required field: {field}")

        # Validate schema version
        if self.data["schema_version"] != self.SCHEMA_VERSION:
            raise ValidationError(
                f"Unsupported schema version: {self.data['schema_version']} "
                f"(expected {self.SCHEMA_VERSION})"
            )

        # Validate extension metadata
        ext = self.data["extension"]
        for field in ["id", "name", "version", "description"]:
            if field not in ext:
                raise ValidationError(f"Missing extension.{field}")

        # Validate extension ID format
        if not re.match(r"^[a-z0-9-]+$", ext["id"]):
            raise ValidationError(
                f"Invalid extension ID '{ext['id']}': "
                "must be lowercase alphanumeric with hyphens only"
            )

        # Validate semantic version
        try:
            pkg_version.Version(ext["version"])
        except pkg_version.InvalidVersion:
            raise ValidationError(f"Invalid version: {ext['version']}")  # noqa: B904

        # Validate requires section
        requires = self.data["requires"]
        if "fire_phoenix_version" not in requires:
            raise ValidationError("Missing requires.fire-phoenix_version")

        # Validate provides section
        provides = self.data["provides"]
        commands = provides.get("commands", [])
        hooks = self.data.get("hooks")

        if "commands" in provides and not isinstance(commands, list):
            raise ValidationError("Invalid provides.commands: expected a list")
        if "hooks" in self.data and not isinstance(hooks, dict):
            raise ValidationError("Invalid hooks: expected a mapping")

        has_commands = bool(commands)
        has_hooks = bool(hooks)

        if not has_commands and not has_hooks:
            raise ValidationError("Extension must provide at least one command or hook")

        # Validate hook values (if present)
        if hooks:
            for hook_name, hook_config in hooks.items():
                if not isinstance(hook_config, dict):
                    raise ValidationError(f"Invalid hook '{hook_name}': expected a mapping")
                if not hook_config.get("command"):
                    raise ValidationError(f"Hook '{hook_name}' missing required 'command' field")

                # Validate hook phase name format — the only accepted form is
                # `before_<skill>` / `after_<skill>`.
                if not HOOK_PHASE_PATTERN.match(hook_name):
                    raise ValidationError(
                        f"Invalid hook phase '{hook_name}': "
                        "must match pattern '^(before|after)_[a-z][a-z0-9-]*$'"
                    )

        # Validate commands.
        for cmd in commands:
            if not isinstance(cmd, dict):
                raise ValidationError("Each command entry in 'provides.commands' must be a mapping")
            if "name" not in cmd or "file" not in cmd:
                raise ValidationError("Command missing 'name' or 'file'")

            # Validate command name format
            if not EXTENSION_COMMAND_NAME_PATTERN.match(cmd["name"]):
                raise ValidationError(
                    f"Invalid command name '{cmd['name']}': "
                    "must follow pattern 'fire-phoenix.{extension}.{command}'"
                )

            # Validate alias types; no pattern enforcement on aliases — they are
            # intentionally free-form to preserve community extension compatibility
            # (e.g. 'fire-phoenix.verify' short aliases used by existing extensions).
            aliases = cmd.get("aliases")
            if aliases is None:
                cmd["aliases"] = []
                aliases = []
            if not isinstance(aliases, list):
                raise ValidationError(f"Aliases for command '{cmd['name']}' must be a list")
            for alias in aliases:
                if not isinstance(alias, str):
                    raise ValidationError(f"Aliases for command '{cmd['name']}' must be strings")

        # Rewrite any hook command references that used an alias-form ref
        # (ext.cmd → fire-phoenix.ext.cmd).  Always emit a warning when the
        # reference is changed so extension authors know to update the manifest.
        for hook_name, hook_data in self.data.get("hooks", {}).items():
            if not isinstance(hook_data, dict):
                raise ValidationError(
                    f"Hook '{hook_name}' must be a mapping, got {type(hook_data).__name__}"
                )
            command_ref = hook_data.get("command")
            if not isinstance(command_ref, str):
                continue
            # Lift alias-form '{ext_id}.cmd' to canonical 'fire-phoenix.{ext_id}.cmd'.
            parts = command_ref.split(".")
            if len(parts) == 2 and parts[0] == ext["id"]:
                final_ref = f"fire-phoenix.{ext['id']}.{parts[1]}"
            else:
                final_ref = command_ref
            if final_ref != command_ref:
                hook_data["command"] = final_ref
                self.warnings.append(
                    f"Hook '{hook_name}' referenced command '{command_ref}'; "
                    f"updated to canonical form '{final_ref}'. "
                    f"The extension author should update the manifest."
                )

    @property
    def id(self) -> str:
        """Get extension ID."""
        return self.data["extension"]["id"]

    @property
    def name(self) -> str:
        """Get extension name."""
        return self.data["extension"]["name"]

    @property
    def version(self) -> str:
        """Get extension version."""
        return self.data["extension"]["version"]

    @property
    def description(self) -> str:
        """Get extension description."""
        return self.data["extension"]["description"]

    @property
    def requires_fire_phoenix_version(self) -> str:
        """Get required fire-phoenix version range."""
        return self.data["requires"]["fire_phoenix_version"]

    @property
    def commands(self) -> list[dict[str, Any]]:
        """Get list of provided commands."""
        return self.data.get("provides", {}).get("commands", [])

    @property
    def hooks(self) -> dict[str, Any]:
        """Get hook definitions."""
        return self.data.get("hooks", {})

    def get_hash(self) -> str:
        """Calculate SHA256 hash of manifest file."""
        with open(self.path, "rb") as f:
            return f"sha256:{hashlib.sha256(f.read()).hexdigest()}"


def version_satisfies(current: str, required: str) -> bool:
    """Check if current version satisfies required version specifier.

    Args:
        current: Current version (e.g., "0.1.5")
        required: Required version specifier (e.g., ">=0.1.0,<2.0.0")

    Returns:
        True if version satisfies requirement
    """
    try:
        current_ver = pkg_version.Version(current)
        specifier = SpecifierSet(required)
        return current_ver in specifier
    except (pkg_version.InvalidVersion, InvalidSpecifier):
        return False


__all__ = [
    "CORE_COMMAND_NAMES",
    "CompatibilityError",
    "EXTENSION_COMMAND_NAME_PATTERN",
    "ExtensionError",
    "ExtensionManifest",
    "HOOK_PHASE_PATTERN",
    "REINSTALL_COMMAND",
    "ValidationError",
    "_FALLBACK_CORE_COMMAND_NAMES",
    "_load_core_command_names",
    "version_satisfies",
]
