"""Extension catalog queries.

Owns :class:`ExtensionCatalog`: the read-only view over the bundled
extension catalog used by ``fire-phoenix extension list`` /
``... search`` / ``... info``. fire-phoenix is offline-only, so the
catalog is sourced exclusively from the wheel-bundled JSON via
:mod:`fire_phoenix_cli._bundled_catalogs`. The remote-catalog surface
(cache, download, URL config) was removed per ``adr/0062``.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from ..catalog_base import CatalogBase
from .registry import CatalogEntry
from .resolver import ValidationError


class ExtensionCatalog(CatalogBase):
    """Read-only view over the bundled extension catalog (F-18, offline-only)."""

    catalog_kind = "extensions"
    error_class = ValidationError

    def __init__(self, project_root: Path):
        """Initialize extension catalog manager."""
        self.project_root = project_root
        self.extensions_dir = project_root / ".fire-phoenix" / "extensions"

    def _make_entry(self, **kwargs: Any) -> CatalogEntry:
        return CatalogEntry(**kwargs)

    def _get_merged_extensions(self, force_refresh: bool = False) -> list[dict[str, Any]]:
        """Merged, annotated extension dicts (delegates to CatalogBase)."""
        return self._merged_list(force_refresh)

    def get_extension_info(self, extension_id: str) -> dict[str, Any] | None:
        """Return annotated catalog metadata for one extension, or None."""
        return self.get_info(extension_id)


__all__ = ["ExtensionCatalog"]
