"""Shared base for the four asset catalogs (improving-pro-plan.md §P2-1, F-18).

Pattern: this solves *near-duplicate catalog logic across workflows, extensions,
presets, and integrations* — the bundled read/merge/search path was copy-pasted
four ways and had drifted. It accepts a Template-Method shape: the base owns the
algorithm; each subclass declares only what differs (its entry dataclass, error
class, and the bundled catalog kind).

Interface (contract-first) — a subclass declares::

    class FooCatalog(CatalogBase):
        catalog_kind = "foos"          # also the bundled collection key
        error_class = FooCatalogError
        def _make_entry(self, **kw) -> FooCatalogEntry: ...

fire-phoenix is offline-only: :meth:`get_active_catalogs` returns the single
bundled catalog. The remote-catalog surface (URL validation, catalog-stack
loading, cache, and the ``catalog add/list/remove`` CLI) was removed per
``adr/0062`` — it was inert (the stack it wrote was never consulted) and an
invitation to re-wire fetching against the offline invariant.

Evolutionary note (§4): a new asset type becomes a ~1-screen subclass. Org-
curated or remote catalogs, if ever reintroduced, are a new feature (new ADR)
that would attach at :meth:`get_active_catalogs` / :meth:`_fetch_single_catalog`
— the only two seams that assume "bundled, single source".
"""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Any, cast

from ._bundled_catalogs import BUNDLED_CATALOG_URL


class CatalogBase:
    """Read-only view over a bundled asset catalog with search + merge."""

    #: Bundled collection key AND ``load_bundled_catalog`` kind (e.g. "workflows").
    catalog_kind: str = ""
    #: Exception type raised on invalid catalog config / fetch failure.
    error_class: type[Exception] = ValueError

    DEFAULT_CATALOG_URL = BUNDLED_CATALOG_URL

    def __init__(self, project_root: Path) -> None:
        self.project_root = project_root

    # -- Subclass hook ----------------------------------------------------

    def _make_entry(
        self,
        *,
        url: str,
        name: str,
        priority: int,
        install_allowed: bool,
        description: str,
    ) -> Any:
        """Build the subclass's catalog-entry dataclass. Must be overridden."""
        raise NotImplementedError

    # -- Active catalog + fetch (shared, offline-only) --------------------

    def get_active_catalogs(self) -> list[Any]:
        """Return the sole active catalog — the bundled one (offline-only)."""
        return [
            self._make_entry(
                url=self.DEFAULT_CATALOG_URL,
                name="bundled",
                priority=1,
                install_allowed=True,
                description=f"Built-in catalog of bundled {self.catalog_kind}",
            )
        ]

    def _fetch_single_catalog(self, entry: Any, force_refresh: bool = False) -> dict[str, Any]:
        """Return the bundled catalog data (ignores entry.url / force_refresh).

        Imported lazily so test patches on
        ``_bundled_catalogs.load_bundled_catalog`` take effect per call.
        """
        from ._bundled_catalogs import CatalogKind, load_bundled_catalog

        return load_bundled_catalog(cast(CatalogKind, self.catalog_kind))

    # -- Merge (shared) ---------------------------------------------------

    def _merged(self, force_refresh: bool = False) -> dict[str, dict[str, Any]]:
        """Merge entries from active catalogs into ``{id: data}`` (first wins).

        Each item is annotated with ``id``, ``_catalog_name`` and
        ``_install_allowed``. With the single bundled catalog this is simply the
        bundled collection, annotated. Handles both dict and list collections.
        """
        active = self.get_active_catalogs()
        merged: dict[str, dict[str, Any]] = {}
        any_success = False
        for entry in active:
            try:
                data = self._fetch_single_catalog(entry, force_refresh)
                any_success = True
            except self.error_class as exc:
                print(f"Warning: Could not fetch catalog '{entry.name}': {exc}", file=sys.stderr)
                continue
            collection = data.get(self.catalog_kind, {})
            items = (
                collection.items()
                if isinstance(collection, dict)
                else ((str(d.get("id", "")), d) for d in collection if isinstance(d, dict))
            )
            for item_id, item_data in items:
                if not isinstance(item_data, dict) or not item_id:
                    continue
                if item_id not in merged:  # first (highest-priority) catalog wins
                    merged[item_id] = {
                        **item_data,
                        "id": item_id,
                        "_catalog_name": entry.name,
                        "_install_allowed": entry.install_allowed,
                    }
        if not any_success and active:
            raise self.error_class(f"Failed to fetch any {self.catalog_kind} catalog")
        return merged

    def _merged_list(self, force_refresh: bool = False) -> list[dict[str, Any]]:
        return list(self._merged(force_refresh).values())

    # -- Search / info (shared) -------------------------------------------

    def get_info(self, item_id: str) -> dict[str, Any] | None:
        """Return annotated catalog metadata for one id, or None."""
        return self._merged().get(item_id)

    def search(
        self,
        query: str | None = None,
        tag: str | None = None,
        author: str | None = None,
        verified_only: bool = False,
    ) -> list[dict[str, Any]]:
        """Filter merged entries by query (name/description/id/tags), tag, author."""
        results: list[dict[str, Any]] = []
        for item in self._merged_list():
            if verified_only and not item.get("verified", False):
                continue
            author_val = item.get("author", "")
            author_val = author_val if isinstance(author_val, str) else str(author_val or "")
            if author and author_val.lower() != author.lower():
                continue
            raw_tags = item.get("tags", [])
            tags = [t for t in raw_tags if isinstance(t, str)] if isinstance(raw_tags, list) else []
            if tag and tag.lower() not in [t.lower() for t in tags]:
                continue
            if query:
                haystack = " ".join(
                    [
                        str(item.get("name", "") or ""),
                        str(item.get("description", "") or ""),
                        str(item.get("id", "") or ""),
                    ]
                    + tags
                ).lower()
                if query.lower() not in haystack:
                    continue
            results.append(item)
        return results
