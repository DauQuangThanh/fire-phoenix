<!-- markdownlint-disable MD024 -->
# Acceptance Criteria: {feature}

**Last updated:** {date}
**Source spec:** {spec_ref}

All acceptance criteria for this feature, keyed by user-story id.
Write in Given/When/Then form, numbered AC-NNN per story
(AC-001, AC-002, …). See `references/gwt-style-guide.md`.

## US-NN: <story title>

### AC-001 — <short label>

- **Given** <precondition / context>
- **When** <action / trigger>
- **Then** <observable outcome>

### AC-002 — <short label>

- **Given** …
- **When** …
- **Then** …

### AC-003 — <failure path: short label>

<!-- Required where the intent names a failure condition.
     Profile P (Prototype/Demo): happy-path minimum acceptable —
     note the profile here if omitting failure paths. -->

- **Given** <precondition / context>
- **When** <failing action / invalid trigger>
- **Then** <observable failure outcome — message, refusal, no side effect>

---

## US-NN: <next story>

…

---

## EARS decomposition

Each GWT AC above maps to ≥1 EARS criterion — or names its manual
review. See "Decomposing to EARS spec criteria" in
`references/gwt-style-guide.md`.

### AC-NNN

- WHEN <condition>, THE <system> SHALL <response>.
- WHEN <condition>, THE <system> SHALL <response>.

### AC-NNN

- Manual review: <who reviews, what they check>.

---

## G1 agreement

<!-- Optional MIRROR of the canonical G1 record. The canonical
     record gates check is a dated entry in the project's decisions
     file ({context.governance.decisions_file}) naming this feature
     and each confirmation by name (see the skill's
     "Recording the G1 agreement" section). This block alone does
     NOT satisfy the gate — lint R9 checks the decisions entry.
     Each confirmation is advisory input to the single human
     approver. Under rigor Profile P a single confirmer is
     acceptable — record which role confirmed. -->

- Developer: <name> — feasibility confirmed (<date>)
- Tester: <name> — testability confirmed (<date>)
- Product owner: <name> — business fit confirmed (<date>)
- Approver: <name> — accepted (<date>)
- Decisions entry: <YYYY-MM-DD heading in the decisions file>
