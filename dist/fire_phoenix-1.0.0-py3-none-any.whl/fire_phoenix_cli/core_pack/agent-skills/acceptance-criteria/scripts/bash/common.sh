#!/usr/bin/env bash
# Shared helpers for Fire Phoenix role skills.
#
# Every role-skill's action scripts source this file to get:
#   - read_context            : parse .fire-phoenix/context.yml into FIRE_PHOENIX_* env vars
#   - worktype_dir <name>     : resolve docs/<work-type>/
#   - feature_scoped_dir <wt> : resolve docs/<work-type>/<feature>/
#   - append_debt <f> <p> <b> : append a numbered debt entry
#   - write_extract <path> …  : write a .extract companion file
#   - confirm_before_write …  : honour preferences.confirm_before_write
#   - resolve_auto <key>      : --auto / env / answers / .extract lookup
#
# Design notes:
#   * Fails softly. Missing .fire-phoenix/context.yml => warns once, applies
#     documented defaults (paths.docs=docs/, paths.intents=docs/intents/, …).
#   * YAML parsing: python3 with PyYAML → python3 without PyYAML
#     (minimal tokeniser) → grep fallback. We never REQUIRE python3
#     or yq, because fire-phoenix wheels install offline.
#   * All functions are idempotent; sourcing the file twice is safe.

# -------------------------------------------------------------------
# Repo root discovery (re-uses the existing intent convention).
# -------------------------------------------------------------------

find_fire_phoenix_root() {
    local dir="${1:-$(pwd)}"
    dir="$(cd -- "$dir" 2>/dev/null && pwd)" || return 1
    local prev_dir=""
    while true; do
        if [ -d "$dir/.fire-phoenix" ]; then
            echo "$dir"
            return 0
        fi
        if [ "$dir" = "/" ] || [ "$dir" = "$prev_dir" ]; then
            break
        fi
        prev_dir="$dir"
        dir="$(dirname "$dir")"
    done
    return 1
}

get_repo_root() {
    local fire_phoenix_root
    if fire_phoenix_root=$(find_fire_phoenix_root); then
        echo "$fire_phoenix_root"
        return
    fi
    if git rev-parse --show-toplevel >/dev/null 2>&1; then
        git rev-parse --show-toplevel
        return
    fi
    local script_dir
    script_dir="$(CDPATH="" cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
    (cd "$script_dir/../../../.." && pwd)
}

# -------------------------------------------------------------------
# Context-file parsing.
# -------------------------------------------------------------------

# Documented defaults — match src/fire_phoenix_cli/context.py create_context_file().
_FIRE_PHOENIX_DEFAULT_DOCS_DIR="docs"
_FIRE_PHOENIX_DEFAULT_INTENTS_DIR="docs/intents"
_FIRE_PHOENIX_DEFAULT_PLANS_DIR="docs/plans"
_FIRE_PHOENIX_DEFAULT_TASKS_DIR="docs/tasks"
_FIRE_PHOENIX_DEFAULT_TEMPLATES_DIR="templates"
_FIRE_PHOENIX_DEFAULT_SCRIPTS_DIR="scripts"
# governance.adr_dir — canonical ADR home (contracts/task-0077).
_FIRE_PHOENIX_DEFAULT_ADR_DIR="docs/adr"
# governance.decisions_file — canonical L4 decisions log (append-only).
_FIRE_PHOENIX_DEFAULT_DECISIONS_FILE="docs/decisions.md"
# governance.adr_drafts_dir / decisions_pending_dir — unprotected pending queues
# for the sanctioned governance-authoring path (adr/0053). Producers write drafts
# here in every mode; the promote-governance skill is the SOLE writer of the
# canonical adr_dir / decisions_file.
_FIRE_PHOENIX_DEFAULT_ADR_DRAFTS_DIR="docs/adr-drafts"
_FIRE_PHOENIX_DEFAULT_DECISIONS_PENDING_DIR="docs/decisions-pending"

_fire_phoenix_context_warned=""

_fire_phoenix_warn_context_missing() {
    if [ -z "$_fire_phoenix_context_warned" ]; then
        echo "[fire-phoenix] .fire-phoenix/context.yml not found — applying documented defaults" >&2
        _fire_phoenix_context_warned=1
    fi
}

# Parse a .fire-phoenix/context.yml via python3 (+ PyYAML if available) and
# emit NUL-delimited KEY<NUL>VALUE<NUL> pairs on stdout. The bash consumer
# (read_context) assigns them literally to an allowlist of FIRE_PHOENIX_*
# variables and NEVER eval's this output — so a crafted context file can
# never inject shell commands (SAF-03 / FP-Uplift W2).
_fire_phoenix_parse_context_python() {
    local context_file="$1"
    command -v python3 >/dev/null 2>&1 || return 1
    python3 - "$context_file" <<'PY' 2>/dev/null
import os, sys
path = sys.argv[1]
try:
    import yaml  # type: ignore
    with open(path, "r") as f:
        data = yaml.safe_load(f) or {}
except ImportError:
    # Minimal fallback: hand-parse the 2-level-deep scalars we care
    # about. This matches the documented schema exactly.
    data = {"paths": {}, "current": {}, "preferences": {}}
    section = None
    with open(path, "r") as f:
        for raw in f:
            line = raw.rstrip("\n")
            if not line or line.lstrip().startswith("#"):
                continue
            if not line.startswith(" ") and line.endswith(":"):
                section = line[:-1]
                if section not in data:
                    data[section] = {}
                continue
            if line.startswith("  ") and ":" in line:
                key, _, value = line.strip().partition(":")
                value = value.strip()
                if value.startswith('"') and value.endswith('"'):
                    value = value[1:-1]
                elif value.startswith("'") and value.endswith("'"):
                    value = value[1:-1]
                if section and section in data:
                    data[section][key.strip()] = None if value in ("null", "~", "") else value
except Exception as e:
    # Never emit an assignable/eval-able line. Diagnostic to stderr; empty
    # stdout makes read_context fall through to the grep parser (SAF-03).
    sys.stderr.write(f"[fire-phoenix] context parse error: {e!s}\n")
    sys.exit(0)

def emit(key, value):
    # NUL-delimited key<NUL>value<NUL>. Values are RAW: never shell-quoted
    # and never eval'd. The bash consumer assigns them literally to a fixed
    # allowlist of FIRE_PHOENIX_* variables, so no context-file content can
    # be interpreted as a shell command (SAF-03).
    v = "" if value is None else str(value)
    sys.stdout.write(key + "\0" + v + "\0")

paths = data.get("paths", {}) or {}
current = data.get("current", {}) or {}
prefs = data.get("preferences", {}) or {}
gov = data.get("governance", {}) or {}

emit("FIRE_PHOENIX_DOCS_DIR", paths.get("docs"))
emit("FIRE_PHOENIX_INTENTS_DIR", paths.get("intents"))
emit("FIRE_PHOENIX_PLANS_DIR", paths.get("plans"))
emit("FIRE_PHOENIX_TASKS_DIR", paths.get("tasks"))
emit("FIRE_PHOENIX_TEMPLATES_DIR", paths.get("templates"))
emit("FIRE_PHOENIX_SCRIPTS_DIR", paths.get("scripts"))
# Only emit when present: user-context.yml never carries governance,
# and an unconditional empty assignment would clobber the project
# context's custom adr_dir (contracts/task-0077).
if gov.get("adr_dir") is not None:
    emit("FIRE_PHOENIX_ADR_DIR", gov.get("adr_dir"))
if gov.get("decisions_file") is not None:
    emit("FIRE_PHOENIX_DECISIONS_FILE", gov.get("decisions_file"))
if gov.get("adr_drafts_dir") is not None:
    emit("FIRE_PHOENIX_ADR_DRAFTS_DIR", gov.get("adr_drafts_dir"))
if gov.get("decisions_pending_dir") is not None:
    emit("FIRE_PHOENIX_DECISIONS_PENDING_DIR", gov.get("decisions_pending_dir"))
emit("FIRE_PHOENIX_CURRENT_FEATURE", current.get("feature"))
emit("FIRE_PHOENIX_CURRENT_INTENT", current.get("intent"))
emit("FIRE_PHOENIX_CURRENT_PLAN", current.get("plan"))
emit("FIRE_PHOENIX_CURRENT_TASK", current.get("task"))
emit("FIRE_PHOENIX_CURRENT_CHECKLIST", current.get("checklist"))
emit("FIRE_PHOENIX_CURRENT_BRANCH", current.get("branch"))
emit("FIRE_PHOENIX_CONFIRM_BEFORE_WRITE", prefs.get("confirm_before_write", True))
emit("FIRE_PHOENIX_OUTPUT_FORMAT", prefs.get("output_format", "markdown"))
PY
}

# Pure-grep fallback — only extracts the minimum we need when python3
# is unavailable. Matches `  key: value` under known section headers.
_fire_phoenix_parse_context_grep() {
    local context_file="$1"
    local section=""
    while IFS= read -r raw; do
        # strip trailing newline + comments
        local line="${raw%$'\r'}"
        case "$line" in
            "#"*|"") continue ;;
        esac
        if [[ "$line" =~ ^([a-z_]+):[[:space:]]*$ ]]; then
            section="${BASH_REMATCH[1]}"
            continue
        fi
        if [[ "$line" =~ ^[[:space:]]+([a-z_]+):[[:space:]]*(.*)$ ]]; then
            local key="${BASH_REMATCH[1]}"
            local value="${BASH_REMATCH[2]}"
            # strip enclosing quotes
            value="${value%\"}"
            value="${value#\"}"
            value="${value%\'}"
            value="${value#\'}"
            # null markers
            case "$value" in
                "null"|"~"|"") value="" ;;
            esac
            # Emit NUL-delimited key<NUL>value<NUL> pairs — never an
            # eval-able KEY=VALUE line — matching the python parser (SAF-03).
            case "$section/$key" in
                paths/docs)      printf 'FIRE_PHOENIX_DOCS_DIR\0%s\0' "$value" ;;
                paths/intents)   printf 'FIRE_PHOENIX_INTENTS_DIR\0%s\0' "$value" ;;
                paths/plans)     printf 'FIRE_PHOENIX_PLANS_DIR\0%s\0' "$value" ;;
                paths/tasks)     printf 'FIRE_PHOENIX_TASKS_DIR\0%s\0' "$value" ;;
                paths/templates) printf 'FIRE_PHOENIX_TEMPLATES_DIR\0%s\0' "$value" ;;
                paths/scripts)   printf 'FIRE_PHOENIX_SCRIPTS_DIR\0%s\0' "$value" ;;
                governance/adr_dir) printf 'FIRE_PHOENIX_ADR_DIR\0%s\0' "$value" ;;
                governance/decisions_file) printf 'FIRE_PHOENIX_DECISIONS_FILE\0%s\0' "$value" ;;
                governance/adr_drafts_dir) printf 'FIRE_PHOENIX_ADR_DRAFTS_DIR\0%s\0' "$value" ;;
                governance/decisions_pending_dir) printf 'FIRE_PHOENIX_DECISIONS_PENDING_DIR\0%s\0' "$value" ;;
                current/feature)   printf 'FIRE_PHOENIX_CURRENT_FEATURE\0%s\0' "$value" ;;
                current/intent)    printf 'FIRE_PHOENIX_CURRENT_INTENT\0%s\0' "$value" ;;
                current/plan)      printf 'FIRE_PHOENIX_CURRENT_PLAN\0%s\0' "$value" ;;
                current/task)      printf 'FIRE_PHOENIX_CURRENT_TASK\0%s\0' "$value" ;;
                current/checklist) printf 'FIRE_PHOENIX_CURRENT_CHECKLIST\0%s\0' "$value" ;;
                current/branch)    printf 'FIRE_PHOENIX_CURRENT_BRANCH\0%s\0' "$value" ;;
                preferences/confirm_before_write) printf 'FIRE_PHOENIX_CONFIRM_BEFORE_WRITE\0%s\0' "$value" ;;
                preferences/output_format)        printf 'FIRE_PHOENIX_OUTPUT_FORMAT\0%s\0' "$value" ;;
            esac
        fi
    done < "$context_file"
}

# Assign ONE parsed key/value pair, but only for the fixed allowlist of
# FIRE_PHOENIX_* variables. Uses `printf -v` (literal assignment) — the
# value is never interpreted as shell, so a crafted context.yml cannot
# inject commands (SAF-03). Returns 0 if assigned, 1 if the key is not on
# the allowlist (or not a valid identifier).
_fire_phoenix_assign_pair() {
    case "$1" in
        FIRE_PHOENIX_DOCS_DIR|FIRE_PHOENIX_INTENTS_DIR|FIRE_PHOENIX_PLANS_DIR|\
        FIRE_PHOENIX_TASKS_DIR|FIRE_PHOENIX_TEMPLATES_DIR|FIRE_PHOENIX_SCRIPTS_DIR|\
        FIRE_PHOENIX_ADR_DIR|FIRE_PHOENIX_DECISIONS_FILE|FIRE_PHOENIX_ADR_DRAFTS_DIR|FIRE_PHOENIX_DECISIONS_PENDING_DIR|\
        FIRE_PHOENIX_CURRENT_FEATURE|FIRE_PHOENIX_CURRENT_INTENT|\
        FIRE_PHOENIX_CURRENT_PLAN|FIRE_PHOENIX_CURRENT_TASK|FIRE_PHOENIX_CURRENT_CHECKLIST|\
        FIRE_PHOENIX_CURRENT_BRANCH|FIRE_PHOENIX_CONFIRM_BEFORE_WRITE|FIRE_PHOENIX_OUTPUT_FORMAT)
            printf -v "$1" '%s' "$2"
            export "${1?}"
            return 0
            ;;
    esac
    return 1
}

# Read NUL-delimited key/value pairs from a context file via the python
# parser, falling back to the grep parser when python produced nothing.
# Assigns only allowlisted FIRE_PHOENIX_* vars. Never eval's (SAF-03).
_fire_phoenix_apply_context_file() {
    local file="$1"
    local produced=0 key val
    while IFS= read -r -d '' key && IFS= read -r -d '' val; do
        _fire_phoenix_assign_pair "$key" "$val" && produced=1 || true
    done < <(_fire_phoenix_parse_context_python "$file" 2>/dev/null)
    if [ "$produced" -eq 0 ]; then
        while IFS= read -r -d '' key && IFS= read -r -d '' val; do
            _fire_phoenix_assign_pair "$key" "$val" || true
        done < <(_fire_phoenix_parse_context_grep "$file")
    fi
}

# Populate FIRE_PHOENIX_* env vars from .fire-phoenix/context.yml (or defaults).
# Idempotent: subsequent calls re-read the file.
read_context() {
    local repo_root
    repo_root=$(get_repo_root)
    local context_file="$repo_root/.fire-phoenix/context.yml"

    # Start with defaults so downstream code never sees empty vars.
    export FIRE_PHOENIX_REPO_ROOT="$repo_root"
    export FIRE_PHOENIX_DOCS_DIR="$_FIRE_PHOENIX_DEFAULT_DOCS_DIR"
    export FIRE_PHOENIX_INTENTS_DIR="$_FIRE_PHOENIX_DEFAULT_INTENTS_DIR"
    export FIRE_PHOENIX_PLANS_DIR="$_FIRE_PHOENIX_DEFAULT_PLANS_DIR"
    export FIRE_PHOENIX_TASKS_DIR="$_FIRE_PHOENIX_DEFAULT_TASKS_DIR"
    export FIRE_PHOENIX_TEMPLATES_DIR="$_FIRE_PHOENIX_DEFAULT_TEMPLATES_DIR"
    export FIRE_PHOENIX_SCRIPTS_DIR="$_FIRE_PHOENIX_DEFAULT_SCRIPTS_DIR"
    export FIRE_PHOENIX_ADR_DIR="$_FIRE_PHOENIX_DEFAULT_ADR_DIR"
    export FIRE_PHOENIX_DECISIONS_FILE="$_FIRE_PHOENIX_DEFAULT_DECISIONS_FILE"
    export FIRE_PHOENIX_ADR_DRAFTS_DIR="$_FIRE_PHOENIX_DEFAULT_ADR_DRAFTS_DIR"
    export FIRE_PHOENIX_DECISIONS_PENDING_DIR="$_FIRE_PHOENIX_DEFAULT_DECISIONS_PENDING_DIR"
    export FIRE_PHOENIX_CURRENT_FEATURE=""
    export FIRE_PHOENIX_CURRENT_INTENT=""
    export FIRE_PHOENIX_CURRENT_PLAN=""
    export FIRE_PHOENIX_CURRENT_TASK=""
    export FIRE_PHOENIX_CURRENT_CHECKLIST=""
    export FIRE_PHOENIX_CURRENT_BRANCH=""
    export FIRE_PHOENIX_CONFIRM_BEFORE_WRITE="true"
    export FIRE_PHOENIX_OUTPUT_FORMAT="markdown"

    if [ ! -f "$context_file" ]; then
        _fire_phoenix_warn_context_missing
        return 0
    fi

    _fire_phoenix_apply_context_file "$context_file"

    # adr/0030: also parse .fire-phoenix/user-context.yml when present.
    # User-context values OVERRIDE project context values on conflict.
    # current.* lives ONLY in user-context.yml.
    local user_context_file="$repo_root/.fire-phoenix/user-context.yml"
    if [ -f "$user_context_file" ]; then
        _fire_phoenix_apply_context_file "$user_context_file"
    fi

    # Re-apply defaults where the context file left a slot null/empty.
    # Using ${VAR:=default} so we never leak a non-zero exit under set -e.
    : "${FIRE_PHOENIX_DOCS_DIR:=$_FIRE_PHOENIX_DEFAULT_DOCS_DIR}"
    : "${FIRE_PHOENIX_INTENTS_DIR:=$_FIRE_PHOENIX_DEFAULT_INTENTS_DIR}"
    : "${FIRE_PHOENIX_PLANS_DIR:=$_FIRE_PHOENIX_DEFAULT_PLANS_DIR}"
    : "${FIRE_PHOENIX_TASKS_DIR:=$_FIRE_PHOENIX_DEFAULT_TASKS_DIR}"
    : "${FIRE_PHOENIX_TEMPLATES_DIR:=$_FIRE_PHOENIX_DEFAULT_TEMPLATES_DIR}"
    : "${FIRE_PHOENIX_SCRIPTS_DIR:=$_FIRE_PHOENIX_DEFAULT_SCRIPTS_DIR}"
    : "${FIRE_PHOENIX_ADR_DIR:=$_FIRE_PHOENIX_DEFAULT_ADR_DIR}"
    : "${FIRE_PHOENIX_DECISIONS_FILE:=$_FIRE_PHOENIX_DEFAULT_DECISIONS_FILE}"
    : "${FIRE_PHOENIX_ADR_DRAFTS_DIR:=$_FIRE_PHOENIX_DEFAULT_ADR_DRAFTS_DIR}"
    : "${FIRE_PHOENIX_DECISIONS_PENDING_DIR:=$_FIRE_PHOENIX_DEFAULT_DECISIONS_PENDING_DIR}"
    : "${FIRE_PHOENIX_CONFIRM_BEFORE_WRITE:=true}"
    : "${FIRE_PHOENIX_OUTPUT_FORMAT:=markdown}"

    # Normalise Python/YAML boolean representations to lower-case.
    case "$FIRE_PHOENIX_CONFIRM_BEFORE_WRITE" in
        True|TRUE)   FIRE_PHOENIX_CONFIRM_BEFORE_WRITE="true" ;;
        False|FALSE) FIRE_PHOENIX_CONFIRM_BEFORE_WRITE="false" ;;
    esac

    # Agent mode (auto | interactive). When `auto`, we also enable
    # FIRE_PHOENIX_AUTO so skill action scripts take non-interactive paths.
    : "${FIRE_PHOENIX_AGENT_MODE:=interactive}"
    case "$FIRE_PHOENIX_AGENT_MODE" in
        auto|AUTO|Auto)
            FIRE_PHOENIX_AGENT_MODE="auto"
            : "${FIRE_PHOENIX_AUTO:=1}"
            ;;
        *)
            FIRE_PHOENIX_AGENT_MODE="interactive"
            ;;
    esac
    export FIRE_PHOENIX_AGENT_MODE
}

# -------------------------------------------------------------------
# Intent bootstrap gate (adr/0064).
#
# Detect whether an intent exists for the current feature, classifying
# absence as greenfield vs brownfield so entry points can bootstrap
# `intent` (greenfield) or `recover-intent`/`recover-spec` (brownfield).
# Prints exactly ONE token on stdout:
#   present            — an intent.md exists (current feature, or any)
#   absent-brownfield  — no intent, existing source, no recovered baseline
#   absent-greenfield  — no intent, no substantial source
# Pure detection: no writes, no side effects. Safe under `set -e`.
# Callers under `set -e`: status=$(fire_phoenix_intent_status) || true
# -------------------------------------------------------------------
fire_phoenix_intent_status() {
    if [ -z "${FIRE_PHOENIX_INTENTS_DIR:-}" ] || [ -z "${FIRE_PHOENIX_REPO_ROOT:-}" ]; then
        read_context >/dev/null 2>&1 || true
    fi
    local repo_root="${FIRE_PHOENIX_REPO_ROOT:-$(get_repo_root)}"
    local intents_abs="$repo_root/${FIRE_PHOENIX_INTENTS_DIR:-docs/intents}"
    local docs_abs="$repo_root/${FIRE_PHOENIX_DOCS_DIR:-docs}"

    # present: current feature has an intent.md, or any intent.md exists.
    local feature="${FIRE_PHOENIX_CURRENT_FEATURE:-}"
    if [ -n "$feature" ] && [ -f "$intents_abs/$feature/intent.md" ]; then
        printf 'present\n'; return 0
    fi
    if [ -d "$intents_abs" ] && \
       find "$intents_abs" -maxdepth 2 -name 'intent.md' -print -quit 2>/dev/null | grep -q .; then
        printf 'present\n'; return 0
    fi

    # absent: brownfield = existing source AND no recovered baseline.
    local baseline_present=0
    if [ -d "$docs_abs/baseline" ] && \
       find "$docs_abs/baseline" -maxdepth 1 -name '*.md' -print -quit 2>/dev/null | grep -q .; then
        baseline_present=1
    fi

    local source_present=0
    if command -v git >/dev/null 2>&1 && \
       git -C "$repo_root" rev-parse --is-inside-work-tree >/dev/null 2>&1; then
        if git -C "$repo_root" ls-files -- . \
             ':(exclude)docs' ':(exclude).fire-phoenix' ':(exclude)*.md' ':(exclude).git*' \
             2>/dev/null | grep -q .; then
            source_present=1
        fi
    elif find "$repo_root" -maxdepth 2 \
             \( -name '*.py' -o -name '*.ts' -o -name '*.js' -o -name '*.go' \
                -o -name '*.java' -o -name '*.rs' -o -name 'package.json' \
                -o -name 'pyproject.toml' -o -name 'go.mod' \) \
             -not -path '*/.fire-phoenix/*' -not -path '*/docs/*' \
             -print -quit 2>/dev/null | grep -q .; then
        source_present=1
    fi

    if [ "$source_present" -eq 1 ] && [ "$baseline_present" -eq 0 ]; then
        printf 'absent-brownfield\n'; return 0
    fi
    printf 'absent-greenfield\n'; return 0
}

# -------------------------------------------------------------------
# user-context.yml read/write helpers (adr/0030 §Skill helper changes).
#
# `current.*` and per-user overrides of `preferences.*` / `language.*`
# live in `.fire-phoenix/user-context.yml`. These helpers are the
# canonical write path for those keys. They MUST NOT touch the project
# `.fire-phoenix/context.yml`.
# -------------------------------------------------------------------

# Read a dotted key (e.g. "current.feature", "language.output") from
# .fire-phoenix/user-context.yml. Falls back to .fire-phoenix/context.yml
# if the key is missing or null in user-context.yml. Prints the value
# on stdout; exit 0 if found with a non-null value, exit 1 if absent
# from both files (or both files null).
#
# Callers under `set -e` should use:
#   val=$(read_user_context_value KEY) || true
read_user_context_value() {
    local key="$1"
    if [ -z "$key" ]; then
        echo "read_user_context_value: <dotted.key> required" >&2
        return 2
    fi
    if ! command -v python3 >/dev/null 2>&1; then
        echo "read_user_context_value: python3 required" >&2
        return 2
    fi
    local repo_root="${FIRE_PHOENIX_REPO_ROOT:-$(get_repo_root)}"
    local user_file="$repo_root/.fire-phoenix/user-context.yml"
    local project_file="$repo_root/.fire-phoenix/context.yml"

    FIRE_PHOENIX_KEY="$key" \
    FIRE_PHOENIX_USER="$user_file" \
    FIRE_PHOENIX_PROJECT="$project_file" \
    python3 - <<'PY'
import os
import sys

key = os.environ["FIRE_PHOENIX_KEY"]
section, _, leaf = key.partition(".")
if not section or not leaf:
    sys.exit(2)

def _load(path):
    try:
        with open(path, "r", encoding="utf-8") as f:
            raw = f.read()
    except FileNotFoundError:
        return None
    try:
        import yaml  # type: ignore
        return yaml.safe_load(raw) or {}
    except ImportError:
        pass
    # Minimal fallback: 2-level scalars only. Matches the documented schema.
    data = {}
    cur = None
    for line in raw.splitlines():
        s = line.rstrip()
        if not s or s.lstrip().startswith("#"):
            continue
        if not s.startswith(" ") and s.endswith(":"):
            cur = s[:-1]
            data.setdefault(cur, {})
            continue
        if s.startswith(" ") and ":" in s and cur is not None:
            k, _, v = s.strip().partition(":")
            v = v.strip()
            if v.startswith('"') and v.endswith('"'):
                v = v[1:-1]
            elif v.startswith("'") and v.endswith("'"):
                v = v[1:-1]
            if v in ("null", "~", ""):
                v = None
            data[cur][k.strip()] = v
    return data

for path in (os.environ["FIRE_PHOENIX_USER"], os.environ["FIRE_PHOENIX_PROJECT"]):
    data = _load(path)
    if not data:
        continue
    block = data.get(section)
    if not isinstance(block, dict):
        continue
    val = block.get(leaf)
    if val is None:
        continue
    sys.stdout.write(str(val))
    sys.exit(0)

sys.exit(1)
PY
}

# Write a dotted key (e.g. "current.feature") to .fire-phoenix/user-context.yml
# ONLY. Creates the file with a minimal schema-3.0 stub (schema_version +
# current: block with all-null defaults) if absent. Idempotent: a no-op when
# the value already matches. NEVER touches .fire-phoenix/context.yml.
#
# Pass the literal string "null" to set a value to YAML null.
write_user_context_value() {
    local key="$1"
    local value="$2"
    if [ -z "$key" ] || [ $# -lt 2 ]; then
        echo "write_user_context_value: <dotted.key> <value> required" >&2
        return 2
    fi
    if ! command -v python3 >/dev/null 2>&1; then
        echo "write_user_context_value: python3 required" >&2
        return 2
    fi
    local repo_root="${FIRE_PHOENIX_REPO_ROOT:-$(get_repo_root)}"
    local user_file="$repo_root/.fire-phoenix/user-context.yml"
    mkdir -p "$repo_root/.fire-phoenix"

    FIRE_PHOENIX_KEY="$key" \
    FIRE_PHOENIX_VAL="$value" \
    FIRE_PHOENIX_FILE="$user_file" \
    python3 - <<'PY'
import os
import sys

key = os.environ["FIRE_PHOENIX_KEY"]
val_raw = os.environ["FIRE_PHOENIX_VAL"]
path = os.environ["FIRE_PHOENIX_FILE"]

section, _, leaf = key.partition(".")
if not section or not leaf:
    sys.exit(2)
val = None if val_raw == "null" else val_raw

DEFAULT_CURRENT = {
    "feature": None,
    "intent": None,
    "plan": None,
    "tasks": None,
    "checklist": None,
    "branch": None,
}

def _bootstrap():
    return {
        "schema_version": "3.0",
        "current": dict(DEFAULT_CURRENT),
    }

# Read existing (or bootstrap).
try:
    with open(path, "r", encoding="utf-8") as f:
        raw = f.read()
except FileNotFoundError:
    raw = ""

try:
    import yaml  # type: ignore
    data = yaml.safe_load(raw) if raw else None
    if not isinstance(data, dict):
        data = _bootstrap()
    data.setdefault("schema_version", "3.0")
    if not isinstance(data.get("current"), dict):
        data["current"] = dict(DEFAULT_CURRENT)
    else:
        for k, v in DEFAULT_CURRENT.items():
            data["current"].setdefault(k, v)
    if not isinstance(data.get(section), dict):
        data[section] = {}
    # Idempotency: no-op when value already matches.
    if data[section].get(leaf) == val:
        sys.exit(0)
    data[section][leaf] = val
    out = yaml.safe_dump(data, sort_keys=False, default_flow_style=False, allow_unicode=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write(out)
    sys.exit(0)
except ImportError:
    pass

# Stdlib-only path: parse the documented two-level shape, mutate, re-emit
# from a templated layout. Keeps user-context.yml's annotations minimal —
# users who want the full annotated header can `fire-phoenix init` it.
parsed = {}
cur = None
for line in raw.splitlines() if raw else []:
    s = line.rstrip()
    if not s or s.lstrip().startswith("#"):
        continue
    if not s.startswith(" ") and s.endswith(":"):
        cur = s[:-1]
        parsed.setdefault(cur, {})
        continue
    if not s.startswith(" ") and ":" in s:
        k, _, v = s.partition(":")
        parsed[k.strip()] = v.strip().strip('"').strip("'")
        cur = None
        continue
    if s.startswith(" ") and ":" in s and cur is not None:
        k, _, v = s.strip().partition(":")
        v = v.strip().strip('"').strip("'")
        parsed[cur][k.strip()] = None if v in ("null", "~", "") else v

if not isinstance(parsed.get("schema_version"), str):
    parsed["schema_version"] = "3.0"
if not isinstance(parsed.get("current"), dict):
    parsed["current"] = dict(DEFAULT_CURRENT)
else:
    for k, v in DEFAULT_CURRENT.items():
        parsed["current"].setdefault(k, v)
if not isinstance(parsed.get(section), dict):
    parsed[section] = {}

if parsed[section].get(leaf) == val:
    sys.exit(0)
parsed[section][leaf] = val

def _emit(v):
    if v is None:
        return "null"
    s = str(v)
    if s in ("null", "~", "") or any(c in s for c in ' :#"\''):
        return '"' + s.replace('\\', '\\\\').replace('"', '\\"') + '"'
    return s

# Emit schema_version first, then blocks in insertion order. Bootstrap
# always emits `current:` even if every value is null — the helper's
# contract is that user-context.yml carries the current block.
lines = [f'schema_version: "{parsed["schema_version"]}"', ""]
emitted = {"schema_version"}
for top in list(parsed.keys()):
    if top in emitted:
        continue
    block = parsed[top]
    if not isinstance(block, dict):
        lines.append(f"{top}: {_emit(block)}")
        emitted.add(top)
        continue
    lines.append(f"{top}:")
    for k, v in block.items():
        lines.append(f"  {k}: {_emit(v)}")
    lines.append("")
    emitted.add(top)

with open(path, "w", encoding="utf-8") as f:
    f.write("\n".join(lines).rstrip() + "\n")
PY
}

# -------------------------------------------------------------------
# Path resolution for work-type directories.
# -------------------------------------------------------------------

# Return (and create) $FIRE_PHOENIX_DOCS_DIR/<work-type>/ under the repo root.
worktype_dir() {
    local name="$1"
    if [ -z "$name" ]; then
        echo "worktype_dir: work-type name required" >&2
        return 1
    fi
    : "${FIRE_PHOENIX_REPO_ROOT:?read_context must be called first}"
    local dir="$FIRE_PHOENIX_REPO_ROOT/$FIRE_PHOENIX_DOCS_DIR/$name"
    mkdir -p "$dir"
    echo "$dir"
}

# Return (and create) $FIRE_PHOENIX_DOCS_DIR/<work-type>/<feature>/. Errors if
# current.feature is null.
feature_scoped_dir() {
    local name="$1"
    if [ -z "$name" ]; then
        echo "feature_scoped_dir: work-type name required" >&2
        return 1
    fi
    if [ -z "$FIRE_PHOENIX_CURRENT_FEATURE" ]; then
        echo "feature_scoped_dir: .fire-phoenix/context.yml 'current.feature' is not set" >&2
        return 1
    fi
    : "${FIRE_PHOENIX_REPO_ROOT:?read_context must be called first}"
    local dir="$FIRE_PHOENIX_REPO_ROOT/$FIRE_PHOENIX_DOCS_DIR/$name/$FIRE_PHOENIX_CURRENT_FEATURE"
    mkdir -p "$dir"
    echo "$dir"
}

# -------------------------------------------------------------------
# Agent-decisions log.
#
# Records assumptions + non-trivial decisions the agent made, so the
# user can audit what happened (especially in auto mode). Debts and
# decisions are separate: a debt is an UNresolved item the user still
# needs to answer; a decision is a resolved choice the AI already
# made on the user's behalf.
#
# File layout: docs/agent-decisions/<agent>/<YYYY-MM-DD>-decisions.md
# Agent name is taken from FIRE_PHOENIX_AGENT (set by the calling agent);
# defaults to "shared" when a skill is invoked standalone.
#
# Decision kinds:
#   - default-applied     — required input missing → default used
#   - alternative-picked  — chose one of >=2 viable options without asking
#   - autonomous-action   — wrote an artefact the user didn't explicitly request
#   - debt-overridden     — proceeded past a flagged debt on user's say-so
#
#   write_decision <kind> <what> [<why>] [<alternatives>]
#
# Emits the generated decision id (e.g. "D-03") on stdout.
# -------------------------------------------------------------------

write_decision() {
    local kind="$1"
    local what="$2"
    local why="${3:-}"
    local alts="${4:-}"
    if [ -z "$kind" ] || [ -z "$what" ]; then
        echo "write_decision: <kind> <what> required" >&2
        return 1
    fi
    case "$kind" in
        default-applied|alternative-picked|autonomous-action|debt-overridden) ;;
        *)
            echo "write_decision: unknown kind '$kind' (must be one of default-applied|alternative-picked|autonomous-action|debt-overridden)" >&2
            return 1
            ;;
    esac

    : "${FIRE_PHOENIX_REPO_ROOT:?read_context must be called first}"
    local agent="${FIRE_PHOENIX_AGENT:-shared}"
    local date_s
    date_s=$(date +%Y-%m-%d)
    local dir="$FIRE_PHOENIX_REPO_ROOT/$FIRE_PHOENIX_DOCS_DIR/agent-decisions/$agent"
    local file="$dir/$date_s-decisions.md"
    mkdir -p "$dir"

    local next=1
    if [ -f "$file" ]; then
        local last
        last=$(grep -Eo '^### D-[0-9]+' "$file" 2>/dev/null | grep -Eo '[0-9]+' | sort -n | tail -n1 || true)
        [ -n "$last" ] && next=$((10#$last + 1))
    else
        {
            printf '# Agent decisions — %s — %s\n\n' "$agent" "$date_s"
            printf '**Mode:** %s\n\n' "${FIRE_PHOENIX_AGENT_MODE:-interactive}"
        } > "$file"
    fi

    local id
    id=$(printf 'D-%02d' "$next")
    local iso_time
    iso_time=$(date -u +%Y-%m-%dT%H:%M:%SZ)
    {
        printf '### %s — %s\n\n' "$id" "$kind"
        printf -- '- **What:** %s\n' "$what"
        [ -n "$why" ]  && printf -- '- **Why:** %s\n' "$why"
        [ -n "$alts" ] && printf -- '- **Alternatives considered:** %s\n' "$alts"
        printf -- '- **Time:** %s\n\n' "$iso_time"
    } >> "$file"
    echo "$id"
}

# -------------------------------------------------------------------
# record_decision — sanctioned L4 governance-authoring path (adr/0053).
#
# Writes an L4 decisions entry as a DRAFT into the pending queue
# ($FIRE_PHOENIX_DECISIONS_PENDING_DIR). It NEVER writes the canonical
# decisions_file — the promote-governance skill is the sole canonical
# writer (single human-confirmed enforcement point). Works identically
# in interactive and auto mode: auto never touches canonical L4.
#
#   record_decision <kind> <title> [<body-file>|-]
#
# <kind> is a free-form tag (e.g. g1-agreement, critical-signoff,
# incident, ccb, reclassification). <body> is read from a file, from
# stdin when "-", or omitted. Idempotent: the draft filename carries a
# content hash, so re-recording identical content is a no-op. Emits the
# pending draft path on stdout and writes a .extract sidecar.
# -------------------------------------------------------------------

# Portable short content hash (sha256 first 12 chars; cksum fallback).
_fire_phoenix_short_hash() {
    if command -v sha256sum >/dev/null 2>&1; then
        sha256sum | cut -c1-12
    elif command -v shasum >/dev/null 2>&1; then
        shasum -a 256 | cut -c1-12
    else
        cksum | tr -d ' ' | cut -c1-12
    fi
}

record_decision() {
    local kind="$1"
    local title="$2"
    local body_src="${3:-}"
    if [ -z "$kind" ] || [ -z "$title" ]; then
        echo "record_decision: <kind> <title> required" >&2
        return 1
    fi

    : "${FIRE_PHOENIX_REPO_ROOT:?read_context must be called first}"
    local dir="$FIRE_PHOENIX_REPO_ROOT/$FIRE_PHOENIX_DECISIONS_PENDING_DIR"
    mkdir -p "$dir"

    # Resolve the body (file | stdin | empty).
    local body=""
    if [ "$body_src" = "-" ]; then
        body="$(cat)"
    elif [ -n "$body_src" ] && [ -f "$body_src" ]; then
        body="$(cat "$body_src")"
    fi

    local date_s
    date_s=$(date +%Y-%m-%d)
    # slug from title: lower-case, non-alnum -> dash, collapse, trim.
    local slug
    slug=$(printf '%s' "$title" \
        | tr '[:upper:]' '[:lower:]' \
        | sed -e 's/[^a-z0-9]\{1,\}/-/g' -e 's/^-//' -e 's/-$//' \
        | cut -c1-50)
    [ -n "$slug" ] || slug="decision"

    # Content hash over kind+title+body for idempotency.
    local hash
    hash=$(printf '%s\0%s\0%s' "$kind" "$title" "$body" | _fire_phoenix_short_hash)
    local out="$dir/$date_s-$slug-$hash.md"

    # Idempotent: identical content already queued -> no-op.
    if [ -f "$out" ]; then
        echo "$out"
        return 0
    fi

    {
        printf '## %s — %s\n\n' "$date_s" "$title"
        printf -- '<!-- kind: %s | pending governance entry (adr/0053); promote via the promote-governance skill -->\n\n' "$kind"
        [ -n "$body" ] && printf '%s\n' "$body"
    } > "$out"

    write_extract "$out" KIND="$kind" TITLE="$title" DATE="$date_s" STATUS=pending >/dev/null
    echo "$out"
}

# -------------------------------------------------------------------
# Debt register.
# -------------------------------------------------------------------

# Append a numbered debt entry. Auto-increments the suffix based on
# the existing entries in the file.
#   append_debt <file> <prefix> <body-line>
append_debt() {
    local file="$1"
    local prefix="$2"
    local body="$3"
    if [ -z "$file" ] || [ -z "$prefix" ] || [ -z "$body" ]; then
        echo "append_debt: <file> <prefix> <body> required" >&2
        return 1
    fi

    mkdir -p "$(dirname "$file")"

    local next=1
    if [ -f "$file" ]; then
        local last
        last=$(grep -Eo "^${prefix}-[0-9]+" "$file" 2>/dev/null | grep -Eo '[0-9]+$' | sort -n | tail -n1)
        if [ -n "$last" ]; then
            next=$((10#$last + 1))
        fi
    else
        printf '# Debt register (%s)\n\n' "$prefix" > "$file"
    fi

    printf '%s-%02d: %s\n' "$prefix" "$next" "$body" >> "$file"
    printf '%s-%02d\n' "$prefix" "$next"
}

# -------------------------------------------------------------------
# .extract companion files.
# -------------------------------------------------------------------

# Write a flat KEY=VALUE ledger next to an output artefact so the next
# skill in the chain does not have to re-parse markdown.
#   write_extract <artefact-path> KEY=VAL [KEY=VAL …]
write_extract() {
    local artefact="$1"
    shift || true
    if [ -z "$artefact" ]; then
        echo "write_extract: artefact path required" >&2
        return 1
    fi
    local extract="${artefact%.*}.extract"
    mkdir -p "$(dirname "$extract")"
    : > "$extract"
    local pair key value
    for pair in "$@"; do
        key="${pair%%=*}"
        value="${pair#*=}"
        printf '%s=%s\n' "$key" "$value" >> "$extract"
    done
    echo "$extract"
}

# -------------------------------------------------------------------
# confirm_before_write
# -------------------------------------------------------------------

# Prompt the user interactively unless preferences.confirm_before_write
# is false OR --auto was passed. Returns 0 to proceed, 1 to abort.
confirm_before_write() {
    local message="${1:-About to write.}"
    if [ "${FIRE_PHOENIX_AUTO:-0}" = "1" ]; then
        return 0
    fi
    if [ "${FIRE_PHOENIX_CONFIRM_BEFORE_WRITE:-true}" != "true" ]; then
        return 0
    fi
    printf '%s  Proceed? [y/N] ' "$message" >&2
    local answer
    IFS= read -r answer || answer=""
    case "$answer" in
        [yY]|[yY][eE][sS]) return 0 ;;
        *) return 1 ;;
    esac
}

# -------------------------------------------------------------------
# --auto / env / answers / .extract resolution chain.
# -------------------------------------------------------------------

# Load KEY=VALUE lines from an answers file into the current env, but
# only if the variable is not already set (env > answers).
fire_phoenix_load_answers() {
    local file="$1"
    [ -f "$file" ] || return 0
    local line key value
    while IFS= read -r line || [ -n "$line" ]; do
        case "$line" in
            "#"*|"") continue ;;
        esac
        key="${line%%=*}"
        value="${line#*=}"
        # strip surrounding quotes
        value="${value%\"}"
        value="${value#\"}"
        # only set if missing
        if [ -z "${!key:-}" ]; then
            export "$key=$value"
        fi
    done < "$file"
}

# Resolve an answer key in the documented priority order:
#   1. the named env var already set in-process
#   2. FIRE_PHOENIX_ANSWERS file (loaded by the action script)
#   3. an upstream .extract file (each path passed via FIRE_PHOENIX_EXTRACTS,
#      colon-separated)
#   4. the caller-supplied default
# Prints the resolved value and returns 0 if resolved, 1 if the
# default was used. Callers running under `set -e` should use
# `val=$(resolve_auto KEY DEFAULT) || true`.
resolve_auto() {
    local key="$1"
    local default="${2:-}"

    # 1. in-process env
    if [ -n "${!key:-}" ]; then
        printf '%s' "${!key}"
        return 0
    fi

    # 2. answers file (if set but not yet loaded — usually loaded once
    # per action, but we guard here for safety)
    if [ -n "${FIRE_PHOENIX_ANSWERS:-}" ] && [ -f "$FIRE_PHOENIX_ANSWERS" ]; then
        local val
        val=$(grep -E "^${key}=" "$FIRE_PHOENIX_ANSWERS" 2>/dev/null | head -n1 | cut -d= -f2- || true)
        if [ -n "$val" ]; then
            printf '%s' "$val"
            return 0
        fi
    fi

    # 3. .extract chain
    if [ -n "${FIRE_PHOENIX_EXTRACTS:-}" ]; then
        local IFS=':'
        local extract
        for extract in $FIRE_PHOENIX_EXTRACTS; do
            [ -f "$extract" ] || continue
            local val
            val=$(grep -E "^${key}=" "$extract" 2>/dev/null | head -n1 | cut -d= -f2- || true)
            if [ -n "$val" ]; then
                printf '%s' "$val"
                return 0
            fi
        done
    fi

    # 4. default — return non-zero so callers can log a debt if the
    # default kicked in.
    printf '%s' "$default"
    return 1
}

# Standard argument parser for action scripts. Consumes --auto,
# --answers FILE, --dry-run, --help; leaves positional args in the
# caller's "$@".
#   Usage at the top of an action script:
#     source "$(dirname "$0")/common.sh"
#     fire_phoenix_parse_standard_args "$@"; set -- "${FIRE_PHOENIX_REST_ARGS[@]}"
FIRE_PHOENIX_REST_ARGS=()
fire_phoenix_parse_standard_args() {
    FIRE_PHOENIX_REST_ARGS=()
    export FIRE_PHOENIX_AUTO="${FIRE_PHOENIX_AUTO:-0}"
    export FIRE_PHOENIX_DRY_RUN="${FIRE_PHOENIX_DRY_RUN:-0}"
    export FIRE_PHOENIX_ANSWERS="${FIRE_PHOENIX_ANSWERS:-}"
    while [ $# -gt 0 ]; do
        case "$1" in
            --auto)    FIRE_PHOENIX_AUTO=1 ;;
            --dry-run) FIRE_PHOENIX_DRY_RUN=1 ;;
            --answers)
                if [ $# -lt 2 ]; then
                    echo "--answers requires a file path" >&2
                    return 1
                fi
                FIRE_PHOENIX_ANSWERS="$2"
                shift
                ;;
            --help|-h)
                FIRE_PHOENIX_REST_ARGS+=("--help")
                ;;
            *)
                FIRE_PHOENIX_REST_ARGS+=("$1")
                ;;
        esac
        shift
    done
    if [ -n "$FIRE_PHOENIX_ANSWERS" ]; then
        fire_phoenix_load_answers "$FIRE_PHOENIX_ANSWERS"
    fi
    export FIRE_PHOENIX_AUTO FIRE_PHOENIX_DRY_RUN FIRE_PHOENIX_ANSWERS
}

# =============================================================================
# === General utility helpers                                               ===
# === Available to every skill bundle's action scripts via `source common.sh`.
# === Per adr/0024: the SDD-era feature-branch helpers that previously sat   ===
# === here (get_current_branch / check_feature_branch / get_feature_paths / ===
# === find_feature_dir_by_prefix / spec_kit_effective_branch_name) were     ===
# === removed once the β-track skill re-architecture (adr/0023 Option E)    ===
# === closed. Action scripts read .fire-phoenix/context.yml cursors via     ===
# === read_context instead.                                                 ===
# =============================================================================

# Check if we have git available at the fire-phoenix root level.
has_git() {
    command -v git >/dev/null 2>&1 || return 1
    local repo_root=$(get_repo_root)
    [ -e "$repo_root/.git" ] || return 1
    git -C "$repo_root" rev-parse --is-inside-work-tree >/dev/null 2>&1
}

# Check if jq is available for safe JSON construction.
has_jq() {
    command -v jq >/dev/null 2>&1
}

# Escape a string for safe embedding in a JSON value (fallback when jq is unavailable).
json_escape() {
    local s="$1"
    s="${s//\\/\\\\}"
    s="${s//\"/\\\"}"
    s="${s//$'\n'/\\n}"
    s="${s//$'\t'/\\t}"
    s="${s//$'\r'/\\r}"
    s="${s//$'\b'/\\b}"
    s="${s//$'\f'/\\f}"
    local LC_ALL=C
    local i char code
    for (( i=0; i<${#s}; i++ )); do
        char="${s:$i:1}"
        printf -v code '%d' "'$char" 2>/dev/null || code=256
        if (( code >= 1 && code <= 31 )); then
            printf '\\u%04x' "$code"
        else
            printf '%s' "$char"
        fi
    done
}

check_file() { [[ -f "$1" ]] && echo "  ✓ $2" || echo "  ✗ $2"; }
check_dir() { [[ -d "$1" && -n $(ls -A "$1" 2>/dev/null) ]] && echo "  ✓ $2" || echo "  ✗ $2"; }

# Resolve a template name to a file path using the priority stack:
#   1. .fire-phoenix/templates/overrides/
#   2. .fire-phoenix/presets/<preset-id>/templates/ (sorted by priority from .registry)
#   3. .fire-phoenix/extensions/<ext-id>/templates/
#   4. .fire-phoenix/templates/ (core)
#   5. Skill's own bundled templates (self-contained fallback)
resolve_template() {
    local template_name="$1"
    local repo_root="$2"
    local base="$repo_root/.fire-phoenix/templates"

    # Priority 1: Project overrides
    local override="$base/overrides/${template_name}.md"
    [ -f "$override" ] && echo "$override" && return 0

    # Priority 2: Installed presets (sorted by priority from .registry)
    local presets_dir="$repo_root/.fire-phoenix/presets"
    if [ -d "$presets_dir" ]; then
        local registry_file="$presets_dir/.registry"
        if [ -f "$registry_file" ] && command -v python3 >/dev/null 2>&1; then
            local sorted_presets=""
            if sorted_presets=$(FIRE_PHOENIX_REGISTRY="$registry_file" python3 -c "
import json, sys, os
try:
    with open(os.environ['FIRE_PHOENIX_REGISTRY']) as f:
        data = json.load(f)
    presets = data.get('presets', {})
    for pid, meta in sorted(presets.items(), key=lambda x: x[1].get('priority', 10)):
        print(pid)
except Exception:
    sys.exit(1)
" 2>/dev/null); then
                if [ -n "$sorted_presets" ]; then
                    while IFS= read -r preset_id; do
                        local candidate="$presets_dir/$preset_id/templates/${template_name}.md"
                        [ -f "$candidate" ] && echo "$candidate" && return 0
                    done <<< "$sorted_presets"
                fi
            else
                for preset in "$presets_dir"/*/; do
                    [ -d "$preset" ] || continue
                    local candidate="$preset/templates/${template_name}.md"
                    [ -f "$candidate" ] && echo "$candidate" && return 0
                done
            fi
        else
            for preset in "$presets_dir"/*/; do
                [ -d "$preset" ] || continue
                local candidate="$preset/templates/${template_name}.md"
                [ -f "$candidate" ] && echo "$candidate" && return 0
            done
        fi
    fi

    # Priority 3: Extension-provided templates
    local ext_dir="$repo_root/.fire-phoenix/extensions"
    if [ -d "$ext_dir" ]; then
        for ext in "$ext_dir"/*/; do
            [ -d "$ext" ] || continue
            case "$(basename "$ext")" in .*) continue;; esac
            local candidate="$ext/templates/${template_name}.md"
            [ -f "$candidate" ] && echo "$candidate" && return 0
        done
    fi

    # Priority 4: Core templates
    local core="$base/${template_name}.md"
    [ -f "$core" ] && echo "$core" && return 0

    # Priority 5: Skill's own bundled templates (self-contained fallback)
    if [ -n "${SCRIPT_DIR:-}" ]; then
        local skill_tpl="$SCRIPT_DIR/../../templates/${template_name}.md"
        [ -f "$skill_tpl" ] && echo "$skill_tpl" && return 0
    fi

    # Template not found in any location.
    # Callers running under set -e should use: TEMPLATE=$(resolve_template ...) || true
    return 1
}
