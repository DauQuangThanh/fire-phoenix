# Given/When/Then — style guide

GWT acceptance criteria are a contract between the product-owner
and the test-architect. Write each criterion so the tester can
translate it into an automated test without ambiguity.

## Anatomy

- **Given** — the context / preconditions the system must be in.
  State the data, the role, the configuration. *Not* the action.
- **When** — the single trigger event. One verb. If you find
  yourself writing two actions with "and", split into two criteria.
- **Then** — the observable outcome. Measurable, verifiable without
  asking someone a question.

## Good examples

> **Given** an authenticated user with a standard plan
> **When** they upload a file ≤ 10 MB via the /api/upload endpoint
> **Then** the response is 201 with a valid object URL and the file
> appears in their library within 2 seconds.
>
> **Given** an unauthenticated request
> **When** it targets any endpoint under /api/private
> **Then** the response is 401 and no session cookie is set.

## Plain language

GWT is the plain-language layer of acceptance: a non-technical
reader must be able to author and confirm every criterion.

- **Write for a non-technical reader.** If the criterion needs a
  developer to interpret it, rewrite it.
- **One observable outcome per AC.** A criterion verifies exactly
  one thing a user (or observer) can see happen. Two outcomes →
  two ACs.
- **No implementation jargon.** No endpoint names, class names,
  status codes, or database terms in the Given/When/Then text —
  describe what the user does and sees. (Technical precision lives
  in the EARS decomposition below.)

## Common mistakes

- **"Then" says how, not what.** "Then it calls service X" → wrong.
  Rewrite: "Then …the user sees / the response contains / …".
- **Pronouns without antecedent.** "When they click it" — click
  what? Be explicit.
- **Business phrases.** "Then performance is acceptable" → rewrite
  with a measurable threshold ("within 200 ms p95").
- **Multiple Whens.** Split into two criteria.

## Decomposing to EARS spec criteria

GWT is the plain-language layer; EARS ("WHEN [condition], THE
[system] SHALL [response]") is the technical layer. Each GWT AC
maps to **≥1 EARS criterion** — or, where automated phrasing is
not feasible, to a **named manual review** (who reviews, what they
check). No GWT AC is left without one or the other.

Worked example — one GWT AC decomposed into two EARS criteria:

> **AC-003** — **Given** a signed-in user with a full library
> **When** they try to add one more file
> **Then** they see a message telling them the library is full and
> the file is not added.

decomposes into:

- WHEN a signed-in user whose library is at capacity submits an
  upload, THE system SHALL reject the upload with a
  "library full" error and SHALL NOT persist the file.
- WHEN an upload is rejected for a full library, THE system SHALL
  leave the user's stored-file count and quota usage unchanged.

## AI-authoring note

Draft criteria from the spec, but always leave them as proposals
the user can edit. A criterion is "accepted" only when the user or
the product-owner explicitly confirms it.
