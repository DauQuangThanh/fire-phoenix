# BUG-{number}: {title}

**Reported:** {date}
**Severity:** {severity}
**Priority:** {priority}
**Status:** Open

## Traceability

- **Failed TC:** {failed_tc}
- **User story:** {user_story}
- **Affected version / env:** {affected_version}
- **Suspected AC violated:** <AC-NNN from the feature's acceptance
  list, or "none — candidate for a new failure-path AC"> (optional)

## Reproduction

**Deterministic:** <yes — same steps, same failure every run /
intermittent (~1 in N runs) / not yet reproduced>

{steps}

<!-- Steps must be deterministic before a fix starts: exact
     inputs, exact order, starting state. If intermittent, note
     what varies (timing, ordering, shared state, seed). -->

## Expected behaviour

{expected}

## Actual behaviour

{actual}

## Environment

- OS / platform:
- Runtime / browser / client version:
- Config flags / feature toggles:
- Data state (fixtures, migrations, account type):

## Notes

- Logs / stack traces / screenshots (links or pastes) go here.

## Fix history

<!-- bug-fixer + change-register append here once a fix ships. -->
