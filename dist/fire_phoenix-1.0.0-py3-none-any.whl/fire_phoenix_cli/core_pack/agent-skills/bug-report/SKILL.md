---
name: bug-report
description: Authors a structured bug report — repro, expected vs actual, severity,
  affected version, traceability to the failed test or story. Use when filing a bug
  or documenting a defect found in testing.
license: MIT
compatibility: Designed for agentskills.io-compatible agents.
metadata:
  author: Dau Quang Thanh
  version: '1.0'
  requires: []
---

## User Input

```text
$ARGUMENTS
```

## Audience and tone (interactive mode)

**Register first — adapt to role level.** Run as a guided, one-question-at-a-time questionnaire (yes/no first, recommend a default); skip in `FIRE_PHOENIX_AGENT_MODE=auto`. Full rules: `.fire-phoenix/references/subagents/interactive-questionnaire.md`.

## Inputs

- `.fire-phoenix/context.yml`
- `{context.paths.docs}/testing/<feature>/execution.md` (to
  link a failed run)
- `{context.paths.intents}/<feature>/intent.md` (user-story traceability)

## Outputs

- `{context.paths.docs}/bugs/BUG-NNN-<slug>.md` (auto-numbered)

## Context Update

Does not mutate `.fire-phoenix/context.yml`.

## Handoffs

- `bug-triage` consumes bug files to produce a triage list.
- `change-log` links the fix commit.
- `regression-tests` generates a regression test per fixed bug.

## AI authoring scope

**Does:** scaffold a bug report with the required fields, propose
a severity + priority from the symptom description, link to
upstream artefacts, note whether the reproduction is
deterministic, and propose the suspected AC-NNN the bug violates
(or flag it as a candidate for a new failure-path criterion).

**Does not:** decide severity / priority the user hasn't confirmed,
assign the bug, or close it.

## Usage

> `<SKILL_DIR>` = the integration's skills root (e.g. `.claude/skills/`
> for Claude Code, `.codex/skills/` for Codex,
> `.cursor/skills/` for Cursor).
> Scripts live at `<SKILL_DIR>/<skill-name>/scripts/…`.

```bash
BUG_TITLE="Login 500 on empty password" \
BUG_STEPS="1. open /login\n2. submit with empty password field" \
BUG_EXPECTED="400 validation error" \
BUG_ACTUAL="500 + stack trace" \
BUG_SEVERITY="high" BUG_PRIORITY="high" \
BUG_FAILED_TC="TC-04" BUG_AFFECTED_VERSION="1.3.2" \
  bash <SKILL_DIR>/bug-report/scripts/bash/add-bug.sh --auto
```

### Answer keys

| Key | Meaning | Default |
|---|---|---|
| `BUG_TITLE` | one-line summary | *(required)* |
| `BUG_STEPS` | reproduction steps (newline-separated) | *(required)* |
| `BUG_EXPECTED` | what should happen | *(required)* |
| `BUG_ACTUAL` | what actually happens | *(required)* |
| `BUG_SEVERITY` | critical / high / medium / low | `medium` |
| `BUG_PRIORITY` | critical / high / medium / low | `medium` |
| `BUG_AFFECTED_VERSION` | version / commit / env | empty |
| `BUG_FAILED_TC` | TC id from execution ledger | empty |
| `BUG_USER_STORY` | US id from spec | empty |
