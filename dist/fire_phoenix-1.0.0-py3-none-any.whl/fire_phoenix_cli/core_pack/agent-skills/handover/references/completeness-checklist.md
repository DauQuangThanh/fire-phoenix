# Hand-over completeness — checklist

The test of a hand-over package is **contact-free operation**:
the receiving team can run, diagnose, and escalate using the
artefacts alone, without phoning the outgoing team. Walk this
checklist before the package is presented for sign-off; unmet
items become `HOVRDEBT-` entries, not silent gaps.

## Runbooks

- [ ] Every operational scenario named in the deployment and
      observability plans has a runbook, **named** in
      `runbook-index.md` with owner, location, and last-tested
      date. "Ask the dev team" is not a runbook.
- [ ] Every alert in the observability plan maps to a runbook in
      the index; alerts without one are findings.
- [ ] The rollback procedure is indexed like any other runbook.

## Access

- [ ] Access list enumerated: every system the receiving team
      needs (consoles, dashboards, log stores, secret stores,
      repos), the role/permission level required, and **who
      grants it**.
- [ ] No access item depends on a named individual's personal
      account.
- [ ] Break-glass / emergency access path documented.

## Open debts

- [ ] All open `HOVRDEBT-` items (and inherited `OPSDEBT-` /
      residual risks) listed in the package — nothing carried
      into BAU undocumented.
- [ ] Each open item names an owner and a review date.
- [ ] Known limitations section is honest: what the system does
      not do, and what was deferred.

## Contact-free framing

- [ ] Every "who to ask" in the package resolves to an artefact
      or an escalation-matrix tier, not to an individual's
      memory.
- [ ] A newcomer test is plausible: someone who joined the
      receiving team today could locate the runbook for the most
      recent alert using the package alone.
- [ ] Training checklist items each point at a written or
      recorded artefact.

## Sign-off readiness

- [ ] Escalation matrix rows are complete (trigger, team,
      response SLA, next tier) — SLA values confirmed by the
      user, not invented.
- [ ] Warranty / hypercare start and end dates stated.
- [ ] Sign-off table lists the named human approvers; the AI
      never signs.
