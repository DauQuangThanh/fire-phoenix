<#
.SYNOPSIS
  project-map — regenerate the annotated folder tree and write it into the
  preserved TREE sub-block of every root agent context file (CLAUDE.md /
  AGENTS.md and any sibling carrying the Fire Phoenix envelope).
  PowerShell sibling of update-project-map.sh.

.PARAMETER Auto      Non-interactive: write the generated tree with no pause.
.PARAMETER Depth     Tree depth (default 2).
.PARAMETER TreeFile  Use this file verbatim as the tree block (the agent's
                     annotated tree) instead of the generated one.

  Skill-specific helpers live here; the shared common.ps1 is a
  byte-identical canonical library and must not carry action-specific logic.
#>
[CmdletBinding()]
param(
    [switch]$Auto,
    [int]$Depth = 2,
    [string]$TreeFile = ''
)

$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'common.ps1')

$TreeStart     = '<!-- PROJECT FOLDER TREE START -->'
$TreeEnd       = '<!-- PROJECT FOLDER TREE END -->'
$EnvelopeStart = '<!-- Fire Phoenix START -->'
$PruneDirs = @(
    '.git', 'node_modules', '.venv', '.venv-t', '__pycache__', '.mypy_cache',
    '.ruff_cache', '.pytest_cache', 'dist', 'build', 'site', '.tmp-test',
    '.idea', '.vscode'
)

function Test-Pruned {
    param([string]$Name)
    if ($PruneDirs -contains $Name) { return $true }
    if ($Name.StartsWith('.')) { return $true }
    return $false
}

# OBSERVED-only indented directory tree; annotations are the agent's job.
function Get-ProjectTree {
    param([string]$Root, [int]$Depth = 2)
    $acc = New-Object System.Collections.Generic.List[string]
    $acc.Add('```')
    $acc.Add((Split-Path $Root -Leaf) + '/')
    function Walk([string]$Dir, [string]$Indent, [int]$Lvl, $Sink, [int]$Max) {
        if ($Lvl -ge $Max) { return }
        Get-ChildItem -LiteralPath $Dir -Directory -Force -ErrorAction SilentlyContinue |
            Sort-Object Name | ForEach-Object {
                if (Test-Pruned $_.Name) { return }
                $Sink.Add("$Indent$($_.Name)/")
                Walk $_.FullName "$Indent  " ($Lvl + 1) $Sink $Max
            }
    }
    Walk $Root '  ' 0 $acc $Depth
    $acc.Add('```')
    return ($acc -join "`n")
}

function Get-ContextFiles {
    param([string]$Root)
    $named = @('CLAUDE.md', 'AGENTS.md') | ForEach-Object { Join-Path $Root $_ }
    $globbed = Get-ChildItem -LiteralPath $Root -Filter '*.md' -File -ErrorAction SilentlyContinue |
        ForEach-Object { $_.FullName }
    @($named + $globbed) | Sort-Object -Unique | Where-Object {
        (Test-Path -LiteralPath $_ -PathType Leaf) -and
        ((Get-Content -LiteralPath $_ -Raw -ErrorAction SilentlyContinue) -like "*$EnvelopeStart*")
    }
}

# Replace the TREE-marker inner of $File with $TreeContent. $true on write,
# $false when a marker is absent (no change).
function Set-TreeBlock {
    param([string]$File, [string]$TreeContent)
    $raw = Get-Content -LiteralPath $File -Raw -ErrorAction SilentlyContinue
    if ($null -eq $raw) { return $false }
    if ($raw -notlike "*$TreeStart*" -or $raw -notlike "*$TreeEnd*") { return $false }
    $s = $raw.IndexOf($TreeStart)
    $e = $raw.IndexOf($TreeEnd, $s + $TreeStart.Length)
    if ($s -lt 0 -or $e -lt 0) { return $false }
    $new = $raw.Substring(0, $s + $TreeStart.Length) + "`n" + $TreeContent + "`n" + $raw.Substring($e)
    Set-Content -LiteralPath $File -Value $new -NoNewline -Encoding utf8
    return $true
}

$root = Find-FirePhoenixRoot
if (-not $root) { Write-Error 'not inside a fire-phoenix project (.fire-phoenix/ not found)'; exit 1 }

if ($TreeFile) { $tree = Get-Content -LiteralPath $TreeFile -Raw }
else           { $tree = Get-ProjectTree -Root $root -Depth $Depth }

Write-Host "== generated project map (depth $Depth) =="
Write-Host $tree
if (-not $TreeFile -and -not $Auto) {
    Write-Warning 'NEXT: annotate each major folder with a one-line OBSERVED note, then re-run:'
    Write-Warning '  update-project-map.ps1 -TreeFile <annotated> [-Auto]'
    exit 0
}

$targets = @(Get-ContextFiles -Root $root)
$wrote = 0; $missing = 0
foreach ($f in $targets) {
    if (Set-TreeBlock -File $f -TreeContent $tree) {
        Write-Host ("updated: " + $f.Substring($root.Length).TrimStart('\', '/')); $wrote++
    } else {
        Write-Warning ("SKIP (no TREE markers — needs 'fire-phoenix upgrade'): " + $f.Substring($root.Length).TrimStart('\', '/')); $missing++
    }
}
if ($wrote -eq 0 -and $missing -eq 0) {
    Write-Error "no root context file with a Fire Phoenix envelope found — run 'fire-phoenix upgrade' first"
    exit 3
}
Write-Host "project-map: updated $wrote file(s), skipped $missing."
