---
name: project-map
description: Regenerates an annotated major-folder tree into the preserved TREE sub-block
  of every root context file (CLAUDE.md, AGENTS.md), surviving fire-phoenix upgrade.
  Use after adding/moving/removing a major folder.
license: MIT
compatibility: Designed for agentskills.io-compatible agents.
metadata:
  author: Dau Quang Thanh
  version: '1.0'
  requires: []
---

Pattern intent: this skill keeps a durable, cross-session map of the project
layout in the one place every AI provider reads first — the root context file —
accepting that the map is capability-level (major folders, not every file) so it
stays small and low-churn.

## User Input

```text
$ARGUMENTS
```

Consider the user input before proceeding (if not empty). A depth number
(e.g. `3`) sets tree depth; a path scopes the root; otherwise use defaults.

## Audience and tone (interactive mode)

**Register first — adapt to role level.** Run as a guided, one-question-at-a-time questionnaire (yes/no first, recommend a default); skip in `FIRE_PHOENIX_AGENT_MODE=auto`. Full rules: `references/interactive-questionnaire.md`.

## How the tree persists (the load-bearing contract)

The tree lives between the `PROJECT FOLDER TREE START` / `PROJECT FOLDER TREE END`
HTML-comment markers **inside** the managed prose section
`## Keep the project structure map current`. The installer preserves everything
between those markers verbatim across `fire-phoenix upgrade`, even though the
surrounding prose is regenerated. This
skill therefore writes **only** between the markers — never outside them (that
region is regenerated and would drop the map on the next upgrade).

## Inputs

- `.fire-phoenix/context.yml` — project root, preferences.
- The project's directory structure on disk (OBSERVED).
- Every root context file carrying the `Fire Phoenix START` envelope
  (auto-discovered — no hardcoded provider list).

## Outputs

- The `PROJECT FOLDER TREE` sub-block of every discovered root context file
  (`CLAUDE.md`, `AGENTS.md`, and any sibling), updated in place.
- No new files; no `.fire-phoenix/context.yml` mutation.

## Context Update

Does not mutate `.fire-phoenix/context.yml`.

## Confidence discipline (no fabrication)

- The **structure** is OBSERVED — the script prints only directories that exist
  on disk. Do not add folders that are not there.
- The **annotations** (one line per major folder: what it holds) must be
  OBSERVED too — derive each from the folder's actual contents or an existing
  README, never from the folder name alone. If a folder's purpose is not
  evidenced, mark it `— (purpose unconfirmed)` rather than guessing.

## Handoffs

- **`technical-analyst` subagent** — invokes this skill as the final step of the
  mid-stream brownfield baseline so downstream agents open on an accurate map.
- **`codebase-scan` skill** — its inventory (directories, entry points) is the
  natural evidence source for the annotations.
- **Every future session, any provider** — reads the persisted tree from its
  root context file; this is the cross-session handoff surface.

## AI authoring scope

**Does:** generate the OBSERVED directory tree; add OBSERVED annotations; write
the tree between the TREE markers in every enveloped root context file;
idempotently no-op when unchanged.

**Does not:** write outside the TREE markers; touch non-context files; invent
folders or purposes; run `fire-phoenix upgrade`; edit `.fire-phoenix/`.

## Outline

1. **Locate the project root** (`.fire-phoenix/` parent).
2. **Generate the tree** — run the action script with no `--tree-file` to print
   the mechanical depth-2 directory tree.
3. **Annotate** — append a one-line OBSERVED note to each major folder (source
   evidence: `codebase-scan`, README, folder contents). Mark unconfirmed
   purposes explicitly.
4. **Confirm** (interactive) — show the annotated tree; proceed on confirmation.
5. **Write** — re-run the script with `--tree-file <annotated>` (`--auto` to
   skip the pause). It replaces the TREE sub-block in every enveloped root
   context file and reports which were updated / skipped.
6. **Handle skips** — a "no TREE markers" skip means that context file predates
   the 3rd amendment; recommend `fire-phoenix upgrade`, then re-run.

## Usage

> `<SKILL_DIR>` = the integration's skills root.

```bash
# 1. generate (prints tree, pauses for annotation)
bash <SKILL_DIR>/project-map/scripts/bash/update-project-map.sh --depth 2
# 2. write the annotated tree into every root context file
bash <SKILL_DIR>/project-map/scripts/bash/update-project-map.sh \
  --tree-file annotated-tree.md --auto
```

```powershell
pwsh <SKILL_DIR>/project-map/scripts/powershell/update-project-map.ps1 -Depth 2
pwsh <SKILL_DIR>/project-map/scripts/powershell/update-project-map.ps1 `
  -TreeFile annotated-tree.md -Auto
```

### Answer keys

| Key | Meaning | Default |
|---|---|---|
| `--depth` / `-Depth` | Tree depth | `2` |
| `--tree-file` / `-TreeFile` | Annotated tree to write verbatim | *(generate)* |
| `--auto` / `-Auto` | Write without the annotation pause | interactive |
