# Interactive questionnaire — project-map

Skill-specific audience/questionnaire rules. The `project-map` SKILL.md body points
here; read this file when it sends you here.

**Register first — adapt to role level.** Resolve the reader's level from the
merged `.fire-phoenix/context.yml` + `.fire-phoenix/user-context.yml`
(`user-context.yml` wins): `preferences.tech_role_level` for technical work.
An explicit in-session signal overrides. The plain-English floor applies only
when the level is unset; never treat role level as a gate. Full rule:
`.fire-phoenix/references/subagents/register-resolution.md`.

When `FIRE_PHOENIX_AGENT_MODE=auto`, skip the pause, write the generated tree,
and log decisions. Otherwise show the generated tree, add annotations, and
confirm before writing.
