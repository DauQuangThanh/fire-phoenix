# Graduated approval for the `critical` lane

Detail for the `critical` lane's sign-off (see `SKILL.md` §Lane →
gate activation). Non-critical lanes pass on the single-approver
floor.

The change cannot be signed off without recorded dev/tester/PO
confirmations. Record them via `record_decision` (kind
`critical-signoff`, a pending draft) and promote with the
`promote-governance` skill — the promoted entry lands under a
decisions-file heading naming the change and reading `Critical
sign-off`, e.g.:

```
## <date> — <id> Critical sign-off
- Dev (feasibility): <name> — confirmed
- Tester (testability): <name> — confirmed
- PO (business fit): <name> — confirmed
```

`fire-phoenix check approval --change <id>` enforces this.
