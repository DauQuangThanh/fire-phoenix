# spec-delta.md format (folded on `archive`)

`change new` scaffolds `spec-delta.md`; fill it as the change
proceeds. Three sections — the fold (`fire-phoenix change archive`)
applies them to `baseline/`:

```
# Spec delta — <id>

## Added
- <cap-id>: <one-line capability statement>

## Modified
- <cap-id>: <new statement>

## Removed
- <cap-id>
```

Each `<cap-id>` becomes one `baseline/<cap-id>.md` file. A fold
conflict (add-exists / modify-absent / remove-absent) is applied
last-fold-wins and flagged under `baseline/.conflicts/` for the
approver — never resolved silently.
