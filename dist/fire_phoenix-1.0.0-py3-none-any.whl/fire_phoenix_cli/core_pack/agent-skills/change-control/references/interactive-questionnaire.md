# Interactive questionnaire — change-control

Skill-specific audience/questionnaire rules. The `change-control` SKILL.md body points
here; read this file when it sends you here.

**Register first — adapt to role level.** Before applying the beginner floor
below, resolve the reader's level from the merged `.fire-phoenix/context.yml`
+ `.fire-phoenix/user-context.yml` (`user-context.yml` wins): use
`preferences.tech_role_level` for technical work (`junior` → hand-hold, one
path; `mid` → ≥2 options with one-line trade-offs; `senior` → defer on
judgment, surface edge cases, be brief; `staff` → be terse, challenge
premises, skip obvious caveats) and `preferences.non_tech_role_level` for
stakeholder work (`non-technical` → outcomes not jargon; `familiar` → simple
jargon glossed; `fluent` → concepts without explanation; `technical` → full
vocabulary). An explicit in-session signal (e.g. "be terse", "skip the
explanation") overrides everything. The plain-English, one-question-at-a-time
floor below applies **only when the relevant level is unset**; never treat
role level as a gate. Full rule: `.fire-phoenix/references/subagents/register-resolution.md`.

When `FIRE_PHOENIX_AGENT_MODE=interactive` (the default), assume the user
has **no technical or project-management background**. Run this
skill as a guided questionnaire:

- **One question at a time.** No walls of questions.
- **Yes / no first.** Phrase so `yes`, `no`, `not sure`, or `skip`
  is a valid answer.
- **No jargon.** Translate to everyday words: "What's the change
  in plain words?" not "describe the CR"; "Who asked for it?" not
  "requestor"; "Will this make the work bigger, take longer, cost
  more, or change quality?" *(yes / no per category)* instead of
  "scope / schedule / budget / quality impact"; avoid "CCB" — say
  "Who can approve this?".
- **Choices, not blank fields.** When yes/no isn't enough, offer
  2-4 lettered options (A/B/C/D) with one-line everyday
  descriptions. Always include "Not sure — pick a sensible default".
- **Always recommend.** State the option you would pick and why in
  one sentence so the user can reply "yes" / "ok" to accept. NEVER
  recommend "approved" or "rejected" — only the user can decide
  that.
- **`not sure` / `skip` triggers a sensible default** in the
  change-log entry (status defaults to "Pending"), marked
  "(default applied — confirm later)" in `change-log.md`, and a
  `PMDEBT-` entry in `pm-debts.md`.

When `FIRE_PHOENIX_AGENT_MODE=auto` (or `--auto`), skip the questionnaire
entirely: capture the change as `Pending` and log decisions to the
project-manager agent's decision log. Never auto-approve.
