# Change-class decision guide

Every change request maps to one of the four change classes the
project already uses for task contracts (handbook ch. 06 §3). The
class — assigned by **blast radius**, never chosen to dodge
ceremony — decides what evidence the CR needs before a decision,
and what happens to the plan after approval.

## Evidence each class requires

| Class | Typical CR | Evidence required before decision |
|---|---|---|
| **Mechanical** | copy fix, config value, doc correction | The one-line description itself; impact row all-L |
| **Routine** | small feature per an established pattern | Impact assessment (H/M/L × 4) + the intent artefact section it touches |
| **Consequential** | new module, schema change, new integration | Full impact assessment + affected epic-spec / contract list + risk-register cross-check |
| **Critical** | payment / auth / data-deletion paths, L1 invariants | All of the above + the named L1 invariant or ADR it touches + an explicit risk entry |

A CR whose class is uncertain is assessed at the **higher** class.
If the evidence for the class is missing, the CR stays `Pending`
and a `PMDEBT-` names the gap — never downgrade the class to make
the evidence fit.

## Who approves

The project's approver model governs — today that is a **single
named human approver** for every class (see the project's ADR on
approval, e.g. a single-approver decision record). The class does
not change *who* approves; it changes *how much evidence* the
approver sees. The AI records the decision the user reports; it
never approves, and never marks a CR `Approved` without approver
name + date.

## Absorb vs. re-plan

After approval, decide the disposition and record it in the CR:

- **Absorb into the current baseline** when the impact row is
  M-or-below on scope and schedule: the change lands as one or
  more task contracts inside the existing plan; milestones stand.
- **Force a re-plan** when scope or schedule impact is **H**, a
  milestone moves past its target date, or the change alters the
  Definition of Done: re-run `project-planning`, then re-baseline
  (see the `baseline` skill's re-baseline triggers) so later CRs
  measure against the new "from" state.

An approved CR with no recorded disposition is a 🟡 Important
debt — the plan and the ledger have silently diverged.
