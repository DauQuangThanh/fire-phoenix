# Change Register (applied bug-fixes)

**Started:** {date}

## Rows

| Bug | Date | Commit | PR | Files | Regression test | Reviewer | Root cause | Red→green evidence |
|---|---|---|---|---|---|---|---|---|
| BUG-NN | YYYY-MM-DD | `abc1234` | #512 | `src/x.ts; src/y.ts` | `tests/regression/bug-NN.test.ts` | <reviewer> | expected 400, got 500, because empty password skips validation | fail: `AssertionError …` / pass: `1 passed` |

<!-- Append rows only; never rewrite history.
     Root cause: one line, "expected X, got Y, because Z" form.
     Red→green evidence: the regression test's failing run output
     from before the fix + passing run output from after (short
     excerpts or a link to the captured runs). The record-fix
     script appends the base columns; complete the last two cells
     in the same edit. -->
