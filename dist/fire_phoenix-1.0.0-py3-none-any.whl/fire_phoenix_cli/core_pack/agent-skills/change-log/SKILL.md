---
name: change-log
description: Maintains the change register — one row per applied bug-fix with bug
  id, commit/PR, files touched, regression test, root cause. Use when recording a
  shipped fix or tracking which commits fixed which bugs.
license: MIT
compatibility: Designed for agentskills.io-compatible agents.
metadata:
  author: Dau Quang Thanh
  version: '1.0'
  requires: []
---

## User Input

```text
$ARGUMENTS
```

## Audience and tone (interactive mode)

**Register first — adapt to role level.** Run as a guided, one-question-at-a-time questionnaire (yes/no first, recommend a default); skip in `FIRE_PHOENIX_AGENT_MODE=auto`. Full rules: `.fire-phoenix/references/subagents/interactive-questionnaire.md`.

## Inputs

- `.fire-phoenix/context.yml`
- `{context.paths.docs}/bugs/BUG-*.md`
- `{context.paths.docs}/testing/regression-index.md`

## Outputs

- `{context.paths.docs}/bugs/change-register.md`
- `{context.paths.docs}/bugs/change-register.extract`

## Context Update

Does not mutate `.fire-phoenix/context.yml`.

## Handoffs

- `regression-tests` cross-references each closed bug.
- `status-report` pulls counts for the status summary.
- `deployment-strategy` reviews the register when assembling release
  notes.

## AI authoring scope

**Does:** append one row per applied fix with bug id, commit,
files, regression-test id, reviewer, one-line root cause, and
red→green evidence (see `references/fix-register-hygiene.md`; the
script appends the base columns — complete the root-cause and
evidence cells in the same edit); update the source bug file's
status to "Closed" once the user confirms.

**Does not:** write code, push commits, close bugs without the
user's explicit confirmation of commit + reviewer.

## Usage

> `<SKILL_DIR>` = the integration's skills root (e.g. `.claude/skills/`
> for Claude Code, `.codex/skills/` for Codex,
> `.cursor/skills/` for Cursor).
> Scripts live at `<SKILL_DIR>/<skill-name>/scripts/…`.

```bash
CR_BUG_ID=BUG-014 CR_COMMIT=abc123 CR_PR=#512 \
CR_FILES="src/email.ts;tests/regression/bug-014.test.ts" \
CR_REGRESSION_TEST="tests/regression/bug-014.test.ts" \
CR_REVIEWER="tech-lead" \
  bash <SKILL_DIR>/change-log/scripts/bash/record-fix.sh --auto
```

### Answer keys

| Key | Meaning | Default |
|---|---|---|
| `CR_BUG_ID` | bug fixed | *(required)* |
| `CR_COMMIT` | commit SHA (short or long) | *(required)* |
| `CR_PR` | PR reference (#512) | empty |
| `CR_FILES` | `;`-separated files touched | empty |
| `CR_REGRESSION_TEST` | path to new regression test | empty (→ debt) |
| `CR_REVIEWER` | who reviewed / approved | *(required)* |
