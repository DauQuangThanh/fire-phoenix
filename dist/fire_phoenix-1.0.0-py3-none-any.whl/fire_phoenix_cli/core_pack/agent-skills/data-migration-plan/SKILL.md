---
name: data-migration-plan
description: Drafts the data migration plan — strategy (Big Bang/Phased/Parallel/Trickle),
  field mapping, data-quality rules, ETL outline, cutover, rollback, reconciliation.
  Use for legacy-data migration.
license: MIT
compatibility: Designed for agentskills.io-compatible agents.
metadata:
  author: Dau Quang Thanh
  version: '1.0'
  requires: []
---

## User Input

```text
$ARGUMENTS
```

Consider the user input before proceeding (if not empty).

## Audience and tone (interactive mode)

**Register first — adapt to role level.** Run as a guided, one-question-at-a-time questionnaire (yes/no first, recommend a default); skip in `FIRE_PHOENIX_AGENT_MODE=auto`. Full rules: `references/interactive-questionnaire.md`.

## Migration strategies

| Strategy | Description | When to use |
|---|---|---|
| Big Bang | All data moved in a single cutover window (downtime required) | Small dataset; short acceptable downtime |
| Phased | Data migrated in batches by domain or date range | Large dataset; partial go-live acceptable |
| Parallel Run | Old and new systems run simultaneously; data kept in sync | Zero downtime required; high risk tolerance needed |
| Trickle (CDC) | Continuous replication using Change Data Capture until cutover | Very large dataset; near-zero downtime |

## Inputs

- `.fire-phoenix/context.yml`
- `{context.paths.docs}/analysis/srs.md` — data entities,
  volumes, retention rules (FR-NNN / NFR-NNN related to data)
- `{context.paths.docs}/architecture/intake.md` — legacy system
  description, technology stack
- `{context.paths.docs}/design/<feature>/data-model.md` — target
  data model (if produced by development-design)
- `{context.paths.docs}/project/risk-register.md` — data-related
  risks

## Outputs

- `{context.paths.docs}/analysis/data-migration-plan.md` — the
  migration strategy and scope (primary artefact; owned by
  business-analyst)
- `{context.paths.docs}/analysis/field-mapping.md` — source-to-
  target field mapping table (business logic; owned by
  business-analyst)
- `{context.paths.docs}/operations/migration-runbook.md` — step-by-
  step cutover runbook (technical execution; owned by DevOps)
- `{context.paths.docs}/analysis/data-migration-plan.extract` —
  companion KEY=VALUE ledger
  (DM_STRATEGY, DM_CUTOVER_WINDOW, DM_ROLLBACK_TRIGGER,
   DM_RECORD_VOLUME, DM_VALIDATION_APPROACH)
- `{context.paths.docs}/analysis/dm-debts.md` — open items
  (DMDEBT-NN: …)

## Context Update

Does not mutate `.fire-phoenix/context.yml`.

## Handoffs

- `phase-gate` (orr / go-live gate) checks whether the
  migration plan is complete and the dry-run result is documented.
- `baseline` can snapshot field-mapping.md as part of the
  design baseline.
- `test-strategy` should include a data-validation test tier
  for the migration; this plan feeds that tier.
- `risk-register` should capture migration-specific risks
  (data loss, downtime over-run, rollback complexity).
- `deployment-strategy` is read to align the migration cutover
  window with the deployment window.

## AI authoring scope

**Does:**

- Draft the migration strategy selection with rationale.
- Produce a source-to-target field mapping table from the data model
  and SRS entities.
- Define data quality rules (null handling, type coercion, dedup,
  encoding, date formats).
- Outline ETL steps at the logical level (extract, transform,
  validate, load, verify).
- Define cutover window, rollback triggers, and the rollback
  procedure (a rehearsed data restore).
- State the dual-write seam decisions and reconciliation cadence
  for Parallel Run / Trickle strategies.
- Register compatibility shims with sunset dates and removal
  triggers.
- Produce a post-migration reconciliation checklist.

**Does not:**

- Write ETL code or SQL scripts.
- Access any database or data file.
- Execute or schedule any migration step.

## Outline

1. **Determine scope** — from user input, or ask:
   a. What is the source system? (name, type, rough record count)
   b. What data must be migrated? (all / subset by date / subset by
      entity)
   c. Is downtime acceptable? (yes / no / limited window)

2. **Interactive questionnaire** (interactive mode only):
   a. Source system type: A) relational DB, B) file system / CSV,
      C) another SaaS, D) mix.
   b. Record volume: A) < 100K, B) 100K–1M, C) 1M–100M, D) > 100M.
   c. Migration strategy preference (see table above).
   d. Cutover window: A) weekend maintenance, B) overnight weekday,
      C) business hours with parallel run, D) not decided.
   e. Rollback trigger: A) any reconciliation failure, B) > X%
      failure rate, C) manual decision only.
   f. Privacy / compliance: does the migrated data contain PII,
      financial data, or health records? (affects encryption and
      audit requirements).

3. **Draft field mapping** — for each target entity in the data
   model, map source fields to target fields, noting:
   - Data type transformation needed (e.g. VARCHAR → UUID)
   - Nullable / required differences
   - Default value for missing source data
   - Transformation rule (concatenate, split, lookup, generate)
   Mark unmapped fields as DMDEBT entries.

4. **Define data quality rules**:
   - Null handling policy per critical field
   - Duplicate detection strategy
   - Character encoding (UTF-8 requirement)
   - Date / time zone normalisation
   - Referential integrity checks

5. **Outline ETL process** (logical, not code):
   - Extract: source query / export mechanism, incremental vs full
   - Transform: rule application order, error handling
   - Load: batch size, idempotency strategy (every transform is
     idempotent and re-runnable — a repeated run converges to the
     same target state, no duplicates), index rebuild
   - Verify: record count match, sample spot-checks, checksum

6. **Define cutover plan**:
   - Freeze point (when writes to old system stop)
   - Migration window duration estimate
   - Rollback decision point and trigger
   - Rollback procedure — rolling back a data migration is a data
     restore, not a code revert; rehearse the restore in the dry-run
     (step 7) rather than trusting it on paper
   - Point of no return — the step after which rollback is no
     longer possible, named in the sequence, with sign-off
   - Dual-write seams (Parallel Run / Trickle): state the
     write-split decision per seam (which system owns writes for
     which data); reconciliation re-runs continuously against fresh
     deltas, not as a one-off check
   - Compatibility shims: each shim carries a sunset date and a
     removal trigger; record shims as DMDEBT entries so none
     quietly becomes permanent
   - Communication plan for downtime

7. **Apply the verification and reversibility rules** — per
   `references/migration-verification.md`: every migration has a
   rehearsal (dry run) whose recorded results size the cutover
   window; every data class in the field mapping has a named
   verification check (counts, checksums, spot checks,
   referential integrity — PII classes get masking/encryption
   checks on top); every cutover step has an explicit rollback or
   a documented point of no return. Gaps become `DMDEBT-` entries.

8. **Draft migration runbook** — step-by-step numbered procedures
   for the cutover team, including go / no-go decision checkpoints.

9. **Propose failure-path criteria** — turn each rollback trigger
   and verification failure mode into a candidate negative
   acceptance criterion (Given/When/Then) and hand the candidates
   to the business-analyst, who authors the final criteria. This
   skill only proposes.

10. **Post-migration validation checklist** — items the team must
    verify within 24 h of cutover before decommissioning the source.

11. **Write outputs** — write plan, field mapping, runbook, and
    extract.

12. **Summary** — print strategy, estimated cutover window,
    unmapped field count (DMDEBT), and recommended next action.

## Usage

> `<SKILL_DIR>` = the integration's skills root.

```bash
DM_STRATEGY="phased" \
DM_SOURCE="legacy-mysql-5.7" \
DM_RECORD_VOLUME="500000" \
DM_CUTOVER_WINDOW="2026-07-05T22:00/2026-07-06T06:00" \
  bash <SKILL_DIR>/data-migration-plan/scripts/bash/draft-dm-plan.sh --auto
```

### Answer keys

| Key | Meaning | Default |
|---|---|---|
| `DM_STRATEGY` | `big-bang` / `phased` / `parallel` / `trickle` | `big-bang` |
| `DM_SOURCE` | Source system description | *(ask in interactive)* |
| `DM_RECORD_VOLUME` | Approximate total record count | *(ask in interactive)* |
| `DM_CUTOVER_WINDOW` | ISO interval `start/end` | *(ask in interactive)* |
| `DM_ROLLBACK_TRIGGER` | `any-failure` / `threshold` / `manual` | `any-failure` |
| `DM_HAS_PII` | `true` / `false` — data contains PII | `false` |
