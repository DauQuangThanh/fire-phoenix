# Data Migration Plan: {project}

**Revision:** {revision}
**Date:** {date}
**Migration Strategy:** {strategy}
**Cutover Window:** {cutover_window}
**Status:** Draft

---

## 1. Migration overview

| Item | Value |
|---|---|
| Source system | {source_system} |
| Target system | {target_system} |
| Migration strategy | {strategy} |
| Estimated record volume | {record_volume} |
| Contains PII | {has_pii} |
| Estimated migration duration | {duration_estimate} |

---

## 2. Scope

### In scope

{in_scope}

### Out of scope (deferred or excluded data)

{out_scope}

---

## 3. Migration strategy rationale

**Selected strategy:** {strategy}

{strategy_rationale}

---

## 4. Data quality rules

| Rule | Description | Action on violation |
|---|---|---|
| Null handling | Required fields with null source values | {null_action} |
| Deduplication | Records matching on {dedup_key} | Retain most recent; log discarded |
| Encoding | All text fields must be UTF-8 | Transcode at extract; reject non-transcodable |
| Date normalisation | All dates stored as ISO 8601 UTC | Apply timezone offset at transform |
| Referential integrity | Foreign key references must resolve | Log orphans as DMDEBT; set to null / sentinel |

---

## 5. ETL outline

### 5.1 Extract

- **Mechanism:** {extract_mechanism}
- **Mode:** {extract_mode} (full / incremental)
- **Batch size:** {batch_size} records per batch

### 5.2 Transform

{transform_rules}

### 5.3 Load

- **Load mode:** upsert (insert or update on primary key)
- **Idempotency key:** {idempotency_key}
- **Re-run policy:** every transform is idempotent and re-runnable —
  a repeated run converges to the same target state with no
  duplicate records
- **Index strategy:** disable non-unique indexes during bulk load; rebuild after

### 5.4 Verify

One named check per data class — a class with no check is a
DMDEBT (see `references/migration-verification.md`):

| Data class | Check | Tolerance | Owner |
|---|---|---|---|
| <entity> | count match per entity | ±0.01% | |
| <entity, critical fields> | checksum / hash comparison | exact | |
| <entity> | spot-check sample incl. edge rows | 100 records | |
| <FK relationships> | referential integrity queries | zero orphans | |
| <PII / regulated fields> | masking / encryption held end-to-end | exact | |

---

## 6. Cutover plan

| Step | Description | Owner | Go/No-Go checkpoint |
|---|---|---|---|
| T-7 days | Dry-run migration on staging, including a rollback-restore rehearsal; document results | Migration lead | Record count match ≥ 99.9%; restore rehearsal passed |
| T-3 days | Resolve all dry-run DMDEBT items | Dev team | All blockers closed |
| T-1 day | Final data quality snapshot of source | Migration lead | Quality score baseline |
| Cutover start | Freeze writes to source system | PM | Stakeholders notified |
| Migrate | Execute ETL; monitor progress | Migration lead | Error rate < threshold |
| Verify | Run reconciliation checks | QA | All checks pass |
| Go/No-Go | Decision to proceed or roll back | PM + Tech Lead | See rollback trigger |
| Cutover end | Open writes to target system | PM | Go confirmed |
| T+24 hours | Post-migration validation checklist | QA | All items checked |

### Rollback trigger

**Condition:** {rollback_trigger}

### Point of no return

**Step:** {point_of_no_return} — after this step rollback is no
longer possible; what is lost by attempting it, and who signed
off on crossing it. The go/no-go checkpoint immediately before
it is the last that can choose "no".

### Candidate failure-path criteria

Each rollback trigger and verification failure mode above is a
candidate negative criterion, handed to the business-analyst who
authors the final version:

- **Given** a cutover in progress, **When** {rollback_trigger}
  occurs, **Then** the migration halts, writes stay frozen, and
  the source system remains authoritative.

### Rollback procedure

> Rolling back a data migration is a **data restore**, not a code
> revert. The restore below is rehearsed during the T-7 dry-run —
> an unrehearsed restore is a hope, not a procedure.

1. Stop all load processes immediately.
2. Re-enable writes to the source system.
3. Notify stakeholders and document the failure point.
4. Restore the target database from the pre-migration snapshot
   (the restore path rehearsed at T-7).
5. Run post-rollback verification on source system integrity.
6. Schedule retrospective within 24 hours.

### Dual-write seams (Parallel Run / Trickle only)

While both systems accept writes there are two sources of truth.
State the write-split decision per seam and keep reconciliation
running against fresh deltas — a one-off check goes stale the
moment the next write lands.

| Seam (entity / domain) | Writes owned by | Reconciliation cadence | Action on drift |
|---|---|---|---|
| <!-- seam --> | <!-- source / target / split rule --> | <!-- continuous / per sync batch --> | <!-- action or DMDEBT ref --> |

### Compatibility shims

Every shim is a contract with a sunset date. A shim without a
removal trigger becomes permanent architecture by default.

| Shim | Purpose | Sunset date | Removal trigger | DMDEBT ref |
|---|---|---|---|---|
| <!-- shim --> | <!-- purpose --> | <!-- YYYY-MM-DD --> | <!-- trigger --> | DMDEBT-NN |

---

## 7. Post-migration validation checklist

- [ ] Record counts match within tolerance (±0.01%)
- [ ] All critical entity spot-checks pass
- [ ] No unresolved referential integrity violations
- [ ] Dual-write reconciliation (if applicable) shows zero
      unexplained drift against the latest deltas
- [ ] Application smoke test passes in production
- [ ] Monitoring alerts baseline re-established
- [ ] Source system decommission plan confirmed (if applicable)
- [ ] Migration log archived and accessible

---

## 8. Privacy and compliance

{privacy_notes}

---

## 9. Open items (DMDEBT)

See `dm-debts.md`.
