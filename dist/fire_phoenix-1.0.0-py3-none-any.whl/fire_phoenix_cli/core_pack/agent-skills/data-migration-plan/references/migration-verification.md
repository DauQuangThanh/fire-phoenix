# Migration verification and reversibility — rules

The business-analyst owns the migration strategy and field
mapping; this reference deepens the technical side those feed:
how the migration is rehearsed, verified, and — if needed —
undone. It applies to the plan and, through DevOps, to the
cutover runbook.

## Rehearsal (dry run)

- [ ] **Every migration has at least one full rehearsal** on
      production-like data (volume and shape, not necessarily raw
      production content — respect the PII answer) before the
      real cutover.
- [ ] Rehearsal results are recorded: duration, error classes,
      reconciliation outcome, and every deviation as a `DMDEBT-`.
- [ ] The cutover window estimate comes from the rehearsal, not
      from hope. A rehearsal that has not been run is a
      go-live blocker at the readiness gate.

## Verification per data class

One generic "record counts match" check is not verification.
For **each data class** in the field mapping (per entity, and
separately for PII / financial / regulated fields), the plan
names its check:

- [ ] **Counts** — source vs. target within the agreed tolerance,
      per entity (not just the grand total).
- [ ] **Checksums / hashes** — on critical fields, so silent
      truncation and encoding damage surface.
- [ ] **Spot checks** — a sample of records compared field by
      field, including edge rows (oldest, newest, longest text,
      null-heavy).
- [ ] **Referential integrity** — orphan queries per foreign-key
      relationship.
- [ ] **PII / regulated classes** — additionally verify masking /
      encryption held end-to-end and access stayed audited.

A data class with no named verification check is a `DMDEBT-`.

## Reversibility

- [ ] Every cutover step has one of:
      - an **explicit rollback** — the undo action written next
        to the step; or
      - a **documented point of no return** — the step after
        which rollback is no longer possible, what is lost by
        attempting it, and who signed off on crossing it.
- [ ] The point of no return appears in the cutover sequence by
      name — the go/no-go decision before it is the last one
      that can choose "no".
- [ ] Rollback itself is rehearsed at least once (usually during
      the dry run), and post-rollback verification of the source
      system is defined.

## Failure-path criteria

Each rollback trigger and verification failure mode is a
candidate **negative acceptance criterion** in Given/When/Then
form (Given a cutover in progress / When reconciliation fails
beyond the agreed tolerance / Then the migration halts, writes
stay frozen, and the source remains authoritative). Hand the
candidates to the business-analyst, who authors the final
criteria through the normal acceptance gate — this skill only
proposes.
