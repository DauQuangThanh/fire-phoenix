# Run a blameless postmortem. Every incident feeds the IDD intent
# layer (new harness check / new guardrail / amended spec /
# strengthened invariant) — otherwise the incident can recur.

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
. (Join-Path $ScriptDir 'common.ps1')

$RestArgs = Import-FirePhoenixStandardArgs $args

if ($RestArgs.Count -gt 0 -and $RestArgs -contains '-Help') {
    @'
Usage: Run-Postmortem.ps1 [--auto] [--answers FILE] [--dry-run] [--help] <incident-slug>

Drafts a blameless postmortem at ops/postmortem-<slug>.md. Mandatory
final section: "Which intent artefact changes?" — a postmortem with
this section empty is incomplete.
'@ | Write-Host
    exit 0
}

$ctx = Read-Context
$Slug = if ($RestArgs.Count -gt 0) { $RestArgs[0] } else { '' }
if ([string]::IsNullOrEmpty($Slug)) {
    Write-Error "incident-slug required."
    exit 1
}

$OutDir = Get-WorktypeDir -Name 'ops'
$PmFile = Join-Path $OutDir "postmortem-$Slug.md"

if ($env:FIRE_PHOENIX_DRY_RUN -eq '1') {
    Write-Host "[dry-run] would write: $PmFile"
    exit 0
}

if (Test-Path $PmFile) {
    Write-Error "Postmortem already exists at $PmFile — refusing to overwrite."
    exit 1
}

if (-not (Confirm-BeforeWrite "Write postmortem for '$Slug' to $PmFile")) {
    Write-Error "Aborted."
    exit 1
}

@"
# Postmortem — $Slug

> Blameless. Focus on systems + signal gaps, NOT individuals. Every
> incident must feed the IDD intent layer (otherwise it can recur).

## Summary

TBD-source — one paragraph: what happened, blast radius, when detected, when resolved.

## Timeline

| Time (UTC) | Event | Observable |
|---|---|---|
| HH:MM | <event> | <link> |

## Evidence chain

TBD-source — chain of "we saw X, which means Y".

## Root cause(s)

TBD-source — Five-whys to the systemic cause.

## Contributing factors

TBD-source — load spike, deploy timing, coverage gaps.

## Detection gap

TBD-source — incident start to detection. What signal would have shortened that?

## Response gap

TBD-source — detection to resolution. What runbook gap?

## Which intent artefact changes? (MANDATORY)

> Load-bearing. A postmortem without an answer here is incomplete.

- [ ] **New characterisation test** at ``tests/characterisation/test_<surface>.py``.
- [ ] **New L1 invariant** in ``PRODUCT.md §Invariants``.
- [ ] **New failure-path AC** in the feature's acceptance list (negative acceptance criterion).
- [ ] **New guardrail** in ``CLAUDE.md`` negative constraints.
- [ ] **Strengthened SLO** at ``ops/slo-*.yml``.
- [ ] **Amended runbook** at ``ops/runbook-*.md``.
- [ ] **New ADR** at ``adr/NNNN-*.md``.

Each checked box → link the realised contract / PR / commit.

## Re-occurrence risk after these changes

TBD-source — honest assessment.
"@ | Set-Content -Path $PmFile -Encoding UTF8

Write-Host "Postmortem drafted at $PmFile"
Write-Host "Reminder: the 'Which intent artefact changes?' section is MANDATORY."
