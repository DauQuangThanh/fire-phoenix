#!/usr/bin/env bash
# Run a blameless postmortem. Templates the incident → intent loop:
# every postmortem MUST end by naming which intent artefact changes
# (new harness check / new guardrail / amended spec / strengthened
# invariant). An incident that changes no intent artefact is an
# incident the system can repeat.

set -e

SCRIPT_DIR="$(CDPATH="" cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=common.sh
source "$SCRIPT_DIR/common.sh"

fire_phoenix_parse_standard_args "$@"
set -- "${FIRE_PHOENIX_REST_ARGS[@]}"

if [ "${1:-}" = "--help" ]; then
    cat <<'USAGE'
Usage: run-postmortem.sh [--auto] [--answers FILE] [--dry-run] [--help] <incident-slug>

Drafts a blameless postmortem at ops/postmortem-<slug>.md. Mandatory
final section: "Which intent artefact changes?" — a postmortem with
this section empty is incomplete.

Flags:
  --auto            non-interactive; resolve answers from env/answers/extracts
  --answers FILE    KEY=VALUE file consulted when --auto
  --dry-run         print what would be written, do not touch the filesystem
  --help            show this message and exit
USAGE
    exit 0
fi

read_context

SLUG="${1:-}"
if [ -z "$SLUG" ]; then
    echo "Error: incident-slug required. Usage: run-postmortem.sh <slug>" >&2
    exit 1
fi

OUT_DIR=$(worktype_dir "ops")
PM_FILE="$OUT_DIR/postmortem-${SLUG}.md"

if [ "${FIRE_PHOENIX_DRY_RUN:-0}" = "1" ]; then
    echo "[dry-run] would write: $PM_FILE"
    exit 0
fi

if [ -e "$PM_FILE" ]; then
    echo "Error: postmortem already exists at $PM_FILE — refusing to overwrite." >&2
    exit 1
fi

if ! confirm_before_write "Write postmortem for '$SLUG' to $PM_FILE"; then
    echo "Aborted." >&2
    exit 1
fi

cat > "$PM_FILE" <<EOF
# Postmortem — ${SLUG}

> Blameless. Focus on systems + signal gaps, NOT individuals. Every
> incident must feed the IDD intent layer (otherwise it can recur).

## Summary

TBD-source — one paragraph: what happened, blast radius, when detected,
when resolved.

## Timeline

TBD-source — UTC timestamps, observable events only. Each row links to
a log / metric / alert.

| Time (UTC) | Event | Observable |
|---|---|---|
| HH:MM | <event> | <link> |

## Evidence chain

TBD-source — what observable led to what conclusion. Chain of "we saw
X, which means Y" — each link defensible from a log or metric, not
recollection.

## Root cause(s)

TBD-source — Why did this happen? Use the "five whys" or equivalent.
Stop at the systemic cause (an absent guardrail, a missing test, an
unstated invariant) — NOT at a person's action.

## Contributing factors

TBD-source — secondary conditions that amplified the incident: load
spike, deploy timing, on-call coverage gaps, etc.

## Detection gap

TBD-source — how long between the incident starting and detection?
What signal would have shortened that? This is the SLO question —
maybe the SLO itself needs strengthening.

## Response gap

TBD-source — how long between detection and resolution? What in the
runbook was missing or wrong? Update the runbook BEFORE closing this
postmortem.

## Which intent artefact changes? (MANDATORY)

> This is the load-bearing section. A postmortem without an answer here
> is incomplete — the incident → intent loop is broken.

Pick AT LEAST ONE (usually multiple):

- [ ] **New characterisation test** at \`tests/characterisation/test_<surface>.py\` pinning the observed-correct behaviour.
- [ ] **New L1 invariant** in \`PRODUCT.md §Invariants\` — what must always hold that didn't.
- [ ] **New failure-path AC** in the feature's acceptance list — the failure condition becomes a negative acceptance criterion the harness can check.
- [ ] **New guardrail** in \`CLAUDE.md\` negative constraints — what must never be done.
- [ ] **Strengthened SLO** at \`ops/slo-*.yml\` — tighter target, or new SLO entirely.
- [ ] **Amended runbook** at \`ops/runbook-*.md\` — what step was wrong/missing.
- [ ] **New ADR** at \`adr/NNNN-*.md\` — what structural decision needs revisit.

For each box checked, link to the contract / PR / commit that lands the
change. The postmortem closes only when every checked box has a
realised landing.

## Re-occurrence risk after these changes

TBD-source — would the proposed changes catch this incident next time?
If not, what's missing? Honest answer here is more valuable than
optimistic plans.
EOF

echo "Postmortem drafted at $PM_FILE"
echo "Reminder: the 'Which intent artefact changes?' section is MANDATORY — every other section is in service of it."
