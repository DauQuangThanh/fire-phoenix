# Postmortem — <incident-slug>

> Blameless. Focus on systems + signal gaps, NOT individuals.

## Summary

One paragraph: what happened, blast radius, when detected, when resolved.

## Timeline

| Time (UTC) | Event | Observable |
|---|---|---|
| HH:MM | <event> | <link> |

Include the fast-track containment actions (pin / flag off /
rollback / WAF rule) — first-hour containment legitimately runs
without a contract; record it retroactively in `decisions.md` (via `record_decision` → `promote-governance`), and
route the persistent fix (contract + spec citation + regression
test, within the next working day) through §8.

## Evidence chain

Chain of "we saw X, which means Y" — each link defensible from a log
or metric, not recollection.

## Root cause(s)

Five-whys to the systemic cause (absent guardrail / missing test /
unstated invariant) — NOT to a person's action.

## Contributing factors

Secondary conditions: load spike, deploy timing, on-call coverage gaps.

## Detection gap

How long between incident start and detection? What signal would have
shortened it?

## Response gap

How long between detection and resolution? What runbook step was
missing or wrong?

## Which intent artefact changes? (MANDATORY)

> Load-bearing. A postmortem without an answer here is incomplete —
> the incident → intent loop is broken.

Pick at least one (usually multiple):

- [ ] New characterisation test at `tests/characterisation/test_<surface>.py`.
- [ ] New L1 invariant in `PRODUCT.md §Invariants`.
- [ ] New guardrail in `CLAUDE.md` negative constraints.
- [ ] New failure-path AC in the feature's acceptance list.
- [ ] Strengthened SLO at `ops/slo-*.yml`.
- [ ] Amended runbook at `ops/runbook-*.md`.
- [ ] New ADR at `adr/NNNN-*.md`.

Each checked box → link the realised contract / PR / commit; the
corrective contract cites the amended intent artefact. The
postmortem closes only when every checked box has a realised landing.

## Re-occurrence risk after these changes

Would the proposed changes catch this incident next time? If not,
what's missing?
