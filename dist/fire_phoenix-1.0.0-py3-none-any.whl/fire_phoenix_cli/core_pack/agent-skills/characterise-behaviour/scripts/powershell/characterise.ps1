# Author a characterisation-test scaffold pinning OBSERVED legacy
# behaviour. Brownfield discipline: pin behaviour BEFORE change. See
# references/brownfield-discipline.md for the rules enforced here.

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
. (Join-Path $ScriptDir 'common.ps1')

$RestArgs = Import-FirePhoenixStandardArgs $args

if ($RestArgs.Count -gt 0 -and $RestArgs -contains '-Help') {
    @'
Usage: characterise.ps1 [--auto] [--answers FILE] [--dry-run] [--help] <module-path>

Drafts a characterisation-test scaffold at
tests/characterisation/test-<surface>-checklist.md. Each row pins
OBSERVED behaviour against the current legacy code.
'@ | Write-Host
    exit 0
}

$ctx = Read-Context
$ModulePath = if ($RestArgs.Count -gt 0) { $RestArgs[0] } else { '' }
if ([string]::IsNullOrEmpty($ModulePath)) {
    Write-Error "module-path required."
    exit 1
}

$Surface = [System.IO.Path]::GetFileNameWithoutExtension($ModulePath)
$OutDir = Join-Path $ctx.REPO_ROOT 'tests/characterisation'
$OutFile = Join-Path $OutDir "test-$Surface-checklist.md"

if ($env:FIRE_PHOENIX_DRY_RUN -eq '1') {
    Write-Host "[dry-run] would write: $OutFile"
    exit 0
}

if (Test-Path $OutFile) {
    Write-Error "Checklist already exists at $OutFile — refusing to overwrite."
    exit 1
}

if (-not (Confirm-BeforeWrite "Write characterisation checklist for '$Surface' to $OutFile")) {
    Write-Error "Aborted."
    exit 1
}

New-Item -ItemType Directory -Path $OutDir -Force | Out-Null
@"
# Characterisation checklist — $Surface

> Handbook v1.1 ch. 11 — Brownfield archetype.
> Each row pins **OBSERVED** behaviour from ``$ModulePath``. NEVER pin
> what the code *should* do — that's a refactor specification.

## Source

- Module: ``$ModulePath``
- Source revision pinned to: TBD-source — commit SHA / tag.

## Checklist rows

| # | Input scenario | OBSERVED outcome | Source: file:line |
|---|---|---|---|
| 1 | TBD-source | TBD-source | ``$ModulePath``:TBD-line |

## Verification protocol

1. Each "OBSERVED outcome" came from RUNNING the legacy code.
2. Each row cites file:line. No line → DROP.
3. Tests materialised from this checklist MUST pass against the
   CURRENT (pre-change) code.

## Refusal conditions

- Row with OBSERVED "TODO" → not characterised; do NOT promote.
- Row with empty Source column → speculative; drop.
- Checklist with zero file:line citations → characterisation failed.

## Hand-off

When all rows pin observable file:line outcomes AND the materialised
tests pass against the current code, hand off to the engineer.
"@ | Set-Content -Path $OutFile -Encoding UTF8

Write-Host "Characterisation checklist drafted at $OutFile"
