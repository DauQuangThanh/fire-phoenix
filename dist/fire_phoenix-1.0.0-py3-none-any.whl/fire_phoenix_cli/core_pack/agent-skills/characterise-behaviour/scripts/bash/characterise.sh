#!/usr/bin/env bash
# Author a characterisation-test scaffold pinning OBSERVED legacy
# behaviour. Brownfield discipline: pin behaviour BEFORE change, not
# desired behaviour. The script REFUSES to author tests whose
# expectations are speculative. See
# references/brownfield-discipline.md for the rules enforced here.

set -e

SCRIPT_DIR="$(CDPATH="" cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=common.sh
source "$SCRIPT_DIR/common.sh"

fire_phoenix_parse_standard_args "$@"
set -- "${FIRE_PHOENIX_REST_ARGS[@]}"

if [ "${1:-}" = "--help" ]; then
    cat <<'USAGE'
Usage: characterise.sh [--auto] [--answers FILE] [--dry-run] [--help] <module-path>

Drafts a characterisation-test scaffold at
tests/characterisation/test_<surface>.md (a checklist; the user
materialises the actual test file in their stack's test framework
from the checklist rows).

Flags:
  --auto            non-interactive
  --answers FILE    KEY=VALUE file consulted when --auto
  --dry-run         print what would be written, do not touch the filesystem
  --help            show this message and exit
USAGE
    exit 0
fi

read_context

MODULE_PATH="${1:-}"
if [ -z "$MODULE_PATH" ]; then
    echo "Error: module-path required. Usage: characterise.sh <legacy/path/to/module>" >&2
    exit 1
fi

# Derive the surface name from the module path (basename, sans extension).
SURFACE="$(basename "$MODULE_PATH")"
SURFACE="${SURFACE%.*}"

OUT_DIR="$FIRE_PHOENIX_REPO_ROOT/tests/characterisation"
OUT_FILE="$OUT_DIR/test-${SURFACE}-checklist.md"

if [ "${FIRE_PHOENIX_DRY_RUN:-0}" = "1" ]; then
    echo "[dry-run] would write: $OUT_FILE"
    echo "[dry-run] surface:     $SURFACE"
    echo "[dry-run] module:      $MODULE_PATH"
    exit 0
fi

if [ -e "$OUT_FILE" ]; then
    echo "Error: checklist already exists at $OUT_FILE — refusing to overwrite." >&2
    exit 1
fi

if ! confirm_before_write "Write characterisation checklist for '$SURFACE' to $OUT_FILE"; then
    echo "Aborted." >&2
    exit 1
fi

mkdir -p "$OUT_DIR"
cat > "$OUT_FILE" <<EOF
# Characterisation checklist — ${SURFACE}

> Handbook v1.1 ch. 11 — Brownfield archetype.
> Each row pins **OBSERVED** behaviour from \`${MODULE_PATH}\`. NEVER pin
> what the code *should* do — that's a refactor specification, not
> characterisation. If a row's expectation comes from "what makes
> sense" or "what the docs say" rather than from RUNNING the code,
> REMOVE the row.

## Source

- Module: \`${MODULE_PATH}\`
- Source revision pinned to: TBD-source — commit SHA / tag at
  characterisation time.

## Checklist rows

Each row is one observation. Materialise each in your stack's test
framework AFTER all rows pass current behaviour.

| # | Input scenario | OBSERVED outcome | Source: file:line |
|---|---|---|---|
| 1 | TBD-source — concrete inputs (no "various"; no "edge cases") | TBD-source — what the code did when run with those inputs | \`${MODULE_PATH}\`:TBD-line |
| 2 | … | … | \`${MODULE_PATH}\`:TBD-line |

## Verification protocol

1. Each row's "OBSERVED outcome" came from running the legacy code
   against the row's "Input scenario" — NOT from reading the code or
   the docs.
2. Each row's "Source: file:line" points at the code path whose
   behaviour the row pins. If a row can't cite a line, the row is
   speculative — DROP IT.
3. After authoring the test file from this checklist, run the tests
   against the CURRENT (pre-change) code: every test MUST PASS. A
   failing test pins something other than observed behaviour and
   needs revision.

## Refusal conditions

- A row whose OBSERVED outcome is "TODO" or "investigate" → row is
  not yet characterised; do NOT promote to a real test.
- A row whose Source column is empty → speculative; drop or
  research before promoting.
- An entire checklist with zero rows that can cite file:line →
  characterisation failed; do NOT proceed to change.

## Hand-off

When all rows have observable outcomes pinned to file:line AND the
materialised tests pass against the current code, hand off to the
engineer for the change. The engineer's contract MUST keep this
checklist + the materialised tests green throughout the change.
EOF

echo "Characterisation checklist drafted at $OUT_FILE"
echo "Reminder: each row pins OBSERVED behaviour. Speculative rows MUST be removed before promoting to tests."
