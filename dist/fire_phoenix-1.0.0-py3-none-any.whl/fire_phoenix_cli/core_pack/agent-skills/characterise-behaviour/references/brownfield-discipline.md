# Brownfield discipline — characterisation reference

Self-contained background for the `characterise-behaviour` skill.
The rules below define what the skill enforces; AI sessions that
invoke this skill must respect them.

- **Pin behaviour BEFORE change.** Characterisation tests pin the
  system's *currently observed* behaviour on legacy code, so any
  engineer's change is constrained against a real baseline, not a
  wished-for one. The tests are written, made to pass on the current
  code, and held green throughout the change.

- **OBSERVED, not DESIRED.** The skill REFUSES to author tests that
  assert what the legacy code *should* do — that conflates
  characterisation with refactor intent. Refactor intent lives in
  the spec (`specs/epic-*.md`) or the task contract
  (`contracts/task-*.md`), not in characterisation tests.

- **Each row cites `file:line`.** A characterisation row that cannot
  point at the exact code path producing the outcome is speculative;
  drop it.

- **Tests stay green throughout change.** The engineer's contract
  amends the characterisation tests only when the spec / contract
  explicitly says observed behaviour must change — otherwise the
  tests are a fence against unintended regression.
