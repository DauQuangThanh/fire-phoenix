---
name: characterise-behaviour
description: Drafts a characterisation-test checklist pinning OBSERVED legacy behaviour
  from a named module before any change, each row citing source file:line; refuses
  to assert what code SHOULD do. Use before changing legacy code.
license: MIT
compatibility: Designed for agentskills.io-compatible agents.
metadata:
  author: Dau Quang Thanh
  version: '1.0'
  requires: []
---

## User Input

```text
$ARGUMENTS
```

You **MUST** consider the user input before proceeding (if not empty).

## Pre-Execution Checks

1. **Identify the legacy module/surface** the user wants to
   characterise. Confirm it's a CONCRETE artefact (`src/foo/bar.py`,
   `services/auth/handler.go`, etc.), not a vague description ("the
   billing logic"). Reject vague answers — characterisation needs a
   single source file or a tight bundle.
2. **Confirm pre-change state.** Ask which revision/commit/tag this
   characterisation pins to. Pin the revision in the checklist's
   Source section so future readers know the baseline.
3. **Confirm the testing framework.** The skill produces a markdown
   CHECKLIST; the user materialises tests in their stack (pytest,
   Go test, JUnit, RSpec, etc.). The skill does NOT generate
   framework-specific test code — it generates the behavioural
   contract the test code expresses.

## Outline

Author `tests/characterisation/test-<surface>-checklist.md` with these
sections per `templates/characterisation-test-template.md`:

1. **Source** — module path + pinned revision.
2. **Checklist rows** — one row per observation. Required columns:
   - Input scenario (concrete inputs; no "various", no "edge cases").
   - OBSERVED outcome (what the code DID when run; not what it should).
   - Source: file:line (the code path producing the outcome).
3. **Verification protocol** — instructions for materialising the
   checklist into the user's test framework + the protocol for
   running the materialised tests against the current code (all MUST
   PASS before the engineer's change starts).
4. **Refusal conditions** — what makes a row drop:
   - "TODO" / "investigate" in the OBSERVED column.
   - Empty Source column.
   - Speculative outcome ("should", "would", "probably").
5. **Hand-off** — to the engineer, with the requirement that the
   materialised tests stay green throughout the change.

## Characterisation-test-generation mode

This mode turns the checklist's OBSERVED rows into framework-native, **runnable** pinned tests — the regression fence you run *before* touching the code. It is AI-driven: read the checklist and author the test file directly, using `templates/pinned-test-template.py` as the pytest skeleton (and the analogous shape for other frameworks). Write it to `tests/characterisation/pinned_<framework>.<ext>` under the repo root.

The checklist is the source; this mode is the materialiser the base skill deliberately refuses to be by hand. It is only sound because every row is already OBSERVED-only and file:line-cited.

**Framework detection.** Default `pytest` (`.py`). Also emit for `jest` (JS/TS, `.test.js`), `go test` (Go, `_test.go`), or `JUnit` (Java, `.java`) when the project's stack is detected — pick the framework matching the target's stack.

**Generation rules — one test per checklist row:**

1. Assert the OBSERVED value **verbatim**. `assert actual == <OBSERVED>` — the value the code produced when run, character-for-character. Never normalise, round, or "clean up" the pinned value.
2. Cite the source `file:line` in a comment on the test (`# source: src/foo.py:42`). A row with no citation is not materialised — it was speculative and should never have reached the checklist.
3. These tests are the **regression fence, NOT aspirational.** They lock CURRENT behaviour, quirks included — a silent `None` return, an off-by-one, a swallowed exception all get pinned as-is. Fixing the quirk is the engineer's *contract* concern; the pinned test is what proves the fix (not the fence) changed behaviour.
4. A **failing** pinned test means behaviour changed. Investigate the change before "fixing" the test — never edit the assertion to make it pass unless an L2/L3 spec explicitly says the observed behaviour must change.

The authored file starts from the template skeleton: one worked example plus a `# TODO` per remaining row. Fill each row's inputs and OBSERVED value from the checklist, then run the file against pre-change code — all green is the gate to start the change.

## The OBSERVED-only discipline

This is the load-bearing rule. The skill REFUSES to author tests that
encode desired behaviour:

- "When the user is null, raise ValueError" → if the legacy code
  currently raises ValueError, OK. If it currently returns None
  silently, you must pin THAT — not what you want.
- "Returns a list of users" → if the legacy code currently returns a
  generator, you pin the generator; refactoring it to a list is the
  engineer's contract concern, not characterisation.

When the user's draft row contradicts what the code actually does, the
skill surfaces the contradiction and asks the user to:

1. Verify the actual behaviour by running the code, OR
2. Drop the row from the characterisation (and surface the desired
   behaviour as a spec amendment, NOT a characterisation row).

## Post-Execution Checks

- Every row has `OBSERVED outcome` + `Source: file:line`.
- No row contains "should", "must", "would" in the OBSERVED column.
- The checklist's `Source` section pins a specific revision.

## Inputs

- The legacy module/surface path.
- The pinned revision (commit SHA, tag, or branch).
- (Optional) Prior characterisation work the user already drafted.

## Outputs

- `tests/characterisation/test-<surface>-checklist.md` — the
  materialisation-ready behavioural contract.

The user materialises tests in their stack from this checklist; the
skill does NOT generate test code (test framework variance is
out-of-scope).

## Context Update

This skill does NOT mutate `.fire-phoenix/context.yml`. The
characterisation checklist under `tests/characterisation/` is the
only on-disk side-effect.

## Handoffs

- **Engineer (or developer subagent)** — materialises tests in the
  project's framework + holds the line through the change.
- **Tester subagent** — reviews the materialisation: are the tests
  truly characterising observed behaviour, or have they slipped into
  desired-behaviour assertions?
- **`parity-ledger` skill** — when characterisation is being used as
  part of a migration archetype (not just a brownfield change), pair
  the characterisation with a parity ledger so the new
  implementation's outputs are checked against the old.
  Characterisation and parity rows are authored BEFORE any
  transformation starts — the equivalence contract is the
  migration's acceptance-criteria layer.
- **`parity-ledger` (from the generation mode)** — the runnable
  pinned tests emitted by `generate-pinned-tests` become the parity
  assertions: each pinned OBSERVED value is the "old output" the new
  implementation must reproduce, so the ledger's rows are seeded from
  the same OBSERVED verbatim values the pinned tests lock.

## Refusal modes (negative constraints)

- **Refuse** to author a row whose OBSERVED outcome contains "should",
  "must", "would", "expected" — these are desired-behaviour markers,
  not observations.
- **Refuse** to author a row whose Source column is empty or vague.
- **Refuse** to mark the checklist as ready for hand-off if any row
  fails to cite file:line.
- **Refuse** to auto-generate test code in a specific framework —
  framework-specific generation is out of scope (variance is high;
  fire-phoenix stays at the behavioural-contract layer).
