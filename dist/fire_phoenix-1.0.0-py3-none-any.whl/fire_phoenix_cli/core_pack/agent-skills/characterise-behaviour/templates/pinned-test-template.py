"""Pinned characterisation tests — generated {date} for framework: {framework}.

These are CHARACTERISATION (pinning) tests generated from the
characterisation-test checklist's OBSERVED rows
(tests/characterisation/test-<surface>-checklist.md). They are the
regression fence you run BEFORE any change.

Each test asserts what the legacy code DID when run — verbatim,
quirks included — NOT what it should do. A silent None, an off-by-one,
a swallowed exception: pin it exactly as observed. Fixing the quirk is
the engineer's CONTRACT concern; this fence is what proves the fix
changed behaviour.

Discipline:
- One test per checklist row. Copy the row's OBSERVED value verbatim
  into the assertion; never normalise, round, or "clean up" it.
- Cite the row's source file:line in a `# source:` comment.
- A FAILING pinned test means behaviour changed. Investigate the
  change BEFORE "fixing" the test. Only amend an assertion when an
  L2/L3 spec explicitly says the observed behaviour must change.
"""

# TODO: import the legacy code path under characterisation.
# from legacy_pkg.module import legacy_fn


def test_pinned_returns_none_on_missing_user():
    """Example pinned test — replace with one test per checklist row.

    Pins the OBSERVED outcome for a single concrete input scenario.
    """
    # source: TBD-source — src/<module>.py:<line> (from the checklist row)
    # TODO: call the legacy code path with the row's concrete inputs.
    # observed_actual = legacy_fn(user=None)
    observed_actual = None

    # TODO: replace the right-hand side with the row's OBSERVED value,
    # copied verbatim. This asserts what the code DID, not what it should.
    assert observed_actual == None  # noqa: E711 — pins observed identity


# TODO: add one `def test_pinned_<behaviour>():` per remaining
# checklist row. Each keeps its own `# source:` file:line citation and
# asserts that row's OBSERVED value verbatim.
