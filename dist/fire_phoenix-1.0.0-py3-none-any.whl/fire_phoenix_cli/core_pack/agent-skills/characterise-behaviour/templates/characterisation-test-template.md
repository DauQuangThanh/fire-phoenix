# Characterisation test template

> Pins **OBSERVED** behaviour before any brownfield change. Never pin
> desired behaviour. See `references/brownfield-discipline.md` for
> the full rules this template encodes.

## Pattern per test row

```
Arrange:   <set up the OBSERVED pre-state — exact inputs, no "various">
Act:       <invoke the legacy code path>
Assert:    <the OBSERVED outcome — what the code DID do when run, not what it should>
Source:    <module file:line that produces the outcome>
```

## Each row MUST cite file:line

If a row cannot cite the exact code line whose behaviour it pins, the
row is speculative — drop it OR research the path further before
promoting.

## What characterisation does NOT do

- **Refactor spec.** "The function should return X" belongs in an L2
  spec or contract, not here.
- **Bug-fix spec.** "When input is negative, raise ValueError" is
  desired behaviour. Characterisation pins what currently happens
  (e.g. "currently returns -1 silently"), then the engineer's
  CONTRACT prescribes the fix.
- **Performance baseline.** If you want to pin "p99 latency is 200ms",
  that's a separate harness; this template is for functional
  characterisation.

## Verification protocol

1. Run materialised tests against the CURRENT code: every test MUST PASS.
2. If any fails, the row pins something other than observed
   behaviour → revise the row OR drop it.
3. Only after step 1 succeeds, hand off to the engineer for change.
4. Engineer's contract keeps this test file green throughout the
   change. Tests amend ONLY when the spec (L2/L3) explicitly says the
   observed behaviour must change.
