# Error-handling design checklist

Run this pass after the module structure and API contract are
drafted, before the design is handed to `unit-tests` or
`implement`. Every failure condition named in the intent
(`intent.md` failure conditions, the epic's acceptance criteria,
PRODUCT.md invariants) must have a **designed response** — not a
hope that the framework copes.

## Per failure condition

- [ ] **Named response.** The design states what the system does
      when the condition fires: reject, retry, degrade, or halt.
      "The framework handles it" needs the framework mechanism
      named and its behaviour stated.
- [ ] **User-visible message.** What the caller / user sees:
      error code, message shape, and which details are withheld
      (stack traces and internals never leak to the caller).
- [ ] **Retry / backoff decision.** Transient failures (timeout,
      5xx, lock contention) get an explicit retry policy —
      attempt count, backoff shape, and the give-up behaviour.
      Non-transient failures explicitly do NOT retry.
- [ ] **No silent swallow.** No catch block may discard an error
      without logging it and either re-raising, returning an
      error value, or degrading visibly. An empty catch is a
      design finding, not a style nit.
- [ ] **Logged with context.** The error log line carries enough
      to diagnose (correlation id, operation, input class) —
      never secrets or raw personal data.
- [ ] **AC linkage.** If the condition is user-observable, an
      AC-NNN covers it. If none does, hand the gap to the
      business-analyst — the intent layer is incomplete.

## Design-level checks

- [ ] Error shapes are part of the API contract (status codes +
      structured error body), not an implementation afterthought.
- [ ] Every module block's "Error handling" line is filled:
      exceptions raised, retry policy, fallback.
- [ ] Partial-failure behaviour is designed for multi-step
      operations: what rolls back, what is idempotent on re-run.
- [ ] Every network / IO call the design introduces has a
      timeout with a stated default.

Unresolved boxes become `TDEBT-` entries in the shared
tech-debts file — never silently skipped.
