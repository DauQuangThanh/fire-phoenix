---
name: api-docs
description: Generates API documentation from source — endpoints, RPC methods, queue
  topics with schemas and auth — from routes plus OpenAPI/proto/gql. Use when documenting
  an API or generating endpoint reference docs.
license: MIT
compatibility: Designed for agentskills.io-compatible agents.
metadata:
  author: Dau Quang Thanh
  version: '1.0'
  requires: []
---

## User Input

```text
$ARGUMENTS
```

## Audience and tone (interactive mode)

**Register first — adapt to role level.** Run as a guided, one-question-at-a-time questionnaire (yes/no first, recommend a default); skip in `FIRE_PHOENIX_AGENT_MODE=auto`. Full rules: `.fire-phoenix/references/subagents/interactive-questionnaire.md`.

## Inputs

- `.fire-phoenix/context.yml`
- `{context.paths.docs}/analysis/codebase-scan.md`
- Route modules + OpenAPI / proto / GraphQL schema files

## Outputs

- `{context.paths.docs}/analysis/api-docs.md`
- `{context.paths.docs}/analysis/api-docs.extract`

## Context Update

Does not mutate `.fire-phoenix/context.yml`.

## Handoffs

- `development-design` (architect / developer) references api-docs
  when evolving contracts.
- `security-review` uses the endpoint list for authZ review.

## AI authoring scope

**Does:** enumerate endpoints, include request / response
schemas, auth requirement, error responses, idempotency notes,
and one example per endpoint; annotate with source `file:line`.

**Does not:** invent routes; guess schemas where the code doesn't
declare them; hit live endpoints; present a constructed example
as captured traffic.

## Completeness gate

Before presenting the artefact, walk
`references/completeness-checklist.md` per endpoint: route +
method cited, auth requirement explicit (public is stated, never
implied), schema or logged gap, error shapes the code actually
produces, idempotency note, one example. An endpoint failing an
item is completed or its gap logged as an `ANALYSISDEBT-`.

Because these docs are extracted (brownfield), every documented
behaviour carries a confidence tag — `OBSERVED` with `file:line`,
`INFERRED (low|med|high confidence)` with reasoning, or
`UNKNOWN`. An error shape read from a shared handler is
`INFERRED` for a given route unless that route's path through
the handler was traced. Close with the checklist's coverage
line: endpoints found vs fully documented.

## Usage

> `<SKILL_DIR>` = the integration's skills root (e.g. `.claude/skills/`
> for Claude Code, `.codex/skills/` for Codex,
> `.cursor/skills/` for Cursor).
> Scripts live at `<SKILL_DIR>/<skill-name>/scripts/…`.

```bash
API_STYLE=rest bash <SKILL_DIR>/api-docs/scripts/bash/generate-api-docs.sh --auto
```

### Answer keys

| Key | Default |
|---|---|
| `API_STYLE` (`rest`/`graphql`/`grpc`/`trpc`/`events`) | `rest` |

## References

- `references/extraction-by-style.md` — where the authoritative
  contract lives per API style (OpenAPI, GraphQL schema, proto,
  tRPC routers, topic schemas).
- `references/completeness-checklist.md` — the per-endpoint
  completeness items, the brownfield tagging rule, and the
  coverage summary.
