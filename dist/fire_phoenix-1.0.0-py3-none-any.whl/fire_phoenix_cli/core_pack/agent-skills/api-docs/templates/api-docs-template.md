# API documentation (extracted)

**Date:** {date}
**Style:** {style}

> Extracted docs, not a specification: every documented
> behaviour carries `OBSERVED` (with `file:line`), `INFERRED
> (low|med|high confidence)`, or `UNKNOWN`.

## Endpoints

<!-- Idempotency: safe / idempotent / non-idempotent (+ retry
     detection: idempotency key, upsert, none). -->

| Method | Path | Source | Auth | Idempotency | Notes |
|---|---|---|---|---|---|
| GET | /api/v1/things | `src/api/things.ts:14` | user | safe | list |
| POST | /api/v1/things | `src/api/things.ts:40` | user | non-idempotent — no key | create |

## Schemas

```ts
// Extracted from types at src/types/thing.ts
type Thing = { id: string; name: string; createdAt: string }
type NewThing = Omit<Thing, 'id' | 'createdAt'>
```

## Auth

- Middleware: `src/auth/middleware.ts:12` — OIDC Bearer
- Public endpoints: `/health`, `/api/public/*`

## Error responses

| Status | Seen in | Payload |
|---|---|---|
| 400 | validation failure | `{error, details}` |
| 401 | missing / expired token | `{error}` |
| 403 | role-based | `{error}` |
| 404 | not found | `{error}` |
| 500 | handler | `{error, requestId}` |

## Examples

<!-- One request/response pair per endpoint. Constructed
     examples are marked "illustrative — constructed from
     schema", never presented as captured traffic. -->

```http
POST /api/v1/things
{ "name": "example" }        ← illustrative — constructed from schema

201 { "id": "…", "name": "example", "createdAt": "…" }
```

## Coverage

- Endpoints found: <N>; fully documented per the completeness
  checklist: <M>; gaps logged below.

## Gaps / unknowns

- Logged as `ANALYSISDEBT-NN`.
