# API docs completeness checklist

Run this checklist per endpoint (or RPC method / queue topic)
before the artefact is presented. An endpoint missing an item is
either completed or its gap is logged as an `ANALYSISDEBT-` —
never left silently blank. Extraction tactics per API style live
in `extraction-by-style.md`.

## Per-endpoint items

1. **Route + method** cited to `file:line` — `OBSERVED`.
2. **Auth requirement** stated explicitly. "Public" is a valid
   answer but must be tagged (e.g. "public — OBSERVED, no auth
   middleware on this route at `file:line`"), never implied by
   omission.
3. **Request / response schema** extracted from declared types or
   schema files. Where the code declares nothing (`any`, dynamic
   payloads), record the endpoint without the schema and log the
   gap.
4. **Error shapes** listed — at minimum the 4xx/5xx statuses the
   code can actually produce, with payload shape. An error shape
   read from a shared handler applies to a specific route as
   `INFERRED` unless that route's path through the handler was
   traced.
5. **Idempotency note** — safe / idempotent / non-idempotent,
   and whether retries are detectable (idempotency key,
   natural-key upsert, none). For queue topics: at-least-once vs
   at-most-once delivery assumptions.
6. **One example** request/response pair. Examples constructed
   from the schema (not captured from live traffic) are marked
   "illustrative — constructed from schema", never presented as
   observed traffic.

## Brownfield tagging rule

Documented behaviour carries the confidence tags throughout:

- **`OBSERVED`** — read directly in source / schema, `file:line`
  cited.
- **`INFERRED (low|med|high confidence)`** — implied by
  convention, framework default, or a shared code path not fully
  traced. State the reasoning.
- **`UNKNOWN`** — the code doesn't answer it. Surface as an open
  question; never guess.

## Coverage summary

Close the artefact with a coverage line: endpoints found vs
fully documented (all six items), with remaining gaps logged as
debts.
