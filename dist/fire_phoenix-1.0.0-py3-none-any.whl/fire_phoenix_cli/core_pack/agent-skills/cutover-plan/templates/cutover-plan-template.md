# Cutover plan — {slug}

> Authored on {date}. This is the **per-slice cutover protocol** for a
> migration slice: it gates the switch from the old path to the new one
> behind rehearsal parity evidence, a live shadow/canary comparison, a
> **named-approver sign-off**, an old-path freeze, and a scheduled
> decommission. A cutover with no named approver or no decommission date
> is invalid and is never authored. Discipline:
> `references/cutover-protocol.md`.

## Slice scope

- **Slice:** {slug}
- **Old path (retired):** `<concrete old module(s)/path(s)>`
- **New path (cut in):** `<concrete new module(s)/path(s)>`
- **Parity ledger:** `tests/parity/{slug}-ledger.md` (the `parity-ledger`
  artefact this cutover consumes).

## Rehearsal record

At least **N rehearsals** (N ≥ 1; default 2) exercise the cutover
end to end in a non-production environment before the real switch. Each
rehearsal cites the parity evidence that backed it.

| # | Date | Environment | Parity evidence (ledger pointer) | Outcome |
|---|---|---|---|---|
| 1 | `<YYYY-MM-DD>` | `<staging/…>` | `tests/parity/{slug}-ledger.md §Progress` | pass / fail |

- A rehearsal that fails resets the count; the next real cutover requires
  a fresh clean rehearsal.

## Shadow / canary comparison plan

Before flipping all traffic, run old and new **side by side on live
input** and compare outputs:

- **Shadow:** mirror live requests to the new path; compare against the
  old path's response; log divergences. No user sees the new path yet.
- **Canary:** route a small, named percentage of live traffic to the new
  path; watch the divergence + error signals; ramp only on green.
- Divergences are triaged against the parity ledger — an untraced
  divergence is a `MISMATCH`, not an acceptable difference.

## Cutover gate

> **The gate.** The cutover proceeds ONLY after
> **{approver}** signs off in writing. No self-approval; no silent flip.

| Gate condition | Status |
|---|---|
| N-rehearsal record complete, last rehearsal green | ☐ |
| Shadow/canary comparison shows no untraced divergence | ☐ |
| Every parity-ledger row is `automated` or `different-but-traced` | ☐ |
| Rollback path verified (how to revert to the old path) | ☐ |
| Named approver **{approver}** sign-off recorded | ☐ |

**The cutover is BLOCKED while ANY parity-ledger row is an unresolved
mismatch.** Resolve or supersede the row (per `parity-ledger`) before the
gate can pass — the gate never opens over a red ledger.

## Old-path freeze declaration

Once the gate passes and the switch is made, the old path is **frozen**:

- No new features, no behaviour changes on the old path — bug-fix-only,
  and only for issues that block the new path's rollback.
- The freeze is declared here with a date and is visible to the whole
  team; changes after the freeze require the approver's explicit
  exception.
- **The parity ledger never closes while the old path is still live.** It
  closes only after decommission — until then it remains the system of
  record proving old and new agree.

- **Freeze declared:** `<YYYY-MM-DD>` — old path `<module>` is
  bug-fix-only from this date.

## Decommission

- **Decommission date:** **{decommission_date}**
- On this date the old path is removed: code deleted, infrastructure torn
  down, routes withdrawn, and the parity ledger closed.
- A decommission date is **non-negotiable** — a cutover with no
  decommission date leaves two live implementations forever (the worst
  migration outcome). If the date is not yet certain, the cutover is not
  ready to author.
- **Post-decommission check:** confirm no caller still references the old
  path; archive the parity ledger alongside this plan.
