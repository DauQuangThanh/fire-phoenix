# Cutover protocol — per-slice migration reference

Self-contained background for the `cutover-plan` skill. The rules below
define what the skill enforces; AI sessions that invoke this skill must
respect them.

## Cutover is per slice, never big-bang

A strangler-fig migration cuts over one seam at a time (see
`seam-analysis`). Each slice gets its own cutover plan so a failure is
contained to one slice and the rollback is small. A single big-bang
cutover of the whole system has no safe rollback and no bounded blast
radius — the skill authors per-slice protocols only.

## The rehearsal → shadow/canary → gate → freeze → decommission sequence

1. **N rehearsals.** Exercise the cutover end to end in a non-production
   environment, each backed by parity evidence from the ledger. A failed
   rehearsal resets the count.
2. **Shadow / canary.** Run old and new side by side on live input.
   Shadow mirrors traffic (no user impact); canary routes a small named
   percentage. Ramp only while divergence + error signals stay green.
3. **Named-approver gate.** A human named in the plan signs off. The gate
   never opens while any parity-ledger row is an unresolved mismatch.
4. **Old-path freeze.** Post-switch, the old path is bug-fix-only. The
   freeze is declared, dated, and team-visible.
5. **Decommission.** On the scheduled date the old path is removed and
   the parity ledger is closed.

## Why the approver is non-negotiable

A cutover changes what real users hit. Someone must own that decision by
name — accountability that survives the session, not an AI's silent flip.
The skill REFUSES to author a cutover with no named approver: an
unapproved cutover is an ungoverned production change, which the IDD
audit-trail invariant forbids. The approver is not the author (no
self-approval); the skill drafts the protocol, the human owns the gate.

## Why the decommission date is non-negotiable

A migration without a decommission date never ends — it leaves two live
implementations in parallel indefinitely, doubling maintenance, drifting
apart, and eroding the very parity the migration proved. The date is the
commitment that the old path *will* go away. The skill REFUSES to author
a cutover with no decommission date: an open-ended cutover is not a
migration, it is a permanent fork.

## The parity ledger is the gate's evidence

The `cutover-plan` skill consumes `parity-ledger` output. The gate reads
the ledger's Progress section:

- Every required row must be `automated` (old and new agree) or
  `different-but-traced` (divergence authorised by a cited spec section).
- A row that is `blocked`, `human-finished`-but-still-mismatching, or an
  untraced `MISMATCH` **blocks the gate**. Resolve or supersede it (per
  the ledger's immutable-rows discipline) before the gate can pass.

## The ledger stays open until decommission

The parity ledger does **not** close at the moment of cutover. While the
old path is still live (frozen, but running), the ledger remains the
system of record proving old and new continue to agree. It closes only
at decommission, when the old path is gone and there is nothing left to
compare. Closing the ledger early throws away the evidence that would
catch a post-cutover regression before the old path is removed.
