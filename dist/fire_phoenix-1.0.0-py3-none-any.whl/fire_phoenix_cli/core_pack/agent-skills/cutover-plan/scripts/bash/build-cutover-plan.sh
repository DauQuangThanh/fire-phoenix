#!/usr/bin/env bash
set -e
SCRIPT_DIR="$(CDPATH="" cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=common.sh
source "$SCRIPT_DIR/common.sh"
fire_phoenix_parse_standard_args "$@"
set -- "${FIRE_PHOENIX_REST_ARGS[@]}"
if [ "${1:-}" = "--help" ]; then echo "Usage: build-cutover-plan.sh [--auto] <slice-slug>  (requires CP_APPROVER + CP_DECOMMISSION_DATE)"; exit 0; fi
read_context
SKILL_DIR="$(CDPATH="" cd "$SCRIPT_DIR/../.." && pwd)"
SLUG="${1:-}"
if [ -z "$SLUG" ]; then echo "Error: slice slug required (concrete, kebab-case). Usage: build-cutover-plan.sh <slice-slug>" >&2; exit 1; fi
# Load-bearing refusal: a cutover with no named approver OR no decommission
# date is invalid — REFUSE before writing anything.
APPROVER="$(resolve_auto CP_APPROVER "")" || true
DECOMMISSION_DATE="$(resolve_auto CP_DECOMMISSION_DATE "")" || true
if [ -z "$APPROVER" ] || [ -z "$DECOMMISSION_DATE" ]; then
  echo "Error: a cutover requires BOTH a named approver (CP_APPROVER) and a decommission date (CP_DECOMMISSION_DATE). Refusing to author a cutover without them." >&2
  exit 1
fi
DIR="$FIRE_PHOENIX_REPO_ROOT/$FIRE_PHOENIX_DOCS_DIR/migration"
OUT="$DIR/cutover-${SLUG}.md"
if [ "${FIRE_PHOENIX_DRY_RUN:-0}" = "1" ]; then echo "[dry-run] would write: $OUT"; exit 0; fi
if [ -f "$OUT" ]; then echo "Cutover plan exists: $OUT" >&2; exit 2; fi
if ! confirm_before_write "Scaffold cutover plan at $OUT."; then echo "Aborted." >&2; exit 1; fi
mkdir -p "$DIR"
sed -e "s|{date}|$(date +%Y-%m-%d)|g" -e "s|{slug}|$SLUG|g" -e "s|{approver}|$APPROVER|g" -e "s|{decommission_date}|$DECOMMISSION_DATE|g" "$SKILL_DIR/templates/cutover-plan-template.md" > "$OUT"
write_extract "$OUT" "SLICE=$SLUG" "APPROVER=$APPROVER" "DECOMMISSION_DATE=$DECOMMISSION_DATE" > /dev/null
echo "Wrote $OUT"
