#!/usr/bin/env pwsh
param([switch]$Auto, [switch]$DryRun, [string]$Answers, [switch]$Help, [Parameter(Position=0)][string]$Slug)
$ErrorActionPreference = 'Stop'
$ScriptDir = Split-Path -Parent $PSCommandPath
. (Join-Path $ScriptDir 'common.ps1')
if ($Auto)    { $env:FIRE_PHOENIX_AUTO = '1' }
if ($DryRun)  { $env:FIRE_PHOENIX_DRY_RUN = '1' }
if ($Answers) { $env:FIRE_PHOENIX_ANSWERS = $Answers; Import-FirePhoenixAnswers -Path $Answers }
if ($Help) { "Usage: build-cutover-plan.ps1 -Auto <slice-slug>  (requires CP_APPROVER + CP_DECOMMISSION_DATE)" | Write-Host; exit 0 }
$ctx = Read-Context
$SkillDir = (Resolve-Path -LiteralPath (Join-Path $ScriptDir '..\..')).Path
if ([string]::IsNullOrEmpty($Slug)) { Write-Error "slice slug required (concrete, kebab-case)."; exit 1 }
# Load-bearing refusal: a cutover with no named approver OR no decommission
# date is invalid — REFUSE before writing anything.
$Approver = Resolve-Auto -Key 'CP_APPROVER' -Default ''
$DecommissionDate = Resolve-Auto -Key 'CP_DECOMMISSION_DATE' -Default ''
if ([string]::IsNullOrEmpty($Approver) -or [string]::IsNullOrEmpty($DecommissionDate)) {
    Write-Error "a cutover requires BOTH a named approver (CP_APPROVER) and a decommission date (CP_DECOMMISSION_DATE). Refusing to author a cutover without them."
    exit 1
}
$Dir = Join-Path (Join-Path $ctx.REPO_ROOT $ctx.DOCS_DIR) 'migration'
$Out = Join-Path $Dir "cutover-$Slug.md"
if ($env:FIRE_PHOENIX_DRY_RUN -eq '1') { Write-Host ("[dry-run] would write: {0}" -f $Out); exit 0 }
if (Test-Path -LiteralPath $Out) { Write-Error "Cutover plan exists: $Out"; exit 2 }
if (-not (Confirm-BeforeWrite -Message "Scaffold cutover plan at $Out.")) { Write-Error 'Aborted.'; exit 1 }
New-Item -ItemType Directory -Force -Path $Dir | Out-Null
$tpl = Join-Path $SkillDir 'templates\cutover-plan-template.md'
$c = Get-Content -LiteralPath $tpl -Raw
$c = $c.Replace('{date}', (Get-Date -Format 'yyyy-MM-dd')).Replace('{slug}', $Slug).Replace('{approver}', $Approver).Replace('{decommission_date}', $DecommissionDate)
Set-Content -LiteralPath $Out -Value $c
Write-Extract -ArtefactPath $Out "SLICE=$Slug" "APPROVER=$Approver" "DECOMMISSION_DATE=$DecommissionDate" | Out-Null
Write-Host ("Wrote {0}" -f $Out)
