---
name: cutover-plan
description: Authors a per-slice cutover protocol — parity evidence, shadow/canary
  comparison, a named-approver gate, old-path freeze, decommission date. Use when
  scheduling a slice's cutover after parity-ledger.
license: MIT
compatibility: Designed for agentskills.io-compatible agents.
metadata:
  author: Dau Quang Thanh
  version: '1.0'
  requires: [parity-ledger]
---

## User Input

```text
$ARGUMENTS
```

You **MUST** consider the user input before proceeding (if not empty).

## Pre-Execution Checks

1. **Confirm a named approver.** A cutover changes what real users hit;
   someone must own that decision BY NAME. REJECT a blank, a role
   ("the team"), or "TBD" — the gate needs an accountable human. No
   named approver → the skill REFUSES to author the cutover.
2. **Confirm a decommission date.** A migration with no decommission
   date never ends — two live implementations forever. REJECT "later" /
   "eventually". No decommission date → the skill REFUSES.
3. **Confirm the slice scope.** Pin the CONCRETE old module(s) being
   retired and the CONCRETE new module(s) cutting in — not "the old
   system". Vague scope is rejected.
4. **Confirm the parity ledger.** Point at the `parity-ledger` artefact
   for this slice. A slice with unresolved ledger mismatches cannot pass
   the gate; say so up front.

## Audience and tone (interactive mode)

**Register first — adapt to role level.** Run as a guided, one-question-at-a-time questionnaire (yes/no first, recommend a default); skip in `FIRE_PHOENIX_AGENT_MODE=auto`. Full rules: `references/interactive-questionnaire.md`.

## Inputs

- `.fire-phoenix/context.yml`
- The migration **slice slug** (kebab-case), plus the concrete old →
  new module scope.
- **Named approver** for the cutover gate (required — no default).
- **Decommission date** for the old path (required — no default).
- The slice's `parity-ledger` output (`tests/parity/<slug>-ledger.md`),
  whose Progress section the gate reads.

## Outputs

- `{context.paths.docs}/migration/cutover-<slug>.md` — the per-slice
  cutover protocol: slice scope, rehearsal record, shadow/canary
  comparison plan, the named-approver cutover gate, the old-path freeze
  declaration, and the decommission date.

## Context Update

Does not mutate `.fire-phoenix/context.yml`. The cutover plan under
`{context.paths.docs}/migration/` is the only on-disk side-effect.

## Handoffs

- **`parity-ledger`** — consumed: the gate reads the slice's ledger
  Progress section; an unresolved mismatch blocks the gate.
- **`seam-analysis`** — pairs on slices: the seam plan defines which
  slices exist and their order; this skill authors the cutover for one.
- **`reconciliation-harness`** — pairs on data: for a data-migration
  slice, reconciliation evidence backs the rehearsal record before the
  gate.

## AI authoring scope

**Does:** author a per-slice cutover protocol from the slice scope,
approver, decommission date, and parity ledger; require an N-rehearsal
record, a shadow/canary live-comparison plan, a named-approver gate, an
old-path freeze declaration, and a decommission date; state that the gate
is BLOCKED while any parity-ledger row is an unresolved mismatch and that
the ledger stays open until decommission.

**Does not:** approve the cutover (that is the named human — no
self-approval); flip traffic, freeze, or decommission anything itself
(the plan is the contract, execution is the engineer's); author a cutover
with no named approver or no decommission date (a hard refusal); decide
the slice boundaries (that is `seam-analysis`).

## Usage

> `<SKILL_DIR>` = the integration's skills root (e.g. `.claude/skills/`
> for Claude Code, `.codex/skills/` for Codex, `.cursor/skills/` for
> Cursor). Scripts live at
> `<SKILL_DIR>/<skill-name>/scripts/…`.

```bash
CP_APPROVER="Jane Doe" CP_DECOMMISSION_DATE=2026-12-31 \
  bash <SKILL_DIR>/cutover-plan/scripts/bash/build-cutover-plan.sh --auto <slice-slug>
```

### Answer keys

| Key | Default |
|---|---|
| (positional) `<slice-slug>` | required |
| `CP_APPROVER` | required — no default (refuses if empty) |
| `CP_DECOMMISSION_DATE` | required — no default (refuses if empty) |
