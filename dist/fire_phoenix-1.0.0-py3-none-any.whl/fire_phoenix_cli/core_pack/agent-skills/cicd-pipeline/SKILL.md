---
name: cicd-pipeline
description: Drafts CI/CD pipeline design — stages, triggers, quality-gate integration,
  artefact flow — as a provider-neutral doc plus a YAML skeleton. Use when designing
  a pipeline for GitHub Actions, GitLab CI, etc.
license: MIT
compatibility: Designed for agentskills.io-compatible agents.
metadata:
  author: Dau Quang Thanh
  version: '1.0'
  requires: []
---

## User Input

```text
$ARGUMENTS
```

## Audience and tone (interactive mode)

**Register first — adapt to role level.** Run as a guided, one-question-at-a-time questionnaire (yes/no first, recommend a default); skip in `FIRE_PHOENIX_AGENT_MODE=auto`. Full rules: `.fire-phoenix/references/subagents/interactive-questionnaire.md`.

## Inputs

- `.fire-phoenix/context.yml`
- `{context.paths.docs}/testing/*/quality-gates.md` (gates per feature)
- `{context.paths.docs}/architecture/c4-container.md` (build units)

## Outputs

- `{context.paths.docs}/operations/cicd.md` — design doc.
- `{context.paths.docs}/operations/cicd.extract`
- `assets/ci-pipeline.sample.yml` — provider-specific starter
  (GitHub Actions / GitLab CI / Azure Pipelines / CircleCI /
  Buildkite).

## Context Update

Does not mutate `.fire-phoenix/context.yml`.

## Handoffs

- `deployment-strategy` references the pipeline's release stage.

## AI authoring scope

**Does:** design stage ordering (lint → unit → integration →
security → build → deploy-to-staging → e2e → approve → deploy-to-prod),
draft a YAML skeleton matching the chosen provider.

**Does not:** provision CI; push YAML to the repo; run pipelines.

## Pipeline gates

Every pipeline this skill drafts carries the required-gate
checklist in `references/pipeline-gates.md`: lint + format, type
check, tests, **coverage on changed files** (not the repo
average), security / integrity scans, immutable build. Stages are
ordered fail-fast — cheap checks first, expensive tails last —
for the feedback-economics rationale spelled out there.

Non-negotiable: **a required gate is never bypassed silently.** A
bypass is a recorded decision (who, which gate, why, what re-arms
it) in the decision log, plus an `OPSDEBT-` if the gate stays
weakened. Provider trade-offs live in `references/providers.md`.

## Usage

> `<SKILL_DIR>` = the integration's skills root (e.g. `.claude/skills/`
> for Claude Code, `.codex/skills/` for Codex,
> `.cursor/skills/` for Cursor).
> Scripts live at `<SKILL_DIR>/<skill-name>/scripts/…`.

```bash
CI_PROVIDER=github-actions bash <SKILL_DIR>/cicd-pipeline/scripts/bash/draft-cicd.sh --auto
```

### Answer keys

| Key | Meaning | Default |
|---|---|---|
| `CI_PROVIDER` | github-actions / gitlab-ci / azure-pipelines / circleci / buildkite | `github-actions` |
| `CI_REQUIRES_MANUAL_RELEASE` | `true` / `false` | `true` |
