# Pipeline gates — required checks and ordering

A pipeline is the project's quality gates made mechanical. Every
gate below maps to a row in the project's standards / quality-gate
artefacts; a pipeline stage with no corresponding gate is
decoration, and a gate with no pipeline stage is a promise.

## Required gates

- [ ] **Lint + format** — zero warnings on changed files.
- [ ] **Type check** — on the languages that have one; ratcheted
      per module rather than all-or-nothing.
- [ ] **Tests** — the full suite, on every supported platform and
      shell the project claims.
- [ ] **Coverage on changed files** — measure the diff, not the
      repo average: a repo-wide number lets untested new code hide
      behind well-tested old code. Exemplar: a `diff-cover` job
      comparing against the main branch with a fail-under
      threshold (this repo's own CI gates changed-file line
      coverage at ≥ 80%). The threshold itself is the user's
      decision, recorded as such.
- [ ] **Security scan** — SAST + secret scan; fails on Critical.
- [ ] **Integrity checks** — lockfile / manifest / artefact
      integrity where the project ships assets.
- [ ] **Build** — one immutable artefact per merge, tagged by
      git-sha; releases redeploy that artefact, never rebuild.

## Fail-fast ordering

Order stages cheap → expensive, most-likely-to-fail first:

1. Lint / format / type check — seconds; catches the majority of
   broken pushes before a runner spins up anything heavy.
2. Unit tests — minutes; no external services.
3. Integration tests / security scan — needs stubs or services.
4. Build + deploy-to-staging + e2e — the expensive tail.

The rationale is feedback economics: a developer who learns about
a lint failure in 30 seconds fixes it in the same sitting; the
same failure after a 20-minute e2e run costs a context switch.
Never gate a cheap check behind an expensive one.

## The bypass rule

**A required gate is never bypassed silently.** Skipping,
soft-failing, or force-merging past a red gate is sometimes the
right call (emergency hotfix, known-flaky check) — but it is a
**recorded decision**: who bypassed, which gate, why, and what
restores the gate. Log it in the project's decision log and as an
`OPSDEBT-` if the gate stays weakened. A gate that can be quietly
skipped is not a gate; it is a suggestion.

Corollaries:

- No `continue-on-error` on a required gate without a written
  waiver.
- A gate downgraded to warn-only keeps a dated debt entry naming
  the condition that re-arms it.
- Every stage has a timeout — a hung gate blocks honestly, not
  indefinitely.
