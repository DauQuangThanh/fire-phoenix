---
name: infrastructure-plan
description: Drafts an infrastructure-as-code plan — cloud accounts, networks, compute/storage/database,
  IAM boundaries — as a tool-neutral design plus a starter module. Use when planning
  cloud infrastructure.
license: MIT
compatibility: Designed for agentskills.io-compatible agents.
metadata:
  author: Dau Quang Thanh
  version: '1.0'
  requires: []
---

## User Input

```text
$ARGUMENTS
```

## Audience and tone (interactive mode)

**Register first — adapt to role level.** Run as a guided, one-question-at-a-time questionnaire (yes/no first, recommend a default); skip in `FIRE_PHOENIX_AGENT_MODE=auto`. Full rules: `.fire-phoenix/references/subagents/interactive-questionnaire.md`.

## Inputs

- `.fire-phoenix/context.yml`
- `{context.paths.docs}/architecture/intake.md` (cloud preference,
  compliance regime)
- `{context.paths.docs}/architecture/c4-container.md` (compute +
  storage needs)

## Outputs

- `{context.paths.docs}/operations/infra.md`
- `{context.paths.docs}/operations/infra.extract`
- `assets/infra-starter.tf` or `assets/infra-starter.bicep` —
  tool-specific starter module.

## Context Update

Does not mutate `.fire-phoenix/context.yml`.

## Handoffs

- `containerization` reads compute decisions.
- `deployment-strategy` reads environment layout.
- `cicd-pipeline` reads deploy targets.

## AI authoring scope

**Does:** design the resource tree (accounts / subscriptions →
networks → compute / storage / data), IAM boundaries, per-env
separation. Draft a starter module in the chosen tool.

**Does not:** run `terraform apply`, create cloud resources,
store credentials.

## Review checklist

Before the plan is handed on, walk
`references/review-checklist.md`: least privilege (one role per
service, no wildcards), secret handling (managed store, state
treated as sensitive), network boundaries cross-checked against
the architect's C4 trust boundaries (a mismatch is a finding for
the architect), cost visibility (tagging + attributable spend),
and environment parity (same module shape, different variables).
Unmet items become `OPSDEBT-` entries. Tool trade-offs live in
`references/tool-comparison.md`.

## Usage

> `<SKILL_DIR>` = the integration's skills root (e.g. `.claude/skills/`
> for Claude Code, `.codex/skills/` for Codex,
> `.cursor/skills/` for Cursor).
> Scripts live at `<SKILL_DIR>/<skill-name>/scripts/…`.

```bash
INFRA_TOOL=terraform INFRA_CLOUD=aws bash <SKILL_DIR>/infrastructure-plan/scripts/bash/draft-infra.sh --auto
```

### Answer keys

| Key | Default |
|---|---|
| `INFRA_TOOL` (`terraform`/`opentofu`/`bicep`/`pulumi`/`cloudformation`) | `terraform` |
| `INFRA_CLOUD` (`aws`/`azure`/`gcp`/`on-prem`/`multi`) | `aws` |
| `INFRA_ENVS` | `dev,staging,prod` |
