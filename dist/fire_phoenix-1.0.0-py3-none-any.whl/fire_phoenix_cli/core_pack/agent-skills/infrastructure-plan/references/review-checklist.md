# Infrastructure plan — review checklist

Walk this before the plan is handed on. Each unmet item is an
`OPSDEBT-`, not a silent gap. The checklist reviews the *design*;
no cloud CLI runs.

## Least privilege

- [ ] One role per service; no shared "app role" across services.
- [ ] No wildcard actions or resources in any IAM policy the
      starter module ships.
- [ ] Human access federated via the IdP with short-lived
      credentials; no long-lived user keys.
- [ ] Break-glass access exists, is named, and is audited.

## Secret handling

- [ ] Every secret lives in the managed secret store; none in
      environment variables at rest, IaC variables, or state
      files.
- [ ] Rotation owner named per secret class.
- [ ] IaC state itself treated as sensitive (remote backend,
      encrypted, access-controlled) — state files leak secrets.

## Network boundaries

- [ ] Public subnets carry ingress only; compute + data are
      private.
- [ ] Every network boundary in the plan corresponds to a trust
      boundary on the architect's C4 container diagram — and vice
      versa. A boundary present in one artefact and absent in the
      other is a finding for the architect, not a thing to patch
      silently.
- [ ] Egress is deliberate: services that need no outbound
      internet access do not have it.

## Cost visibility

- [ ] Every resource is tagged with owner + environment +
      service so spend is attributable.
- [ ] A budget alarm (or equivalent) is planned per environment —
      the amount is the user's decision, recorded as such.
- [ ] The plan names its single most expensive resource class and
      the signal that would prompt resizing.

## Environment parity

- [ ] Environments differ by size and data, not by shape — same
      module, different variables.
- [ ] Anything that exists only in production (a manual fix, a
      console-clicked resource) is either codified or logged as
      an `OPSDEBT-`.
- [ ] Staging data policy stated (synthetic / anonymised subset —
      never raw production data).
