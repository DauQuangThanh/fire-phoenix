---
name: bug-triage
description: Triages open bugs into fix-now / next-sprint / defer / won't-fix buckets
  from severity, priority, age, and cost. Use when prioritising a bug backlog or preparing
  a bug-fix sprint.
license: MIT
compatibility: Designed for agentskills.io-compatible agents.
metadata:
  author: Dau Quang Thanh
  version: '1.0'
  requires: []
---

## User Input

```text
$ARGUMENTS
```

## Audience and tone (interactive mode)

**Register first — adapt to role level.** Run as a guided, one-question-at-a-time questionnaire (yes/no first, recommend a default); skip in `FIRE_PHOENIX_AGENT_MODE=auto`. Full rules: `.fire-phoenix/references/subagents/interactive-questionnaire.md`.

## Inputs

- `.fire-phoenix/context.yml`
- `{context.paths.docs}/bugs/BUG-*.md`
- `{context.paths.docs}/bugs/change-register.md` (closed bugs)

## Outputs

- `{context.paths.docs}/bugs/triage.md` — overwrites per run
- `{context.paths.docs}/bugs/triage.extract`

## Context Update

Does not mutate `.fire-phoenix/context.yml`.

## Handoffs

- `regression-tests` produces tests for bugs marked fix-now.
- `change-log` records each fix as the bug-fixer closes.
- The PO / business-analyst owns the class-(b) intent decision
  (see below); triage flags (b) bugs as blocked-on-intent until
  that decision is recorded.

## AI authoring scope

**Does:** read open bug files, group by bucket (per
`references/triage-rubric.md` — ordered rules, severity ×
frequency matrix), assign each bug its three-way class (per the
rubric's classification section) with reproduction +
classification evidence, fill the root-cause-known? and AC-linked?
columns, propose an order, call out stale bugs (open > 30 days)
and aging fix-now bugs per the rubric's escalation guideline.

**Does not:** close bugs, reassign, decide won't-fix without
the user, or make the class-(b) intent call — whether an
undocumented "keep" behaviour may change is a human (PO / BA)
decision, and it comes before any fix is scheduled.

## Three-way classification (routing)

Buckets decide *when*; the class decides *how the fix is framed*:

- **(a) violates stated intent** — the fix's task contract cites
  the violated invariant / AC-NNN.
- **(b) undocumented behaviour previously classified "keep"** —
  intent decision FIRST; the fix may in fact be a spec change,
  and behaviour someone depends on is never changed silently.
  **The (b) call is human-owned** (PO / BA); the skill drafts the
  evidence, never the decision.
- **(c) regression against an AC** — regression test first (it
  must fail on the current code), then the fix.

Full definitions live in `references/triage-rubric.md`.

## Usage

> `<SKILL_DIR>` = the integration's skills root (e.g. `.claude/skills/`
> for Claude Code, `.codex/skills/` for Codex,
> `.cursor/skills/` for Cursor).
> Scripts live at `<SKILL_DIR>/<skill-name>/scripts/…`.

```bash
bash <SKILL_DIR>/bug-triage/scripts/bash/triage.sh --auto
```

### Answer keys

| Key | Meaning | Default |
|---|---|---|
| `BT_STALE_DAYS` | threshold (days) above which a bug is "stale" | `30` |
