# Triage rubric

Apply in order; the first bucket a bug lands in is where it goes.

1. **Critical severity OR active incident** → Fix now.
2. **Critical priority (customer-facing + visible)** → Fix now.
3. **High severity with workaround** → Next sprint.
4. **Medium severity + high recurrence** → Next sprint.
5. **Low severity + visible** → Defer.
6. **Low severity + low recurrence + no business case** → Won't
   fix (propose to PO; user confirms).

## Severity × frequency matrix

When the ordered rules above don't settle a bug, read the cell
where severity (from the bug file) meets frequency / user impact
(how many users hit it, how often — from evidence, not guesswork).
The ordered rules win when the two disagree.

| Severity ↓ / Frequency → | Most users / every run | Some users / often | Few users / rare |
|---|---|---|---|
| **Critical** | Fix now | Fix now | Fix now |
| **High** | Fix now | Next sprint | Next sprint |
| **Medium** | Next sprint | Next sprint | Defer |
| **Low** | Defer | Defer | Won't fix (propose) |

Severity bands match the bug-report skill's
`references/severity-vs-priority.md`; keep the two files in step.

## Classification — how the bug relates to intent

Independent of bucket, every bug gets one of three classes; the
class routes the fix:

- **(a) Violates stated intent.** The bug contradicts a written
  invariant or acceptance criterion → the fix's contract cites
  the violated invariant / AC-NNN.
- **(b) Undocumented behaviour previously classified "keep".**
  Someone may depend on today's behaviour → the intent decision
  comes first, and it is **human-owned** (PO / BA) — the "fix"
  may in fact be a spec change. Never silently change behaviour
  someone depends on.
- **(c) Regression against an AC.** Behaviour that once satisfied
  an AC no longer does → regression test first (failing on the
  current code), then the fix.

Triage drafts the reproduction and classification evidence for
each class; a (b) bug stays out of the fix-now queue until its
intent decision is recorded.

## Aging — escalation guideline

Open bugs age; each bucket has a clock. The day counts below are
**per-project guidelines to agree with the team**, not fixed
numbers — record the agreed values in the triage header:

- A **fix-now** bug (critical / blocker) still open after the
  agreed escalation window (suggested starting point: 2 working
  days) escalates to the PO / incident owner. A blocker that sits
  is either not a blocker or not staffed — triage must say which.
- A **next-sprint** bug still open after one full sprint is
  re-triaged, not rolled over silently.
- Any bug with no activity beyond the stale threshold
  (`BT_STALE_DAYS`, default 30) lands in the stale list below.

## What moves a bug between buckets

- A bug can **escalate** when new evidence lands (more users
  affected, regulatory implication, data loss reveal).
- A bug can **deescalate** when a workaround ships or the calling
  surface is deprecated.
- Movement is recorded as a comment on the bug file, never silently.

## Stale

- Open bug with no activity in > 30 days (configurable).
- Triage should decide: escalate, defer, or close with rationale.
- Never silently let a bug drift.
