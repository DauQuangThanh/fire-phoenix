# Bug Triage

**Date:** {date}
**Stale threshold:** {stale_days} days

## Buckets

### 🔴 Fix now (this sprint / incident window)

| Bug | Severity | Priority | Age | Class | Root cause known? | AC-linked? | Notes |
|---|---|---|:-:|:-:|---|---|---|
| BUG-NN | Critical | Critical | 3d | (a) | no — isolate first | AC-012 | outage; ongoing |

### 🟡 Next sprint

| Bug | Severity | Priority | Age | Class | Root cause known? | AC-linked? | Notes |
|---|---|---|:-:|:-:|---|---|---|

### 🟢 Defer (backlog)

| Bug | Severity | Priority | Age | Class | Root cause known? | AC-linked? | Notes |
|---|---|---|:-:|:-:|---|---|---|

### ⚪ Won't fix (propose — confirm with PO)

| Bug | Rationale |
|---|---|
| BUG-NN | low severity + low incidence; tracked in known-issues |

## Stale bugs (open > {stale_days} days)

- BUG-NN — needs a fresh owner or a downgrade

<!-- Column guide: "Class" is the three-way classification from
     the rubric — (a) violates stated intent, (b) undocumented
     behaviour previously kept (human intent decision FIRST;
     blocked-on-intent until recorded), (c) regression against an
     AC (regression test first). "Root cause known?" is yes (point
     at the RCA note in the bug file) or no (isolate first — see
     the bug-fixer's RCA procedure). "AC-linked?" is the AC-NNN
     the bug violates, or "none" (candidate failure-path AC for
     the business-analyst). -->
