---
name: c4-diagrams
description: Authors C4 model diagrams (Context / Container / Component) as Mermaid
  flowcharts, one file per zoom level. Use when creating architecture diagrams or
  visualising system structure.
license: MIT
compatibility: Designed for agentskills.io-compatible agents.
metadata:
  author: Dau Quang Thanh
  version: '1.0'
  requires: []
---

## User Input

```text
$ARGUMENTS
```

## Audience and tone (interactive mode)

**Register first — adapt to role level.** Run as a guided, one-question-at-a-time questionnaire (yes/no first, recommend a default); skip in `FIRE_PHOENIX_AGENT_MODE=auto`. Full rules: `.fire-phoenix/references/subagents/interactive-questionnaire.md`.

## Inputs

- `.fire-phoenix/context.yml`
- `{context.paths.docs}/architecture/intake.md`
- `{context.governance.adr_dir}/NNNN-*.md` (authored via the `adr-author` draft → `promote-governance` path)

## Outputs

- `{context.paths.docs}/architecture/c4-context.md`
- `{context.paths.docs}/architecture/c4-container.md`
- `{context.paths.docs}/architecture/c4-component.md`

Level 4 (Code) is intentionally omitted — code diagrams belong in
the design skill, not the architecture skill.

## Context Update

Does not mutate `.fire-phoenix/context.yml`.

## Handoffs

- `development-design` uses container diagrams to identify modules.
- `security-review` references container diagrams for attack
  surface.
- `cicd-pipeline` / `deployment-strategy` reference container diagrams to
  align runtime topology with pipelines.

## AI authoring scope

**Does:** draft Mermaid diagrams using the C4 convention; cite
which actors + systems come from which intake entry.

**Does not:** invent containers or components not stated by the
user or an ADR; redraw on unapproved changes without asking.

## Review pass

Before presenting any diagram, walk
`references/diagram-review-checklist.md`:

1. **Ownership** — every container's "Owned by" cell is filled;
   an ownerless container is logged as a `TDEBT-`.
2. **Trust boundaries** — every crossing from a less-trusted to
   a more-trusted zone is visible on the container diagram and
   listed in the trust-boundaries table. This is what the
   security reviewer walks STRIDE against; an unmarked boundary
   never gets threat-modelled.
3. **Consistency with dependency reality** — every edge maps to
   a real dependency and every known dependency has an edge;
   cross-check the extracted architecture / dependency map when
   they exist. A mismatch is recorded as a finding and put to
   the user — never silently redrawn.
4. **Hygiene** — labelled edges, no invented nodes, ≤ ~12 nodes,
   one zoom level per diagram.

## Usage

> `<SKILL_DIR>` = the integration's skills root (e.g. `.claude/skills/`
> for Claude Code, `.codex/skills/` for Codex,
> `.cursor/skills/` for Cursor).
> Scripts live at `<SKILL_DIR>/<skill-name>/scripts/…`.

```bash
bash <SKILL_DIR>/c4-diagrams/scripts/bash/draft-c4.sh --auto
```

### Answer keys

| Key | Meaning | Default |
|---|---|---|
| `C4_LEVEL` | `context`, `container`, `component`, or `all` | `all` |
| `C4_SYSTEM_NAME` | the subject system | derived from `current.feature` |

## References

- `references/c4-shorthand.md` — how to draw C4 in plain Mermaid
  (no special plugins required).
- `references/diagram-review-checklist.md` — the pre-presentation
  review pass: owners, trust boundaries, dependency consistency,
  hygiene.
- `assets/c4-context-example.mmd`,
  `assets/c4-container-example.mmd` — reference diagrams.
