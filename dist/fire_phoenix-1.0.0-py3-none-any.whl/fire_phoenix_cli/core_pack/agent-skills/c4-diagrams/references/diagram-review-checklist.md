# Diagram review checklist

Run this pass on every drafted diagram before presenting it for
confirmation. Failures are fixed or logged as debts — never
shipped silently. Drawing conventions live in `c4-shorthand.md`.

## Ownership

- **Every container has an owner.** The "Owned by" column in the
  container table is filled with a person, role, or team. An
  ownerless container is a debt (`TDEBT-`) — nobody is on the
  hook when it breaks.

## Trust boundaries

- **Every trust boundary is visible.** Mark where data crosses
  from a less-trusted to a more-trusted zone: user → web app,
  web app → API, API → third-party service, anything →
  database. Use a subgraph border or a labelled edge note.
- **List each boundary in the trust-boundaries table** of the
  container artefact. The security reviewer walks STRIDE
  boundary by boundary — a boundary that isn't on the diagram
  is a boundary that never gets threat-modelled.

## Consistency with dependency reality

- **Every edge corresponds to a real dependency** — an import, a
  network call, a queue binding, a compose / manifest link. No
  aspirational arrows.
- **Every known dependency appears as an edge.** When an
  extracted architecture or dependency map exists (from the
  technical-analyst), cross-check both directions.
- **A mismatch is a finding, not a redraw.** Record "diagram
  says X, dependency evidence says Y" and ask the user which is
  right; never silently change either side.

## Hygiene

- Every edge is labelled with a protocol or interaction type —
  never a bare arrow.
- No invented nodes: every actor, system, and container traces
  to an intake entry, an ADR, or a user statement.
- Node count stays under ~12 per diagram; split by subsystem
  when it doesn't.
- One zoom level per diagram (see anti-patterns in
  `c4-shorthand.md`).
