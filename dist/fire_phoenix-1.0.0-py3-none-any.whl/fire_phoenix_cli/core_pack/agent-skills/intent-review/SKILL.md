---
name: intent-review
description: Reviews a feature's implemented source against its intent and acceptance
  criteria — flags behaviour unmet, partial, contradicted, out-of-scope, or untraceable,
  each cited (file:line + AC-NNN). Read-only. Use before merge.
license: MIT
compatibility: Designed for agentskills.io-compatible agents.
metadata:
  author: Dau Quang Thanh
  version: '1.0'
  requires: []
---

## User Input

```text
$ARGUMENTS
```

You **MUST** consider the user input before proceeding (if not empty).

## Pattern intent

This skill solves *"did we build what the intent asked for?"* in the
post-implementation review context, accepting that it judges
**conformance to stated intent — not code quality, not security**.
It is the code-vs-intent lens that sits beside `quality-review`
(code-vs-standards) and `security-review` (code-vs-OWASP). It reads
implemented source and the feature's `intent.md` + `acceptance.md`,
and reports where the two diverge. It never decides whether the
intent itself is *right* — that is the business-analyst / product-owner
call upstream.

## Audience and tone (interactive mode)

**Register first — adapt to role level.** Run as a guided, one-question-at-a-time questionnaire (yes/no first, recommend a default); skip in `FIRE_PHOENIX_AGENT_MODE=auto`. Full rules: `references/interactive-questionnaire.md`.

## Inputs

- `.fire-phoenix/context.yml` (+ `user-context.yml`) via
  `scripts/bash/common.sh` (or `scripts/powershell/common.ps1`).
- `{context.current.feature}` — active feature slug (required).
- `{context.paths.intents}/{context.current.feature}/intent.md` —
  the why + user stories with priorities (the conformance target).
- `{context.paths.docs}/product/acceptance.md` — the AC-NNN
  acceptance criteria (the per-story done-checks).
- Changed source files for the feature (the implementation under review).
- Optional: `{context.paths.docs}/design/{context.current.feature}/design.md`
  and the traceability matrix at `{context.paths.docs}/analysis/` —
  consulted to resolve a trace before flagging UNTRACEABLE.

## Outputs

- `{context.paths.docs}/reviews/{context.current.feature}/intent-conformance.md`
  — the review artefact (see `templates/intent-conformance-template.md`).
- `{context.paths.docs}/reviews/{context.current.feature}/intent-conformance.extract`
  — key=value companion for downstream skills.
- `{context.paths.docs}/reviews/intent-debts.md` — append-only,
  shared across features; each High / Critical finding without a
  proposed remediation lands here as an `ICDEBT-` entry.

## Context Update

Does not mutate `.fire-phoenix/context.yml`. `fire-phoenix` CLI commands are
the only writers to that file.

## Handoffs

- `bug-fixer` reads UNMET / CONTRADICTED findings at severity ≥ High
  as fix candidates.
- `developer` reads OUT-OF-SCOPE findings to decide whether to remove
  the unrequested behaviour or route it back to intent.
- `business-analyst` / `product-owner` receive UNTRACEABLE findings and
  candidate acceptance criteria as **suggestions** — they own the
  decision to formalise, defer, or reject them (this skill never edits
  `intent.md` / `acceptance.md`).
- `traceability-matrix` consumes the `.extract` to update requirement →
  implementation links.

## AI authoring scope

**Does:** read source + `intent.md` + `acceptance.md`; map each user
story and AC-NNN to the code that implements it; cite both a source
`file:line` and the `intent` / `AC-NNN` id for every finding; classify
each divergence (UNMET / PARTIAL / CONTRADICTED / OUT-OF-SCOPE /
UNTRACEABLE); assign a qualitative severity; propose a remediation
outline; propose *candidate* acceptance criteria for untraceable
behaviour, clearly flagged as suggestions.

**Does not:** modify code; edit `intent.md` or `acceptance.md` (surfaces
gaps, never resolves them); fabricate a trace or invent an AC to make
existing code look conformant; assign findings to individuals;
self-block a merge (the workflow gate + CI do that).

## Finding taxonomy

Every finding is exactly one of these five kinds. See
`references/finding-taxonomy.md` for the decision rules and worked
examples.

| Kind | Meaning |
|---|---|
| **UNMET** | An intent user story or AC-NNN has no implementing code. |
| **PARTIAL** | The AC is implemented for the happy path only; a stated condition / edge / failure path is missing. |
| **CONTRADICTED** | Code exists but behaves against what the intent / AC states. |
| **OUT-OF-SCOPE** | Code adds user-facing behaviour that no intent / AC authorises (scope creep). |
| **UNTRACEABLE** | Behaviour that cannot be tied to any intent / AC — needs an intent decision (formalise) or removal. |

## Trace discipline

Traceability claims follow the OBSERVED / INFERRED / UNKNOWN discipline
in `references/trace-discipline.md`, mirroring the brownfield-recovery
skills. A trace is **OBSERVED** only when the code path was re-read end
to end and demonstrably realises the AC; **INFERRED** when the link is
plausible from naming / structure but not confirmed; **UNKNOWN** when it
could not be established. Never record INFERRED as OBSERVED, and never
downgrade a real divergence to "probably fine".

## Review flow

1. **Scope** — resolve `IR_SCOPE` (glob of source under review) and load
   `intent.md` + `acceptance.md`. Record what is in and out of scope.
   If `acceptance.md` is absent (mechanical feature), fall back to the
   `intent.md` user stories and record the reduced-assurance caveat in
   the artefact.
2. **Build the conformance map** — one row per user story / AC-NNN →
   the implementing `file:line`(s), tagged OBSERVED / INFERRED / UNKNOWN
   per `references/trace-discipline.md`.
3. **Walk the taxonomy** — from the map, derive candidate findings:
   unmapped ACs (UNMET / PARTIAL), mapped-but-divergent (CONTRADICTED),
   code with no upstream row (OUT-OF-SCOPE / UNTRACEABLE). Every
   candidate carries its dual citation.
4. **Verification pass** — before a candidate becomes a reported
   finding, re-read its code path *and* re-read the cited intent / AC. A
   finding dies if the behaviour is actually present and traced (a
   "missing" AC realised in a helper the first pass missed), or if the
   cited intent line actually authorises the behaviour. Record the
   outcome per finding: **verified** or **unverified** (state why).
5. **Severity** — assign qualitative bands (Critical / High / Medium /
   Low / Info) per `references/severity-rubric.md`. Never invent numeric
   scores; effort to fix and authorship never change severity.
6. **Write the artefact** — fill every section of the template; each
   High / Critical finding carries a remediation outline and, when it
   has no owner-ready fix, an `ICDEBT-` entry in `intent-debts.md`.

## Usage

> `<SKILL_DIR>` = the integration's skills root (e.g. `.claude/skills/`
> for Claude Code, `.codex/skills/` for Codex, `.cursor/skills/` for
> Cursor). Scripts live at
> `<SKILL_DIR>/<skill-name>/scripts/…`.

```bash
IR_SCOPE="src/**/*.ts" bash <SKILL_DIR>/intent-review/scripts/bash/review.sh --auto
```

```powershell
$env:IR_SCOPE="src/**/*.ts"; pwsh <SKILL_DIR>/intent-review/scripts/powershell/review.ps1 -Auto
```

### Standard flags

`--auto` / `-Auto`, `--answers FILE` / `-Answers FILE`,
`--dry-run` / `-DryRun`, `--help` / `-Help` — as defined for every
Fire Phoenix action script.

### Answer keys

| Key | Meaning | Default |
|---|---|---|
| `IR_SCOPE` | glob of source files to review | `src/**` |
| `IR_ACCEPTANCE` | path to the acceptance artefact | `{context.paths.docs}/product/acceptance.md` |

## References

- `references/finding-taxonomy.md` — the five finding kinds, decision
  rules, and worked examples (including the UNMET-vs-PARTIAL and
  OUT-OF-SCOPE-vs-UNTRACEABLE boundaries).
- `references/trace-discipline.md` — OBSERVED / INFERRED / UNKNOWN
  tagging and the dual-citation rule.
- `references/severity-rubric.md` — the qualitative bands this skill
  assigns (adapted from the security reviewer's rubric to the intent
  lens: no invented numbers).
- `references/interactive-questionnaire.md` — the beginner-friendly
  interactive flow (interactive mode only).
