# Intent-Conformance Review: {feature}

**Date:** {date}
**Scope:** {scope}
**Acceptance source:** {acceptance}  *(mark "intent user-stories fallback — reduced assurance" if no acceptance.md)*

## Summary

- **User stories / ACs in scope:** <count>
- **Conformant (OBSERVED):** <count>
- **Findings:** Critical <n> · High <n> · Medium <n> · Low <n> · Info <n>
- **By kind:** UNMET <n> · PARTIAL <n> · CONTRADICTED <n> · OUT-OF-SCOPE <n> · UNTRACEABLE <n>
- **Overall conformance verdict:** <Conformant / Conformant-with-findings / Non-conformant>  *(AI proposal — the gate decides)*

## Conformance map

One row per user story / AC-NNN. Trace tag per `references/trace-discipline.md`.

| Intent anchor | Description | Implementing `file:line` | Trace | Status |
|---|---|---|---|---|
| `AC-001` | <one line> | `src/…:NN` | OBSERVED / INFERRED / UNKNOWN | conformant / finding IC-NN |
| `AC-002` | <one line> | — | UNKNOWN | UNMET → IC-01 |

## Findings

> Every finding carries a **dual citation** (source `file:line` +
> intent / `AC-NNN`), a **kind**, a **severity**, a **verification**
> mark, and a **trace** tag.

### IC-01: <short title>

- **Kind:** UNMET / PARTIAL / CONTRADICTED / OUT-OF-SCOPE / UNTRACEABLE
- **Severity:** Critical / High / Medium / Low / Info  *(driving factor: <…>)*
- **Intent anchor:** `AC-NNN` — "<quote the relevant clause>"
- **Source anchor:** `path/to/file.ext:NN-NN`
- **Verification:** verified (path + AC re-read) / unverified (<why>)
- **Trace:** OBSERVED / INFERRED / UNKNOWN
- **What diverges:** <the gap between what the intent asks and what the code does>
- **Remediation outline:** <outline, not a patch — or, for OUT-OF-SCOPE / UNTRACEABLE, the decision needed and who owns it>

## Candidate acceptance criteria (suggestions only)

> For OUT-OF-SCOPE / UNTRACEABLE behaviour the team may choose to keep.
> **Suggestions**, not directives — the business-analyst / product-owner
> owns the decision. This skill never edits `intent.md` / `acceptance.md`.

- *Consider* AC-<next>: "WHEN <condition>, THE <system> SHALL <response>."
  — covers the behaviour at `src/…:NN` (finding IC-NN).

## Reduced-assurance caveats

- <e.g. "No acceptance.md — mapped against intent user stories only;
  edge-case conformance not assessable.">
- <e.g. "IC-04 left unverified: could not run the code path in this
  session.">

## Debt

High / Critical findings without an owner-ready remediation are
duplicated in `{context.paths.docs}/reviews/intent-debts.md` as
`ICDEBT-NN` entries so they persist beyond this review.
