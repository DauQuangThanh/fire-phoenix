#!/usr/bin/env pwsh
param([switch]$Auto, [switch]$DryRun, [string]$Answers, [switch]$Help)
$ErrorActionPreference = 'Stop'
$ScriptDir = Split-Path -Parent $PSCommandPath
. (Join-Path $ScriptDir 'common.ps1')
if ($Auto)    { $env:FIRE_PHOENIX_AUTO = '1' }
if ($DryRun)  { $env:FIRE_PHOENIX_DRY_RUN = '1' }
if ($Answers) { $env:FIRE_PHOENIX_ANSWERS = $Answers; Import-FirePhoenixAnswers -Path $Answers }
if ($Help) { "Usage: review.ps1 -Auto. Keys: IR_SCOPE, IR_ACCEPTANCE." | Write-Host; exit 0 }
$ctx = Read-Context
if (-not $ctx.CURRENT_FEATURE) { Write-Error "current.feature required"; exit 2 }
$SkillDir = (Resolve-Path -LiteralPath (Join-Path $ScriptDir '..\..')).Path
$Dir = Get-FeatureScopedDir -Name 'reviews'
$Out = Join-Path $Dir 'intent-conformance.md'
$Scope = Resolve-Auto -Key 'IR_SCOPE' -Default 'src/**'
$DefaultAcceptance = Join-Path (Join-Path $ctx.REPO_ROOT $ctx.DOCS_DIR) 'product/acceptance.md'
$Acceptance = Resolve-Auto -Key 'IR_ACCEPTANCE' -Default $DefaultAcceptance

if ($env:FIRE_PHOENIX_DRY_RUN -eq '1') { Write-Host ("[dry-run] would write: {0} (scope={1}, acceptance={2})" -f $Out, $Scope, $Acceptance); exit 0 }
if (Test-Path -LiteralPath $Out) { Write-Error "Review exists: $Out"; exit 2 }
if (-not (Confirm-BeforeWrite -Message "Scaffold intent-conformance review at $Out.")) { Write-Error 'Aborted.'; exit 1 }

$AcceptanceLabel = $Acceptance
if (-not (Test-Path -LiteralPath $Acceptance)) {
    $AcceptanceLabel = "intent user-stories fallback — reduced assurance (no acceptance.md at $Acceptance)"
}

$tpl = Join-Path $SkillDir 'templates\intent-conformance-template.md'
$c = Get-Content -LiteralPath $tpl -Raw
$c = $c.Replace('{feature}', $ctx.CURRENT_FEATURE).Replace('{date}', (Get-Date -Format 'yyyy-MM-dd')).Replace('{scope}', $Scope).Replace('{acceptance}', $AcceptanceLabel)
Set-Content -LiteralPath $Out -Value $c
Write-Extract -ArtefactPath $Out "FEATURE=$($ctx.CURRENT_FEATURE)" "SCOPE=$Scope" "ACCEPTANCE=$Acceptance" | Out-Null
Write-Host ("Wrote {0}" -f $Out)
