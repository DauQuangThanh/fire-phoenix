#!/usr/bin/env bash
set -e
SCRIPT_DIR="$(CDPATH="" cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=common.sh
source "$SCRIPT_DIR/common.sh"
fire_phoenix_parse_standard_args "$@"
set -- "${FIRE_PHOENIX_REST_ARGS[@]}"
if [ "${1:-}" = "--help" ]; then
    echo "Usage: review.sh [--auto]. Keys: IR_SCOPE, IR_ACCEPTANCE."; exit 0
fi
read_context
SKILL_DIR="$(CDPATH="" cd "$SCRIPT_DIR/../.." && pwd)"
if [ -z "${FIRE_PHOENIX_CURRENT_FEATURE:-}" ]; then echo "ERROR: current.feature required" >&2; exit 2; fi
DIR=$(feature_scoped_dir reviews)
OUT="$DIR/intent-conformance.md"

SCOPE=$(resolve_auto IR_SCOPE "src/**") || true
ACCEPTANCE=$(resolve_auto IR_ACCEPTANCE "$FIRE_PHOENIX_REPO_ROOT/$FIRE_PHOENIX_DOCS_DIR/product/acceptance.md") || true

if [ "${FIRE_PHOENIX_DRY_RUN:-0}" = "1" ]; then echo "[dry-run] would write: $OUT (scope=$SCOPE, acceptance=$ACCEPTANCE)"; exit 0; fi
if [ -f "$OUT" ]; then echo "Review exists: $OUT" >&2; exit 2; fi
if ! confirm_before_write "Scaffold intent-conformance review at $OUT."; then echo "Aborted." >&2; exit 1; fi

ACCEPTANCE_LABEL="$ACCEPTANCE"
if [ ! -f "$ACCEPTANCE" ]; then
    ACCEPTANCE_LABEL="intent user-stories fallback — reduced assurance (no acceptance.md at $ACCEPTANCE)"
fi

sed \
    -e "s|{feature}|$FIRE_PHOENIX_CURRENT_FEATURE|g" \
    -e "s|{date}|$(date +%Y-%m-%d)|g" \
    -e "s|{scope}|$SCOPE|g" \
    -e "s|{acceptance}|$ACCEPTANCE_LABEL|g" \
    "$SKILL_DIR/templates/intent-conformance-template.md" > "$OUT"
write_extract "$OUT" "FEATURE=$FIRE_PHOENIX_CURRENT_FEATURE" "SCOPE=$SCOPE" "ACCEPTANCE=$ACCEPTANCE" > /dev/null
echo "Wrote $OUT — agent to build the conformance map and findings by reading intent.md, acceptance.md, and the scoped source."
