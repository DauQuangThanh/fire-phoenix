# Trace discipline — OBSERVED / INFERRED / UNKNOWN + dual citation

This skill's credibility rests on honest traceability. A conformance
claim ("AC-014 is implemented") is worthless unless the reader can tell
whether it was *confirmed* or *guessed*. This file defines the tags and
the dual-citation rule, mirroring the brownfield recovery skills
(`recover-spec`, `characterise-behaviour`).

## The three trace tags

Every row in the conformance map, and every finding, carries one tag.

- **OBSERVED** — the code path was re-read end to end and demonstrably
  realises (or violates) the cited AC. The reviewer can name the exact
  `file:line` and trace the data/control flow from entry point to the
  behaviour the AC describes.
- **INFERRED** — the link is plausible from naming, structure, or
  proximity, but the code path was **not** confirmed end to end. A
  function called `applyDiscount` *probably* implements AC-020, but the
  reviewer did not trace it. INFERRED is a lead, not a conclusion.
- **UNKNOWN** — no link could be established. Used for UNMET (no code
  found) and UNTRACEABLE (code found, purpose unestablished).

### The one-way rule

**Never record INFERRED as OBSERVED.** Upgrading a trace from INFERRED
to OBSERVED requires actually re-reading the path in the verification
pass. If time or access prevents confirmation, the row stays INFERRED
and the finding is marked **unverified** with the reason. An honest
INFERRED beats a confident-but-wrong OBSERVED.

## The dual-citation rule

Every finding cites **both** ends of the trace:

1. **Source anchor** — `path/to/file.ext:LINE` (or a `LINE-LINE`
   range). This is where the behaviour is (or is conspicuously absent).
2. **Intent anchor** — the `AC-NNN` id, or the intent user-story id /
   `intent.md` heading, that the behaviour relates to.

A finding missing either anchor is not shippable:

- No source anchor → it is a complaint about the intent, not a
  conformance finding. Route to business-analyst.
- No intent anchor → it is (by definition) OUT-OF-SCOPE or UNTRACEABLE;
  say so explicitly rather than leaving the intent column blank.

### Worked citation

> **IC-03 (CONTRADICTED, High, verified, trace: OBSERVED)**
> Intent anchor: `AC-014` — "WHEN the cart total is 0, THE checkout
> SHALL be disabled."
> Source anchor: `src/checkout/guard.ts:88-95` — the guard checks
> `total < 0`, so a zero total enables checkout, inverting the AC.

## The verification pass and traces

The verification pass (SKILL.md §Review flow step 4) is where INFERRED
becomes OBSERVED or the finding is dropped:

- A candidate UNMET dies if the verification pass finds the AC realised
  in a helper the mapping pass missed (trace upgrades to OBSERVED, no
  finding).
- A candidate CONTRADICTED dies if re-reading the cited AC shows the AC
  actually authorises the behaviour (the first read misread the AC).
- A finding that cannot be confirmed either way stays reported but
  **unverified**, with the blocking reason named — never silently
  dropped "to be safe" and never asserted as OBSERVED.
