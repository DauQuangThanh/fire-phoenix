# Severity rubric — qualitative (intent-conformance lens)

Assign every finding one of five severities using three questions. No
numeric scoring — the AI has no calibrated basis for a decimal, and a
defensible qualitative band beats an invented number. When the band
isn't obvious, note the driving factor next to the severity
("CONTRADICTED + P1 story + user-facing").

This rubric adapts the security reviewer's discipline
(`security-review/references/severity-rubric.md`) to the intent lens:
the questions change (conformance, not exploitability), the band
discipline does not.

## The three questions

1. **Divergence kind** — how badly does the code diverge from intent?
   - *Severe*: CONTRADICTED (the system does the wrong thing) or UNMET
     of a committed AC.
   - *Moderate*: PARTIAL (happy path only, a stated edge/failure path
     missing) or OUT-OF-SCOPE behaviour with real side effects.
   - *Minor*: UNTRACEABLE code with no observable harm; OUT-OF-SCOPE
     behaviour that is inert or trivially reverted.
2. **Story priority** — how important is the affected intent?
   - *High*: a P1 / must-have user story, or an AC tied to a governance
     invariant (PRODUCT.md L1) or acceptance agreement (G1).
   - *Medium*: a P2 / should-have story.
   - *Low*: a P3 / nice-to-have, or a non-user-facing detail.
3. **Blast radius** — who feels the divergence?
   - *Wide*: default path, every user, or data integrity / money /
     regulated data affected.
   - *Narrow*: an edge configuration, a single role, an internal-only
     surface, easily reverted.

## The bands

| Severity | Rule of thumb |
|---|---|
| **Critical** | Severe divergence on a high-priority story at wide blast radius. The system demonstrably does the wrong thing for everyone on a committed requirement. |
| **High** | Severe divergence behind a medium priority or narrow radius; or a moderate divergence on a P1 story at wide radius. |
| **Medium** | Moderate divergence on a medium-priority story; or a severe divergence on a genuinely low-priority / narrow surface. |
| **Low** | Minor divergence, or OUT-OF-SCOPE behaviour with no demonstrated harm. |
| **Info** | No behavioural impact today; an observation worth recording (an AC satisfied by accident, a trace worth confirming later, a naming mismatch between code and AC). |

## Modifiers

- **Governance invariant in force** (a PRODUCT.md L1 invariant or a G1
  acceptance agreement the AC descends from): raise impact one band —
  a contradiction of a ratified invariant is never merely Medium.
- **Verified trace** (see the verification pass in SKILL.md): a real,
  re-read trace that shows the behaviour is actually present can *drop*
  a candidate finding entirely — but only after re-reading, never on
  assumption.
- **Chained divergences**: two PARTIALs that together leave a whole
  user story unusable are reported as one High, with both dual
  citations.

## What never changes severity

- Effort to fix — a one-line fix for a CONTRADICTED Critical is still
  Critical.
- Who wrote the code.
- Whether the divergence is embarrassing or was "obviously an
  oversight".
