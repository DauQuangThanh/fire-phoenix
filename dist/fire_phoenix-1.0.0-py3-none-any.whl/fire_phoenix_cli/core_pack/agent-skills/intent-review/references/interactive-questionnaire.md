# Interactive questionnaire — intent-review

Loaded in `interactive` mode only (the default). Skip entirely in
`auto`; pick defaults from upstream artefacts and log per the auto-mode
rules. Assume the user reads code but is **not** a requirements-tracing
expert. One question at a time; recommend a default for every choice;
explain each term in plain English on first use; pause between batches.

## Batch 1 — scope

1. **"Which code should I check against the intent?"**
   Offer: A) everything changed for this feature (recommended),
   B) a folder / glob you name, C) not sure — I'll use the feature's
   changed files. Maps to `IR_SCOPE`.
2. **"Do we have written acceptance criteria for this feature?"**
   yes / no / not sure. If no → explain that the review will fall back
   to the intent's user stories and will be *less precise* (record the
   caveat in the report). Maps to the `acceptance.md` fallback.

## Batch 2 — the conformance map (show, don't ask)

For each user story / AC-NNN, present the trace you found as a
pre-filled line and ask only for a yes / no confirmation:

> "AC-014 says *checkout is disabled when the cart is empty*. I found
> the check at `guard.ts:88`. It looks like it fires on `total < 0`,
> not `total == 0` — so an empty cart still lets checkout through. Is
> that a problem? [yes / no / not sure]"

- `yes` → record as a CONTRADICTED finding.
- `no` → the user believes it's fine; record trace as OBSERVED and move
  on (note the user's confirmation).
- `not sure` → keep as unverified, flag for the verification pass, add
  a debt entry.

## Batch 3 — the four judgement calls

Only ask these where the artefacts don't already settle them:

3. **Unrequested behaviour.** "The code also does X, which no
   requirement mentions. Should that be: A) removed, B) written up as a
   new requirement, C) left as-is for now (I'll flag it)?" Never edit
   the intent yourself — B produces a *suggested* AC for the
   business-analyst.
4. **Missing edges.** "AC-020 lists three cases; I only see two handled.
   Is the third case in scope for this feature? [yes / no / not sure]"
5. **Severity sanity-check.** State the band you'd assign and why in one
   sentence; let the user accept with "ok" or nudge it.
6. **Untraceable code.** "I can't tie `sync.ts:210-240` to any
   requirement and can't tell what it's for. Do you know its purpose?
   [describe / not sure — flag it]"

## Fallback when scripts can't run

If `scripts/bash/review.sh` cannot run (no shell, no repo root), do the
work by hand: read `intent.md` + `acceptance.md`, read the scoped source,
build the conformance map in the artefact directly, and write
`intent-conformance.md` from `templates/intent-conformance-template.md`
using the file tools. The script only scaffolds the artefact and resolves
paths — the analysis is the agent's regardless.

## Defaults applied on `not sure` / `skip`

- Scope → the feature's changed files.
- Missing acceptance.md → intent user-story fallback + reduced-assurance
  caveat.
- Unresolved trace → unverified + `ICDEBT-` entry.
- Unrequested behaviour with no decision → flag as OUT-OF-SCOPE, do not
  remove, do not formalise.
