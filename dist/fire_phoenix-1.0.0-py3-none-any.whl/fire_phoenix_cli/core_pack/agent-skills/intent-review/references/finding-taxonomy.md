# Finding taxonomy — the five kinds

Every intent-conformance finding is exactly one of five kinds. The
taxonomy is deliberately closed: if a candidate does not fit one of
these, it is not an intent-conformance finding (it may be a
`quality-review` or `security-review` finding instead — route it there,
do not stretch a kind to fit).

The two axes that separate the kinds:

- **Is there an upstream row?** — does an intent user story or an
  AC-NNN describe this behaviour?
- **Is there implementing code?** — does the source realise it?

```
                    code realises it?
                    NO                     YES
upstream       ┌──────────────────┬──────────────────────┐
row exists? YES│ UNMET / PARTIAL  │ CONTRADICTED (if the │
               │                  │ code fights the AC)  │
               ├──────────────────┼──────────────────────┤
            NO │  (nothing —      │ OUT-OF-SCOPE /       │
               │   not a finding) │ UNTRACEABLE          │
               └──────────────────┴──────────────────────┘
```

## UNMET

An intent user story or an AC-NNN has **no implementing code at all**.

- Trigger: a conformance-map row whose implementing `file:line` column
  is empty after the verification pass.
- Dual citation: the `AC-NNN` / intent line, and the *absence* stated
  plainly ("no implementing code found under `IR_SCOPE`").
- Do **not** raise UNMET if the code exists but is wrong — that is
  CONTRADICTED. Do not raise it if only an edge is missing — that is
  PARTIAL.

## PARTIAL

The AC is implemented for the **happy path only**; a stated condition,
edge case, or failure path named in the AC is missing.

- Trigger: the AC has an explicit "WHEN … THE system SHALL …" condition
  (or an enumerated edge) with no corresponding branch in the code.
- Dual citation: `AC-NNN` (quote the unmet clause) + the `file:line`
  where the happy path is handled but the branch is absent.
- The distinguishing test vs UNMET: *some* code traces to the AC, but
  not *all* of its stated behaviour.

## CONTRADICTED

Code exists and traces to the AC, but **behaves against** what the
intent / AC states.

- Trigger: the code path realises the feature but produces an outcome
  the AC forbids or inverts (wrong default, opposite condition,
  disallowed value permitted).
- Dual citation: `AC-NNN` (quote the violated clause) + the `file:line`
  of the contradicting logic.
- This is almost always ≥ High severity: the system actively does the
  wrong thing, which is worse than doing nothing (UNMET).

## OUT-OF-SCOPE

Code adds **user-facing behaviour that no intent / AC authorises** —
scope creep with a plausible home in the product, but no mandate.

- Trigger: a user-observable capability (endpoint, flag, UI affordance,
  side effect) with no upstream row.
- Dual citation: the `file:line` of the unrequested behaviour + the
  explicit statement that no intent / AC covers it.
- Resolution is a *decision*, not a *fix*: either remove it (developer)
  or formalise it as new intent (business-analyst / product-owner). The
  skill proposes a candidate AC as a **suggestion** only.
- Distinguish from UNTRACEABLE: OUT-OF-SCOPE is coherent, deliberate
  behaviour that simply was never asked for; UNTRACEABLE is behaviour
  whose *purpose* cannot even be established.

## UNTRACEABLE

Behaviour that **cannot be tied to any intent / AC** and whose purpose
cannot be established from the code alone.

- Trigger: logic that changes observable behaviour but maps to no
  upstream row and has no self-evident rationale (dead-looking feature
  flags, half-wired capabilities, speculative hooks that are actually
  reachable).
- Dual citation: the `file:line` + "no intent / AC; purpose
  unestablished (trace: UNKNOWN)".
- Resolution: route to business-analyst for an intent decision, or to
  developer for removal. Never guess the intent to make it disappear.

## What is NOT an intent-conformance finding

- A code smell with correct behaviour → `quality-review`.
- A security weakness with correct behaviour → `security-review`.
- An inconsistency *between* `intent.md`, `plan.md`, `tasks.md`,
  `acceptance.md` *before* implementation → `verify-tasks`.
- The intent itself being wrong / incomplete → surface to
  business-analyst; this skill reviews conformance, not the intent's
  merit.
