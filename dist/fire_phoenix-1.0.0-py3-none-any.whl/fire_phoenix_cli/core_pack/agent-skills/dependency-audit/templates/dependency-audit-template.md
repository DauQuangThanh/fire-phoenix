# Dependency Audit: {feature}

**Date:** {date}
**Lockfile:** {lockfile}
**Licence policy:** {licence_policy}
**Rigor profile:** {profile} <!-- P = advisory minimum;
  F = full walk (default) -->
**Data freshness:** every CVE / version / maintenance claim below
was fetched live on the date shown under Sources — never answered
from training memory. A cell whose data has not been fetched yet
is `TBD-source`, not a guess.

## Summary

- **Direct deps:** <count>
- **Transitive deps:** <count>
- **CVEs open — Critical:** <count>
- **CVEs open — High:** <count>
- **Licence conflicts:** <count>
- **Abandonware candidates:** <count>
- **Supply-chain check failures:** <count>

## Verdict per dependency

One row per direct dep (plus any flagged transitive dep). Each
column stays `TBD-source` until its data has been fetched live.

| Dep | Version | CVE status | Licence | Maintenance | Action |
|---|---|---|---|---|---|
| `pkg-a` | 1.2.3 | TBD-source (not yet fetched) | MIT | active | keep |
| `pkg-b` | 2.0.0 | CVE-2026-XXXXX High — fixed in 2.0.4 | Apache-2.0 | active | patch bump |
| `old-pkg` | 0.9.1 | none found (OSV, fetched YYYY-MM-DD) | MIT | no release in 18+ months | replace / fork decision |

## CVEs

| Dep | Version | CVE | Severity | Fixed in | Upgrade path |
|---|---|---|---|---|---|
| `pkg-a` | 1.2.3 | CVE-2026-XXXXX | High | 1.2.5 | patch bump |

## Licence conflicts

| Dep | Version | Licence | Action |
|---|---|---|---|
| `gpl-pkg` | 1.0.0 | GPL-3.0 | replace / negotiate exception |

## Abandonware candidates

| Dep | Last release | Notes |
|---|---|---|
| `old-pkg` | 2023-01-15 | no activity in 18+ months — consider fork |

## Supply-chain checks

Per `references/supply-chain-checklist.md`:

| # | Check | Result | Notes |
|---|---|---|---|
| 1 | Lockfile committed + pinned | pass / fail | |
| 2 | Integrity hashes present | pass / fail | |
| 3 | Typosquatting check (new deps) | pass / fail / n-a | |
| 4 | Install scripts reviewed (new deps) | pass / fail / n-a | |
| 5 | Abandonware 18-month rule | pass / fail | |
| 6 | Registry / source provenance | pass / fail | |

## Bot-PR triage (when a dependency bot is in use)

One row per open bot PR, filled BEFORE merge. Bot PRs are a
supply-chain attack surface: same review gates as external
contributions — never auto-merged on green.

| PR | Dep + bump | Breaking changes | Transitive impact | Security | Change class | Verdict |
|---|---|---|---|---|---|---|
| #NN | `pkg-a` 1.2.3 → 1.2.5 | none (patch) | none | fixes CVE-2026-XXXXX | mechanical | merge after review |

<!-- Class routing: lockfile-only bump + green harness =
     mechanical; code has to adapt = routine; the dependency's
     API shifts = consequential. -->

## Sources

- Vendor advisories / GitHub Security Advisories — fetched
  YYYY-MM-DD.
- OSV database — fetched YYYY-MM-DD.

## Debt

All open High / Critical CVEs and licence conflicts are duplicated
as `CSDEBT-NN` entries in `security-debts.md`.
