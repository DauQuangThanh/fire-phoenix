---
name: dependency-audit
description: Audits third-party dependencies — direct and transitive against CVE databases
  (WebSearch/WebFetch), licence conflicts, abandonware — into a dated file. Use for
  a vulnerability check or licence audit.
license: MIT
compatibility: Designed for agentskills.io-compatible agents.
metadata:
  author: Dau Quang Thanh
  version: '1.0'
  requires: []
---

## User Input

```text
$ARGUMENTS
```

## Audience and tone (interactive mode)

**Register first — adapt to role level.** Run as a guided, one-question-at-a-time questionnaire (yes/no first, recommend a default); skip in `FIRE_PHOENIX_AGENT_MODE=auto`. Full rules: `.fire-phoenix/references/subagents/interactive-questionnaire.md`.

## Inputs

- `.fire-phoenix/context.yml`
- Project lockfiles (package-lock.json, uv.lock, poetry.lock,
  go.sum, Cargo.lock, pom.xml, Gemfile.lock, …)

## Outputs

- `{context.paths.docs}/reviews/<feature>/dependencies.md`
- `{context.paths.docs}/reviews/<feature>/dependencies.extract`

## Context Update

Does not mutate `.fire-phoenix/context.yml`.

## Handoffs

- `security-review` Category A06 cites this file.
- `bug-fixer` reads Critical / High CVEs to drive fixes.
- `cicd-pipeline` mirrors the audit as a pipeline stage.

## AI authoring scope

**Does:** enumerate direct + transitive deps from the right
lockfile, fetch current CVE data via `WebSearch`/`WebFetch`,
flag licence conflicts against project policy, run the
supply-chain checks, record a per-dependency verdict (CVE status
/ licence / maintenance / action), propose upgrade paths.

**Does not:** upgrade packages, edit lockfiles, merge or approve
dependency-bot PRs, claim "no vulnerabilities" without a
citation.

## Audit rules

- **Data freshness (hard rule).** CVE and version data MUST be
  fetched live at run time via `WebSearch`/`WebFetch` — never
  answered from training memory. Every claim carries its source
  and fetch date; anything not yet fetched is `TBD-source`,
  never a guess. This mirrors the code-security-reviewer's
  ground rule; the audit artefact restates it in its header.
- **Supply-chain checks.** Walk
  `references/supply-chain-checklist.md` (pinning, integrity
  hashes, typosquatting on new deps, install-script review,
  abandonware, provenance) and record one row per check in the
  audit artefact.
- **Verdict per dependency.** Every direct dep gets one row in
  the artefact's verdict table: CVE status, licence,
  maintenance, action.
- **Bot-generated PRs are a supply-chain attack surface.** When
  the project runs a dependency bot, this audit's triage runs on
  top of each bot PR BEFORE merge: breaking changes, transitive
  impact, security implications. Bot PRs get the same review
  gates as external contributions — **never auto-merge on
  green**. Route the resulting change by the project's existing
  change classes: a lockfile-only bump with a green harness is
  `mechanical`; the code has to adapt is `routine` (behavioural);
  the dependency's API shifts is `consequential`.

## Rigor profile

Read the declared rigor profile from the project context; when
none is declared, behave as Profile **F**.

- **P (Prototype/Demo)** — the audit is advisory: direct deps
  only, Critical / High CVEs, supply-chain checks 1 and 3. Say
  so in the artefact.
- **M (MVP)** — full CVE + licence pass on direct deps;
  transitive deps for Critical CVEs.
- **F (Production, default)** — full walk: direct + transitive
  deps, licences, abandonware, all six supply-chain checks.

## Usage

> `<SKILL_DIR>` = the integration's skills root (e.g. `.claude/skills/`
> for Claude Code, `.codex/skills/` for Codex,
> `.cursor/skills/` for Cursor).
> Scripts live at `<SKILL_DIR>/<skill-name>/scripts/…`.

```bash
bash <SKILL_DIR>/dependency-audit/scripts/bash/audit.sh --auto
```

### Answer keys

| Key | Meaning | Default |
|---|---|---|
| `DA_LICENCE_POLICY` | allow-list, comma-separated | `MIT,Apache-2.0,BSD-3-Clause,BSD-2-Clause,ISC` |
| `DA_MAX_AGE_DAYS` | flag deps untouched for this many days | `730` |

## References

- `references/lockfile-matrix.md` — which lockfile + list command
  per ecosystem, and the CVE sources to cite.
- `references/supply-chain-checklist.md` — pinning, integrity
  hashes, typosquatting, install-script review, abandonware,
  provenance.
