# Supply-chain checklist

Run alongside the CVE / licence / abandonware audit. Each check
gets a row in the audit artefact's "Supply-chain checks" table
with a pass / fail / n-a result and a note.

## Checks

1. **Lockfile committed and pinned.** A lockfile exists for
   every manifest (see `references/lockfile-matrix.md`), is
   committed, and pins exact versions — no floating ranges
   resolved at install time. CI installs from the lockfile
   (`npm ci`, `uv sync --frozen`, …), not from the manifest.
2. **Integrity hashes present.** The lockfile carries content
   hashes (`integrity` in package-lock.json, hash entries in
   uv.lock / poetry.lock, `go.sum` lines) and they have not been
   stripped. Missing hashes mean the registry is trusted
   blindly.
3. **Typosquatting sanity check on new deps.** For every dep
   added since the last audit: does the name match the package
   the project meant (`requests` vs `request`)? Check the
   registry page — download count, age, and a repository link
   that actually points at the claimed source. A brand-new,
   low-download package with a familiar-looking name is a
   finding.
4. **Install-script review on new deps.** For every new dep,
   check for code that runs at install time (npm `preinstall` /
   `postinstall`, Python `setup.py`, build scripts). Read what
   it does; network calls or file writes outside the package
   directory are findings.
5. **Abandonware (18-month rule).** No commits or releases in
   18+ months → flag: High for security-critical libs (auth,
   crypto, parsing untrusted input), Medium otherwise — matching
   the code-security-reviewer's questionnaire default. Scripts
   parameterise the window via `DA_MAX_AGE_DAYS`.
6. **Registry / source provenance.** Deps resolve from the
   expected registry — no unexpected resolved URLs pointing at
   private mirrors, git commits, or tarballs the project never
   agreed to.

## Scope note

Checks 3 and 4 apply to deps **added or changed since the
previous audit** — re-litigating every historical dep each run
drowns the signal. Checks 1, 2, 5, and 6 apply to the whole
tree. Under rigor Profile P run checks 1 and 3 only; under
Profile F run all six.
