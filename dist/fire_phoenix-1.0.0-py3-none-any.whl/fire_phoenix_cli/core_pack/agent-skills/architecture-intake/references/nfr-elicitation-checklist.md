# NFR elicitation checklist

Walk each category below during intake. An NFR without a number
(or an explicit band) is a debt — record the value the user gives,
or apply a stated default marked "(default applied — confirm
later)" and log a `TDEBT-`. For the canonical quality-attribute
vocabulary, see `quality-attributes.md`.

For every category, always ask the closing question: **"What
happens when this target is missed?"** — the answer is a *named
failure condition* and feeds the negative-AC mapping step in the
skill flow.

## Categories

### Performance

- Target latency for the main user action (p95, not average)?
- Expected peak throughput (requests / jobs per second)?
- Failure condition: what does the user see when the system is
  slower than the target — a spinner, a timeout, an error?

### Availability

- Uptime target (SLA) and the blast radius of an outage?
- Planned-maintenance windows acceptable?
- RTO / RPO (how long to recover, how much data loss is
  tolerable)?
- Failure condition: what must the system do while a dependency
  is down — queue, degrade, refuse?

### Security

- Authentication and authorisation model (who signs in, what
  roles exist)?
- Data classification: does the system hold personal, financial,
  or health data?
- Failure condition: what must an unauthenticated or
  under-privileged request receive — and what must it never
  receive?

### Compliance

- Regimes in force (e.g. GDPR, HIPAA, PCI-DSS) and
  data-residency rules?
- Audit-trail obligations (who did what, retained how long)?
- Failure condition: what happens on a subject-access or
  deletion request the system cannot fulfil?

### Data retention

- How long is each data class kept, and what triggers deletion?
- Backups: frequency, retention, restore-test cadence?
- Failure condition: what must happen when retention expires —
  hard delete, anonymise, archive?

### Operability

- Who runs this system day to day, and with what monitoring?
- Deploy cadence and rollback expectation?
- Failure condition: when the system misbehaves at 3 a.m., what
  signal reaches whom?

## From failure condition to candidate negative AC

Every named failure condition maps to a **candidate negative
acceptance criterion** in Given/When/Then form — a statement of
what the system must do (and must never do) when the condition
fires:

> **Given** the payment provider is unreachable, **When** a user
> submits an order, **Then** the order is queued with a visible
> "pending" state and no charge is attempted twice.

These are *candidates*: hand them to the business-analyst, who
authors the final criteria into the feature's acceptance
artefact. This skill proposes; it never authors acceptance
criteria itself.
