#!/usr/bin/env pwsh
# Create a new intent (feature). Entry point of the IDD lifecycle.
#
# IDD-canon write semantics (branch
# decoupling).
# Pre-β₂: this script hardcoded "specs/" as the intents directory and
# implicitly relied on the SDD-era feature-branch model. Post-β₂: the
# intents directory is read from .fire-phoenix/context.yml via Read-Context
# ($ctx.INTENTS_DIR), and on successful (non-dry-run) creation the new
# intent.md's relative path is written into context.yml's current.intent
# cursor.
#
# Branch ownership: this core command creates the intent
# DIRECTORY + intent.md + current.intent cursor ONLY. It does NOT create or
# switch git branches — the git extension's `before_specify` hook
# (fire-phoenix.git.feature) is the sole brancher (see SKILL.md:150).
# Intent-directory numbering derives from the intents directory alone and is
# independent of git branches (SKILL.md:74). The BRANCH_NAME / FEATURE_NUM
# JSON keys are retained for interface stability: BRANCH_NAME now names the
# intent-directory prefix, not a branch this script created.
# -AllowExistingBranch is accepted but is a no-op (CLI-surface stability).
[CmdletBinding()]
param(
    [switch]$Json,
    [switch]$AllowExistingBranch,
    [switch]$DryRun,
    [string]$ShortName,
    [Parameter()]
    [long]$Number = 0,
    [switch]$Timestamp,
    [switch]$Help,
    [Parameter(Position = 0, ValueFromRemainingArguments = $true)]
    [string[]]$FeatureDescription
)
$ErrorActionPreference = 'Stop'

# Show help if requested
if ($Help) {
    Write-Host "Usage: ./create-new-feature.ps1 [-Json] [-DryRun] [-AllowExistingBranch] [-ShortName <name>] [-Number N] [-Timestamp] <feature description>"
    Write-Host ""
    Write-Host "Creates the intent directory + intent.md + current.intent cursor."
    Write-Host "Git branch creation is handled by the git extension's before_specify"
    Write-Host "hook, not by this command."
    Write-Host ""
    Write-Host "Options:"
    Write-Host "  -Json               Output in JSON format"
    Write-Host "  -DryRun             Compute the name and paths without creating directories or files"
    Write-Host "  -AllowExistingBranch  Deprecated no-op (retained for CLI-surface stability)"
    Write-Host "  -ShortName <name>   Provide a custom short name (2-4 words) for the directory prefix"
    Write-Host "  -Number N           Specify the sequential number manually (overrides auto-detection)"
    Write-Host "  -Timestamp          Use timestamp prefix (YYYYMMDD-HHMMSS) instead of sequential numbering"
    Write-Host "  -Help               Show this help message"
    Write-Host ""
    Write-Host "Examples:"
    Write-Host "  ./create-new-feature.ps1 'Add user authentication system' -ShortName 'user-auth'"
    Write-Host "  ./create-new-feature.ps1 'Implement OAuth2 integration for API'"
    Write-Host "  ./create-new-feature.ps1 -Timestamp -ShortName 'user-auth' 'Add user authentication'"
    exit 0
}

# Deprecated no-op: the core command no longer touches git
# branches. Reference the switch so PowerShell does not flag it as unused.
$null = $AllowExistingBranch

# Check if feature description provided
if (-not $FeatureDescription -or $FeatureDescription.Count -eq 0) {
    Write-Error "Usage: ./create-new-feature.ps1 [-Json] [-DryRun] [-AllowExistingBranch] [-ShortName <name>] [-Number N] [-Timestamp] <feature description>"
    exit 1
}

$featureDesc = ($FeatureDescription -join ' ').Trim()

# Validate description is not empty after trimming (e.g., user passed only whitespace)
if ([string]::IsNullOrWhiteSpace($featureDesc)) {
    Write-Error "Error: Feature description cannot be empty or contain only whitespace"
    exit 1
}

# current.intent cursor writes flow through the canonical helper
# Write-UserContextValue dot-sourced from common.ps1, closing the
# skill-helper cursor-write gap. The helper targets
# .fire-phoenix/user-context.yml exclusively and bootstraps the file
# if absent.

# Load canonical helpers (Read-Context, Resolve-Template, …) and the shared
# branch/dir naming helpers (Get-HighestNumberFromSpecs, ConvertTo-CleanBranchName,
# Get-BranchName) — single source. Intent-directory numbering
# derives from the intents directory ALONE.
. "$PSScriptRoot/common.ps1"
. "$PSScriptRoot/branch-naming.ps1"

# Resolve repo root + intents directory from .fire-phoenix/context.yml.
# Read-Context populates $ctx.REPO_ROOT + $ctx.INTENTS_DIR (with documented
# defaults when context.yml is absent).
$ctx = Read-Context

$repoRoot = $ctx.REPO_ROOT

Set-Location $repoRoot

$specsDir = Join-Path $repoRoot $ctx.INTENTS_DIR
if (-not $DryRun) {
    New-Item -ItemType Directory -Path $specsDir -Force | Out-Null
}

# Generate directory suffix
if ($ShortName) {
    # Use provided short name, just clean it up
    $branchSuffix = ConvertTo-CleanBranchName -Name $ShortName
} else {
    # Generate from description with smart filtering
    $branchSuffix = Get-BranchName -Description $featureDesc
}

# Warn if -Number and -Timestamp are both specified
if ($Timestamp -and $Number -ne 0) {
    Write-Warning "[intent] Warning: -Number is ignored when -Timestamp is used"
    $Number = 0
}

# Determine directory prefix
if ($Timestamp) {
    $featureNum = Get-Date -Format 'yyyyMMdd-HHmmss'
    $branchName = "$featureNum-$branchSuffix"
} else {
    # Sequential number: intents directory only (independent of git branches).
    if ($Number -eq 0) {
        $Number = (Get-HighestNumberFromSpecs -SpecsDir $specsDir) + 1
    }

    $featureNum = ('{0:000}' -f $Number)
    $branchName = "$featureNum-$branchSuffix"
}

# GitHub enforces a 244-byte limit on branch names; the git extension will
# use this prefix as its branch name, so keep the directory prefix within
# the same limit for parity.
$maxBranchLength = 244
if ($branchName.Length -gt $maxBranchLength) {
    # Account for prefix length: timestamp (15) + hyphen (1) = 16, or sequential (3) + hyphen (1) = 4
    $prefixLength = $featureNum.Length + 1
    $maxSuffixLength = $maxBranchLength - $prefixLength

    # Truncate suffix
    $truncatedSuffix = $branchSuffix.Substring(0, [Math]::Min($branchSuffix.Length, $maxSuffixLength))
    # Remove trailing hyphen if truncation created one
    $truncatedSuffix = $truncatedSuffix -replace '-$', ''

    $originalBranchName = $branchName
    $branchName = "$featureNum-$truncatedSuffix"

    Write-Warning "[intent] Name exceeded GitHub's 244-byte branch limit"
    Write-Warning "[intent] Original: $originalBranchName ($($originalBranchName.Length) bytes)"
    Write-Warning "[intent] Truncated to: $branchName ($($branchName.Length) bytes)"
}

$featureDir = Join-Path $specsDir $branchName
$specFile = Join-Path $featureDir 'intent.md'
# Relative path used for the context.yml current.intent cursor. Forward
# slashes always — YAML paths stay portable across shells.
$intentRel = ('{0}/{1}/intent.md' -f $ctx.INTENTS_DIR.TrimEnd('/', '\'), $branchName)

if (-not $DryRun) {
    # No git branch is created here: the git extension's
    # before_specify hook owns branch creation. This command only writes
    # the intent directory, intent.md, and the current.intent cursor.
    New-Item -ItemType Directory -Path $featureDir -Force | Out-Null

    if (-not (Test-Path -PathType Leaf $specFile)) {
        $template = Resolve-Template -TemplateName 'intent-template' -RepoRoot $repoRoot
        if ($template -and (Test-Path $template)) {
            Copy-Item $template $specFile -Force
        } else {
            New-Item -ItemType File -Path $specFile -Force | Out-Null
        }
    }

    # Persist the new intent path into .fire-phoenix/context.yml's
    # current.intent cursor so downstream skills (/plan, /taskify, …)
    # see this feature as the active one.
    Write-UserContextValue -Key current.intent -Value $intentRel

    # Set the FIRE_PHOENIX_FEATURE environment variable for the current session
    $env:FIRE_PHOENIX_FEATURE = $branchName
}

if ($Json) {
    $obj = [PSCustomObject]@{
        BRANCH_NAME = $branchName
        INTENT_FILE = $specFile
        FEATURE_NUM = $featureNum
    }
    if ($DryRun) {
        $obj | Add-Member -NotePropertyName 'DRY_RUN' -NotePropertyValue $true
    }
    $obj | ConvertTo-Json -Compress
} else {
    Write-Output "BRANCH_NAME: $branchName"
    Write-Output "INTENT_FILE: $specFile"
    Write-Output "FEATURE_NUM: $featureNum"
    if (-not $DryRun) {
        Write-Output "FIRE_PHOENIX_FEATURE environment variable set to: $branchName"
    }
}
