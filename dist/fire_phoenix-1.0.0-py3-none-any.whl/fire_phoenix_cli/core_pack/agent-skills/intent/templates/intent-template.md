# Intent — {feature_name}

**Promoted to:** `specs/epic-{slug}.md` (L2 canonical location for an
epic-scoped intent + spec pair)
**Created:** {date}
**Status:** {status}  <!-- Draft / Active / Superseded -->
**Authored by:** {author}  <!-- BA is the sole author of L1 + L2 intent and AC -->

<!--
  Intent answers *why* and *what must hold* — goals, constraints,
  success/failure conditions, scale/quality expectations. Distinct
  from the spec (the falsifiable, testable layer). Intent comes
  BEFORE acceptance criteria. If intent is wrong, the code can be
  spec-complete but still wrong.
-->

## Intent

- **Goal:** [What outcome does this feature deliver? One sentence.]
- **Invariants (constraints from PRODUCT.md):** [What must always hold? Reference PRODUCT.md §Invariants.]
- **Success conditions:** [How will we know it worked, qualitatively?]
- **Failure conditions:** [What states must NOT occur?]
- **Scale & quality expectations:** [Throughput, latency, accuracy, reliability targets.]
- **Non-goals:** [What this feature explicitly does NOT do.]
- **Open questions (with owners):** [Unresolved with owner + deadline; resolve before spec finalisation.]

## Narrative

[2-5 paragraphs of plain-language story: who the actors are, what problem they face today, what the world looks like after this feature ships. No technical detail.]

## Actors and triggers

- **Primary actor:** [Who uses this feature directly?]
- **Secondary actors:** [Systems / roles affected indirectly.]
- **Triggers:** [Events / conditions that invoke this feature.]

## Acceptance criteria

<!--
  EARS format (Easy Approach to Requirements Syntax) is preferred where the
  domain is ambiguous: "WHEN <condition>, THE <system> SHALL <response>."
  Use plain prose where the criterion is unambiguous. Each criterion must
  derive from an Intent element above.
-->

1. WHEN [condition], THE [system] SHALL [response].
2. WHEN [condition], THE [system] SHALL [response].
3. [Plain-prose criterion if EARS adds no clarity.]

## Out of scope

- [Things explicitly EXCLUDED from this intent — protects scope from creep.]

## Open questions

- [ ] [Question] (Owner: {owner}, Deadline: {deadline})
- [ ] [Question] (Owner: {owner}, Deadline: {deadline})

## Traceability

- **PRODUCT.md invariants honoured:** [list §<section> references]
- **ADRs respected:** [list adr/<NNNN>-*.md if any architecture decisions constrain this]
- **Downstream:** Promotes to `specs/epic-{slug}.md`; plan derives from `## Acceptance criteria`; task contracts derive from plan.
