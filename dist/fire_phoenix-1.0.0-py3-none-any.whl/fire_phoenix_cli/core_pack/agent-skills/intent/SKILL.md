---
name: intent
description: Captures or updates the feature intent (the why and desired outcome)
  from a natural-language description, and derives the specification. Use when starting
  a feature or turning a story or idea into a traceable record.
license: MIT
compatibility: Designed for agentskills.io-compatible agents.
metadata:
  author: Dau Quang Thanh
  version: '1.0'
  requires: []
---

## User Input

```text
$ARGUMENTS
```

You **MUST** consider the user input (if not empty) before proceeding.

## Pre-Execution Checks

If `.fire-phoenix/extensions.yml` does not exist in the project
root, skip silently. If it exists, read
`references/extension-hooks.md` §Pre-execution and apply the hook
protocol against the `hooks.before_specify` key before the Outline.

## Interactive Mode (beginner-friendly questionnaire)

If `FIRE_PHOENIX_AGENT_MODE=interactive` (the default) **and** the
feature description is too sparse to populate every mandatory
spec-template section (e.g. only "build me a booking app", missing
users, data, devices, or success), pause before step 5, read
`references/interactive-questionnaire.md`, and walk the user through
it (conversational rules, seven question batches,
answers-to-spec-sections mapping). Skip it when the description is
already complete.

When `FIRE_PHOENIX_AGENT_MODE=auto` (or `--auto`), **skip the
questionnaire entirely** (do not read the reference): apply sensible
defaults, document them in Assumptions, and let the business-analyst
log decisions.

## Outline

The text the user typed after `/intent` **is** the feature description — assume you have it even if `$ARGUMENTS` appears literally below; do not ask the user to repeat it unless the command was empty.

Given the feature description:

1. **Generate a concise short name** (2-4 words) for the feature:
   - Extract the most meaningful keywords; action-noun format when possible (e.g., "add-user-auth", "fix-payment-bug").
   - Preserve technical terms and acronyms (OAuth2, API, JWT).
   - Example: "Fix payment processing timeout bug" → "fix-payment-timeout"

2. **Branch creation** (optional, via hook):

   If a `before_specify` hook ran successfully above, it created/switched to a git branch and output JSON with `BRANCH_NAME` and `FEATURE_NUM`. Note these; the branch name does **not** dictate the spec directory name.

   If the user provided `GIT_BRANCH_NAME`, pass it to the hook so the branch script uses that exact value (bypassing prefix/suffix generation).

3. **Create the intent feature directory**:

   New intents live under `{context.paths.intents}/` (resolved from `.fire-phoenix/context.yml`). The action script `scripts/bash/create-new-feature.sh` (or the PowerShell sibling) resolves paths, creates the `<prefix>-<short-name>` directory, copies `templates/intent-template.md` to `intent.md`, and sets the `current.intent` cursor — invoke it, don't re-implement it. Only when it cannot run, read `references/feature-directory-resolution.md` and follow its manual steps.

   **IMPORTANT**:
   - Only one feature per `/intent` invocation.
   - The intent directory name and git branch name are independent (may match).
   - The intent directory, intent file, and `current.intent` cursor are written by the action script, never the hook.

4. Load `templates/intent-template.md` for the required sections.

5. Follow this execution flow:
    1. Parse the description. If empty: ERROR "No feature description provided".
    2. Extract key concepts: actors, actions, data, constraints.
    3. For unclear aspects, make informed guesses from context + industry standards. Mark `[NEEDS CLARIFICATION: question]` only when the choice significantly impacts scope or UX, multiple reasonable interpretations exist, or no reasonable default exists. **LIMIT: max 3 markers**, prioritised scope > security/privacy > UX > technical detail.
    4. Fill User Scenarios & Testing. If no clear user flow: ERROR "Cannot determine user scenarios".
    5. Generate Functional Requirements (each testable; reasonable defaults documented in Assumptions).
    6. Define Success Criteria (measurable, technology-agnostic, verifiable without implementation detail).
    7. Identify Key Entities (if data involved).
    8. Return: SUCCESS (spec ready for planning).

6. Write the specification to `{context.current.intent}` (the action script populates this cursor in `.fire-phoenix/user-context.yml`) using the template structure; replace placeholders with concrete details from the feature description, preserving section order and headings.

7. **Specification Quality Validation**: after writing the initial spec, validate against quality criteria:

   a. **Create Spec Quality Checklist** at `{context.paths.intents}/<feature-dir>/checklists/requirements.md` (alongside `intent.md`), from `templates/requirements-checklist.md` — fill the `[FEATURE NAME]` / `[DATE]` / link placeholders.

   b. **Run Validation Check**: review the spec against each checklist item; mark pass/fail, documenting issues (quote spec sections).

   c. **Handle Results**:
      - **All pass**: mark checklist complete and proceed.
      - **Items fail (excluding [NEEDS CLARIFICATION])**: list the failing items + issues, update the spec, re-run until all pass (max 3 iterations); if still failing, document remaining issues in checklist notes and warn the user.
      - **[NEEDS CLARIFICATION] markers remain**: extract all markers; if more than 3, keep the 3 most critical (scope/security/UX), guess the rest; read `references/clarification-question-format.md` (only now) and present each question (max 3, numbered Q1-Q3) in that format's table style; present together, apply the user's choices to the markers, then re-run validation.

   d. **Update Checklist**: after each iteration, update the checklist file with current status.

8. **Report completion** with:
   - The feature directory path (`dirname` of `{context.current.intent}`)
   - The intent file path (`{context.current.intent}`, aka `INTENT_FILE` in the script's JSON)
   - Checklist summary
   - Next phase (`/clarify-intent` or `/plan`)

9. **Check for extension hooks**: after reporting completion, check if `.fire-phoenix/extensions.yml` exists in the project root. If not, skip silently. If it exists, read `references/extension-hooks.md` §Post-completion and apply the hook protocol against the `hooks.after_specify` key.

**NOTE:** Branch creation is handled by the `before_specify` hook (git extension); spec directory and file creation are always this core command's job.

## Quick Guidelines

- Focus on **WHAT** users need and **WHY**; avoid HOW (no tech stack, APIs, code structure).
- Written for business stakeholders, not developers.
- Do not embed checklists in the spec — that is a separate command.
- In interactive mode, **the user may have no technical or
  domain background** — never present jargon, blank fields, or
  multi-question prompts (see above).

### Section Requirements

- **Mandatory sections**: complete for every feature.
- **Optional sections**: include only when relevant.
- When a section doesn't apply, remove it entirely (not "N/A").

### Authoring guidelines

When filling the intent template (step 5) and authoring/validating
Success Criteria (steps 5-7), read
`references/authoring-guidelines.md` — informed-guess rules, the
3-marker clarification budget, reasonable defaults, and good/bad
success-criteria examples. Consult it at those steps, not before.

## Inputs

- **Feature Description** (`{context.current.feature}`)
  - If set: use it as the specification subject.
  - If null / not provided: ask the user to describe the feature; do not proceed without one.

- **Upstream artifact** (optional) — if a `recover-spec` output
  (`recovered/<capability>.md`) or `brainstorm` record exists, prefer it
  over the raw description.

- **Existing-system context** (optional, brownfield) — when
  `{context.paths.docs}/baseline/capabilities.md` exists, name
  duplicated/impacted capabilities in Assumptions; when
  `{context.paths.docs}/analysis/codebase-scan.md` exists, take
  actor/entity vocabulary from it, don't guess.

## Outputs

- **Specification** (`{context.paths.intents}/{context.current.feature}/intent.md`)
  - Create the spec file at this path; overwrite guarded by `{context.preferences.confirm_before_write}`.

- **Specification Quality Checklist** (`{context.paths.intents}/{context.current.feature}/checklists/requirements.md`)
  - Create the checklist file; overwrite guarded by `{context.preferences.confirm_before_write}`.

## Context Update

On success, update `.fire-phoenix/user-context.yml`:

- Set current.intent to the created specification file's path.
- Set current.feature to the feature slug.
- Leave all other `current.*` fields unchanged; do not modify `paths.*` or `preferences.*`

Use `write_user_context_value current.<key> <value>` (bash) or `Write-UserContextValue -Key current.<key> -Value <value>` (PowerShell) from the bundle helpers. Hand-editing `.fire-phoenix/user-context.yml` is also fine; do NOT modify `.fire-phoenix/context.yml`.

## Handoffs

- **Build Technical Plan**: run `/plan`.
- **Clarify Spec Requirements**: run `/clarify-intent`.
