# Manual feature-directory resolution for `/intent`

> Read this only when the action script
> (`scripts/bash/create-new-feature.sh` / PowerShell sibling) cannot
> run and you must create the feature directory by hand. Extracted
> — canonical text, not a copy.

**Resolution order for the new feature directory**:

1. The intents root is always `{context.paths.intents}/` from
   `.fire-phoenix/context.yml`. There is no separate
   environment-variable override — projects that need a non-default
   location reconfigure `paths.intents` in their context file.
2. Prefix selection:
   - Check `.fire-phoenix/init-options.yml` for `branch_numbering`
   - If `"timestamp"` (or `--timestamp` is passed to the action
     script): prefix is `YYYYMMDD-HHMMSS` (current timestamp)
   - If `"sequential"` or absent: prefix is `NNN` (next available
     3-digit number after scanning existing directories under
     `{context.paths.intents}/`)
3. Construct the directory name: `<prefix>-<short-name>` (e.g.,
   `003-user-auth` or `20260319-143022-user-auth`).

**Create the directory and intent file**:

- `mkdir -p {context.paths.intents}/<branch-name>`
- Copy `templates/intent-template.md` to
  `{context.paths.intents}/<branch-name>/intent.md` as the starting
  point
- Update the `current.intent` cursor to point at the new file
  (relative to repo root), so downstream skills (`/plan`,
  `/taskify`, …) pick it up without further glue — via
  `write_user_context_value` / `Write-UserContextValue` against
  `.fire-phoenix/user-context.yml`.
