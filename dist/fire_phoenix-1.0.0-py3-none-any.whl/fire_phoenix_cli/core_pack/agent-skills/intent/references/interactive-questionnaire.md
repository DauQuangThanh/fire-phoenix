# `/intent` interactive-mode questionnaire

> Read this only in interactive mode when the feature description is
> too sparse to populate every mandatory section of the intent
> template. Extracted — canonical text, not a copy.

Audience: assume the user has **no technical and no business-domain
background**. Tone: friendly, plain English, examples over
abstractions.

Conversational rules (apply to every question):

- **One question at a time.** Never present a wall of questions.
- **Yes / no first.** Phrase questions so `yes`, `no`, `not sure`,
  or `skip` is a valid answer.
- **Choices, not blank fields.** When yes/no isn't enough, offer
  2-4 lettered options (A/B/C/D) with one-line everyday
  descriptions. Always include "Not sure — pick a sensible default".
- **Always recommend.** State which option you would pick and why
  in one sentence so the user can reply "yes" / "ok".
- **No jargon.** Avoid NFR, SLA, RBAC, PII, GDPR, throughput,
  idempotent, eventual consistency. Translate to everyday words
  with concrete examples ("Should each user only see their own
  things?" not "Is this multi-tenant?").
- **Treat `not sure` / `skip` as a default-trigger.** Apply a
  sensible default, write it into the spec marked
  "(default applied — confirm later)", and log an `RDEBT-` entry.
- **Confirm progress visibly.** After each batch, summarise what you
  captured in 2-3 plain bullets and ask "Did I get that right? (yes
  / change X)" before moving on.

Question batches (run in order, skip a batch if already answered):

1. **Goal** — problem in one sentence; how it's done today (by hand,
   spreadsheet, another tool); what success looks like in everyday
   terms.
2. **Users** — who uses it (A) just me, B) my team, C) customers /
   public, D) other); will users sign in?; do different users see
   different things?; rough headcount (A) <10, B) 10-100, C)
   100-1,000, D) >1,000, E) not sure).
3. **What it does** — main flow in plain words, step by step;
   creates / saves anything?; searches / looks things up?; shares
   with others?; deletes / undoes?; sends messages (email / SMS /
   push)?
4. **Data** — collects personal info (names, emails, phone, address,
   payments)?; special rules (medical, financial, children, EU
   users)?; deleted data: A) gone forever, B) kept for a while,
   C) not sure.
5. **Devices and access** — A) phone, B) computer, C) tablet, D) all;
   needs offline?; needs multiple languages?
6. **Speed and scale** — speed feel: A) instant, B) within a couple
   of seconds, C) a few seconds, D) longer is fine; many users at
   once? (rough peak).
7. **When things go wrong** — error handling: A) friendly error,
   try again, B) save and resume later, C) not sure; concurrent
   edits: A) last one wins, B) warn them, C) not sure; explicit
   out-of-scope items.

Mapping answers into the spec template:

| Batch | Spec sections it feeds |
|-------|------------------------|
| 1     | problem statement, Success Criteria |
| 2     | User Scenarios (As a X I want Y so that Z), actors |
| 3     | Functional Requirements, primary user journey |
| 4     | Key Entities, privacy / compliance NFRs, retention assumption |
| 5     | NFRs (devices, offline, i18n), Assumptions |
| 6     | NFRs (performance, scale), measurable Success Criteria |
| 7     | Edge Cases, Out-of-scope, conflict-resolution rules |
