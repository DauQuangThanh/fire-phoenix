#!/usr/bin/env bash
# Shared helpers for docx-markdown action scripts.
#
# These skills are standalone Office round-trip tools: they don't read
# .fire-phoenix/context.yml, don't write under docs/<work-type>/, and don't
# need the full fire-phoenix helper surface area. Sourcing this file gives
# the action scripts a tiny, consistent set of log helpers and the
# location of the bundle's Python scripts so setup_env / wrappers
# can resolve requirements.txt and venv_bootstrap.py reliably.

FIRE_PHOENIX_SKILL_SCRIPTS_DIR="$( cd -- "$( dirname -- "${BASH_SOURCE[0]}" )/.." &> /dev/null && pwd )"
FIRE_PHOENIX_SKILL_NAME="docx-markdown"

fire_phoenix_log()  { echo "[${FIRE_PHOENIX_SKILL_NAME}] $*"; }
fire_phoenix_warn() { echo "[${FIRE_PHOENIX_SKILL_NAME}] warning: $*" >&2; }
fire_phoenix_err()  { echo "[${FIRE_PHOENIX_SKILL_NAME}] error: $*"   >&2; }
