# Bootstrap a project-local virtualenv for docx-markdown (Windows / PowerShell).
#
# Creates .\.venv in the current working directory (so it sits next to your
# .docx files, not inside the skill folder), then pip-installs the skill's
# Python deps from scripts\requirements.txt.
#
# Run from the workspace where you want the venv to live:
#
#   pwsh <skill-dir>\scripts\powershell\setup_env.ps1
#
# Override the Python executable with: $env:PYTHON = "py -3.12"; .\setup_env.ps1
#
# Note: pandoc is a separate system dependency. Install via Chocolatey
# (choco install pandoc) or from https://pandoc.org/installing.html.
$ErrorActionPreference = "Stop"

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Definition
. (Join-Path $ScriptDir 'common.ps1')

$RequirementsFile = Join-Path $Script:FirePhoenixSkillScriptsDir "requirements.txt"
$VenvDir   = if ($env:VENV_DIR) { $env:VENV_DIR } else { ".venv" }
$PythonBin = if ($env:PYTHON)   { $env:PYTHON }   else { "python" }

$pythonCheck = Get-Command $PythonBin -ErrorAction SilentlyContinue
if (-not $pythonCheck) {
    FirePhoenix-Err "'$PythonBin' not found on PATH. Install Python 3.10+ or set `$env:PYTHON and re-run."
    exit 1
}

if (-not (Test-Path $RequirementsFile)) {
    FirePhoenix-Err "$RequirementsFile not found."
    exit 1
}

if (-not (Test-Path $VenvDir)) {
    FirePhoenix-Log "Creating virtual environment at $VenvDir ..."
    & $PythonBin -m venv $VenvDir
} else {
    FirePhoenix-Log "Using existing virtual environment at $VenvDir"
}

$VenvPy = Join-Path $VenvDir "Scripts\python.exe"

& $VenvPy -m pip install --upgrade pip
& $VenvPy -m pip install -r $RequirementsFile

$pandocCheck = Get-Command pandoc -ErrorAction SilentlyContinue
if (-not $pandocCheck) {
    Write-Host ""
    FirePhoenix-Warn "'pandoc' is not on PATH."
    Write-Host "  This skill uses pandoc for the docx <-> md conversion."
    Write-Host "  Install via:  choco install pandoc  |  https://pandoc.org/installing.html"
}

Write-Host ""
FirePhoenix-Log "venv ready at $VenvDir"
Write-Host "  Activate (optional):  $VenvDir\Scripts\Activate.ps1"
Write-Host "  Or just run scripts directly; they will auto-prefer .\$VenvDir."
