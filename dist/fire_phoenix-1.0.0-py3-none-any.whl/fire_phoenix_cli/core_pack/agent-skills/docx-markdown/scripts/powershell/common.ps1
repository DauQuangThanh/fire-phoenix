# Shared helpers for docx-markdown action scripts (PowerShell).
#
# These skills are standalone Office round-trip tools: they don't read
# .fire-phoenix/context.yml, don't write under docs/<work-type>/, and don't
# need the full fire-phoenix helper surface area. Dot-sourcing this file gives
# the action scripts a tiny, consistent set of log helpers and the
# location of the bundle's Python scripts so setup_env / wrappers can
# resolve requirements.txt and venv_bootstrap.py reliably.

$Script:FirePhoenixSkillScriptsDir = (Resolve-Path (Join-Path (Split-Path -Parent $MyInvocation.MyCommand.Definition) '..')).Path
$Script:FirePhoenixSkillName = 'docx-markdown'

function FirePhoenix-Log  { param([string]$Message) Write-Host  "[$Script:FirePhoenixSkillName] $Message" }
function FirePhoenix-Warn { param([string]$Message) Write-Host  "[$Script:FirePhoenixSkillName] warning: $Message" -ForegroundColor Yellow }
function FirePhoenix-Err  { param([string]$Message) Write-Error "[$Script:FirePhoenixSkillName] $Message" }
