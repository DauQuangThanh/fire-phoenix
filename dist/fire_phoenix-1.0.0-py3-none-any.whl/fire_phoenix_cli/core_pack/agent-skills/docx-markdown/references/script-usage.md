# Script usage

Detailed per-script invocations and flags. The `python …` calls work
identically on macOS, Linux, and Windows — forward slashes in script
paths are accepted by Python on all three (only venv setup and direct
`soffice` invocation differ per platform).

## `docx_to_md.py`

macOS / Linux (bash):

```bash
python scripts/docx_to_md.py report.docx report.md
python scripts/docx_to_md.py report.docx report.md --assets-dir media
python scripts/docx_to_md.py report.docx report.md --accept-changes
python scripts/docx_to_md.py report.docx report.md --no-meta
```

Windows (PowerShell):

```powershell
python scripts\docx_to_md.py report.docx report.md
python scripts\docx_to_md.py report.docx report.md --assets-dir media
python scripts\docx_to_md.py report.docx report.md --accept-changes
python scripts\docx_to_md.py report.docx report.md --no-meta
```

Options:

- `--assets-dir` — override the media folder (default: `<name>.assets`).
- `--accept-changes` — accept all tracked changes before converting (runs LibreOffice headlessly).
- `--no-meta` — skip the sidecar (lossy export).

## `md_to_docx.py`

macOS / Linux (bash):

```bash
python scripts/md_to_docx.py report.md report.docx
python scripts/md_to_docx.py report.md report.docx --reference-doc original.docx
python scripts/md_to_docx.py report.md report.docx --meta report.meta.json
```

Windows (PowerShell):

```powershell
python scripts\md_to_docx.py report.md report.docx
python scripts\md_to_docx.py report.md report.docx --reference-doc original.docx
python scripts\md_to_docx.py report.md report.docx --meta report.meta.json
```

Options:

- `--reference-doc` — override the reference doc used by pandoc for styles.
- `--meta` — override the sidecar location.
- `--skip-post-process` — skip re-injection of comments / tracked changes (useful for debugging).

## `roundtrip_check.py`

Exports, rebuilds, re-exports, and diffs the two Markdown files.

macOS / Linux (bash):

```bash
python scripts/roundtrip_check.py report.docx
```

Windows (PowerShell):

```powershell
python scripts\roundtrip_check.py report.docx
```
