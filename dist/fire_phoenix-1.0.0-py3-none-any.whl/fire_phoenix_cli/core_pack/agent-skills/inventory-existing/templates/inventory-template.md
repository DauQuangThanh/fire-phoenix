# Initial inventory — <YYYY-MM-DD>

> OBSERVED-only snapshot of an existing (brownfield) project. Every
> line below is OBSERVED — directly visible from the filesystem +
> `git log`. No inference about purpose, design, or quality. See
> `references/brownfield-discipline.md` for the rules this template
> encodes.

## Methodology artefacts (top-level)

- OBSERVED: `<file>` exists. (one row per artefact found)

## Tests (top-level directories)

- OBSERVED: `<dir>` exists.

## Build tooling (top-level)

- OBSERVED: `<file>` exists.

## CI / containerisation / infra

- OBSERVED: `<dir-or-file>` exists.

## Git age

- OBSERVED: first commit date is `<ISO8601>` (`git log --reverse
  --format=%aI | head -1`).
- OBSERVED: total commit count on HEAD is `<N>` (`git rev-list
  --count HEAD`).

## How to use this inventory

1. Read every `OBSERVED:` line.
2. Promote selected rows into `STATUS.md §What was here at init time`.
3. For each observed module / surface you intend to change, run
   `/characterise-behaviour <module>` to pin OBSERVED behaviour first.
4. For methodology artefacts conflicting with IDD canon, surface the
   conflict in a NEW `adr/NNNN-*.md` rather than silently overwriting.

## Refusal scope

This template (and the producing skill) REFUSES to enumerate:

- Purpose / intent of any artefact (`OBSERVED:` is the only tag).
- Quality judgements (no "good", "bad", "poor", "low coverage").
- Inferred design ("this looks like a microservice").
- Anything not directly observable from the filesystem + git log.

Inference belongs in the technical-analyst subagent + the
`/characterise-behaviour` skill, not here.
