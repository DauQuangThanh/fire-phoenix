---
name: inventory-existing
description: Enumerates observable artefacts in a brownfield project into an inventory
  report — every line tagged OBSERVED and citing the path or git command, refusing
  to infer. Canonical first move after init --brownfield.
license: MIT
compatibility: Designed for agentskills.io-compatible agents.
metadata:
  author: Dau Quang Thanh
  version: '1.0'
  requires: []
---

## User Input

```text
$ARGUMENTS
```

You **MUST** consider the user input before proceeding (if not empty).

## Pre-Execution Checks

1. **Confirm brownfield context.** The skill is intended for projects
   initialised with `fire-phoenix init --brownfield` (or for existing
   projects adopting IDD). On a fresh greenfield init, the inventory
   is trivially empty — the skill still runs, but flag the user that
   the brownfield archetype expects an existing codebase to enumerate.
2. **Check output path.** Inventory writes to
   `{context.paths.docs}/inventory/initial-inventory-<YYYY-MM-DD>.md`.
   If a file with that name already exists, REFUSE to overwrite —
   propose a different date or move the existing file out of the way.

## Outline

Walk the project root and enumerate, **OBSERVED-only**, into a markdown
report:

1. **Methodology artefacts (top-level)** — README.md, AGENTS.md,
   CLAUDE.md, PRODUCT.md, STATUS.md, decisions.md, CHANGELOG.md,
   CONTRIBUTING.md, LICENSE; adr/, specs/, contracts/, docs/,
   architecture/, ops/, .fire-phoenix/.
2. **Tests** — tests/, test/, __tests__/, spec/.
3. **Build tooling** — pyproject.toml / setup.py / package.json /
   pom.xml / Cargo.toml / go.mod / Makefile / Gemfile (and lockfiles).
4. **CI / containerisation / infra** — .github/, .gitlab/, .circleci/,
   .azure-pipelines/, terraform/, kubernetes/, helm/, Dockerfile,
   docker-compose.yml, .gitlab-ci.yml.
5. **Git age** — first commit date + total commit count.
6. **Recovery state** — whether
   `{context.paths.docs}/baseline/capabilities.md` exists and whether it
   still holds only the seeded placeholder rows (OBSERVED: file + first
   data row), so downstream recovery knows if the capabilities index has
   been started.

Every row carries the OBSERVED tag + the command / path that proves
it. Empty buckets stay empty (don't fabricate rows).

## The OBSERVED-only discipline

This is the load-bearing rule. The skill REFUSES to:

- Infer purpose ("this is a microservice") — instead: "OBSERVED:
  presence of Dockerfile + kubernetes/".
- Judge quality ("test coverage is low", "code is well-structured")
  — no judgement adjectives. Quality assessment is the
  technical-analyst's archaeology phase, not the inventory's.
- Read file *contents* beyond filename + existence. Exception:
  package.json / pyproject.toml / Cargo.toml / go.mod are read for
  declared languages + dependency counts, but ONLY the declared
  entries are enumerated; no interpretation.
- Claim anything not directly observable from the filesystem or
  `git log`.

When the user asks the skill to make an inferential claim, surface
the refusal + propose hand-off to technical-analyst (for archaeology)
or `/characterise-behaviour` (for behaviour pinning).

## Post-Execution Checks

- Output file exists at the expected path.
- Every body line starts with `- OBSERVED:` (no inference rows).
- The `## Git age` section has either two rows (first commit + count)
  OR a single "`.git/` absent" row.
- The `## How to use this inventory` footer is present (it carries
  the canonical hand-off recipe).

## Inputs

- The project root (from `FIRE_PHOENIX_REPO_ROOT`).
- `.fire-phoenix/context.yml` (`{context.paths.docs}` for output
  root).
- Optionally, `FIRE_PHOENIX_INVENTORY_DATE` env var (test fixture
  override; defaults to `date -u +%Y-%m-%d`).

## Outputs

- `{context.paths.docs}/inventory/initial-inventory-<YYYY-MM-DD>.md`
  — the OBSERVED-only inventory report.

## Context Update

This skill does NOT mutate `.fire-phoenix/context.yml`. The inventory
under `{context.paths.docs}/inventory/` is the only on-disk
side-effect.

## Handoffs

- **`technical-analyst` subagent** — receives the inventory and
  conducts archaeology (inference about purpose / structure /
  failure modes), tagged INFERRED.
- **`/characterise-behaviour` skill** — for each module the
  inventory surfaces that the team plans to change, run
  characterisation FIRST to pin OBSERVED behaviour.
- **BA / architect (human)** — promotes selected OBSERVED rows
  to NEW invariants in `PRODUCT.md §Invariants` (the brownfield
  variant has an explicit promotion track).
- **`STATUS.md §What was here at init time`** — the inventory is
  the canonical seed for this dated snapshot section.

## Refusal modes (negative constraints)

- **Refuse** to add inferential rows ("appears to be", "looks like",
  "probably is").
- **Refuse** quality judgements ("good", "bad", "low", "high",
  "poor", "excellent").
- **Refuse** to overwrite an existing inventory at the same date —
  pick a different date OR move the previous file aside.
- **Refuse** to read file contents beyond filename + the bounded set
  of build-tooling manifests (pyproject.toml / package.json /
  Cargo.toml / go.mod).
- **Refuse** to claim anything not directly observable from the
  filesystem or `git log`.
