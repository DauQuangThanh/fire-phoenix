# Brownfield discipline — inventory reference

Self-contained background for the `/inventory-existing` skill, which
implements the **archaeology-first step** of any brownfield IDD
project. The rules below define what the skill enforces; AI sessions
that invoke this skill must respect them.

- **Inventory FIRST, inference SECOND.** Before any change to a
  brownfield project, the team needs an OBSERVED snapshot of what is
  already there. This skill produces that snapshot.

- **OBSERVED-only discipline.** Every line in the inventory must be
  OBSERVED — directly visible from the filesystem + git log. No
  inference about purpose, design, or quality. Inferred work belongs
  to the `technical-analyst` subagent (archaeology) and to
  `/characterise-behaviour` (behaviour pinning).

- **Inventory feeds `STATUS.md §What was here at init time`.** The
  brownfield scaffold's `STATUS.md` has a dedicated section for the
  initial inventory; the inventory output is the canonical seed.

- **Inventory feeds the `PRODUCT.md` recovery process.** Recovered
  invariants drafted from inventory observations carry the
  `INFERRED (low|med|high confidence)` tag until a human promotes
  them to `OBSERVED` (per the brownfield `PRODUCT.md` variant).

Related skill: `/characterise-behaviour` — pin behaviour on modules
the inventory surfaces, before changing them.
