#!/usr/bin/env bash
# Enumerate observable artefacts in an existing (brownfield) project.
# Every line tagged OBSERVED: + cites the path that proves it. The
# skill REFUSES to infer purpose / design / quality.
#
# Per assets/agent-skills/inventory-existing/SKILL.md.

set -e

SCRIPT_DIR="$(CDPATH="" cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=common.sh
source "$SCRIPT_DIR/common.sh"

fire_phoenix_parse_standard_args "$@"
set -- "${FIRE_PHOENIX_REST_ARGS[@]}"

if [ "${1:-}" = "--help" ]; then
    cat <<'USAGE'
Usage: inventory.sh [--auto] [--answers FILE] [--dry-run] [--help]

Enumerate observable artefacts in the project root. Writes an inventory
report at {context.paths.docs}/inventory/initial-inventory-<YYYY-MM-DD>.md.

Each line tagged OBSERVED: + cites the path that proves it. The skill
refuses to infer purpose / design / quality.

Flags:
  --auto            non-interactive
  --answers FILE    KEY=VALUE file consulted when --auto
  --dry-run         print what would be written, do not touch the filesystem
  --help            show this message and exit
USAGE
    exit 0
fi

read_context

# Resolve date. The script intentionally does NOT call `date` for
# anything semantic — only for the filename. Override via env for tests.
TODAY="${FIRE_PHOENIX_INVENTORY_DATE:-$(date -u +%Y-%m-%d)}"

OUT_DIR=$(worktype_dir "inventory")
OUT_FILE="$OUT_DIR/initial-inventory-${TODAY}.md"

if [ "${FIRE_PHOENIX_DRY_RUN:-0}" = "1" ]; then
    echo "[dry-run] would write: $OUT_FILE"
    exit 0
fi

if [ -e "$OUT_FILE" ]; then
    echo "Error: inventory already exists at $OUT_FILE — refusing to overwrite." >&2
    exit 1
fi

if ! confirm_before_write "Write inventory report to $OUT_FILE"; then
    echo "Aborted." >&2
    exit 1
fi

# Helper: enumerate a target path if it exists.
emit_path_if_exists() {
    local rel="$1"
    local target="$FIRE_PHOENIX_REPO_ROOT/$rel"
    if [ -e "$target" ]; then
        printf -- "- OBSERVED: \`%s\` exists.\n" "$rel"
    fi
}

# Helper: enumerate any files matching a pattern (one per line).
emit_glob() {
    local glob="$1"
    local hits
    hits=$(cd "$FIRE_PHOENIX_REPO_ROOT" && ls $glob 2>/dev/null || true)
    if [ -n "$hits" ]; then
        for f in $hits; do
            printf -- "- OBSERVED: \`%s\` exists.\n" "$f"
        done
    fi
}

{
    cat <<EOF_HDR
# Initial inventory — ${TODAY}

> OBSERVED-only inventory of an existing (brownfield) project. Every
> line below is OBSERVED — directly visible from the filesystem. No
> inference about purpose, design, or quality. Inference belongs in
> follow-up archaeology (technical-analyst subagent +
> /characterise-behaviour).

## Methodology artefacts (top-level)

EOF_HDR

    for f in README.md AGENTS.md CLAUDE.md PRODUCT.md STATUS.md decisions.md CHANGELOG.md CONTRIBUTING.md LICENSE; do
        emit_path_if_exists "$f"
    done

    for d in adr specs contracts docs architecture ops .fire-phoenix; do
        emit_path_if_exists "$d"
    done

    cat <<'EOF_TESTS'

## Tests (top-level directories)

EOF_TESTS

    for d in tests test __tests__ spec; do
        emit_path_if_exists "$d"
    done

    cat <<'EOF_BUILD'

## Build tooling (top-level)

EOF_BUILD

    for f in pyproject.toml setup.py setup.cfg requirements.txt requirements-dev.txt \
             package.json package-lock.json yarn.lock pnpm-lock.yaml \
             pom.xml build.gradle build.gradle.kts \
             Cargo.toml Cargo.lock \
             go.mod go.sum \
             Makefile makefile \
             Gemfile Gemfile.lock; do
        emit_path_if_exists "$f"
    done

    cat <<'EOF_INT'

## CI / containerisation / infra

EOF_INT

    for d in .github .gitlab .circleci .azure-pipelines terraform kubernetes helm; do
        emit_path_if_exists "$d"
    done
    for f in Dockerfile docker-compose.yml docker-compose.yaml .gitlab-ci.yml; do
        emit_path_if_exists "$f"
    done

    cat <<EOF_GIT

## Git age

EOF_GIT

    if [ -d "$FIRE_PHOENIX_REPO_ROOT/.git" ]; then
        first_commit=$(cd "$FIRE_PHOENIX_REPO_ROOT" && git log --reverse --format=%aI 2>/dev/null | head -n 1 || echo "")
        commit_count=$(cd "$FIRE_PHOENIX_REPO_ROOT" && git rev-list --count HEAD 2>/dev/null || echo "")
        if [ -n "$first_commit" ]; then
            printf -- "- OBSERVED: first commit date is \`%s\` (\`git log --reverse --format=%%aI | head -1\`).\n" "$first_commit"
        else
            printf -- "- OBSERVED: \`.git/\` exists but no commits found (\`git log\` empty).\n"
        fi
        if [ -n "$commit_count" ]; then
            printf -- "- OBSERVED: total commit count on HEAD is %s (\`git rev-list --count HEAD\`).\n" "$commit_count"
        fi
    else
        printf -- "- OBSERVED: \`.git/\` is absent (project is not a git repository).\n"
    fi

    cat <<EOF_FOOT

## How to use this inventory

1. Read every \`OBSERVED:\` line.
2. Promote selected rows into \`STATUS.md §What was here at init time\`
   (the canonical brownfield-context anchor).
3. For each observed module / surface you intend to change, run
   \`/characterise-behaviour <module>\` to pin OBSERVED behaviour
   before the change.
4. For methodology artefacts that conflict with IDD canon (e.g. an
   existing \`docs/architecture/\` with non-canonical structure),
   surface the conflict in a NEW \`adr/NNNN-*.md\` rather than
   silently overwriting.

## Refusal scope

This skill REFUSES to enumerate:

- Purpose / intent of any artefact (\`OBSERVED:\` is the only tag).
- Quality judgements (no "good", "bad", "poor", "low coverage").
- Inferred design ("this looks like a microservice").
- Anything not directly observable from the filesystem + git log.

Inference belongs in the technical-analyst subagent + the
\`/characterise-behaviour\` skill, not here.
EOF_FOOT

} > "$OUT_FILE"

echo "Inventory written to $OUT_FILE"
echo "Reminder: every line is OBSERVED. Inference belongs to technical-analyst + /characterise-behaviour."
