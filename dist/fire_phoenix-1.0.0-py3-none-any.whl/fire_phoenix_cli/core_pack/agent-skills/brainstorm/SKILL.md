---
name: brainstorm
description: Explores the problem space upstream of intent — compares three or more
  divergent solution directions from an opportunity statement, then hands off to intent.
  Use at the front of the funnel before a feature is chosen.
license: MIT
compatibility: Designed for agentskills.io-compatible agents.
metadata:
  author: Dau Quang Thanh
  version: '1.0'
  requires: []
---

## User Input

```text
$ARGUMENTS
```

You **MUST** consider the user input before proceeding (if not empty). The
text is an *opportunity or problem statement* — the reason someone thinks
there may be something worth building — not yet a chosen feature.

## Purpose

This skill is the divergent front of the IDD funnel. It runs **before**
`intent`: `intent` captures and formalises a feature the user has already
decided to build; `brainstorm` helps the user decide *what* is worth
building by widening the space first. Its output is deliberately
**non-binding** — a set of options and open questions, never a decision.

## Audience and tone

Assume the user may have only a rough sense of the problem and no fixed
solution in mind. Run as a light, guided exploration:

- **Widen before you narrow.** Resist the first plausible answer; the
  point of this step is optionality, not closure.
- **Offer, don't interrogate.** Propose framings and options for the user
  to react to rather than demanding they fill blanks.
- **Name trade-offs in plain language.** Every option carries a one-line
  "good when / costly when" so a non-expert can compare.
- **Always leave a way out.** The user may end with "none of these" — that
  is a valid, recorded outcome, not a failure.

## Outline

Given the opportunity statement, do this:

1. **Frame the problem — more than one way.** State the problem in the
   user's own terms, then offer two or three alternative framings (who
   hurts, what job is unmet, what would change if solved). The framing
   chosen downstream shapes everything, so surface it explicitly rather
   than assuming.

2. **Diverge — generate at least three genuinely different directions.**
   Each option is a *direction*, not an implementation. Options must be
   materially distinct (a different bet, not a re-wording). For each,
   record: the core idea in one sentence; who it serves; the main
   trade-off (good when / costly when); and the biggest unknown.

3. **Tag every factual claim.** Any statement about users, market,
   competitors, cost, or demand is tagged `OBSERVED` (grounded in a source
   the user supplied or you can cite), `INFERRED` (reasoned, not
   confirmed), or `UNKNOWN` (needs research). **Never present an inference
   as observation, and never invent figures.** An `UNKNOWN` is a better
   entry than a fabricated fact.

4. **Compare — a light option table.** One row per option, columns for the
   trade-off, the key unknown, and a rough effort signal (small / medium /
   large — qualitative, not estimated hours). Do not score to a winner.

5. **Shortlist and open questions.** Narrow to one or two directions worth
   carrying forward, with a one-line reason each, and list the questions
   that would most change the choice if answered. Selecting the direction
   is the **user's** call, not this skill's.

6. **Write the brainstorm record** (see Outputs) and report where it landed
   plus the recommended next step.

## AI authoring scope

**Does:** widen the problem framing; generate at least three distinct
solution directions; surface trade-offs and unknowns; produce a comparison
and a shortlist; record every factual claim with an `OBSERVED` /
`INFERRED` / `UNKNOWN` tag.

**Does not:** pick a winner; commit the user to an option; invent market,
user, or cost figures; write or edit the feature `intent.md`; mutate any
project state cursor.

## Negative constraints

- **Never emit a decision.** The artefact holds options; the user decides,
  and the decision is recorded downstream by `intent`, not here.
- **Never fabricate** market, user, competitor, or cost data. Unverifiable
  claims are tagged `UNKNOWN`.
- **Never write to or overwrite** a feature's `intent.md` or its checklists.
- **Never behave as a required gate.** This skill is opt-in; a fast path
  that skips brainstorming straight to `intent` must remain valid.

## Inputs

- **Opportunity Statement** (`$ARGUMENTS`)
  - If set: use it as the subject to explore.
  - If empty: ask the user to describe the problem or opportunity in a
    sentence or two before proceeding.

## Outputs

- **Brainstorm Record** (`{context.paths.intents}/<opportunity-short-name>/brainstorm.md`)
  - Derive a 2–4 word short name for the opportunity (action-noun form,
    e.g. "reduce-onboarding-drop-off"), create that directory under
    `{context.paths.intents}/` if it does not exist, and write the record
    there.
  - The record contains: the problem framings, the divergent options
    (≥3), the comparison table, the shortlist, and the open questions.
  - Overwrite guarded by `{context.preferences.confirm_before_write}`.

## Context Update

This skill does not write to `.fire-phoenix/context.yml` or
`.fire-phoenix/user-context.yml`. It does not set `current.feature` or
`current.intent`; the downstream `intent` run establishes those cursors per
its own contract when the user commits to a direction. Leaving state
untouched keeps re-running this skill idempotent and side-effect free.

## Handoffs

- **Formalise the chosen direction**: run `/intent` with the selected
  option as the feature description to open the committed feature.
- **Research an open question**: run `/technology-research` when a
  shortlisted direction hinges on an unresolved technology choice.
