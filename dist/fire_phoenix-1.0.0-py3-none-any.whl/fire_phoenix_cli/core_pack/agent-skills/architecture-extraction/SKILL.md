---
name: architecture-extraction
description: Extracts architecture from an existing codebase — containers, components,
  data flow, dependencies — seeding ADRs and C4 diagrams. Use when reverse-engineering
  a codebase or generating architecture docs from code.
license: MIT
compatibility: Designed for agentskills.io-compatible agents.
metadata:
  author: Dau Quang Thanh
  version: '1.0'
  requires: []
---

## User Input

```text
$ARGUMENTS
```

## Audience and tone (interactive mode)

**Register first — adapt to role level.** Run as a guided, one-question-at-a-time questionnaire (yes/no first, recommend a default); skip in `FIRE_PHOENIX_AGENT_MODE=auto`. Full rules: `.fire-phoenix/references/subagents/interactive-questionnaire.md`.

## Inputs

- `.fire-phoenix/context.yml`
- `{context.paths.docs}/analysis/codebase-scan.md`
- Source tree

## Outputs

- `{context.paths.docs}/architecture/extracted.md`
- `{context.paths.docs}/architecture/extracted.extract`

## Context Update

Does not mutate `.fire-phoenix/context.yml`.

## Handoffs

- `c4-diagrams` converts extracted structure into C4 Mermaid.
- `adr-author` seeds candidate ADRs for decisions embedded in the
  code (e.g. "chose PostgreSQL") that had no prior ADR.

## AI authoring scope

**Does:** read config files (compose / k8s / terraform / ci),
entry-point modules, and infer the container + dependency graph.
Flag decisions that appear to have been made implicitly (no ADR).

**Does not:** modify code; claim intent without evidence; edit or
overwrite existing architecture docs (drift is reported, the
architect decides what to update).

## Extraction flow

1. **Start from the scan** — entry points, hot paths, and
   detected infrastructure files from `codebase-scan.md` seed
   the container hunt.
2. **Extract** containers, integrations, and data flow per
   `references/extraction-heuristics.md`. Every claim carries a
   confidence tag — `OBSERVED` with `file:line`, `INFERRED
   (low|med|high confidence)` with reasoning, or `UNKNOWN` — and
   is re-verified against its source before it lands in the
   artefact.
3. **Reconcile against documented architecture** — read any
   existing `{context.paths.docs}/architecture/c4-*.md`,
   `intake.md`, and ADRs. For each documented element, check the
   code evidence and classify: **match** (docs and code agree),
   **drift** (docs say X, code shows Y), **undocumented** (in
   code, absent from docs), or **unimplemented** (in docs,
   absent from code). Drift and its neighbours are recorded as
   findings in the artefact's drift table — the existing docs
   are never silently rewritten to match the code (or vice
   versa); the architect resolves each row.
4. **Flag implicit decisions** as candidate ADRs — evident from
   implementation, rationale not documented; never invent the
   rationale.
5. **Log gaps** (`TDEBT-` / `ANALYSISDEBT-`) — missing
   rate-limiting, tracing, inconsistent logging, unverifiable
   claims.

## Usage

> `<SKILL_DIR>` = the integration's skills root (e.g. `.claude/skills/`
> for Claude Code, `.codex/skills/` for Codex,
> `.cursor/skills/` for Cursor).
> Scripts live at `<SKILL_DIR>/<skill-name>/scripts/…`.

```bash
bash <SKILL_DIR>/architecture-extraction/scripts/bash/extract.sh --auto
```
