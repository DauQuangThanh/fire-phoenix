# Definition-of-Done anatomy (milestone / DoD checklists)

When this skill builds a **milestone, Definition-of-Done, or
ceremony-prep checklist** (the PM and Scrum Master use cases —
distinct from the requirements-quality checklists in the main
flow), each item follows the same anatomy the project's completion
checklists already use elsewhere: an item is a **falsifiable claim
plus the evidence that proves it**, never an activity.

## Item anatomy

```text
- [ ] <claim that is true or false> — evidence: <artefact>
```

- **Falsifiable** — a reviewer can answer yes/no without judgement
  calls. "Documentation updated" fails this test; "user-facing
  docs cover the two new CLI flags" passes.
- **Evidenced** — the item names where the proof lives. Without an
  evidence source, ticking the box is an assertion, not a check.

## Standard evidence sources

| DoD dimension | Evidence to name |
|---|---|
| Acceptance coverage | Every AC-NNN in scope has a covering test citing its id, or a named manual review in the coverage map |
| Tests | The test run (suite green, new tests failing-before / passing-after where the change fixed a bug) |
| Docs | The updated file(s), named |
| Registers | Risk-register rows reviewed; change-log entry / register row for the change, with disposition recorded |
| Approval | The named approver's sign-off, with date |

## Rules

- Items the project's standards already enforce mechanically
  (lint, coverage thresholds) still appear — the checklist cites
  the run rather than restating the rule.
- An unticked item at the deadline is not deleted; it is either
  done, waived with a recorded rationale, or logged as a debt in
  the parent agent's debt file.
- Sprint- or milestone-level DoD **inherits** the project-level
  DoD from `project-plan.md`; the checklist adds specifics, it
  never silently drops an inherited item.
