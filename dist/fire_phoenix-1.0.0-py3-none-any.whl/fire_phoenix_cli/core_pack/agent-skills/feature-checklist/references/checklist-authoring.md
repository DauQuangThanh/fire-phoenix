# Checklist authoring — categories, item structure, coverage

Deep authoring rules for step 5 of `SKILL.md` (requirements-quality
domain). Read this when generating checklist items.

## Category Structure — group items by requirement quality dimension

- **Requirement Completeness** (all documented?)
- **Requirement Clarity** (specific, unambiguous?)
- **Requirement Consistency** (aligned, no conflicts?)
- **Acceptance Criteria Quality** (measurable?)
- **Scenario Coverage** (all flows/cases?)
- **Edge Case Coverage** (boundaries defined?)
- **Non-Functional Requirements** (Performance, Security,
  Accessibility, etc. — specified?)
- **Dependencies & Assumptions** (documented, validated?)
- **Ambiguities & Conflicts** (what needs clarification?)

## Item Structure

Each item follows this pattern:

- Question format asking about requirement quality.
- Focus on what's WRITTEN (or not written) in the spec/plan.
- Include the quality dimension in brackets
  [Completeness/Clarity/Consistency/etc.].
- Reference `[Spec §X.Y]` when checking existing requirements.
- Use `[Gap]` when checking for missing requirements.

## Scenario Classification & Coverage (requirements-quality focus)

- Check requirements exist for: Primary, Alternate, Exception/Error,
  Recovery, Non-Functional scenarios.
- For each scenario class, ask: "Are [scenario type] requirements
  complete, clear, and consistent?"
- If a scenario class is missing: "Are [scenario type] requirements
  intentionally excluded or missing? [Gap]"
- Include resilience/rollback on state mutation: "Are rollback
  requirements defined for migration failures? [Gap]"

## Traceability Requirements

- MINIMUM: ≥80% of items MUST include ≥1 traceability reference.
- Each item references `[Spec §X.Y]`, or the markers `[Gap]`,
  `[Ambiguity]`, `[Conflict]`, `[Assumption]`.
- If no ID system exists: "Is a requirement & acceptance criteria ID
  scheme established? [Traceability]"

## Content Consolidation

- Soft cap: if raw candidate items > 40, prioritize by risk/impact.
- Merge near-duplicates on the same requirement aspect.
- If >5 low-impact edge cases, create one item: "Are edge cases X, Y,
  Z addressed in requirements? [Coverage]"
