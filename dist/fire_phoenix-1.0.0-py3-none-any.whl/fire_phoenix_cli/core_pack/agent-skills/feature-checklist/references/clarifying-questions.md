# Clarifying-question generation for `/checklist`

> Read this only when you are about to formulate or present
> clarifying questions in Execution Step 2. Do not read it when
> `$ARGUMENTS` is already unambiguous (zero questions needed) or in
> auto mode. Extracted — canonical text, not a copy.

Generation algorithm:

1. Extract signals: feature domain keywords (e.g., auth, latency, UX, API), risk indicators ("critical", "must", "compliance"), stakeholder hints ("QA", "review", "security team"), and explicit deliverables ("a11y", "rollback", "contracts").
2. Cluster signals into candidate focus areas (max 4) ranked by relevance.
3. Identify probable audience & timing (author, reviewer, QA, release) if not explicit.
4. Detect missing dimensions: scope breadth, depth/rigor, risk emphasis, exclusion boundaries, measurable acceptance criteria.
5. Formulate questions chosen from these archetypes:
   - Scope refinement (e.g., "Should this include integration touchpoints with X and Y or stay limited to local module correctness?")
   - Risk prioritization (e.g., "Which of these potential risk areas should receive mandatory gating checks?")
   - Depth calibration (e.g., "Is this a lightweight pre-commit sanity list or a formal release gate?")
   - Audience framing (e.g., "Will this be used by the author only or peers during PR review?")
   - Boundary exclusion (e.g., "Should we explicitly exclude performance tuning items this round?")
   - Scenario class gap (e.g., "No recovery flows detected—are rollback / partial failure paths in scope?")

Question formatting rules:

- If presenting options, generate a compact table with columns: Option | Candidate | Why It Matters
- Limit to A–E options maximum; omit table if a free-form answer is clearer
- Never ask the user to restate what they already said
- Avoid speculative categories (no hallucination). If uncertain, ask explicitly: "Confirm whether X belongs in scope."

Defaults when interaction impossible:

- Depth: Standard
- Audience: Reviewer (PR) if code-related; Author otherwise
- Focus: Top 2 relevance clusters

Output the questions (label Q1/Q2/Q3). After answers: if ≥2 scenario classes (Alternate / Exception / Recovery / Non-Functional domain) remain unclear, you MAY ask up to TWO more targeted follow‑ups (Q4/Q5) with a one-line justification each (e.g., "Unresolved recovery path risk"). Do not exceed five total questions. Skip escalation if user explicitly declines more.
