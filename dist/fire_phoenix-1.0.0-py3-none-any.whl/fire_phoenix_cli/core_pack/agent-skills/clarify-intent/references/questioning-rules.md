# Question-queue selection rules

Constraints for building the prioritized candidate queue (step 3 of
`SKILL.md`). Read this when generating the queue.

- Questions are limited to 5 total across the session.
- Each question must be answerable with EITHER:
  - a short multiple-choice selection (2–5 distinct, mutually
    exclusive options), OR
  - a one-word / short-phrase answer (constrain: "Answer in <=5
    words").
- Only include questions whose answers affect architecture, data
  modeling, task decomposition, test design, UX behavior, operational
  readiness, or compliance validation.
- Balance coverage: cover the highest-impact unresolved categories
  first; avoid two low-impact questions when one high-impact area
  (e.g., security posture) is unresolved.
- Exclude questions already answered, trivial stylistic preferences,
  or plan-level execution details (unless blocking correctness).
- Favor clarifications that cut rework risk or prevent misaligned
  acceptance tests.
- If more than 5 categories remain, pick the top 5 by
  (Impact × Uncertainty) heuristic.
