# Question presentation formats for `/clarify-intent`

> Read this only when you are about to present a multiple-choice or
> short-answer question in the sequential questioning loop (step 4).
> Do not read it in auto mode — no questions are presented there.
> Extracted — canonical text, not a copy.

For multiple‑choice questions:

- **Analyze all options** and determine the **most suitable option** based on:
  - Best practices for the project type
  - Common patterns in similar implementations
  - Risk reduction (security, performance, maintainability)
  - Alignment with any explicit project goals or constraints visible in the spec
- Present your **recommended option prominently** at the top with clear reasoning (1-2 sentences in plain words explaining why this is the best choice).
- Format as: `**Recommended:** Option [X] - <reasoning in plain words>`
- Then render all options as a Markdown table. Each option's description must be **plain consequence**, not a technical implication ("users wait a bit longer" not "added latency"; "you store a bit more data" not "increased storage cost"):

  | Option | Plain-language answer | What this means for you |
  |--------|------------------------|--------------------------|
  | A | <Everyday-language answer> | <Plain consequence> |
  | B | <Everyday-language answer> | <Plain consequence> |
  | C | <Everyday-language answer> | <Plain consequence> (add D/E up to 5) |
  | Not sure | Use the recommended default | <What the default is, in plain words> |
  | Short | Tell me in your own words (<=5 words) | I'll translate it into the spec for you (include only if a free-form answer is appropriate) |

- After the table, add: `You can reply with the option letter (e.g., "A"), say "yes" or "recommended" to accept the suggestion, say "not sure" to use the default, or give a short answer in your own words.`

For short‑answer style (no meaningful discrete options):

- Provide your **suggested answer** based on best practices and context.
- Format as: `**Suggested:** <your proposed answer> - <brief reasoning in plain words>`
- Then output: `Format: Short answer (<=5 words). Say "yes" or "suggested" to accept, "not sure" to use the suggestion as a default, or give your own answer.`
