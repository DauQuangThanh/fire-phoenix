# Answer integration — section mapping and formatting rules

How to fold each accepted clarification back into the spec (step 5 of
`SKILL.md`). Read this when integrating an answer.

## Where each clarification lands

Apply the clarification to the best-fit section(s):

- **Functional ambiguity** → update or add a bullet in Functional
  Requirements.
- **User interaction / actor distinction** → update User Stories or
  the Actors subsection (if present) with the clarified role,
  constraint, or scenario.
- **Data shape / entities** → update Data Model (add fields, types,
  relationships) preserving ordering; note new constraints.
- **Non-functional constraint** → add/modify measurable criteria in
  Success Criteria > Measurable Outcomes (convert a vague adjective
  to a metric or target).
- **Edge case / negative flow** → add a new bullet under Edge Cases /
  Error Handling (or create it if the template provides a
  placeholder).
- **Terminology conflict** → normalize the term across the spec; keep
  the original only if necessary, adding `(formerly referred to as
  "X")` once.

## Formatting and consistency rules

- If the clarification invalidates an earlier ambiguous statement,
  replace it — do not duplicate; leave no obsolete contradictory text.
- Save the spec AFTER each integration to cut context-loss risk
  (atomic overwrite).
- Preserve formatting: don't reorder unrelated sections; keep the
  heading hierarchy intact.
- Keep each inserted clarification minimal and testable (no narrative
  drift).
