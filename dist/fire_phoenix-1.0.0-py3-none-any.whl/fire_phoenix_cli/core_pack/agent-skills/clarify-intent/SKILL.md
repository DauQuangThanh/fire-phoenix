---
name: clarify-intent
description: Identifies underspecified areas in the current feature spec by asking
  up to 5 targeted clarification questions and encoding answers back in. Use when
  a spec has gaps or ambiguities.
license: MIT
compatibility: Designed for agentskills.io-compatible agents.
metadata:
  author: Dau Quang Thanh
  version: '1.0'
  requires: [intent]
  scripts:
    sh: scripts/bash/check-prerequisites.sh --json --paths-only
    ps: scripts/powershell/check-prerequisites.ps1 -Json -PathsOnly
---

## User Input

```text
$ARGUMENTS
```

You **MUST** consider the user input (if not empty).

## Pre-Execution Checks

Check for extension hooks before clarification:

- If `.fire-phoenix/extensions.yml` is absent, skip silently.
- If it exists, read `references/extension-hooks.md` §Pre-execution
  and apply that hook protocol against the
  `hooks.before_clarify-specs` key before the Outline.

## Outline

Goal: Detect and reduce ambiguity or missing decision points in the active feature spec; record clarifications directly in it.

Note: This workflow should run and complete BEFORE `/plan`. If the user explicitly skips clarification (e.g., exploratory spike), you may proceed but must warn that downstream rework risk rises.

### Audience and tone (interactive mode)

**Register first — adapt to role level.** Resolve level from merged context (`user-context.yml` wins) per `.fire-phoenix/references/subagents/register-resolution.md`; unset → beginner floor.

If `FIRE_PHOENIX_AGENT_MODE=interactive` (the default), assume the user has
**no technical and no business-domain background**. The step-2
taxonomy is your **internal** coverage map — never expose its
labels to the user.

Before presenting any question in step 4, read
`references/interactive-style.md` (yes/no-first phrasing,
plain-English translations, recommendation duty, default handling).
Skip it in auto mode.

When `FIRE_PHOENIX_AGENT_MODE=auto` (or `--auto`), skip the question loop:
pick the recommended option for every Partial / Missing category and
log decisions to the business-analyst decision log.

Execution steps:

1. Run `{SCRIPT}` from repo root **once** (`--json --paths-only` / `-Json -PathsOnly`). Parse minimal JSON fields:
   - `FEATURE_DIR`
   - `FEATURE_SPEC`
   - (Optionally capture `IMPL_PLAN`, `TASKS` for future flows.)
   - If JSON parsing fails, abort and tell the user to re-run `/intent` to populate `{context.current.intent}` in `.fire-phoenix/context.yml`.
   - For single quotes in args like "I'm Groot", use escape syntax: e.g 'I'\''m Groot' (or double-quote if possible: "I'm Groot").

2. Load the current spec file. Run a structured ambiguity & coverage scan using the taxonomy in `references/ambiguity-taxonomy.md` — read it only now, once the spec is loaded (not when aborting for a missing spec). For each category, mark status: Clear / Partial / Missing. Produce an internal coverage map for prioritization (output it only if no questions will be asked).

   For each Partial or Missing category, add a candidate question unless:
   - Clarification would not change implementation or validation strategy
   - Information is better deferred to planning (note internally)

3. Generate (internally) a prioritized queue of candidates (max 5; do NOT output all at once) per the selection rules in `references/questioning-rules.md`. In short: each question answerable as a 2–5 option MCQ or a ≤5-word phrase; include only answers that affect architecture, data, tasks, tests, UX, ops, or compliance; highest (Impact × Uncertainty) categories first.

4. Sequential questioning loop (interactive):
    - Present EXACTLY ONE question at a time.
    - **Always rewrite the question in plain everyday language before showing it.** Never expose taxonomy labels (NFR, observability, scalability, throughput, idempotent, RBAC, PII, eventual consistency). Translate it into a concrete situation with an example — worked translations in `references/interactive-style.md` (already read).
    - Before a multiple-choice or short-answer question,
      read `references/question-formats.md` and render in that
      format (recommended-option header, options table with
      plain descriptions, reply instructions). Skip it in auto
      mode — no questions asked.
    - After the user answers:
       - If the user replies "yes", "recommended", or "suggested", use your prior recommendation/suggestion as the answer.
       - If the user replies "not sure" or "skip", apply the recommendation/suggestion as default, mark the spec entry "(default applied — confirm later)", and continue unblocked.
       - Otherwise, validate the answer maps to one option or fits <=5 words.
       - If ambiguous, ask for quick disambiguation in plain words (same question; do not advance).
       - Once satisfactory, record it in working memory (not yet to disk) and move to the next question.
    - Stop asking further questions when:
       - All critical ambiguities resolved early (remaining items unnecessary), OR
       - User signals completion ("done", "good", "no more", "that's enough"), OR
       - You reach 5 asked questions.
    - Never reveal future questions.
    - If no valid questions exist at start, report no critical ambiguities.

5. Integration after EACH accepted answer (incremental) — read `references/answer-integration.md` for the full section-mapping and formatting rules:
    - Keep an in-memory copy of the spec (loaded once) plus the raw file contents.
    - For the first integrated answer this session, ensure a `## Clarifications` section exists (after the top-level overview per the spec template) with a `### Session YYYY-MM-DD` subheading for today.
    - Append `- Q: <question> → A: <final answer>`, then apply the clarification to the best-fit section(s) per the mapping in that reference.
    - Save the spec AFTER each integration (atomic overwrite); preserve heading hierarchy; keep each clarification minimal and testable.

6. Validation (after EACH write plus final pass):
   - Clarifications session has one bullet per accepted answer (no duplicates).
   - Total asked (accepted) questions ≤ 5.
   - Updated sections have no lingering vague placeholders the answer resolved.
   - No contradictory earlier statement remains (now-invalid alternatives removed).
   - Markdown structure valid; only allowed new headings: `## Clarifications`, `### Session YYYY-MM-DD`.
   - Terminology consistency: same canonical term across all sections.

7. Write the updated spec back to `FEATURE_SPEC`.

8. Report completion (after the loop or early termination):
   - Number of questions asked & answered.
   - Path to updated spec.
   - Sections touched (list names).
   - Coverage summary table: each taxonomy category with Status — Resolved (was Partial/Missing, now addressed), Deferred (exceeds quota or better for planning), Clear (already sufficient), Outstanding (still Partial/Missing, low impact).
   - If any Outstanding or Deferred remain, recommend whether to proceed to `/plan` or rerun `/clarify-specs` post-plan.
   - Suggested next command.

Behavior rules:

- If no meaningful ambiguities found (or all candidates are low-impact), respond: "No critical ambiguities detected worth formal clarification." and suggest proceeding.
- If spec file missing, tell the user to run `/intent` first (do not create a new spec here).
- Never exceed 5 total asked questions (retries for a single question don't count as new).
- Avoid speculative tech-stack questions unless absence blocks functional clarity.
- Respect user early termination signals ("stop", "done", "proceed").
- If no questions asked due to full coverage, output a compact summary (all Clear) then suggest advancing.
- If quota reached with unresolved high-impact categories, flag them Deferred with rationale.

Context for prioritization: $ARGUMENTS

## Post-Execution Checks

Check for extension hooks after clarification:

- If `.fire-phoenix/extensions.yml` is absent, skip silently.
- If it exists, read `references/extension-hooks.md`
  §Post-completion and apply that hook protocol against the
  `hooks.after_clarify-specs` key.

## Inputs

- **Feature Specification** (`{context.current.intent}`)
  - If set: read the spec file.
  - If null: Search {context.paths.intents} for the most recent intent.md.
  - If not provided (intent gate): clarify-intent needs an existing intent, so when none exists, bootstrap it first (Option A) not merely advise — in interactive mode confirm "No intent found — start by developing it?" then run the `intent` skill (greenfield) or `recover-intent`/`recover-spec` (brownfield); in auto mode run it and continue. Never clarify a non-existent intent.

## Outputs

- **Updated Specification** (`{context.current.intent}`)
  - Behavior: Update the spec in-place with clarifications. Ask before overwriting if confirm_before_write is true.
  - Overwrite guarded by `{context.preferences.confirm_before_write}`.

## Context Update

This skill does NOT modify `.fire-phoenix/context.yml` or `.fire-phoenix/user-context.yml` (in-spec updates only).

## Handoffs

- **Build Technical Plan**: run `/plan` to continue.
