---
name: dependency-map
description: Renders the project's internal module-dependency graph plus external
  dependency list as a Mermaid diagram, from imports and the codebase-scan lockfile.
  Use when visualising dependencies or finding circular coupling.
license: MIT
compatibility: Designed for agentskills.io-compatible agents.
metadata:
  author: Dau Quang Thanh
  version: '1.0'
  requires: [codebase-scan]
---

## User Input

```text
$ARGUMENTS
```

## Audience and tone (interactive mode)

**Register first — adapt to role level.** Run as a guided, one-question-at-a-time questionnaire (yes/no first, recommend a default); skip in `FIRE_PHOENIX_AGENT_MODE=auto`. Full rules: `.fire-phoenix/references/subagents/interactive-questionnaire.md`.

## Inputs

- `.fire-phoenix/context.yml`
- `{context.paths.docs}/analysis/codebase-scan.md`
- Source imports; project lockfile

## Outputs

- `{context.paths.docs}/analysis/dependencies.md`
- `assets/module-graph.mmd`

## Context Update

Does not mutate `.fire-phoenix/context.yml`.

## Handoffs

- `dependency-audit` extends this with CVEs + licences.
- `quality-review` flags circular / high-fan-out modules.

## AI authoring scope

**Does:** list top-N internal modules by fan-in + fan-out,
render a Mermaid flowchart, list external deps with versions,
flag circular imports, annotate risk flags per external
dependency.

**Does not:** modify imports; install / upgrade packages; run
the full CVE / licence audit (that is `dependency-audit`'s job —
this skill only raises flags for it).

## Risk flags

Annotate each external dependency (and any suspicious edge) with
the flags below. The vocabulary matches `dependency-audit` —
see `dependency-audit/references/supply-chain-checklist.md` (sibling skill) for the full
check definitions; do not restate them here, cross-reference.

- **`unpinned`** — no exact version resolved via a committed
  lockfile (supply-chain check 1).
- **`abandoned`** — no commits or releases in 18+ months
  (supply-chain check 5's abandonware rule; the audit assigns
  the severity).
- **`licence`** — copyleft or unknown licence in a context whose
  intake constraints exclude it; the audit's licence pass makes
  the call, this map just raises the flag.
- **`single-maintainer`** — bus-factor risk: one active
  maintainer visible on the registry / repository. Pair with the
  audit's provenance and typosquatting checks.

Internal-edge risks stay in `references/graph-heuristics.md`
territory: dashed (dynamic) edges are less safe than static
imports, and every cycle is logged as an `ANALYSISDEBT-`.

Risk flags here are pointers, tagged `OBSERVED` or `INFERRED
(low|med|high confidence)` like every other claim; the
authoritative CVE / licence / abandonware verdicts live in the
`dependency-audit` output.

## Usage

> `<SKILL_DIR>` = the integration's skills root (e.g. `.claude/skills/`
> for Claude Code, `.codex/skills/` for Codex,
> `.cursor/skills/` for Cursor).
> Scripts live at `<SKILL_DIR>/<skill-name>/scripts/…`.

```bash
DM_MAX_MODULES=25 bash <SKILL_DIR>/dependency-map/scripts/bash/build-map.sh --auto
```

### Answer keys

| Key | Default |
|---|---|
| `DM_MAX_MODULES` | `25` |
