---
name: codebase-scan
description: Scans an existing codebase for an overview — language and LOC by directory,
  frameworks, entry points, test-coverage signals, build/lint tooling. Use after inventory-existing,
  before architecture extraction.
license: MIT
compatibility: Designed for agentskills.io-compatible agents.
metadata:
  author: Dau Quang Thanh
  version: '1.0'
  requires: []
---

## User Input

```text
$ARGUMENTS
```

## Audience and tone (interactive mode)

**Register first — adapt to role level.** Run as a guided, one-question-at-a-time questionnaire (yes/no first, recommend a default); skip in `FIRE_PHOENIX_AGENT_MODE=auto`. Full rules: `.fire-phoenix/references/subagents/interactive-questionnaire.md`.

## Inputs

- Project root files (package.json, pyproject.toml, go.mod, …)
- Source tree under `src/`, `lib/`, `app/`, …

## Outputs

- `{context.paths.docs}/analysis/codebase-scan.md`
- `{context.paths.docs}/analysis/codebase-scan.extract`

## Context Update

Does not mutate `.fire-phoenix/context.yml`.

## Handoffs

- `architecture-extraction` starts from this scan.
- `api-docs` narrows to detected HTTP / RPC frameworks.
- `dependency-map` uses the LOC + entry-point list.

## AI authoring scope

**Does:** classify files by extension, count LOC per top-level
dir, detect primary language(s), detect frameworks (web, test,
build, lint), find entry points (`main.*`, `server.*`,
`index.*`).

**Does not:** modify files, run tests, push anything.

## Scan flow (staged)

Work the stages in order — each narrows the next. Every recorded
fact carries a confidence tag: **`OBSERVED`** (read directly,
`file:line` cited), **`INFERRED (low|med|high confidence)`**
(pattern-matched, reasoning stated), or **`UNKNOWN`** (surfaced
as an open question, never guessed).

1. **Inventory** — manifests, languages, LOC per top-level dir,
   build / test / lint tooling, per
   `references/detection-signals.md`. Mostly `OBSERVED`.
2. **Entry points** — `main.*` / `server.*` / `index.*` / CLI
   commands / scheduled jobs / queue consumers. An entry point
   named by convention but not traced is `INFERRED`, not
   `OBSERVED`.
3. **Hot paths** — the most-imported modules, the largest files,
   and (when git history is available) the most-churned areas.
   These are where later extraction and refactoring effort
   concentrates.
4. **Risk areas** — untested directories, generated or vendored
   code mixed into source, dynamic typing walls (`any`,
   reflection), config entries shaped like secrets. Flag; do not
   fix.

**Verify before asserting** — before any claim lands in the
artefact, re-check its evidence: open the file, confirm the
line still says what the claim says (mirrors the security
reviewer's verification pass). A claim that cannot be verified
is recorded as `UNKNOWN` and logged as an `ANALYSISDEBT-` — it
is never promoted "to be safe".

## Usage

> `<SKILL_DIR>` = the integration's skills root (e.g. `.claude/skills/`
> for Claude Code, `.codex/skills/` for Codex,
> `.cursor/skills/` for Cursor).
> Scripts live at `<SKILL_DIR>/<skill-name>/scripts/…`.

```bash
bash <SKILL_DIR>/codebase-scan/scripts/bash/scan.sh --auto
```

### Answer keys

| Key | Default |
|---|---|
| `CS_EXCLUDE_GLOBS` | `node_modules/**,dist/**,.venv/**,build/**,target/**` |
