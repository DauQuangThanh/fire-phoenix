#!/usr/bin/env bash
set -e
SCRIPT_DIR="$(CDPATH="" cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=common.sh
source "$SCRIPT_DIR/common.sh"
fire_phoenix_parse_standard_args "$@"
set -- "${FIRE_PHOENIX_REST_ARGS[@]}"
if [ "${1:-}" = "--help" ]; then echo "Usage: scan.sh [--auto]. Keys: CS_EXCLUDE_GLOBS."; exit 0; fi
read_context
SKILL_DIR="$(CDPATH="" cd "$SCRIPT_DIR/../.." && pwd)"
DIR="$FIRE_PHOENIX_REPO_ROOT/$FIRE_PHOENIX_DOCS_DIR/analysis"
OUT="$DIR/codebase-scan.md"
EXCL=$(resolve_auto CS_EXCLUDE_GLOBS "node_modules/**,dist/**,.venv/**,build/**,target/**") || true

if [ "${FIRE_PHOENIX_DRY_RUN:-0}" = "1" ]; then echo "[dry-run] would write: $OUT"; exit 0; fi
if [ -f "$OUT" ]; then echo "Scan doc exists: $OUT" >&2; exit 2; fi
if ! confirm_before_write "Scaffold codebase scan at $OUT."; then echo "Aborted." >&2; exit 1; fi
mkdir -p "$DIR"
sed -e "s|{date}|$(date +%Y-%m-%d)|g" -e "s|{root}|$FIRE_PHOENIX_REPO_ROOT|g" -e "s|{excludes}|$EXCL|g" \
    "$SKILL_DIR/templates/scan-template.md" > "$OUT"
write_extract "$OUT" "ROOT=$FIRE_PHOENIX_REPO_ROOT" "EXCLUDES=$EXCL" > /dev/null
echo "Wrote $OUT — agent to walk the tree and fill tables."
