# Script usage

Detailed per-script invocations and flags. The `python …` calls work
identically on macOS, Linux, and Windows — forward slashes in script
paths are accepted by Python on all three (only venv setup/activation
differs per platform).

## `pptx_to_md.py`

macOS / Linux (bash):

```bash
python scripts/pptx_to_md.py deck.pptx deck.md
python scripts/pptx_to_md.py deck.pptx deck.md --assets-dir custom-assets
python scripts/pptx_to_md.py deck.pptx --list-layouts    # Print layout names and exit
python scripts/pptx_to_md.py deck.pptx deck.md --no-meta # Skip sidecar (lossy export)
```

Windows (PowerShell):

```powershell
python scripts\pptx_to_md.py deck.pptx deck.md
python scripts\pptx_to_md.py deck.pptx deck.md --assets-dir custom-assets
python scripts\pptx_to_md.py deck.pptx --list-layouts
python scripts\pptx_to_md.py deck.pptx deck.md --no-meta
```

Output files:

- `deck.md`
- `deck.assets/` (images, embedded media)
- `deck.meta.json` (unless `--no-meta`)

## `md_to_pptx.py`

macOS / Linux (bash):

```bash
python scripts/md_to_pptx.py deck.md deck.pptx
python scripts/md_to_pptx.py deck.md deck.pptx --template original.pptx
python scripts/md_to_pptx.py deck.md deck.pptx --meta deck.meta.json
```

Windows (PowerShell):

```powershell
python scripts\md_to_pptx.py deck.md deck.pptx
python scripts\md_to_pptx.py deck.md deck.pptx --template original.pptx
python scripts\md_to_pptx.py deck.md deck.pptx --meta deck.meta.json
```

By default the script looks for `<name>.meta.json` beside `<name>.md` and uses the original deck as the template if referenced there. Pass `--template` to force a specific template (the source `.pptx` is the best template — it carries master slides, layouts, and theme).

## `roundtrip_check.py`

Exports a deck to Markdown, rebuilds it, then diffs the two `.pptx` files on text + structure. Returns nonzero on mismatch. Use it in QA.

macOS / Linux (bash):

```bash
python scripts/roundtrip_check.py deck.pptx
```

Windows (PowerShell):

```powershell
python scripts\roundtrip_check.py deck.pptx
```
