# Prioritisation rubric — qualitative bands and tie-breaks

A lighter alternative to the scoring frames in
`prioritization-frames.md`: no numbers to invent, just bands the
user can pick in plain words. The AI proposes a band per axis and
an ordering; the human product-owner decides. At the acceptance
gate (G1) the product-owner confirms business fit — the BA authors
the criteria; this rubric never changes that split.

## The four axes

### Value — what the item is worth to the business

- **High** — a stated business outcome depends on it; the release
  is pointless without it.
- **Medium** — clearly useful; the release still makes sense
  without it.
- **Low** — nice-to-have; nobody has asked for it by name.

### Risk — what we don't yet know

- **High** — unproven assumption, new integration, or a failure
  condition with no agreed handling.
- **Medium** — some unknowns, but a fallback exists.
- **Low** — well-understood, done-before work.

### Effort — how big it feels

Use the T-shirt anchors in `estimation-t-shirt.md` (XS–XL). Do not
convert sizes to numbers to "add them up" — bands stay bands.

### Dependency — how it sits in the graph

- **Blocks others** — at least one other item cannot start until
  this one is done.
- **Independent** — no ordering constraint either way.
- **Blocked** — cannot start until a named item is done.

## Ordering guidance

1. Items that **block others** float to the top of their value
   band — they buy optionality for everything downstream.
2. Within a value band, **high-risk items go earlier**: if an
   assumption is wrong, cheaper to learn it now.
3. **Blocked** items sort no higher than the item blocking them.

## Tie-break rules

When two items land in the same bands, break ties in this order:

1. The one that **blocks more items** wins.
2. The one with **higher risk** wins (fail fast).
3. The **smaller effort** wins (quicker feedback).
4. Still tied — alphabetical by title, matching the backlog
   legend, so the order is stable and boring rather than clever.

## AI-authoring note

Bands are qualitative on purpose: inventing scores gives false
precision. The skill proposes bands and an ordering with a
one-line rationale each; every proposal stays flagged until the
user confirms. The final order is always the human
product-owner's call.
