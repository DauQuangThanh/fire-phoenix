# Product Backlog

**Last updated:** {date}
**Owner:** Product Owner

## Legend

- **Priority** — 1 is highest. Ties broken alphabetically by title.
  Band guidance: `references/prioritization-rubric.md`.
- **Size** — T-shirt: XS / S / M / L / XL. See
  `references/estimation-t-shirt.md`.
- **Status** — New / Ready / In progress / Done / Cut.
  `Ready` requires a story ref, BA-authored `AC-NNN` criteria, and
  the epic's `## G1 agreement` record — otherwise the item stays
  `New`.

## Items

| # | Priority | Title | Size | Status | Story ref |
|---|:-:|---|:-:|---|---|
| BL-01 | 1 | <title> | M | New | specs/<feature>/intent.md#us-01 |
