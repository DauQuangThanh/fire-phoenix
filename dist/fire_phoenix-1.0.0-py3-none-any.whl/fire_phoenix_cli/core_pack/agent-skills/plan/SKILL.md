---
name: plan
description: Executes the implementation planning workflow using the plan template
  to generate design artefacts. Use when creating an implementation plan or breaking
  architecture into design documents, before taskify.
license: MIT
compatibility: Designed for agentskills.io-compatible agents.
metadata:
  author: Dau Quang Thanh
  version: '1.0'
  requires: [intent]
  scripts:
    sh: scripts/bash/setup-plan.sh --json
    ps: scripts/powershell/setup-plan.ps1 -Json
---

## User Input

```text
$ARGUMENTS
```

You **MUST** consider the user input before proceeding (if not empty).

## Audience and tone (interactive mode)

**Register first — adapt to role level.** Run as a guided, one-question-at-a-time questionnaire (yes/no first, recommend a default); skip in `FIRE_PHOENIX_AGENT_MODE=auto`. Full rules: `.fire-phoenix/references/subagents/interactive-questionnaire.md`.

## Pre-Execution Checks

**Check for extension hooks (before planning)**:

- Check if `.fire-phoenix/extensions.yml` exists in the project root.
- If it exists, read it and look for entries under the `hooks.before_plan` key
- If the YAML cannot be parsed or is invalid, skip hook checking silently and continue normally
- Filter out hooks where `enabled` is explicitly `false`. Treat hooks without an `enabled` field as enabled by default.
- For each remaining hook, do **not** attempt to interpret or evaluate hook `condition` expressions:
  - If the hook has no `condition` field, or it is null/empty, treat the hook as executable
  - If the hook defines a non-empty `condition`, skip the hook and leave condition evaluation to the HookExecutor implementation
- For each executable hook, output the following based on its `optional` flag:
  - **Optional hook** (`optional: true`):

    ```text
    ## Extension Hooks

    **Optional Pre-Hook**: {extension}
    Command: `/{command}`
    Description: {description}

    Prompt: {prompt}
    To execute: `/{command}`
    ```

  - **Mandatory hook** (`optional: false`):

    ```text
    ## Extension Hooks

    **Automatic Pre-Hook**: {extension}
    Executing: `/{command}`
    EXECUTE_COMMAND: {command}

    Wait for the result of the hook command before proceeding to the Outline.
    ```

- If no hooks are registered or `.fire-phoenix/extensions.yml` does not exist, skip silently

## Outline

1. **Setup**: Run `{SCRIPT}` from repo root and parse JSON for FEATURE_INTENT, IMPL_PLAN, INTENTS_DIR, BRANCH. For single quotes in args like "I'm Groot", use escape syntax: e.g 'I'\''m Groot' (or double-quote if possible: "I'm Groot").

2. **Load context**: Read FEATURE_INTENT and `{context.paths.docs}/standards.md`. Load IMPL_PLAN template (already copied).

3. **Execute plan workflow**: Follow the structure in IMPL_PLAN template to:
   - Fill Technical Context (mark unknowns as "NEEDS CLARIFICATION")
   - Fill Standards Check section from standards
   - Evaluate gates (ERROR if violations unjustified)
   - Phase 0: Generate research.md (resolve all NEEDS CLARIFICATION)
   - Phase 1: Generate data-model.md, contracts/, quickstart.md
   - Phase 1: Update agent context by running the agent script
   - Re-evaluate Standards Check post-design

4. **Stop and report**: Command ends after Phase 2 planning. Report branch, IMPL_PLAN path, and generated artifacts.

5. **Check for extension hooks**: after reporting, apply the **same** hook-rendering protocol as Pre-Execution Checks (above) — same `enabled`/`condition`/`optional` handling and the same optional/mandatory output blocks — but against the `hooks.after_plan` key. If `.fire-phoenix/extensions.yml` is absent or unparseable, skip silently.

## Phases

### Phase 0: Outline & Research

1. **Extract unknowns from Technical Context** above:
   - For each NEEDS CLARIFICATION → research task
   - For each dependency → best practices task
   - For each integration → patterns task

2. **Generate and dispatch research agents**:

   ```text
   For each unknown in Technical Context:
     Task: "Research {unknown} for {feature context}"
   For each technology choice:
     Task: "Find best practices for {tech} in {domain}"
   ```

3. **Consolidate findings** in `research.md` as: Decision / Rationale /
   Alternatives considered.

**Output**: research.md with all NEEDS CLARIFICATION resolved

### Phase 1: Design & Contracts

**Prerequisites:** `research.md` complete

1. **Extract entities from feature spec** → `data-model.md`:
   - Entity name, fields, relationships
   - Validation rules from requirements
   - State transitions if applicable

2. **Define interface contracts** (if project has external interfaces) → `/contracts/`:
   - Identify what interfaces the project exposes to users or other systems
   - Document the contract format appropriate for the project type
   - Examples: public APIs (libraries), command schemas (CLI tools), endpoints (web services), grammars (parsers), UI contracts
   - Skip if project is purely internal (build scripts, one-off tools, etc.)

3. **Agent context update**:
   - Update the plan reference in the fire-phoenix managed section — the block ending at the `<!-- Fire Phoenix END -->` marker — in your project's agent context file (locate the file containing that marker) to point to the plan file created in step 1 (the IMPL_PLAN path)

**Output**: data-model.md, /contracts/*, quickstart.md, updated agent context file

## Key rules

- Use absolute paths for filesystem operations; use project-relative paths for references in documentation and agent context files
- ERROR on gate failures or unresolved clarifications

## Inputs

- **Feature Specification** (`{context.current.intent}`)
  - If set: Read the specification file at this path.
  - If null: Search {context.paths.intents} for the most recent intent.md.
  - If not provided (intent gate): do NOT merely ask the user to run /intent. `setup-plan.sh` will exit 3 with `FIRE_PHOENIX_BOOTSTRAP=intent|recover` and `INTENT_STATUS`. Act on it (Option A): in interactive mode, tell the user "No intent found for this feature — start by developing it?" and on confirmation run the `intent` skill (greenfield) or `recover-intent` + `recover-spec` (brownfield, `BOOTSTRAP=recover`), then re-run planning; in auto mode, run the bootstrap skill, log the decision, then continue. Never plan while intent is absent.

- **Existing-system context** (optional; read each that exists):
  `{context.paths.docs}/architecture/extracted.md` (never contradict the
  recovered architecture silently — divergence is a stated decision in
  `research.md`), `{context.paths.docs}/analysis/codebase-scan.md` (reuse
  the detected stack before proposing a new one),
  `{context.paths.docs}/analysis/dependencies.md` (high fan-in module =
  stated risk), `{context.paths.docs}/analysis/context-baseline.md`
  (stale/debt inputs are not trustworthy). Cite what you used in Technical
  Context.

## Outputs

- **Implementation Plan** (`{context.paths.plans}/{context.current.feature}/plan.md`)
  - Behavior: Write the plan file. If it exists and confirm_before_write is true, ask the user.
  - Overwrite guarded by `{context.preferences.confirm_before_write}`.

- **Research Findings** (`{context.paths.plans}/{context.current.feature}/research.md`)
  - Behavior: Write research findings documenting design decisions.
  - Overwrite guarded by `{context.preferences.confirm_before_write}`.

- **Data Model** (`{context.paths.plans}/{context.current.feature}/data-model.md`)
  - Behavior: Write entity definitions and relationships.
  - Overwrite guarded by `{context.preferences.confirm_before_write}`.

## Context Update

After this skill completes successfully, update `.fire-phoenix/user-context.yml`:

- Set current.plan to the path of the created plan file
- Set current.feature if inferred or confirmed during planning
- Leave all other current.* fields unchanged
- Do not modify paths.*or preferences.*

Recommended: run `bash {context.paths.scripts}/bash/set-plan-cursor.sh "<plan-path>"` (or `pwsh {context.paths.scripts}/powershell/set-plan-cursor.ps1 <PlanPath>`) — a thin wrapper around the canonical helper. Direct invocation also works: `write_user_context_value current.plan <value>` (bash) / `Write-UserContextValue -Key current.plan -Value <value>` (PowerShell). Hand-editing `.fire-phoenix/user-context.yml` is also fine; do NOT modify `.fire-phoenix/context.yml`.

## Handoffs

- **Create Tasks**: run `/taskify` to continue the workflow.
- **Create Checklist**: run `/feature-checklist` to continue the workflow.
