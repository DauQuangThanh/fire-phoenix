#!/usr/bin/env bash

# Set the current.plan cursor in .fire-phoenix/user-context.yml.
#
# current.* lives in the per-user file (gitignored), NOT
# the team-shared .fire-phoenix/context.yml. This script wraps the
# canonical write_user_context_value helper from common.sh so the AI
# has a turn-key invocation post-plan creation.

set -e

SCRIPT_DIR="$(CDPATH="" cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/common.sh"

fire_phoenix_parse_standard_args "$@"
set -- "${FIRE_PHOENIX_REST_ARGS[@]}"

if [ "${1:-}" = "--help" ]; then
    cat <<'USAGE'
Usage: set-plan-cursor.sh [--auto] [--dry-run] [--answers FILE] <plan-path>

Set .fire-phoenix/user-context.yml's current.plan to <plan-path>
(repo-root-relative). Bootstraps user-context.yml when absent.
USAGE
    exit 0
fi

if [ $# -lt 1 ]; then
    echo "ERROR: set-plan-cursor.sh requires <plan-path>" >&2
    echo "Run with --help for usage." >&2
    exit 1
fi

PLAN_PATH="$1"

read_context

if [ "${FIRE_PHOENIX_DRY_RUN:-0}" = "1" ]; then
    echo "DRY-RUN: would set current.plan=${PLAN_PATH} in ${FIRE_PHOENIX_REPO_ROOT}/.fire-phoenix/user-context.yml"
    exit 0
fi

write_user_context_value current.plan "$PLAN_PATH"
echo "set current.plan=${PLAN_PATH}"
