#!/usr/bin/env pwsh
# Setup implementation plan for a feature

[CmdletBinding()]
param(
    [switch]$Json,
    [switch]$Help
)

$ErrorActionPreference = 'Stop'

# Show help if requested
if ($Help) {
    Write-Output "Usage: ./setup-plan.ps1 [-Json] [-Help]"
    Write-Output "  -Json     Output results in JSON format"
    Write-Output "  -Help     Show this help message"
    exit 0
}

# Load common functions
. "$PSScriptRoot/common.ps1"

# IDD-canon prerequisite resolution.
$ctx = Read-Context

$repoRoot = $ctx.REPO_ROOT

# Intent gate: signal BOOTSTRAP (Option A) instead of hard-failing.
$fpIntentMissing = $false
if ([string]::IsNullOrEmpty($ctx.CURRENT_INTENT)) {
    $fpIntentMissing = $true
} elseif (-not (Test-Path -LiteralPath (Join-Path $repoRoot $ctx.CURRENT_INTENT) -PathType Leaf)) {
    $fpIntentMissing = $true
}
if ($fpIntentMissing) {
    $fpStatus = Get-FirePhoenixIntentStatus
    if ($fpStatus -eq 'absent-greenfield' -or $fpStatus -eq 'absent-brownfield') {
        $fpVerb = if ($fpStatus -eq 'absent-brownfield') { 'recover' } else { 'intent' }
        Write-Output "FIRE_PHOENIX_BOOTSTRAP=$fpVerb"
        Write-Output "INTENT_STATUS=$fpStatus"
        [Console]::Error.WriteLine("No usable intent for this feature ($fpStatus). Bootstrap intent BEFORE planning:")
        [Console]::Error.WriteLine("  - greenfield: run the 'intent' skill (interactive: confirm first; auto: proceed).")
        [Console]::Error.WriteLine("  - brownfield: run 'recover-intent' (+ 'recover-spec' for the named module).")
        [Console]::Error.WriteLine("Then re-run this step.")
        exit 3
    } else {
        [Console]::Error.WriteLine("ERROR: an intent exists on disk but current.intent is unset (INTENT_STATUS=$fpStatus).")
        [Console]::Error.WriteLine("Set current.intent (or re-run /intent) to select the feature before planning.")
        exit 1
    }
}

$featureIntent = Join-Path $repoRoot $ctx.CURRENT_INTENT
$featureDir = Split-Path -Parent $featureIntent

$implPlan = if ($ctx.CURRENT_PLAN) { Join-Path $repoRoot $ctx.CURRENT_PLAN } else { Join-Path $featureDir 'plan.md' }

$paths = [PSCustomObject]@{
    REPO_ROOT      = $repoRoot
    CURRENT_BRANCH = if ($ctx.CURRENT_BRANCH) { $ctx.CURRENT_BRANCH } elseif ($ctx.CURRENT_FEATURE) { $ctx.CURRENT_FEATURE } else { 'main' }
    HAS_GIT        = [bool](Test-HasGit)
    FEATURE_DIR    = $featureDir
    FEATURE_INTENT = $featureIntent
    IMPL_PLAN      = $implPlan
}

# Ensure the feature directory exists
New-Item -ItemType Directory -Path $paths.FEATURE_DIR -Force | Out-Null

# Copy plan template if it exists, otherwise note it or create empty file
$template = Resolve-Template -TemplateName 'plan-template' -RepoRoot $paths.REPO_ROOT
if ($template -and (Test-Path $template)) {
    Copy-Item $template $paths.IMPL_PLAN -Force
    Write-Output "Copied plan template to $($paths.IMPL_PLAN)"
} else {
    Write-Warning "Plan template not found"
    # Create a basic plan file if template doesn't exist
    New-Item -ItemType File -Path $paths.IMPL_PLAN -Force | Out-Null
}

# Output results
if ($Json) {
    $result = [PSCustomObject]@{
        FEATURE_INTENT = $paths.FEATURE_INTENT
        IMPL_PLAN = $paths.IMPL_PLAN
        INTENTS_DIR = $paths.FEATURE_DIR
        BRANCH = $paths.CURRENT_BRANCH
        HAS_GIT = $paths.HAS_GIT
    }
    $result | ConvertTo-Json -Compress
} else {
    Write-Output "FEATURE_INTENT: $($paths.FEATURE_INTENT)"
    Write-Output "IMPL_PLAN: $($paths.IMPL_PLAN)"
    Write-Output "INTENTS_DIR: $($paths.FEATURE_DIR)"
    Write-Output "BRANCH: $($paths.CURRENT_BRANCH)"
    Write-Output "HAS_GIT: $($paths.HAS_GIT)"
}
