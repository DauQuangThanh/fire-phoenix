---
name: deployment-strategy
description: Drafts the deployment strategy and release runbook — canary/blue-green/rolling,
  promotion flow, rollback, feature flags, release-notes seed. Use when planning a
  deployment or choosing a pattern.
license: MIT
compatibility: Designed for agentskills.io-compatible agents.
metadata:
  author: Dau Quang Thanh
  version: '1.0'
  requires: []
---

## User Input

```text
$ARGUMENTS
```

## Audience and tone (interactive mode)

**Register first — adapt to role level.** Run as a guided, one-question-at-a-time questionnaire (yes/no first, recommend a default); skip in `FIRE_PHOENIX_AGENT_MODE=auto`. Full rules: `.fire-phoenix/references/subagents/interactive-questionnaire.md`.

## Inputs

- `.fire-phoenix/context.yml`
- `{context.paths.docs}/operations/cicd.md`
- `{context.paths.docs}/operations/infra.md`
- `{context.paths.docs}/operations/monitoring.md`
- `{context.paths.docs}/bugs/change-register.md` (for release
  notes)

## Outputs

- `{context.paths.docs}/operations/deployment.md`
- `{context.paths.docs}/operations/release-notes-<date>.md` (on
  each release)

## Context Update

Does not mutate `.fire-phoenix/context.yml`.

## Handoffs

- `project-planning` references the release model in milestones.
- `status-report` references the most recent release.
- `observability-plan` is consulted for canary bake thresholds.

## AI authoring scope

**Does:** pick a release model (canary / blue-green / rolling),
draft the promotion flow across environments, specify rollback
criteria + commands, propose feature-flag usage, seed release
notes from the change register.

**Does not:** deploy; run kubectl / terraform / any cloud CLI;
toggle feature flags.

## Picking the release model

Recommend, never pre-select: walk the qualitative decision guide
in `references/release-models.md` (traffic control, rollback
speed, infra cost, state / schema constraints) and let the user
pick. State the one constraint most likely to override the
default — usually a backwards-incompatible schema change or the
absence of per-version metrics.

## Rollback readiness

No release model is complete until the rollback-readiness
checklist in `references/rollback-readiness.md` passes: trigger
defined, decision owner named, data reversibility stated (or the
point of no return documented), command rehearsed, verify step
tied to the SLIs. Unmet items become `OPSDEBT-` entries; rollback
triggers double as candidate failure-path criteria handed to the
business-analyst.

## Usage

> `<SKILL_DIR>` = the integration's skills root (e.g. `.claude/skills/`
> for Claude Code, `.codex/skills/` for Codex,
> `.cursor/skills/` for Cursor).
> Scripts live at `<SKILL_DIR>/<skill-name>/scripts/…`.

```bash
DP_MODEL=canary DP_CANARY_BAKE_MIN=30 bash <SKILL_DIR>/deployment-strategy/scripts/bash/draft-deployment.sh --auto
```

### Answer keys

| Key | Default |
|---|---|
| `DP_MODEL` (`canary`/`blue-green`/`rolling`/`recreate`) | `canary` |
| `DP_CANARY_BAKE_MIN` | `30` |
| `DP_ENVIRONMENTS` | `dev,staging,prod` |
