# Rollback readiness — checklist

A release model without a rehearsed way back is a one-way door
dressed up as a process. Walk this checklist before any release
ships; an unmet item is an `OPSDEBT-`, not a footnote.

## The checklist

- [ ] **Trigger defined.** The condition that starts a rollback is
      written down before the release (e.g. "error rate above the
      agreed baseline multiple for N minutes", "any Critical
      alert"). The numbers are the user's decision, recorded as
      such — the skill proposes, the user confirms.
- [ ] **Who decides.** One named role/person calls the rollback.
      "The team decides" means nobody decides at 03:00.
- [ ] **Data reversibility stated.** For every schema or data
      change in the release, the plan says one of:
      - reversible — the undo step is written next to the do step;
      - forward-only — the release notes name the
        **point of no return** and what is lost by reverting past
        it (a documented one-way door, per expand/contract
        discipline).
- [ ] **Rollback command written and rehearsed.** The exact
      command / pipeline job exists, has been executed at least
      once against staging, and completes inside the agreed
      window (the release-models reference assumes < 5 minutes).
- [ ] **Verify step.** What confirms the rollback worked — the
      same SLIs that would have caught the bad release.
- [ ] **Feature flags accounted for.** Flags shipped with the
      release have a default-off state the rollback restores.

## Candidate failure-path criteria

Each trigger above is also a candidate **negative acceptance
criterion** (Given a deployed release / When the trigger condition
occurs / Then traffic is restored to the previous version with no
data loss). Hand candidates to the business-analyst, who authors
the final criterion — this skill only proposes.
