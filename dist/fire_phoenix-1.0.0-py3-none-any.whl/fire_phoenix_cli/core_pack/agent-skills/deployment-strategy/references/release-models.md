# Release models — quick reference

| Model | Description | Pros | Cons |
|---|---|---|---|
| **Canary** | Small % of traffic to new version; grow if clean | Catches issues without full exposure; measurable risk | Requires routing + per-version metrics |
| **Blue-green** | Two identical envs; flip traffic atomically | Fast rollback; easy verification | Double infra cost; long-running migrations painful |
| **Rolling** | Replace instances gradually | No traffic split needed; simple | Harder to roll back quickly; mixed versions in flight |
| **Recreate** | Stop old, start new | Simplest; good for single-user tools | Downtime |

## Decision guide

Score the four models qualitatively against the project before
recommending one. The user picks; the skill recommends.

| Dimension | Canary | Blue-green | Rolling | Recreate |
|---|---|---|---|---|
| Traffic control needed | Fine-grained (% routing) | Atomic switch only | None | None |
| Rollback speed | Fast (shrink canary) | Fastest (flip back) | Slow (roll forward/back) | Slow (redeploy old) |
| Infra cost | Low extra | Double during release | None extra | None extra |
| State / schema constraints | Both versions share data | Long migrations painful | Mixed versions in flight | Simplest — one version |

Starting points:

- **Prod with SLA** — canary.
- **Bursty traffic + simple stack** — blue-green.
- **Background workers** — rolling often suffices.
- **Single-tenant / dev tool** — recreate is fine.

Two constraints override the starting points:

- **Backwards-incompatible schema change** — canary and rolling
  both run old + new against the same data; the change must be
  expand/contract (additive first) or the model degrades to
  blue-green / recreate with a migration window.
- **No per-version metrics** — a canary you cannot observe is a
  rolling deploy with extra steps; pick rolling and say so.

## Always have

- A rollback path that takes < 5 minutes to execute.
- A pre-deploy checklist (migrations? feature flags? env vars?).
- A post-deploy check window based on the monitoring SLIs.
