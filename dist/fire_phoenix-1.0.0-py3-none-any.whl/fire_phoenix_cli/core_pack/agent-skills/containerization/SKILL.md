---
name: containerization
description: Drafts Dockerfile / compose / image-build strategy — a multi-stage Dockerfile
  starter, a local-dev compose file, the design doc. Use when dockerising an application
  or planning a container strategy.
license: MIT
compatibility: Designed for agentskills.io-compatible agents.
metadata:
  author: Dau Quang Thanh
  version: '1.0'
  requires: []
---

## User Input

```text
$ARGUMENTS
```

## Audience and tone (interactive mode)

**Register first — adapt to role level.** Run as a guided, one-question-at-a-time questionnaire (yes/no first, recommend a default); skip in `FIRE_PHOENIX_AGENT_MODE=auto`. Full rules: `.fire-phoenix/references/subagents/interactive-questionnaire.md`.

## Inputs

- `.fire-phoenix/context.yml`
- `{context.paths.docs}/architecture/c4-container.md`
- Project root (to detect language / framework)

## Outputs

- `{context.paths.docs}/operations/containers.md`
- `assets/Dockerfile.sample` — multi-stage starter
- `assets/compose.sample.yml` — local dev compose

## Context Update

Does not mutate `.fire-phoenix/context.yml`.

## Handoffs

- `cicd-pipeline` reads the build stage in containers.md.
- `deployment-strategy` reads runtime requirements.
- `security-review` reviews the image base + layers.

## AI authoring scope

**Does:** design multi-stage builds (build → test → runtime),
propose non-root users, size-optimised final stage, healthchecks,
signal handling.

**Does not:** build, push, or deploy images; commit secrets.

## Image hygiene gate

Every Dockerfile this skill drafts passes the pre-handoff
checklist in `references/image-hygiene.md` before it is handed
on: base pinned by digest, non-root runtime user, minimal layers
(build toolchain stripped, caches cleaned), **no secrets in any
layer** (build args and deleted-later files included — deletion
does not scrub earlier layers), healthcheck present, SIGTERM
handled. Unmet items become `OPSDEBT-` entries.

## Usage

> `<SKILL_DIR>` = the integration's skills root (e.g. `.claude/skills/`
> for Claude Code, `.codex/skills/` for Codex,
> `.cursor/skills/` for Cursor).
> Scripts live at `<SKILL_DIR>/<skill-name>/scripts/…`.

```bash
CONT_RUNTIME=node bash <SKILL_DIR>/containerization/scripts/bash/draft-containers.sh --auto
```

### Answer keys

| Key | Default |
|---|---|
| `CONT_RUNTIME` | detected from project |
| `CONT_BASE_IMAGE` | one of distroless / slim / alpine (default `slim`) |
