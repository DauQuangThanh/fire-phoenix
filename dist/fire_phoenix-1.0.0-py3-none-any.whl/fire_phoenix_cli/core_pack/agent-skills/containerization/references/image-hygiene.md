# Container image hygiene

## Size + speed

- **Multi-stage builds** cut the final image size dramatically.
- **Layer ordering**: copy dependency manifests first; install
  deps; then copy source. Layer cache works per-change.
- **Distroless / slim / alpine** — pick based on libc + debug
  needs. Alpine is smallest; can have musl incompatibilities.

## Security

- **Non-root user** — never `USER 0` at runtime.
- **No secrets at build time** — use build-args only for non-
  sensitive context.
- **No SSH keys, tokens, or private registries baked in.**
- **Pin base by digest** (`@sha256:...`), not just tag.
- **No curl|bash install steps** — pin the artefact.
- **Scan before push** — fail CI on High / Critical CVEs.

## Observability

- **Healthcheck** mandatory for orchestrator backoff.
- **Structured logs to stdout** — never a file inside the image.
- **Signal handling** — PID 1 must handle SIGTERM. If using `sh`
  as PID 1, add `tini` or `dumb-init`.

## Pre-handoff checklist

Walk this before the Dockerfile leaves the skill; an unmet item
is an `OPSDEBT-`:

- [ ] Base image pinned by digest (`@sha256:...`), not tag alone.
- [ ] Runtime user is non-root with an explicit uid; no `USER 0`.
- [ ] Multi-stage: build toolchain absent from the final stage;
      layers ordered manifest-first for cache hits; no
      leftover `apt`/`npm` caches inflating layers.
- [ ] No secrets in **any** layer — including build args,
      intermediate stages, and files deleted in a later layer
      (deletion does not remove the earlier layer's copy).
- [ ] `HEALTHCHECK` present and cheap.
- [ ] SIGTERM handled by PID 1 (app or `tini`/`dumb-init`).
- [ ] Image scanned in CI; Critical/High CVEs block the push.
