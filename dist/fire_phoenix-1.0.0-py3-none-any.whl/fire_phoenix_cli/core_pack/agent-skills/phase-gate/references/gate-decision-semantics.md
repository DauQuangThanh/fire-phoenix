# Gate outcomes and IDD gate checks

## Outcome semantics

A gate record recommends exactly one of three outcomes. Each has a
precise meaning; the human approver makes the call.

| Outcome | Meaning | Record must contain |
|---|---|---|
| **Pass** | Every exit criterion is Pass or N/A; no open blockers | Sign-off + date |
| **Conditional pass** | Named criteria failed or Unknown, but the approver waives them to keep moving | Each waived criterion, its waiver rationale, an owner, and a resolve-by date |
| **Fail** | Blocking criteria unmet; the phase does not exit | The blocker list (GATEDEBT ids) and the top actions to re-run the gate |

**Recorded rationale is mandatory for every outcome that is not a
clean Pass.** A conditional pass without per-waiver rationale, or
a fail without named blockers, is an incomplete record — the audit
trail must show what was consciously set aside, by whom, and until
when. A conditional pass whose resolve-by date lapses becomes a
finding at the next gate.

## IDD gate checks

Beyond the phase deliverables, every gate checklist verifies the
project's own acceptance chain:

- **G1 — acceptance agreement recorded.** Each epic entering or
  exiting the phase has its acceptance-criteria agreement recorded
  (a decision-log entry naming the criteria author, the role
  confirmations, and the single human approval). Confirmations are
  advisory inputs to that approval, scaled by the rigor profile in
  force: **P** collapses to a single confirmer, **M** allows
  subagent proxies for absent roles, **F** requires developer,
  tester, and product-owner confirmations.
- **G2 — decomposition precondition.** No decomposition into task
  contracts for an epic whose G1 record is missing. Contracts that
  predate their G1 record are findings.
- **Quality gates from the project standards.** Tests green,
  coverage threshold met, lint clean, cross-platform parity held —
  whatever the project's standards document declares. The gate
  record cites the run, not a verbal "CI is green".
- **Register hygiene.** Every open risk reviewed this phase
  (stale rows are findings — see the risk-register skill), and
  every approved CR carries a recorded disposition.

Mark each check Pass / Fail / Unknown / N/A like any other
criterion; Unknown is a GATEDEBT, not a silent skip.
