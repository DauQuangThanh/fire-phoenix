#!/usr/bin/env python3
"""Parity harness skeleton — exercise old + new implementations side by side.

Reads a parity ledger (tests/parity/<slug>-ledger.md), parses each row,
and runs the OLD + NEW implementations against the row's input.
Mismatches block cutover unless the row's assertion is
``different-but-traced`` (with a spec citation).

The engineer wires:

- Imports of the OLD and NEW implementations (see the TBD-source
  markers below).
- `run_row()` — converts the row's Input cell into concrete call
  arguments + compares outputs per the row's Assertion kind.
"""

from __future__ import annotations

import re
import sys
from dataclasses import dataclass
from pathlib import Path

# TBD-source — import the OLD and NEW implementations here.
# from old_pkg.module import legacy_fn
# from new_pkg.module import replacement_fn


@dataclass(frozen=True)
class LedgerRow:
    number: int
    input_repr: str
    expected_old: str
    expected_new: str
    assertion_kind: str
    supersedes: str | None


_ROW_RE = re.compile(r"^\|\s*(\d+)\s*\|(.+?)\|(.+?)\|(.+?)\|(.+?)\|(.+?)\|\s*$")


def parse_ledger(path: Path) -> list[LedgerRow]:
    rows: list[LedgerRow] = []
    for line in path.read_text(encoding="utf-8").splitlines():
        m = _ROW_RE.match(line)
        if not m:
            continue
        number, inp, old, new, assertion, supersedes = (cell.strip() for cell in m.groups())
        if number.isdigit():
            sup = None if supersedes in ("—", "-") else supersedes
            rows.append(
                LedgerRow(
                    number=int(number),
                    input_repr=inp,
                    expected_old=old,
                    expected_new=new,
                    assertion_kind=assertion,
                    supersedes=sup,
                )
            )
    return rows


def run_row(row: LedgerRow) -> tuple[bool, str]:
    """Exercise OLD + NEW against row.input_repr; compare per row.assertion_kind."""
    # TBD-source — convert row.input_repr to concrete inputs.
    # actual_old = legacy_fn(...)
    # actual_new = replacement_fn(...)
    actual_old = None
    actual_new = None

    if row.assertion_kind == "different-but-traced":
        return True, f"row#{row.number}: divergence intentional (skipped)"

    if row.assertion_kind == "equals":
        passed = actual_old == actual_new
    elif row.assertion_kind == "equivalent":
        passed = repr(actual_old) == repr(actual_new)
    else:
        return False, f"row#{row.number}: unsupported assertion '{row.assertion_kind}'"

    if passed:
        return True, f"row#{row.number}: PARITY ({row.assertion_kind})"
    return False, f"row#{row.number}: MISMATCH old={actual_old!r} new={actual_new!r}"


def main(ledger_path: Path | None = None) -> int:
    if ledger_path is None:
        ledger_path = (
            Path(__file__)
            .with_suffix(".md")
            .with_stem(Path(__file__).stem.replace("-harness", "-ledger"))
        )
    rows = parse_ledger(ledger_path)
    if not rows:
        print(f"FATAL: no rows parsed from {ledger_path}", file=sys.stderr)
        return 2

    failures = 0
    for row in rows:
        ok, message = run_row(row)
        print(message)
        if not ok:
            failures += 1

    print(f"\n{len(rows) - failures}/{len(rows)} rows in parity.")
    return 0 if failures == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
