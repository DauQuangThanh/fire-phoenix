# Parity ledger — {slug}

> Migration parity ledger. Rows are IMMUTABLE once captured; amend by
> superseding. See `references/migration-discipline.md` for the rules
> this template encodes.

## Migration scope

- **Old implementation:** <pointer to legacy module(s)>
- **New implementation:** <pointer to replacement module(s)>
- **Cutover target date:** YYYY-MM-DD
- **Owner:** <named team or person>

## Ledger rows schema (4-column row + supersedes)

| # | Input | Expected OLD output | Expected NEW output | Assertion | Supersedes |
|---|---|---|---|---|---|
| 1 | <concrete input — no "various"> | <what OLD code DOES> | <what NEW code DOES OR what spec says it should> | <kind below> | — or `#N` |

## Assertion vocabulary

- **equals**: old and new must produce byte-identical output.
- **equivalent**: structurally identical (whitespace / ordering tolerant).
- **subset**: new output is a subset of old (lossy migration with
  spec authorisation).
- **superset**: new output is a superset of old.
- **different-but-traced**: divergence is intentional; cite the spec
  that authorises it (e.g. `specs/epic-billing-v2.md §3.2`).

A row's Assertion column MUST be one of the above OR cite a spec
explaining the divergence. Free-text assertions ("looks right",
"seems fine") are REJECTED.

## Progress & percent automated

One status per row — the mutable progress record, kept OUT of the
immutable row table above:

| Row # | Status | Last harness run | Failure context (pointer) |
|---|---|---|---|
| 1 | pending | — | — |

Status vocabulary: **pending** (not yet exercised) /
**automated** (passed with no human intervention) /
**human-finished** (passed only after human completion or
correction) / **blocked** (retries exhausted; waiting on a human
decision).

Summary (update after each harness run):

`automated: N | human-finished: N | blocked: N | pending: N — percent automated: NN%`

The honest metric is **percent automated** — never claim "fully
automated" while any row is human-finished or blocked; plan for a
human tail. Each row is an independently resumable unit: a re-run
resumes from non-`automated` rows, a failed row retries with its
failure-context pointer feeding the next fix attempt (bounded
retries, then `blocked`), and this ledger in the repo — not any
session's memory — is the system of record for progress.

## Cutover-blocking issues

Any row whose harness run reports a mismatch UNLESS the row's
assertion is `different-but-traced` BLOCKS the cutover. To unblock:

1. Author a contract resolving the mismatch (fix the new
   implementation OR amend the spec to authorise the divergence).
2. Add a NEW ledger row that supersedes the failing one.
3. Re-run the harness; the new row must pass before cutover.

## Why rows are immutable

The ledger is the audit trail for the migration. Editing a captured
row erases evidence of what was decided + why. Superseding (adding a
new row that explicitly links to the one it replaces) keeps the chain
intact for post-cutover review. Progress status is deliberately kept
in its own section above so the row table itself never mutates.
