# Author a parity ledger + parity harness runner for a migration cutover.
# See references/migration-discipline.md for the rules enforced here.

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$SkillDir = (Resolve-Path -LiteralPath (Join-Path $ScriptDir '..\..')).Path
. (Join-Path $ScriptDir 'common.ps1')

$RestArgs = Import-FirePhoenixStandardArgs $args

if ($RestArgs.Count -gt 0 -and $RestArgs -contains '-Help') {
    @'
Usage: build-parity-ledger.ps1 [--auto] [--answers FILE] [--dry-run] [--help] <migration-slug>

Drafts a parity ledger at tests/parity/<slug>-ledger.md + a Python
runner skeleton at tests/parity/<slug>-harness.py.
'@ | Write-Host
    exit 0
}

$ctx = Read-Context
$Slug = if ($RestArgs.Count -gt 0) { $RestArgs[0] } else { '' }
if ([string]::IsNullOrEmpty($Slug)) {
    Write-Error "migration-slug required."
    exit 1
}

$OutDir = Join-Path $ctx.REPO_ROOT 'tests/parity'
$LedgerFile = Join-Path $OutDir "$Slug-ledger.md"
$HarnessFile = Join-Path $OutDir "$Slug-harness.py"

if ($env:FIRE_PHOENIX_DRY_RUN -eq '1') {
    Write-Host "[dry-run] would write: $LedgerFile"
    Write-Host "[dry-run] would write: $HarnessFile"
    exit 0
}

if ((Test-Path $LedgerFile) -or (Test-Path $HarnessFile)) {
    Write-Error "Parity artefacts already exist. Refusing to overwrite."
    exit 1
}

if (-not (Confirm-BeforeWrite "Write parity ledger + harness for '$Slug' to tests/parity/")) {
    Write-Error "Aborted."
    exit 1
}

New-Item -ItemType Directory -Path $OutDir -Force | Out-Null

# Render from the shipped templates — the single source of truth for the
# ledger + harness (SKL-03: no inline drift, full parity with the bash
# sibling). Only the ledger carries a {slug} placeholder; the harness
# derives its ledger path from its own filename, so it is copied verbatim.
$ledger = Get-Content -LiteralPath (Join-Path $SkillDir 'templates/parity-ledger-template.md') -Raw
$ledger = $ledger -replace '\{slug\}', $Slug
Set-Content -LiteralPath $LedgerFile -Value $ledger -Encoding UTF8
Copy-Item -LiteralPath (Join-Path $SkillDir 'templates/parity-harness-template.py') -Destination $HarnessFile

Write-Host "Parity bundle drafted at:"
Write-Host "  - $LedgerFile"
Write-Host "  - $HarnessFile"
