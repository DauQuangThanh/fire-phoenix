#!/usr/bin/env bash
# Author a parity ledger + parity harness runner for a migration cutover.
# The ledger enumerates {input → expected old output → expected new
# output → assertion} rows the harness exercises against BOTH
# implementations side by side. See
# references/migration-discipline.md for the rules enforced here.

set -e

SCRIPT_DIR="$(CDPATH="" cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SKILL_DIR="$(CDPATH="" cd "$SCRIPT_DIR/../.." && pwd)"
# shellcheck source=common.sh
source "$SCRIPT_DIR/common.sh"

fire_phoenix_parse_standard_args "$@"
set -- "${FIRE_PHOENIX_REST_ARGS[@]}"

if [ "${1:-}" = "--help" ]; then
    cat <<'USAGE'
Usage: build-parity-ledger.sh [--auto] [--answers FILE] [--dry-run] [--help] <migration-slug>

Drafts a parity ledger at tests/parity/<slug>-ledger.md + a Python
runner skeleton at tests/parity/<slug>-harness.py.

Flags:
  --auto            non-interactive
  --answers FILE    KEY=VALUE file consulted when --auto
  --dry-run         print what would be written, do not touch the filesystem
  --help            show this message and exit
USAGE
    exit 0
fi

read_context

SLUG="${1:-}"
if [ -z "$SLUG" ]; then
    echo "Error: migration-slug required. Usage: build-parity-ledger.sh <slug>" >&2
    exit 1
fi

OUT_DIR="$FIRE_PHOENIX_REPO_ROOT/tests/parity"
LEDGER_FILE="$OUT_DIR/${SLUG}-ledger.md"
HARNESS_FILE="$OUT_DIR/${SLUG}-harness.py"

if [ "${FIRE_PHOENIX_DRY_RUN:-0}" = "1" ]; then
    echo "[dry-run] would write: $LEDGER_FILE"
    echo "[dry-run] would write: $HARNESS_FILE"
    exit 0
fi

if [ -e "$LEDGER_FILE" ] || [ -e "$HARNESS_FILE" ]; then
    echo "Error: parity artefacts already exist (ledger or harness)." >&2
    echo "  ledger:  $LEDGER_FILE" >&2
    echo "  harness: $HARNESS_FILE" >&2
    echo "Refusing to overwrite. Use a different slug or edit the existing files." >&2
    exit 1
fi

if ! confirm_before_write "Write parity ledger + harness for '$SLUG' to tests/parity/"; then
    echo "Aborted." >&2
    exit 1
fi

mkdir -p "$OUT_DIR"

# Render from the shipped templates — the single source of truth for the
# ledger + harness (SKL-03: no inline drift). Only the ledger carries a
# {slug} placeholder; the harness derives its ledger path from its own
# filename, so it is copied verbatim.
sed "s|{slug}|$SLUG|g" "$SKILL_DIR/templates/parity-ledger-template.md" > "$LEDGER_FILE"
cp "$SKILL_DIR/templates/parity-harness-template.py" "$HARNESS_FILE"
chmod +x "$HARNESS_FILE"

echo "Parity bundle drafted at:"
echo "  - $LEDGER_FILE"
echo "  - $HARNESS_FILE"
echo "Reminder: rows are immutable once captured. Amend by superseding."
