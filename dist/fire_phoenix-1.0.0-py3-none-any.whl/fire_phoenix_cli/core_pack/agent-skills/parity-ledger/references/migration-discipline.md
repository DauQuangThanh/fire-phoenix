# Migration discipline — parity reference

Self-contained background for the `parity-ledger` skill. The rules
below define what the skill enforces; AI sessions that invoke this
skill must respect them.

- **Parity harness runs old + new SIDE BY SIDE before cutover.** A
  migration's cutover-readiness is gated by a harness that exercises
  the new implementation against the same inputs as the old AND
  reports mismatches. Cutover proceeds only when the harness reports
  parity on every required row.

- **Every parity row is immutable.** Once a row is captured (after
  the engineer verifies the old behaviour against the input), any
  amendment is a NEW row that supersedes the previous one with an
  explicit link. This preserves the full audit trail.

- **Assertion vocabulary is bounded.** Free-text assertions are
  rejected. Each row uses one of:
  - `equals` — old and new outputs are byte-equal.
  - `equivalent` — outputs are semantically equal (e.g. JSON with
    keys in different order).
  - `subset` — new output is a subset of old (allowed shrink).
  - `superset` — new output is a superset of old (allowed grow).
  - `different-but-traced` — outputs differ AND a cited spec
    section authorises the divergence.

- **Mismatches block cutover.** A row that reports `MISMATCH` (and
  is not on the `different-but-traced` track) means the migration is
  not ready. Resolution: author a task contract that fixes the
  mismatch, supersede the failing row, and re-run.

- **Percent automated is the honest metric.** The pipeline is
  hybrid: deterministic transforms where possible, an AI pass only
  where necessary, a validation gate per row. The ledger's Progress
  section records `automated` / `human-finished` / `blocked` per
  row and the summary reports the split — full automation is never
  claimed; plan for a human tail.

- **Rows are independently resumable units.** Sessions are
  stateless; the ledger in the repo is the system of record for
  progress. A harness re-run resumes from non-`automated` rows;
  completed rows are never redone (idempotent re-run).

- **Failed rows retry with failure context.** A mismatch's OLD/NEW
  diff feeds the next fix attempt. Retries are bounded; when
  exhausted the row is marked `blocked` and escalated to a human —
  never brute-forced.
