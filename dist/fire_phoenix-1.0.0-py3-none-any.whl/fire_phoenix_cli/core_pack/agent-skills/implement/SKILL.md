---
name: implement
description: Executes the implementation plan by processing and executing all tasks
  in tasks.md. Use when coding a feature from an existing tasks.md, or when the plan
  and design are ready and it is time to build.
license: MIT
compatibility: Designed for agentskills.io-compatible agents.
metadata:
  author: Dau Quang Thanh
  version: '1.0'
  requires: [taskify]
  scripts:
    sh: scripts/bash/check-prerequisites.sh --json --require-tasks --include-tasks
    ps: scripts/powershell/check-prerequisites.ps1 -Json -RequireTasks -IncludeTasks
---

## User Input

```text
$ARGUMENTS
```

You **MUST** consider the user input before proceeding (if not empty).

## Audience and tone (interactive mode)

**Register first — adapt to role level.** Run as a guided, one-question-at-a-time questionnaire (yes/no first, recommend a default); skip in `FIRE_PHOENIX_AGENT_MODE=auto`. Full rules: `references/interactive-questionnaire.md`.

## Pre-Execution Checks

**Check for extension hooks (before implementation)**:

- If `.fire-phoenix/extensions.yml` does not exist in the project
  root, skip silently.
- If it exists, read `references/extension-hooks.md` §Pre-execution
  and apply the hook protocol there against the
  `hooks.before_implement` key before proceeding to the Outline.

## Outline

1. Run `{SCRIPT}` from repo root and parse FEATURE_DIR and AVAILABLE_DOCS list. All paths must be absolute. For single quotes in args like "I'm Groot", use escape syntax: e.g 'I'\''m Groot' (or double-quote if possible: "I'm Groot").

2. **Check checklists status** (if FEATURE_DIR/checklists/ exists):
   - Scan all checklist files in the checklists/ directory
   - For each checklist, count:
     - Total items: All lines matching `- [ ]` or `- [X]` or `- [x]`
     - Completed items: Lines matching `- [X]` or `- [x]`
     - Incomplete items: Lines matching `- [ ]`
   - Create a status table:

     ```text
     | Checklist | Total | Completed | Incomplete | Status |
     |-----------|-------|-----------|------------|--------|
     | ux.md     | 12    | 12        | 0          | ✓ PASS |
     | test.md   | 8     | 5         | 3          | ✗ FAIL |
     | security.md | 6   | 6         | 0          | ✓ PASS |
     ```

   - Calculate overall status:
     - **PASS**: All checklists have 0 incomplete items
     - **FAIL**: One or more checklists have incomplete items

   - **If any checklist is incomplete**:
     - Display the table with incomplete item counts
     - **STOP** and ask: "Some checklists are incomplete. Do you want to proceed with implementation anyway? (yes/no)"
     - Wait for user response before continuing
     - If user says "no" or "wait" or "stop", halt execution
     - If user says "yes" or "proceed" or "continue", proceed to step 3

   - **If all checklists are complete**:
     - Display the table showing all checklists passed
     - Automatically proceed to step 3

3. Load and analyze the implementation context:
   - **REQUIRED**: Read tasks.md for the complete task list and execution plan
   - **REQUIRED**: Read plan.md for tech stack, architecture, and file structure
   - **IF EXISTS**: Read the feature's acceptance.md (AC-NNN acceptance criteria). WHEN acceptance.md exists for the feature, implement SHALL load it and SHALL treat the AC-IDs cited in a task's contract (`AC:` field) as part of that task's done-check — the task is not complete until its cited ACs are satisfied
   - **IF EXISTS**: Read data-model.md for entities and relationships
   - **IF EXISTS**: Read contracts/ for API specifications and test requirements
   - **IF EXISTS**: Read research.md for technical decisions and constraints
   - **IF EXISTS**: Read quickstart.md for integration scenarios

4. **Project Setup Verification**:
   - **REQUIRED**: Create/verify ignore files based on actual project setup:

   **Detection & Creation Logic**:
   - Check if the following command succeeds to determine if the repository is a git repo (create/verify .gitignore if so):

     ```sh
     git rev-parse --git-dir 2>/dev/null
     ```

   - Check if Dockerfile* exists or Docker in plan.md → create/verify .dockerignore
   - Check if .eslintrc* exists → create/verify .eslintignore
   - Check if eslint.config.* exists → ensure the config's `ignores` entries cover required patterns
   - Check if .prettierrc* exists → create/verify .prettierignore
   - Check if .npmrc or package.json exists → create/verify .npmignore (if publishing)
   - Check if terraform files (*.tf) exist → create/verify .terraformignore
   - Check if .helmignore needed (helm charts present) → create/verify .helmignore

   **If ignore file already exists**: Verify it contains essential patterns, append missing critical patterns only
   **If ignore file missing**: Create with full pattern set for detected technology

   **Patterns**: once the technologies and tools are detected, read
   `references/ignore-file-patterns.md` — only the subsections for
   the detected stack (per-technology and per-tool pattern sets) —
   and apply those patterns. Do not read it before detection.

5. Parse tasks.md structure and extract:
   - **Task phases**: Setup, Tests, Core, Integration, Polish
   - **Task dependencies**: Sequential vs parallel execution rules
   - **Task details**: ID, description, file paths, parallel markers [P]
   - **Execution flow**: Order and dependency requirements

6. Execute implementation following the task plan:
   - **Phase-by-phase execution**: Complete each phase before moving to the next
   - **Respect dependencies**: Run sequential tasks in order, parallel tasks [P] can run together
   - **Behavioural change → tests first**: Execute test tasks before their corresponding implementation tasks (honour a recorded `Test opt-out:` note in tasks.md where present)
   - **File-based coordination**: Tasks affecting the same files must run sequentially
   - **Validation checkpoints**: Verify each phase completion before proceeding

7. Implementation execution rules:
   - **Setup first**: Initialize project structure, dependencies, configuration
   - **Tests before code**: behavioural change → tests first; write tests for contracts, entities, and integration scenarios before the code they verify
   - **Core development**: Implement models, services, CLI commands, endpoints
   - **Integration work**: Database connections, middleware, logging, external services
   - **Polish and validation**: Unit tests, performance optimization, documentation

8. Progress tracking and error handling:
   - Report progress after each completed task
   - WHEN a task's contract cites an AC-ID that cannot be resolved in acceptance.md, implement SHALL stop and surface the unresolved AC-ID to the user — never silently proceed past it
   - Halt execution if any non-parallel task fails
   - For parallel tasks [P], continue with successful tasks, report failed ones
   - Provide clear error messages with context for debugging
   - Suggest next steps if implementation cannot proceed
   - **IMPORTANT** For completed tasks, make sure to mark the task off as [X] in the tasks file.

9. Completion validation:
   - Verify all required tasks are completed
   - Check that implemented features match the original specification
   - Validate that tests pass and coverage meets requirements
   - Confirm the implementation follows the technical plan
   - Report final status with summary of completed work

Note: This command assumes a complete task breakdown exists in tasks.md. If tasks are incomplete or missing, suggest running `/taskify` first to regenerate the task list.

1. **Check for extension hooks**: After completion validation, check if `.fire-phoenix/extensions.yml` exists in the project root.
    - If it does not exist, skip silently.
    - If it exists, read `references/extension-hooks.md`
      §Post-completion and apply the hook protocol there against the
      `hooks.after_implement` key.

## Inputs

- **Tasks List** (`{context.current.task}`)
  - If set: Read the tasks file.
  - If null: Search {context.paths.tasks} for the most recent tasks.md.
  - If not provided: Error: tasks file is required. Run /taskify first.

- **Implementation Plan** (`{context.current.plan}`)
  - If set: Reference the plan for technical context.
  - If null: Search {context.paths.plans} for the most recent plan.md.
  - If not provided: Proceed with implementation; plan is recommended but not required.

## Outputs

- **Implementation Artifacts** (`project root`): project root.
  - Behavior: Create/modify source files per task definitions. Ask before overwriting files if confirm_before_write is true.
  - Overwrite guarded by `{context.preferences.confirm_before_write}`.

## Context Update

This skill does NOT modify `.fire-phoenix/context.yml` or `.fire-phoenix/user-context.yml` (implementation is artifact creation, not context progression).
