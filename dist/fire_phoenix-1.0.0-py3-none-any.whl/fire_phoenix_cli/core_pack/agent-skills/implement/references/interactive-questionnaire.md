# Interactive questionnaire — implement

Skill-specific audience/questionnaire rules. The `implement` SKILL.md body points
here; read this file when it sends you here.

**Register first — adapt to role level.** Before applying the beginner floor
below, resolve the reader's level from the merged `.fire-phoenix/context.yml`
+ `.fire-phoenix/user-context.yml` (`user-context.yml` wins): use
`preferences.tech_role_level` for technical work (`junior` → hand-hold, one
path; `mid` → ≥2 options with one-line trade-offs; `senior` → defer on
judgment, surface edge cases, be brief; `staff` → be terse, challenge
premises, skip obvious caveats) and `preferences.non_tech_role_level` for
stakeholder work (`non-technical` → outcomes not jargon; `familiar` → simple
jargon glossed; `fluent` → concepts without explanation; `technical` → full
vocabulary). An explicit in-session signal (e.g. "be terse", "skip the
explanation") overrides everything. The plain-English, one-question-at-a-time
floor below applies **only when the relevant level is unset**; never treat
role level as a gate. Full rule: `.fire-phoenix/references/subagents/register-resolution.md`.

When `FIRE_PHOENIX_AGENT_MODE=interactive` (the default), assume the user
has **limited technical background and limited domain knowledge**
— they may know basics but lack deep expertise in software
implementation. Run this skill as a guided questionnaire and
**always show the diff before applying any source edit**:

- **One task at a time.** Walk `tasks.md` task-by-task; never
  apply multiple tasks before the user confirms.
- **Yes / no first.** "Apply this change? (yes / no / explain
  this line)" is the canonical question for each diff.
- **Translate jargon, don't strip it.** Use the term but always
  pair it with a plain-English gloss the first time it appears.
- **Choices, not blank fields.** When yes/no isn't enough, offer
  2-4 lettered options (A/B/C/D) with one-line plain-language
  descriptions of the trade-off. Always include "Not sure — pick
  a sensible default".
- **Always recommend.** State the option you would pick and why in
  one sentence so the user can reply "yes" / "ok" to accept.
- **Show, don't ask.** Propose the smallest viable diff per task
  and ask "yes / change?". Never apply blind.
- **`not sure` / `skip` on a task pauses the task** rather than
  applying a guess; mark it as `(skipped — needs follow-up)` in
  `tasks.md` and continue with the next.

When `FIRE_PHOENIX_AGENT_MODE=auto` (or `--auto`), skip the conversational
gate but still: produce diffs, run tests after each change, halt
on the first failing test, and log decisions to the parent agent's
decision log.
