#!/usr/bin/env bash
set -e
SCRIPT_DIR="$(CDPATH="" cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=common.sh
source "$SCRIPT_DIR/common.sh"
fire_phoenix_parse_standard_args "$@"
set -- "${FIRE_PHOENIX_REST_ARGS[@]}"

if [ "${1:-}" = "--help" ]; then
    cat <<'USAGE'
Usage: plan-team.sh [--auto] [--answers FILE] [--dry-run] [--help] [<slug>]

Scaffolds the coordinator triad idempotently:
  - <docs>/orchestration/<slug>/team-plan.md
  - <docs>/orchestration/<slug>/brief-<role>.md   (one per staffed role)
  - .fire-phoenix/workflows/<slug>/workflow.yml    (engine-valid gated spine)

Answer keys: CT_SLUG, CT_ROLES (comma-separated), CT_MODE,
             CT_INTEGRATION, CT_ENVELOPE.
Roles must match an installed role-subagent (see references/subagent-roster.md);
an unknown role is a hard error and nothing is written.
USAGE
    exit 0
fi

read_context
export FIRE_PHOENIX_AGENT="${FIRE_PHOENIX_AGENT:-coordinate-team}"

SKILL_DIR="$(CDPATH="" cd "$SCRIPT_DIR/../.." && pwd)"
DATE=$(date +%Y-%m-%d)

RAW_SLUG=$(resolve_auto CT_SLUG "${1:-team-run}") || true
SLUG=$(printf '%s' "$RAW_SLUG" | tr '[:upper:] ' '[:lower:]-' | tr -cd 'a-z0-9-' | sed 's/^-*//; s/-*$//')
[ -n "$SLUG" ] || SLUG="team-run"

ROLES=$(resolve_auto CT_ROLES "architect,developer,tester") || true
MODE=$(resolve_auto CT_MODE "${FIRE_PHOENIX_AGENT_MODE:-interactive}") || true
INTEGRATION=$(resolve_auto CT_INTEGRATION "claude") || true
ENVELOPE=$(resolve_auto CT_ENVELOPE "none — non-Routine phases gated for human") || true

# --- Roster validation (AC-CT-005): validate ALL roles before writing. ---
KNOWN_ROLES="business-analyst product-owner architect developer test-architect tester code-quality-reviewer code-security-reviewer devops project-manager scrum-master technical-analyst ux-designer bug-fixer asset-security-reviewer"
IFS=',' read -ra ROLE_ARR <<< "$ROLES"
STAFFED=()
for r in "${ROLE_ARR[@]}"; do
    role=$(printf '%s' "$r" | tr -d '[:space:]')
    [ -n "$role" ] || continue
    case " $KNOWN_ROLES " in
        *" $role "*) STAFFED+=("$role") ;;
        *)
            echo "ERROR: unknown role '$role' — no matching subagent in the roster." >&2
            echo "       Known roles: $KNOWN_ROLES" >&2
            echo "       Nothing written (no partial workflow)." >&2
            exit 2
            ;;
    esac
done
[ "${#STAFFED[@]}" -gt 0 ] || { echo "ERROR: no roles staffed." >&2; exit 2; }

ORCH_DIR=$(worktype_dir "orchestration")
RUN_DIR="$ORCH_DIR/$SLUG"
WF_DIR="$FIRE_PHOENIX_REPO_ROOT/.fire-phoenix/workflows/$SLUG"

if [ "${FIRE_PHOENIX_DRY_RUN:-0}" = "1" ]; then
    echo "[dry-run] slug=$SLUG mode=$MODE integration=$INTEGRATION"
    echo "[dry-run] would write: $RUN_DIR/team-plan.md"
    for role in "${STAFFED[@]}"; do echo "[dry-run]   brief: $RUN_DIR/brief-$role.md"; done
    echo "[dry-run] would write: $WF_DIR/workflow.yml"
    exit 0
fi

if ! confirm_before_write "Scaffold coordinator triad for '$SLUG' to $RUN_DIR/ and $WF_DIR/."; then
    echo "Aborted." >&2
    exit 1
fi

# Idempotent render: write only when content differs (byte-identical re-run). AC-CT-008.
render() {  # render <dest> <template> <sed-expr...>
    local dest="$1" tpl="$2"; shift 2
    local tmp; tmp="$(mktemp)"
    sed "$@" "$tpl" > "$tmp"
    if [ -f "$dest" ] && cmp -s "$tmp" "$dest"; then
        echo "  unchanged: $dest"; rm -f "$tmp"
    else
        mkdir -p "$(dirname "$dest")"; mv "$tmp" "$dest"; echo "  wrote: $dest"
    fi
}

mkdir -p "$RUN_DIR" "$WF_DIR"

render "$RUN_DIR/team-plan.md" "$SKILL_DIR/templates/team-plan-template.md" \
    -e "s|<slug>|$SLUG|g" \
    -e "s|@MODE@|$MODE|g" \
    -e "s|@ENVELOPE@|$ENVELOPE|g"

for role in "${STAFFED[@]}"; do
    render "$RUN_DIR/brief-$role.md" "$SKILL_DIR/templates/brief-template.md" \
        -e "s|<role>|$role|g" \
        -e "s|<slug>|$SLUG|g" \
        -e "s|@MODE@|$MODE|g"
done

render "$WF_DIR/workflow.yml" "$SKILL_DIR/templates/team-workflow-template.yml" \
    -e "s|coordinate-team-run|$SLUG|g" \
    -e "s|execution: \"interactive\"|execution: \"$MODE\"|g" \
    -e "s|default: \"claude\"|default: \"$INTEGRATION\"|g"

write_extract "$RUN_DIR/team-plan.md" \
    SLUG="$SLUG" ROLES="$(IFS=,; echo "${STAFFED[*]}")" MODE="$MODE" STATUS=drafted

if [ "${FIRE_PHOENIX_AGENT_MODE:-interactive}" = "auto" ]; then
    write_decision "autonomous-action" \
        "Staffed team '$SLUG' with roles: $(IFS=,; echo "${STAFFED[*]}")" \
        "coordinate-team scaffolded the triad in auto mode" \
        "smaller/larger roster" || true
fi

echo
echo "Coordinator triad ready. Launch with:"
echo "  fire-phoenix workflow run $SLUG$([ "$MODE" = auto ] && echo ' --auto')"
