#!/usr/bin/env pwsh
param([switch]$Auto, [switch]$DryRun, [string]$Answers, [switch]$Help, [string]$Slug)
$ErrorActionPreference = 'Stop'
$ScriptDir = Split-Path -Parent $PSCommandPath
. (Join-Path $ScriptDir 'common.ps1')
if ($Auto)    { $env:FIRE_PHOENIX_AUTO = '1' }
if ($DryRun)  { $env:FIRE_PHOENIX_DRY_RUN = '1' }
if ($Answers) { $env:FIRE_PHOENIX_ANSWERS = $Answers; Import-FirePhoenixAnswers -Path $Answers }
if ($Help) {
    @'
Usage: plan-team.ps1 [-Auto] [-Answers FILE] [-DryRun] [-Help] [-Slug <slug>]

Scaffolds the coordinator triad idempotently:
  - <docs>/orchestration/<slug>/team-plan.md
  - <docs>/orchestration/<slug>/brief-<role>.md   (one per staffed role)
  - .fire-phoenix/workflows/<slug>/workflow.yml    (engine-valid gated spine)

Answer keys: CT_SLUG, CT_ROLES (comma-separated), CT_MODE,
             CT_INTEGRATION, CT_ENVELOPE.
Roles must match an installed role-subagent (see references/subagent-roster.md);
an unknown role is a hard error and nothing is written.
'@ | Write-Host; exit 0
}

$ctx      = Read-Context
if (-not $env:FIRE_PHOENIX_AGENT) { $env:FIRE_PHOENIX_AGENT = 'coordinate-team' }
$SkillDir = (Resolve-Path -LiteralPath (Join-Path $ScriptDir '../..')).Path
$Date     = Get-Date -Format 'yyyy-MM-dd'

$RawSlug     = Resolve-Auto -Key 'CT_SLUG'        -Default $(if ($Slug) { $Slug } else { 'team-run' })
$SlugVal     = (($RawSlug.ToLower() -replace '[^a-z0-9]+','-') -replace '(^-+|-+$)','')
if (-not $SlugVal) { $SlugVal = 'team-run' }
$Roles       = Resolve-Auto -Key 'CT_ROLES'       -Default 'architect,developer,tester'
$Mode        = Resolve-Auto -Key 'CT_MODE'        -Default $(if ($env:FIRE_PHOENIX_AGENT_MODE) { $env:FIRE_PHOENIX_AGENT_MODE } else { 'interactive' })
$Integration = Resolve-Auto -Key 'CT_INTEGRATION' -Default 'claude'
$Envelope    = Resolve-Auto -Key 'CT_ENVELOPE'    -Default 'none — non-Routine phases gated for human'

# --- Roster validation (AC-CT-005): validate ALL roles before writing. ---
$KnownRoles = @('business-analyst','product-owner','architect','developer','test-architect','tester',
                'code-quality-reviewer','code-security-reviewer','devops','project-manager',
                'scrum-master','technical-analyst','ux-designer','bug-fixer','asset-security-reviewer')
$Staffed = @()
foreach ($r in ($Roles -split ',')) {
    $role = $r.Trim()
    if (-not $role) { continue }
    if ($KnownRoles -notcontains $role) {
        Write-Error ("unknown role '{0}' — no matching subagent in the roster. Known roles: {1}. Nothing written (no partial workflow)." -f $role, ($KnownRoles -join ' '))
        exit 2
    }
    $Staffed += $role
}
if ($Staffed.Count -eq 0) { Write-Error 'no roles staffed.'; exit 2 }

$OrchDir = Get-WorktypeDir -Name 'orchestration'
$RunDir  = Join-Path $OrchDir $SlugVal
$WfDir   = Join-Path $ctx.REPO_ROOT (Join-Path '.fire-phoenix/workflows' $SlugVal)

if ($env:FIRE_PHOENIX_DRY_RUN -eq '1') {
    Write-Host ("[dry-run] slug={0} mode={1} integration={2}" -f $SlugVal, $Mode, $Integration)
    Write-Host ("[dry-run] would write: {0}" -f (Join-Path $RunDir 'team-plan.md'))
    foreach ($role in $Staffed) { Write-Host ("[dry-run]   brief: {0}" -f (Join-Path $RunDir "brief-$role.md")) }
    Write-Host ("[dry-run] would write: {0}" -f (Join-Path $WfDir 'workflow.yml'))
    exit 0
}

if (-not (Confirm-BeforeWrite -Message "Scaffold coordinator triad for '$SlugVal' to $RunDir/ and $WfDir/.")) {
    Write-Error 'Aborted.'; exit 1
}

# Idempotent render: write only when content differs (byte-identical re-run). AC-CT-008.
function Render-File {
    param([string]$Dest, [string]$Template, [hashtable]$Map)
    $content = Get-Content -LiteralPath $Template -Raw
    foreach ($k in $Map.Keys) { $content = $content.Replace($k, $Map[$k]) }
    if ((Test-Path -LiteralPath $Dest) -and ((Get-Content -LiteralPath $Dest -Raw) -eq $content)) {
        Write-Host "  unchanged: $Dest"
    } else {
        New-Item -ItemType Directory -Force -Path (Split-Path -Parent $Dest) | Out-Null
        Set-Content -LiteralPath $Dest -Value $content -NoNewline
        Write-Host "  wrote: $Dest"
    }
}

New-Item -ItemType Directory -Force -Path $RunDir, $WfDir | Out-Null

Render-File -Dest (Join-Path $RunDir 'team-plan.md') `
    -Template (Join-Path $SkillDir 'templates/team-plan-template.md') `
    -Map @{ '<slug>' = $SlugVal; '@MODE@' = $Mode; '@ENVELOPE@' = $Envelope }

foreach ($role in $Staffed) {
    Render-File -Dest (Join-Path $RunDir "brief-$role.md") `
        -Template (Join-Path $SkillDir 'templates/brief-template.md') `
        -Map @{ '<role>' = $role; '<slug>' = $SlugVal; '@MODE@' = $Mode }
}

Render-File -Dest (Join-Path $WfDir 'workflow.yml') `
    -Template (Join-Path $SkillDir 'templates/team-workflow-template.yml') `
    -Map @{ 'coordinate-team-run' = $SlugVal; 'execution: "interactive"' = "execution: `"$Mode`""; 'default: "claude"' = "default: `"$Integration`"" }

Write-Extract -ArtefactPath (Join-Path $RunDir 'team-plan.md') `
    "SLUG=$SlugVal" "ROLES=$($Staffed -join ',')" "MODE=$Mode" 'STATUS=drafted'

if (($env:FIRE_PHOENIX_AGENT_MODE) -eq 'auto') {
    Write-Decision -Kind 'autonomous-action' `
        -What ("Staffed team '{0}' with roles: {1}" -f $SlugVal, ($Staffed -join ',')) `
        -Why 'coordinate-team scaffolded the triad in auto mode' `
        -Alternatives 'smaller/larger roster' | Out-Null
}

Write-Host ''
Write-Host 'Coordinator triad ready. Launch with:'
$autoFlag = if ($Mode -eq 'auto') { ' --auto' } else { '' }
Write-Host ("  fire-phoenix workflow run {0}{1}" -f $SlugVal, $autoFlag)
