# Brief — <role> (team run: <slug>)

> Least-context brief. You are staffed on **one phase** of a larger team
> run. You see only what this phase needs; the coordinator holds the whole
> plan. Communicate results as artefacts, not chat.

## Your phase

<phase name and one-line objective>

## Mode

@MODE@ — inherited from the coordinator via
`FIRE_PHOENIX_AGENT_MODE`. Never switch modes on your own. If delegated
one-shot in `interactive` and you cannot prompt, batch your open questions
in your result rather than auto-deciding.

## Inputs (read only these)

- <artefact path> — <what it gives you>
- <upstream brief or spec section>

## Done means

- [ ] <verifiable outcome 1>
- [ ] <verifiable outcome 2>

## Outputs (write only these)

- <artefact path you produce>

## Boundaries (must never)

- Never approve or sign off a Consequential/Critical decision — surface it
  to the coordinator's gate.
- Never write a canonical decision record (an ADR or the decisions file)
  directly — draft it to the pending queue for the promote step to publish.
- Never read or modify another role's brief or the full team plan.
