# Team plan — <slug>

> Coordinator plan drafted by the `coordinate-team` skill. Single-user,
> artefact-based orchestration. Workers read only their own brief.

## Task

<one-paragraph statement of the complex task this team executes>

## Autonomy posture

- **Mode:** @MODE@
- **Envelope:** @ENVELOPE@
- **Self-close lanes:** Mechanical, Routine (only under a valid envelope in AUTO). Consequential/Critical always gated.

## Phases

| # | Phase | Owner role | Engaged via (command) | Lane | Gate? |
|---|---|---|---|---|---|
| 1 | <phase name> | <role> | `fire-phoenix.<verb>` | <lane> | <yes/no> |
| 2 | … | … | … | … | … |

## Roster staffed (with rationale)

- **<role>** — <why this role, one line>. Brief: `brief-<role>.md`.

## Gates

- **<gate id>** — after phase <#>, lane <Consequential/Critical>. Reject → abort. <what the human is checking>.

## Launch

```bash
fire-phoenix workflow run <slug>          # interactive (pause at each gate)
fire-phoenix workflow run <slug> --auto   # unattended (gates still stop for humans)
```

## Debts (open questions the user still owes)

- <debt, or "none">
