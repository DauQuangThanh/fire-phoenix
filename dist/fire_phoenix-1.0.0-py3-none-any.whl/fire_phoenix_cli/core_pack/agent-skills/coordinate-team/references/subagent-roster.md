# Subagent roster — who to staff, and the command that engages them

A team is staffed from the role-subagents installed in the project — the
15 built-in roles listed below, plus any you have added.
A workflow `command` step does **not** name a subagent directly — it
dispatches a fire-phoenix command, and the agent session that runs it
delegates to the role-subagent. This table maps each role to the
command(s) whose session engages it, so the coordinator can build the
workflow spine.

| Role (subagent) | When to staff | Engaged via (command / skill) |
|---|---|---|
| `business-analyst` | Requirements are unclear; you need a spec, user stories, or acceptance criteria before building. | `fire-phoenix.intent`, `fire-phoenix.acceptance-criteria`, `clarify-intent` |
| `product-owner` | A change needs business-fit confirmation at the acceptance gate; backlog/roadmap decisions. | `fire-phoenix.acceptance-criteria`, `backlog` |
| `architect` | A tech stack or system design must be chosen; ADRs or C4 diagrams needed. | `fire-phoenix.plan`, `development-design`, `c4-diagrams`, `adr-author` |
| `developer` | Implementation: turning a plan/tasks into code with a unit-test strategy. | `fire-phoenix.plan`, `fire-phoenix.taskify`, `fire-phoenix.implement` |
| `test-architect` | Test strategy, automation framework choice, quality-gate definition. | `fire-phoenix.test-cases`, `test-strategy` |
| `tester` | Test-case design, execution tracking, test reporting. | `fire-phoenix.test-cases` |
| `code-quality-reviewer` | An adversarial quality review before a merge/gate (worktree-isolated). | review skills / a `gate` preceded by a review command |
| `code-security-reviewer` | Security/vuln/dependency audit or whole-system safety review (worktree-isolated). | `dependency-audit`, security-review skills |
| `asset-security-reviewer` | Security-review the installed agent assets themselves (subagent/skill bodies + scripts + hooks) for prompt injection, malicious scripts, credential theft, supply-chain/dependency confusion, privilege escalation (worktree-isolated). | `agent-asset-security-review`, `dependency-audit` |
| `devops` | CI/CD, IaC, containerization, monitoring, deployment strategy. | `cicd-pipeline`, `containerization`, `deployment-strategy` |
| `project-manager` | Planning, status tracking, risk management, change control. | `change-control`, project skills |
| `scrum-master` | Sprint planning / retro synthesis / impediment tracking (single-user authoring only). | agile skills |
| `technical-analyst` | Brownfield: reverse-engineer existing code into docs/diagrams/API docs. | `codebase-scan`, `architecture-extraction`, `api-docs` |
| `ux-designer` | UX design, wireframes, runnable SPA mockups. | `react-spa-mockup`, ux skills |
| `bug-fixer` | Resolve open bugs / code-quality debt / security findings in source. | `bug-triage`, `bug-report` |

## Staffing rules

- **Smallest covering team.** Staff only the roles a phase needs. A
  two-phase task usually needs two roles, not fourteen.
- **One owner per phase.** Each phase names a single accountable role;
  reviewers attach to a *gate*, not a phase.
- **Reviewers gate, they don't own.** `code-quality-reviewer` and
  `code-security-reviewer` are worktree-isolated adversarial roles — place
  them before a Consequential/Critical `gate`, never as a phase owner.

## Adding a user-defined role (open–closed)

The roster is data, not code. To staff a role beyond the 15, drop its
subagent definition into the project's subagents directory and add a row
here mapping it to the command that engages it. No change to this skill is
needed — the coordinator reads the roster, it does not hardcode it.
