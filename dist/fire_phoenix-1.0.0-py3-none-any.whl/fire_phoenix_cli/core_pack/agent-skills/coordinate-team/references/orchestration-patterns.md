# Orchestration patterns — decompose, staff, gate

The coordinator's job is three decisions: **what are the phases**, **who
owns each**, and **where do humans check in**. This reference gives the
patterns; the SKILL.md gives the procedure.

## Decomposition patterns

- **Lifecycle spine** — intent → acceptance → plan → taskify → test-cases
  → implement. The default for a greenfield feature. Drop the phases the
  task doesn't need (a bug fix may start at `plan`).
- **Brownfield-first** — codebase-scan → dependency-map → characterise-
  behaviour → recover-spec → (then the lifecycle spine). Use when the
  system exists and intent must be recovered before change.
- **Review sandwich** — a build phase bracketed by a review phase and a
  gate. Use when the change is Consequential and needs an adversarial pass.

## Staffing patterns

- **Solo-with-review** — one owner role + one reviewer at the gate. The
  common case.
- **Design-then-build** — `architect` owns a design phase behind a gate,
  then `developer` owns implementation. Use when the approach is unsettled.
- **Full-cycle** — BA → architect → developer → tester, each a phase, with
  an acceptance gate and a pre-merge review gate.

## Lane → gate mapping

Classify each phase boundary by change lane, then gate accordingly. This
is the load-bearing safety rule — it keeps the coordinator inside the
autonomy ceiling (only Mechanical/Routine can ever auto-close).

| Lane | Gate in the generated workflow | Rationale |
|---|---|---|
| Mechanical | No gate (may self-close in AUTO under a valid envelope) | Reversible, routine, low blast radius. |
| Routine | No gate (may self-close in AUTO under a valid envelope) | Bounded, well-understood. |
| Consequential | **`gate`, `on_reject: abort`** | Humans gate in every mode; never self-closed. |
| Critical | **`gate`, `on_reject: abort`** + `fire-phoenix check approval` | Requires developer, tester, and product-owner sign-off. |

In AUTO, if no valid autonomy envelope permits a Mechanical/Routine
phase's lane, **add the gate anyway** — fail closed to human approval,
never silent self-close.

## Anti-patterns

- **One mega-phase.** If a single phase spans design + build + test, it
  can't be gated or staffed cleanly — split it.
- **Reviewer as owner.** Don't make a review role own a build phase.
- **Control flow in the workflow.** The workflow engine is linear (no
  branching or looping step types); express branching by composing
  separate steps, not `if`/`switch`/`while`/`fan`.
- **Chat state.** Don't rely on conversation memory between phases — the
  briefs and `STATUS.md` are the state.
