# Interactive questionnaire — coordinate-team

Skill-specific audience/questionnaire rules. The `coordinate-team` SKILL.md body points
here; read this file when it sends you here.

**Register first — adapt to role level.** Before applying the beginner floor
below, resolve the reader's level from the merged `.fire-phoenix/context.yml`
+ `.fire-phoenix/user-context.yml` (`user-context.yml` wins): use
`preferences.tech_role_level` for technical work (`junior` → hand-hold, one
path; `mid` → ≥2 options with one-line trade-offs; `senior` → defer on
judgment, surface edge cases, be brief; `staff` → be terse, challenge
premises, skip obvious caveats) and `preferences.non_tech_role_level` for
stakeholder work (`non-technical` → outcomes not jargon; `familiar` → simple
jargon glossed; `fluent` → concepts without explanation; `technical` → full
vocabulary). An explicit in-session signal (e.g. "be terse", "skip the
explanation") overrides everything. The plain-English, one-question-at-a-time
floor below applies **only when the relevant level is unset**; never treat
role level as a gate. Full rule: `.fire-phoenix/references/subagents/register-resolution.md`.

When `FIRE_PHOENIX_AGENT_MODE=interactive` (the default), run the staffing
decisions as a guided interview, not an interrogation:

- **One question at a time.** Never dump the whole staffing plan as a
  wall of questions.
- **Choices, not blank fields.** Offer 2-4 lettered options (A/B/C/D) with
  a one-line trade-off each, plus "Not sure — pick a sensible default".
- **Always recommend.** State the option you would pick and why in one
  sentence, so the user can reply "yes" to accept.
- **Pull defaults from upstream artefacts** — the spec, plan, ADRs, and
  `STATUS.md` — before asking blank. If the intent already implies a role,
  propose it pre-filled and ask only for a yes/no.
- **`not sure` / `skip` applies a sensible default**, marked
  "(default applied — confirm later)" in the plan.

When `FIRE_PHOENIX_AGENT_MODE=auto` (or `--auto`), skip the interview:
apply defaults from upstream artefacts, staff the smallest team that
covers the task, and log every non-trivial choice via `write_decision` to
`{context.paths.docs}/agent-decisions/coordinate-team/`.
