# ADR quality checklist — the 7+2 anatomy, field by field

Run this checklist on every drafted ADR before presenting it to
the decider. A field that fails its quality bar is not "good
enough for now" — fix it or log a debt naming what is missing.
For section layout and voice, see `nygard-style.md`.

## Field-by-field quality bars

| Field | Quality bar |
|---|---|
| **Date** | The date the decision was (or will be) taken, not the date the file was written. If they differ, say so. |
| **Decision** | One sentence, imperative, active voice: "Use PostgreSQL 16 on managed RDS." No hedging ("we might", "probably"). If one sentence can't hold it, you are bundling — split into separate ADRs. |
| **Alternatives** | Each alternative is a real candidate that could have won under different constraints, with a one-line trade-off explaining why it lost *here*. "Do nothing" counts when it was viable. An alternative listed only to be knocked down is a strawman — cut it or state its genuine strength. |
| **Owner** | A named person or role (the Decider). The AI is never the owner. "The team" is not an owner. |
| **Deadline** | When the decision must land or be implemented. `n/a` is allowed for retrospective ADRs, but say "retrospective" explicitly. |
| **Success criteria** | Falsifiable and checkable: a condition someone could verify true or false. "Will improve performance" fails the bar; "read path serves the stated peak load within the intake's latency target" passes. |
| **Re-decision trigger** | Falsifiable events, not vibes. "If the vendor drops the free tier", "if sustained load exceeds the envelope in `intake.md`" pass; "if things change" or "review in a year" alone fail. |
| **Door type** | `one-way` or `two-way`, **with the reversal cost stated** in a phrase. A "two-way door" whose reversal is a multi-month migration is one-way in practice — classify by the cost, not the theory. |
| **Status** | `Proposed` until the human decider accepts. The AI never advances the status. |

## Anti-patterns

- **Retro-fitted ADR** — written after the implementation to
  justify it, dressed up as if decided in advance. Retrospective
  ADRs are legitimate (brownfield archaeology produces them) but
  must say so: "extracted from implementation on YYYY-MM-DD,
  rationale not documented at the time".
- **Bundled decisions** — one ADR deciding database + cache +
  queue. Each gets its own record; bundles hide which trade-offs
  belong to which choice and make superseding one part impossible.
- **Strawman alternatives** — see the Alternatives bar above.
- **Editing an accepted ADR** — never. Write a new ADR that
  supersedes it (see "Versioning" in `nygard-style.md`).
- **Decision dressed as context / vague consequences / no
  alternatives** — see "Anti-patterns" in `nygard-style.md`.
