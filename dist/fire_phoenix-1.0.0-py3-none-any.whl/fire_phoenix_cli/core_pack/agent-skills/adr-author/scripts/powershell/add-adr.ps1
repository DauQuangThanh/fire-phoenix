#!/usr/bin/env pwsh
param([switch]$Auto, [switch]$DryRun, [string]$Answers, [switch]$Help)
$ErrorActionPreference = 'Stop'
$ScriptDir = Split-Path -Parent $PSCommandPath
. (Join-Path $ScriptDir 'common.ps1')
if ($Auto)    { $env:FIRE_PHOENIX_AUTO = '1' }
if ($DryRun)  { $env:FIRE_PHOENIX_DRY_RUN = '1' }
if ($Answers) { $env:FIRE_PHOENIX_ANSWERS = $Answers; Import-FirePhoenixAnswers -Path $Answers }
if ($Help) { "Usage: add-adr.ps1 -Auto. Writes an ADR DRAFT to {governance.adr_drafts_dir}/<slug>-<hash>.md; the canonical NNNN under {governance.adr_dir} is assigned later by the promote-governance skill. Keys: ADR_TITLE, ADR_DECIDER, ADR_CONTEXT, ADR_DECISION, ADR_CONSEQUENCES, ADR_STATUS, ADR_SUPERSEDES." | Write-Host; exit 0 }

$ctx = Read-Context
$SkillDir = (Resolve-Path -LiteralPath (Join-Path $ScriptDir '..\..')).Path
# Write DRAFTS to the pending queue in every mode; the
# promote-governance skill is the sole writer of the canonical adr_dir.
$Dir      = Join-Path $ctx.REPO_ROOT $ctx.ADR_DRAFTS_DIR
$Debts    = Join-Path (Join-Path $ctx.REPO_ROOT $ctx.DOCS_DIR) 'architecture\tech-debts.md'

$Title    = Resolve-Auto -Key 'ADR_TITLE'        -Default ''
$Decider  = Resolve-Auto -Key 'ADR_DECIDER'      -Default ''
$Context  = Resolve-Auto -Key 'ADR_CONTEXT'      -Default ''
$Decision = Resolve-Auto -Key 'ADR_DECISION'     -Default ''
$Conseq   = Resolve-Auto -Key 'ADR_CONSEQUENCES' -Default ''
$Status   = Resolve-Auto -Key 'ADR_STATUS'       -Default 'Proposed'
$Sup      = Resolve-Auto -Key 'ADR_SUPERSEDES'   -Default ''

if ($Status -notin @('Proposed','Accepted','Deprecated','Superseded','Inferred')) { $Status = 'Proposed' }
if (-not $Title) { Write-Error "ADR_TITLE required"; exit 2 }

$slug = ($Title.ToLower() -replace '[^a-z0-9]+', '-').Trim('-')
if (-not $slug) { $slug = 'adr' }
if ($slug.Length -gt 60) { $slug = $slug.Substring(0, 60) }
$hash = _FirePhoenixShortHash ("{0}`0{1}" -f $Title, $Decision)
$Out = Join-Path $Dir ("{0}-{1}.md" -f $slug, $hash)
$supLine = if ($Sup) { "**Supersedes:** $Sup" } else { '' }

if ($env:FIRE_PHOENIX_DRY_RUN -eq '1') { Write-Host ("[dry-run] would write draft: {0}" -f $Out); exit 0 }
if (-not (Confirm-BeforeWrite -Message "Write ADR draft at $Out (promote later via the promote-governance skill).")) { Write-Error 'Aborted.'; exit 1 }
New-Item -ItemType Directory -Force -Path $Dir | Out-Null
if (Test-Path -LiteralPath $Out) { Write-Host ("ADR draft already exists (idempotent): {0}" -f $Out); exit 0 }

# Provisional number "DRAFT" — promote-adrs assigns the canonical NNNN.
$tpl = Get-Content -LiteralPath (Join-Path $SkillDir 'templates\adr-template.md') -Raw
$c = $tpl.Replace('{number}', 'DRAFT').Replace('{title}', $Title).Replace('{date}', (Get-Date -Format 'yyyy-MM-dd'))
$c = $c.Replace('{status}', $Status).Replace('{decider}', $(if ($Decider) { $Decider } else { '<TBD>' }))
$c = $c.Replace('{supersedes_line}', $supLine)
$c = $c.Replace('{context}', $(if ($Context) { $Context } else { '<TBD>' }))
$c = $c.Replace('{decision}', $(if ($Decision) { $Decision } else { '<TBD>' }))
$c = $c.Replace('{consequences}', $(if ($Conseq) { $Conseq } else { '<TBD>' }))
Set-Content -LiteralPath $Out -Value $c

Write-Extract -ArtefactPath $Out "ADR_ID=DRAFT" "SLUG=$slug" "TITLE=$Title" "STATUS=$Status" "DECIDER=$Decider" | Out-Null
Write-Host ("Wrote draft {0}" -f $Out)
Write-Host ("Promote to {0} via the promote-governance skill (interactive, human-confirmed)." -f $ctx.ADR_DIR)

if (-not $Context -or -not $Decision) {
    Append-Debt -File $Debts -Prefix 'TDEBT' -Body "ADR draft '$Title' has incomplete context or decision — flesh out before promoting" | Out-Null
}
if (-not $Decider) {
    Append-Debt -File $Debts -Prefix 'TDEBT' -Body "ADR draft '$Title' has no decider recorded" | Out-Null
}
