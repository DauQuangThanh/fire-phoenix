---
name: observability-plan
description: Drafts the observability plan — logs, metrics, traces, SLIs/SLOs, alerts,
  dashboards — as a design doc plus starter dashboard/alert YAML. Use when setting
  up monitoring or defining SLOs/SLIs.
license: MIT
compatibility: Designed for agentskills.io-compatible agents.
metadata:
  author: Dau Quang Thanh
  version: '1.0'
  requires: []
---

## User Input

```text
$ARGUMENTS
```

## Audience and tone (interactive mode)

**Register first — adapt to role level.** Run as a guided, one-question-at-a-time questionnaire (yes/no first, recommend a default); skip in `FIRE_PHOENIX_AGENT_MODE=auto`. Full rules: `.fire-phoenix/references/subagents/interactive-questionnaire.md`.

## Inputs

- `.fire-phoenix/context.yml`
- `{context.paths.docs}/architecture/intake.md` (SLA)
- `{context.paths.docs}/architecture/c4-container.md`

## Outputs

- `{context.paths.docs}/operations/monitoring.md`
- `assets/alerts.sample.yml` — alert rules starter
- `assets/dashboard.sample.json` — dashboard starter

## Context Update

Does not mutate `.fire-phoenix/context.yml`.

## Handoffs

- `deployment-strategy` reads SLI/SLO to set deploy-time canary bake.
- `cicd-pipeline` reads alert definitions to wire post-deploy checks.

## AI authoring scope

**Does:** design three pillars (logs / metrics / traces), propose
SLIs (request latency, error rate, saturation, duration) + SLOs
aligned with the intake SLA, draft alert thresholds.

**Does not:** provision dashboards or alerts; page on-call;
modify infra.

## SLI selection and alert quality

Select SLIs per service type using the checklist in
`references/sli-slo-basics.md` (availability / latency for
request-driven, freshness / correctness / completion for
pipelines and jobs — qualitative sets, 2-4 per service). Every
service on the C4 diagram is either measured or the plan says why
not.

Every alert passes the rules in `references/alert-quality.md`:
actionable, runbook-linked by name, page-vs-ticket separated, and
burn-rate based where an SLO exists. **Thresholds are user
decisions** — the skill proposes candidates marked "(default
applied — confirm later)"; the user's confirmed value is logged
as a decision, never invented. Note next to each alert which
intent artefact a repeat firing feeds (incident → intent loop).

## Usage

> `<SKILL_DIR>` = the integration's skills root (e.g. `.claude/skills/`
> for Claude Code, `.codex/skills/` for Codex,
> `.cursor/skills/` for Cursor).
> Scripts live at `<SKILL_DIR>/<skill-name>/scripts/…`.

```bash
MON_STACK=otel bash <SKILL_DIR>/observability-plan/scripts/bash/draft-monitoring.sh --auto
```

### Answer keys

| Key | Default |
|---|---|
| `MON_STACK` (`otel`/`datadog`/`newrelic`/`cloudwatch`/`prometheus-grafana`) | `otel` |
| `MON_SLO_AVAILABILITY` | `99.9` |
| `MON_SLO_P95_MS` | `300` |
