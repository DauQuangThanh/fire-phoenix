# Observability plan

**Date:** {date}
**Stack:** {stack}

## Three pillars

- **Logs** — structured JSON, one event per line, with
  `request_id` / `trace_id` correlation.
- **Metrics** — RED (rate, errors, duration) per endpoint + USE
  (utilisation, saturation, errors) per container.
- **Traces** — OpenTelemetry spans around I/O seams (DB, HTTP
  outbound, queue).

## SLIs + SLOs

| SLI | Target (SLO) | Alert threshold |
|---|---|---|
| Availability (successful requests / total) | {slo_avail}% | burn rate |
| Latency — p95 | ≤ {slo_p95_ms} ms | p95 > target for 10 min |
| Error rate | ≤ (100-{slo_avail})% | error budget burn |

## Alerts

> Numbers below are proposals until the user confirms them —
> thresholds are user decisions, logged as such. Every alert
> names its runbook and the action the responder takes; an alert
> with neither becomes a dashboard panel.

| Alert | Condition (proposed) | Runbook | Repeat firing feeds |
|---|---|---|---|
| Availability fast burn | > 2% budget in 1h | `ops/runbook-<name>.md` | <intent artefact> |
| Availability slow burn | > 10% budget in 24h | `ops/runbook-<name>.md` | <intent artefact> |
| Latency | sustained p95 breach + step change | `ops/runbook-<name>.md` | <intent artefact> |
| Saturation | alert 80% / page 90% utilisation | `ops/runbook-<name>.md` | <intent artefact> |
| Background | queue depth / dead-letter growth | `ops/runbook-<name>.md` | <intent artefact> |

## Dashboards

- **Service overview** — RED per endpoint, error budget burn.
- **Dependencies** — DB / cache / IdP latency + error rates.
- **Deploys** — mark deploy events on every chart.

## Starter files

- `assets/alerts.sample.yml`
- `assets/dashboard.sample.json`
