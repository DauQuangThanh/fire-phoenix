# Alert quality — rules for every alert that ships

An alert is a claim that a human must act. Alerts that fail the
rules below train responders to ignore the pager — the most
expensive failure mode an observability plan can have.

## The rules

- [ ] **Actionable.** The alert names the action the responder
      takes. If the honest answer is "watch it", it is a
      dashboard panel, not an alert.
- [ ] **Runbook-linked.** Every alert names its runbook
      (`ops/runbook-*.md` — trigger / owner / steps / verify /
      rollback / feeds). An alert with no runbook is either new
      (write the runbook now) or noise (delete it).
- [ ] **Page vs. ticket.** Page only what needs action inside
      minutes; everything else files a ticket. Never page on
      warnings.
- [ ] **Burn rate over raw thresholds.** For SLO-backed alerts,
      alert on error-budget burn (fast + slow rules), not
      absolute counts.
- [ ] **Thresholds are user decisions.** This skill proposes
      candidate conditions and marks them "(default applied —
      confirm later)"; the user confirms or replaces the numbers,
      and the confirmed value is logged as a decision. Never
      present an invented threshold as settled.
- [ ] **Deduplicated.** One incident, one page. Group causally
      related alerts; suppress downstream symptoms of an upstream
      cause.

## Incident → intent loop

Alerts are the entry point of the incident → intent loop: an
incident that fires an alert must end by changing an intent
artefact — a new or amended runbook, a new invariant, a
strengthened check — or the system can repeat it. When drafting
the plan, note next to each alert which artefact a repeat firing
would feed ("if recurring → runbook + invariant candidate").
Repeat firings with no artefact change are `OPSDEBT-` entries.
