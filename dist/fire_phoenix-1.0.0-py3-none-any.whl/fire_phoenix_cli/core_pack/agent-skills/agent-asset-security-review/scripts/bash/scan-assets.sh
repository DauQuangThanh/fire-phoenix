#!/usr/bin/env bash
# agent-asset-security-review — read-only signature scan over the agent assets
# INSTALLED IN THE CURRENT PROJECT (subagent definitions + skills + their
# scripts under each AI tool's config dir — .claude/, .cursor/,
# .github/, .opencode/, .codex/, … — plus root context files and hook
# configs). Emits a markdown triage table: THREAT-CLASS | file:line | snippet.
# The subagent then verifies, classifies, and suggests fixes — this script never
# classifies as malicious on its own and NEVER executes a match.
#
# Usage: scan-assets.sh [--auto] [--path DIR] [--out FILE] [--help]
#   --path DIR   Scan any folder the user names (repeatable) — a project
#                subfolder, a source tree's assets/, a single skill bundle, etc.
#                Need not be an AI-tool config dir. Overrides auto-discovery.
#   --out FILE   Also write the triage table to FILE.
#
# Skill-specific helpers live here; common.sh is byte-identical
# canonical and carries no action logic.

set -euo pipefail
SCRIPT_DIR="$(CDPATH="" cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=common.sh
source "$SCRIPT_DIR/common.sh"

# Threat signatures. Format: CLASS<TAB>ERE. Heuristic triage only.
read -r -d '' SIGNATURES <<'SIG' || true
DANGEROUS-SCRIPT	(curl|wget)[^|]*\|[[:space:]]*(ba)?sh
DANGEROUS-SCRIPT	base64[[:space:]]+(-d|--decode)
DANGEROUS-SCRIPT	\beval[[:space:]]+["$`]
DANGEROUS-SCRIPT	rm[[:space:]]+-rf[[:space:]]+[/~]
DANGEROUS-SCRIPT	chmod[[:space:]]+(777|\+s)
DANGEROUS-SCRIPT	(/dev/tcp/|mkfifo|nc[[:space:]]+-e|bash[[:space:]]+-i)
CREDENTIAL-THEFT	(~/\.aws|~/\.ssh|id_rsa|\.netrc)
CREDENTIAL-THEFT	(AWS_SECRET|ANTHROPIC_API_KEY|GITHUB_TOKEN|_API_KEY|_SECRET)
CREDENTIAL-THEFT	(printenv|env[[:space:]]*\||cat[[:space:]]+[^;]*token)
SUPPLY-CHAIN	(pip[0-9]?|pipx|uv)[[:space:]]+install
SUPPLY-CHAIN	(npm|pnpm|yarn)[[:space:]]+(install|add)|npx[[:space:]]
SUPPLY-CHAIN	@latest|--index-url|--extra-index-url
PRIVILEGE-ESCALATION	(^|[[:space:]])sudo[[:space:]]
PRIVILEGE-ESCALATION	\.git/hooks|/etc/|~/\.(bashrc|zshrc|profile)
PROMPT-INJECTION	[Ii]gnore[[:space:]]+(all[[:space:]]+)?previous[[:space:]]+instructions
PROMPT-INJECTION	disregard[[:space:]]+[^.]*instructions|you[[:space:]]+are[[:space:]]+now
PROMPT-INJECTION	(exfiltrat|do[[:space:]]+not[[:space:]]+tell[[:space:]]+the[[:space:]]+user)
INDIRECT-INJECTION	(read|fetch|open)[^.\n]*https?://[^.\n]*(run|follow|execute|obey)
SIG

AUTO=0; OUT=""; PATHS=()
while [ $# -gt 0 ]; do
    case "$1" in
        --auto) AUTO=1 ;;
        --path) PATHS+=("$2"); shift ;;
        --out) OUT="$2"; shift ;;
        --help) sed -n '2,12p' "${BASH_SOURCE[0]}" | sed 's/^# \{0,1\}//'; exit 0 ;;
        *) echo "unknown arg: $1" >&2; exit 64 ;;
    esac
    shift
done

read_context
ROOT="${FIRE_PHOENIX_REPO_ROOT:-$(pwd)}"

# Auto-discover the agent assets INSTALLED in this project: any hidden AI-tool
# config dir that holds an agents/, agent/, or skills/ subdir (provider-agnostic
# — no hardcoded provider list), plus root context files. --path overrides this.
if [ "${#PATHS[@]}" -eq 0 ]; then
    for d in "$ROOT"/.*/; do
        [ -d "$d" ] || continue
        case "$(basename "$d")" in .|..|.git) continue ;; esac
        if [ -d "${d}agents" ] || [ -d "${d}agent" ] || [ -d "${d}skills" ]; then
            PATHS+=("$d")   # find recurses into agents/, skills/scripts, hooks, settings
        fi
    done
    for f in CLAUDE.md AGENTS.md; do
        [ -f "$ROOT/$f" ] && PATHS+=("$ROOT/$f")
    done
fi
if [ "${#PATHS[@]}" -eq 0 ]; then
    echo "no installed agent assets found under $ROOT — this reviewer scans a" >&2
    echo "project where fire-phoenix assets are installed. Pass --path <dir> to" >&2
    echo "target a specific tree (e.g. a source repo's assets/)." >&2
    exit 3
fi

# docs-example allowlist: reference/checklist docs deliberately contain attack
# strings. Skip them so examples are not raised as findings (see
# references/docs-example-allowlist.md).
is_allowlisted() {
    case "$1" in
        */references/*|*checklist*|*-patterns.md|*-allowlist.md|*severity-rubric.md) return 0 ;;
        */agent-asset-security-review/SKILL.md|*/asset-security-reviewer.md) return 0 ;;  # the reviewer's own taxonomy docs
    esac
    return 1
}

emit() { printf '%s\n' "$1"; [ -n "$OUT" ] && printf '%s\n' "$1" >> "$OUT"; return 0; }
[ -n "$OUT" ] && : > "$OUT" || true

emit "# Asset-security triage (heuristic — verify each before reporting)"
emit ""
emit "| Threat class | Location | Snippet |"
emit "|---|---|---|"

hits=0
while IFS= read -r asset; do
    [ -z "$asset" ] && continue
    is_allowlisted "$asset" && continue
    while IFS=$'\t' read -r class ere; do
        [ -z "$class" ] && continue
        while IFS= read -r m; do
            [ -z "$m" ] && continue
            ln="${m%%:*}"; snip="${m#*:}"
            snip="$(printf '%s' "$snip" | sed 's/|/\\|/g' | cut -c1-80)"
            emit "| $class | ${asset#"$ROOT"/}:$ln | \`$snip\` |"
            hits=$((hits+1))
        done < <(grep -nE "$ere" "$asset" 2>/dev/null || true)
    done <<< "$SIGNATURES"
done < <(find "${PATHS[@]}" -type f \( -name '*.md' -o -name '*.sh' -o -name '*.ps1' -o -name '*.json' -o -name '*.yml' -o -name '*.yaml' -o -name '*.toml' \) 2>/dev/null | sort)

emit ""
emit "_$hits raw signature hit(s). Heuristic only: confirm real vs. documentation-example, classify, assign severity, and suggest a fix per the skill's references._"
[ "$AUTO" -eq 0 ] && echo "NEXT: verify each hit (docs-example allowlist already applied), then author {context.paths.docs}/reviews/asset-security.md." >&2
exit 0
