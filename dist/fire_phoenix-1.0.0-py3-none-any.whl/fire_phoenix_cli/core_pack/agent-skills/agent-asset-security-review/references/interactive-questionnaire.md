# Interactive questionnaire — agent-asset-security-review

Skill-specific audience/questionnaire rules. The `agent-asset-security-review` SKILL.md body points
here; read this file when it sends you here.

**Register first — adapt to role level.** Resolve the reader's level from the
merged `.fire-phoenix/context.yml` + `.fire-phoenix/user-context.yml`
(`user-context.yml` wins): `preferences.tech_role_level` for technical work.
An explicit in-session signal overrides. The plain-English floor applies only
when the level is unset; never treat role level as a gate. Full rule:
`.fire-phoenix/references/subagents/register-resolution.md`.

Run interactively as a guided review: show what was scanned and each hit
in plain language before classifying. In `auto` mode, skip the pause and
log decisions.
