# Privilege-escalation patterns

An asset reaching beyond its sandbox: the repo working tree + declared outputs.

## Signatures
- `sudo`, `doas`, `runas`
- writes outside the repo: `/etc/`, `/usr/`, `$HOME/.bashrc|.zshrc|.profile`
- editing `.git/hooks/**` (persistence) or the integrations' hook configs
- self-modifying assets (a skill script writing to `assets/**` or its own body)
- disabling guardrails: touching the governance deny-hook / audit hook config

## What to check
- Does the write target sit outside `{context.paths.docs}` and the repo tree?
- Is a hook being installed that runs on every future tool call? High/Critical.
