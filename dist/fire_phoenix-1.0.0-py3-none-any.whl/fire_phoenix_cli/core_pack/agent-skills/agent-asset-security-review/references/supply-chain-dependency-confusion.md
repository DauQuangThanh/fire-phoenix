# Supply-chain & dependency-confusion patterns

Risk introduced by what an asset's scripts install or fetch.

## Signatures
- `pip/pipx/uv install`, `npm/yarn/pnpm install`, `npx`, `gem install` in an
  asset script (fire-phoenix ships offline — installs are suspect)
- unpinned versions: `@latest`, no `==`/lockfile, `--index-url` /
  `--extra-index-url` pointing off the public registry
- internal-sounding package names resolvable on a public index (dependency
  confusion), or names one edit from a popular package (typosquatting)
- install-time scripts (`postinstall`, `setup.py` exec) on a pulled package
- fetch of a binary/script without an integrity hash or provenance

## What to check
- Pinned + hash-verified + provenance-known? If not → finding.
- Hand each package to the `dependency-audit` skill for CVE/provenance depth.
