# Remediation format (suggest-only, human-gated)

Every finding carries a fix the maintainer can apply. Never auto-apply.

```
### <THREAT-CLASS> — <one-line title>  [Severity: High]
- Location: <path>:<line>   Confidence: OBSERVED | INFERRED (level) | UNKNOWN
- Risk: <one sentence: what an attacker achieves>
- Evidence: <the cited line, secrets redacted>
- Suggested fix (diff-style outline):
    - <remove/replace X with Y — e.g. pin the version + add a hash>
- Reference: <OSV / CWE / OWASP link, fetched>
```

Rules: redact secret values; cite an authoritative reference for each fix;
if no fix is known, record an `ASECDEBT-` entry instead of guessing.
