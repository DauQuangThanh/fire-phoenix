# Dangerous-script patterns

Executable risk in `scripts/**` (bash/ps1), hook configs, or template scripts.

## Signatures
- `curl ... | sh` / `wget ... | bash` / `iex (New-Object Net.WebClient)` —
  remote code execution
- `base64 -d | sh` / `eval "$..."` / `Invoke-Expression` — obfuscated exec
- `rm -rf /` or `~` roots — destructive
- `chmod 777` / `chmod +s` — permission weakening / setuid
- `/dev/tcp/`, `mkfifo`, `nc -e`, `bash -i >& /dev/tcp` — reverse shell
- unexpected network egress from a script that should be offline

## What to check
- fire-phoenix scripts are **offline by contract** (PRODUCT.md invariant) — any
  network call in an action script is a finding until justified.
- Is the exec dynamic (attacker-influenced input reaching `eval`/`iex`)?
