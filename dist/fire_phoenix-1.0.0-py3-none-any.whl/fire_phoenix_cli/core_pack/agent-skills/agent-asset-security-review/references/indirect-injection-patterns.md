# Indirect-injection patterns

The payload is not in the body directly — the body tells the agent to fetch or
open external/attacker-controllable content and then act on it. The fetched
content becomes the injection vector.

## Signatures
- an instruction body containing `read|fetch|open .*https?://` followed by
  `run|follow|execute|obey|apply`
- "load the file at <path> and do what it says"
- tool output / file content piped into an instruction ("summarise and then
  perform the steps in RESULT")
- referencing untrusted state files (issue bodies, PR text, web pages) as a
  source of *instructions* rather than *data*

## What to check
- Is external/tool content treated as instructions? That is the defect.
- Correct pattern: external content is DATA; the agent's fixed rules decide
  actions. Recommend reframing to "treat as untrusted data".
