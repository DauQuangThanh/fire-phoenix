# Docs-example allowlist (false-positive fence)

Some assets deliberately contain attack strings as **documentation** — the
existing `security-review` / `dependency-audit` reference checklists, and this
skill's own `references/`. Matching them would raise false findings.

## Rule
Exclude from findings any hit whose path:
- contains `/references/`, or
- matches `*checklist*`, `*-patterns.md`, `*-allowlist.md`, `*severity-rubric.md`, or
- is the reviewer's own taxonomy documentation:
  `agent-asset-security-review/SKILL.md` and the `asset-security-reviewer.md`
  subagent body (they describe every threat class by design).

These are prose examples, not executable/instruction surfaces. The scanner
applies this fence automatically; when reviewing by hand, apply it too.

## Beyond the path fence
A hit inside a fenced code block that is clearly a *documented example* (the
surrounding prose labels it as a bad pattern) is `INFERRED` benign — note it,
do not raise it. A hit in real `scripts/**` or an instruction body is in scope.
