# Severity rubric (qualitative — never invent numeric scores)

- **Critical** — working RCE, credential read+exfil, a persistence hook, or a
  live prompt-injection in an always-in-context subagent body.
- **High** — dangerous exec or secret access without a proven sink; unpinned
  off-registry install; privilege escalation writing outside the repo.
- **Medium** — risky pattern gated by conditions unlikely in normal use;
  unpinned install from the public registry.
- **Low** — hygiene: hard-coded path that could leak context, noisy env dump.
- **Info** — observation, no exploit path under the reviewed scope.

Assign from the *demonstrated* impact + reachability, not the scariest
theoretical case. State the assumption behind each rating.
