"""Deterministic state-query for a change delta (task-0097).

Reports which delta artifacts exist, the recorded lane, and the next spine verb —
the fire-phoenix analogue of OpenSpec's ``openspec status`` / BMAD's artifact-
scanning router, moving "what's next" out of the LLM prompt into a queryable
surface. Read-only; stdlib-only leaf domain package (no fire_phoenix_cli imports).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

# Spine order of the change verbs that produce/consume delta artifacts.
_ARTIFACT_FOR_VERB = [
    ("intent", "intent.md"),
    ("design", "design.md"),
    ("tasks", "tasks.md"),
]


@dataclass
class ChangeStatus:
    change_id: str
    lane: str | None
    present: dict[str, bool] = field(default_factory=dict)
    baseline_capabilities: int = 0
    next_verb: str | None = None


def _count_capabilities(baseline_dir: Path) -> int:
    if not baseline_dir.is_dir():
        return 0
    # One file per capability; exclude the README head + the .conflicts/ dir.
    return sum(
        1 for p in baseline_dir.glob("*.md") if p.is_file() and p.name.lower() != "readme.md"
    )


def change_status(change_dir: Path, baseline_dir: Path) -> ChangeStatus:
    """Report the delta's artifact presence, lane, and the next spine verb."""
    present = {
        "intent.md": (change_dir / "intent.md").is_file(),
        "design.md": (change_dir / "design.md").is_file(),
        "tasks.md": (change_dir / "tasks.md").is_file(),
        "spec-delta.md": (change_dir / "spec-delta.md").is_file(),
    }
    lane_file = change_dir / "lane"
    lane = lane_file.read_text(encoding="utf-8").strip() or None if lane_file.is_file() else None

    # Next verb: the first spine artifact not yet present; else implement→verify→archive.
    next_verb: str | None = None
    for verb, artifact in _ARTIFACT_FOR_VERB:
        if not present[artifact]:
            next_verb = verb
            break
    if next_verb is None:
        next_verb = "implement"  # all planning artifacts present

    return ChangeStatus(
        change_id=change_dir.name,
        lane=lane,
        present=present,
        baseline_capabilities=_count_capabilities(baseline_dir),
        next_verb=next_verb,
    )
