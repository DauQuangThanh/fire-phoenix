"""Fold-on-archive core (adr/0049 migration stage 4, task-0095).

Folds a change's ``spec-delta.md`` into the living baseline, then moves the change
to the archive. Design decisions (Thanh, 2026-07-14):

- **One file per capability**: the baseline is a directory of ``<cap-id>.md`` files.
- **Last-fold-wins with a flagged conflict**: when the baseline state contradicts
  the delta's intent (add an existing cap / modify or remove an absent cap), the
  fold applies the delta anyway AND records a conflict for the approver.

Deterministic and **stdlib-only** — no LLM, no network, no fire_phoenix_cli layer
imports (leaf domain package per the module-boundary contract). The interactive
``change`` skill and (at stage 5) the headless engine both call ``fold_change``.
"""

from __future__ import annotations

import re
import shutil
from dataclasses import dataclass, field
from pathlib import Path

_SECTION_RE = re.compile(r"^##\s+(Added|Modified|Removed)\s*$", re.IGNORECASE)
# `- <cap-id>: <statement>` or `- <cap-id>`
_BULLET_RE = re.compile(r"^[-*]\s+(?P<cap>[A-Za-z0-9][\w.-]*)\s*(?::\s*(?P<stmt>.+?))?\s*$")


@dataclass
class FoldConflict:
    cap_id: str
    kind: str  # "add-exists" | "modify-absent" | "remove-absent"


@dataclass
class FoldResult:
    folded: list[str] = field(default_factory=list)
    conflicts: list[FoldConflict] = field(default_factory=list)
    archived_to: Path | None = None


def _parse_delta(text: str) -> dict[str, list[tuple[str, str]]]:
    """Parse a spec-delta into {section: [(cap_id, statement), ...]}."""
    sections: dict[str, list[tuple[str, str]]] = {"added": [], "modified": [], "removed": []}
    current: str | None = None
    for line in text.splitlines():
        m = _SECTION_RE.match(line.strip())
        if m:
            current = m.group(1).lower()
            continue
        if current is None:
            continue
        b = _BULLET_RE.match(line.strip())
        if b:
            sections[current].append((b.group("cap"), (b.group("stmt") or "").strip()))
    return sections


def _cap_file(baseline_dir: Path, cap_id: str) -> Path:
    return baseline_dir / f"{cap_id}.md"


def _write_capability(baseline_dir: Path, cap_id: str, statement: str) -> None:
    target = _cap_file(baseline_dir, cap_id)
    # An empty statement (a `- CAP-001` delta bullet with no `: stmt`) must not
    # erase an existing baseline body — preserve it. Header-only is written only
    # when the capability file does not yet exist (nothing to lose).
    if not statement and target.exists():
        return
    body = f"# {cap_id}\n\n{statement}\n" if statement else f"# {cap_id}\n"
    target.write_text(body, encoding="utf-8")


def _flag_conflict(baseline_dir: Path, conflict: FoldConflict) -> None:
    conflicts_dir = baseline_dir / ".conflicts"
    conflicts_dir.mkdir(parents=True, exist_ok=True)
    (conflicts_dir / f"{conflict.cap_id}.md").write_text(
        f"# Conflict — {conflict.cap_id}\n\n"
        f"Kind: `{conflict.kind}` (last-fold-wins was applied; approver must resolve).\n",
        encoding="utf-8",
    )


def fold_change(
    change_dir: Path,
    baseline_dir: Path,
    *,
    archive_root: Path,
    date: str,
) -> FoldResult:
    """Fold ``change_dir/spec-delta.md`` into ``baseline_dir`` and archive the change.

    Returns a :class:`FoldResult`. Never raises on a conflict — conflicts are
    recorded and last-fold-wins is applied (adr/0049 §9 model).
    """
    result = FoldResult()
    delta_file = change_dir / "spec-delta.md"
    delta = (
        _parse_delta(delta_file.read_text(encoding="utf-8"))
        if delta_file.is_file()
        else {
            "added": [],
            "modified": [],
            "removed": [],
        }
    )
    baseline_dir.mkdir(parents=True, exist_ok=True)

    for cap_id, stmt in delta["added"]:
        if _cap_file(baseline_dir, cap_id).exists():
            c = FoldConflict(cap_id, "add-exists")
            result.conflicts.append(c)
            _flag_conflict(baseline_dir, c)
        _write_capability(baseline_dir, cap_id, stmt)  # last-fold-wins
        result.folded.append(cap_id)

    for cap_id, stmt in delta["modified"]:
        if not _cap_file(baseline_dir, cap_id).exists():
            c = FoldConflict(cap_id, "modify-absent")
            result.conflicts.append(c)
            _flag_conflict(baseline_dir, c)
        _write_capability(baseline_dir, cap_id, stmt)  # last-fold-wins
        result.folded.append(cap_id)

    for cap_id, _stmt in delta["removed"]:
        target = _cap_file(baseline_dir, cap_id)
        if not target.exists():
            c = FoldConflict(cap_id, "remove-absent")
            result.conflicts.append(c)
            _flag_conflict(baseline_dir, c)
        else:
            target.unlink()
        result.folded.append(cap_id)

    # Archive the change (move the whole delta folder). Guard the destination:
    # `shutil.move` into an EXISTING directory nests the source inside it
    # (archive/<date>-<id>/<id>/…) instead of failing, silently mislocating the
    # delta while the caller still reports success (B10/task-0101). A collision
    # (same id re-archived on the same date) is an error, not a silent nest.
    archive_root.mkdir(parents=True, exist_ok=True)
    dest = archive_root / f"{date}-{change_dir.name}"
    if dest.exists():
        raise FileExistsError(
            f"archive destination already exists: {dest} — refusing to nest the delta"
        )
    shutil.move(str(change_dir), str(dest))
    result.archived_to = dest
    return result
