"""Change-delta domain: fold-on-archive (adr/0049 migration stage 4).

Stdlib-only by design — this is a leaf domain package with no fire_phoenix_cli
layer imports (see tests/test_module_boundaries.py).
"""

from .analyze import AnalyzeResult, Finding, analyze_change
from .fold import FoldConflict, FoldResult, fold_change
from .status import ChangeStatus, change_status

__all__ = [
    "AnalyzeResult",
    "ChangeStatus",
    "Finding",
    "FoldConflict",
    "FoldResult",
    "analyze_change",
    "change_status",
    "fold_change",
]
