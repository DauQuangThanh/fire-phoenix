"""Base classes for AI-assistant integrations.

Provides:
- ``IntegrationOption`` — declares a CLI option an integration accepts.
- ``IntegrationBase`` — abstract base every integration must implement.

The three concrete subclasses (``MarkdownIntegration``,
``TomlIntegration``, ``SkillsIntegration``) live in their own sibling
modules (``markdown_integration.py``, ``toml_integration.py``,
``skills_integration.py``) — import them directly from there. Shared
helpers (frontmatter manipulation, the bootstrap context-section
content, subprocess timeout handling) live in ``rendering.py``,
``bootstrap.py``, and ``dispatch.py`` respectively.
"""

from __future__ import annotations

import re
import shutil
from abc import ABC
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, Any

from ..fsutil import atomic_write_bytes
from .bootstrap import build_context_section as _build_context_section_impl
from .bootstrap import build_imports_header
from .dispatch import _kill_on_timeout
from .rendering import (
    _FRONTMATTER_RE,
    _ensure_mdc_frontmatter,
    _inject_frontmatter_field,
    _strip_frontmatter,
    _strip_frontmatter_field,
)
from .rendering import (
    process_template as _process_template_impl,
)

if TYPE_CHECKING:
    from .manifest import IntegrationManifest


# Matches a ``## Handoffs`` body section up to the next ``## `` heading or EOF.
# Shared by the core install path (IntegrationBase.gate_unsupported_sections)
# and the preset/extension registrar (skills/render.py) so both strip
# handoffs identically for providers that cannot use them (adr/0039).
HANDOFFS_SECTION_RE = re.compile(r"(?ms)^##\s+Handoffs\b.*?(?=^## |\Z)")


# ---------------------------------------------------------------------------
# IntegrationOption
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class IntegrationOption:
    """Declares an option that an integration accepts via ``--integration-options``.

    Attributes:
        name:      The flag name (e.g. ``"--commands-dir"``).
        is_flag:   ``True`` for boolean flags (``--skills``).
        required:  ``True`` if the option must be supplied.
        default:   Default value when not supplied (``None`` → no default).
        help:      One-line description shown in ``fire-phoenix integrate info``.
    """

    name: str
    is_flag: bool = False
    required: bool = False
    default: Any = None
    help: str = ""


# ---------------------------------------------------------------------------
# IntegrationBase — abstract base class
# ---------------------------------------------------------------------------


class IntegrationBase(ABC):  # noqa: B024
    """Abstract base class every integration must implement.

    Subclasses must set the following class-level attributes:

    * ``key``              — unique identifier, matches actual CLI tool name
    * ``config``           — dict compatible with ``AGENT_CONFIG`` entries
    * ``registrar_config`` — dict compatible with ``CommandRegistrar.AGENT_CONFIGS``

    And may optionally set:

    * ``context_file``     — path (relative to project root) of the agent
                             context/instructions file (e.g. ``"CLAUDE.md"``)
    """

    # -- Must be set by every subclass ------------------------------------

    key: str = ""
    """Unique integration key — should match the actual CLI tool name."""

    config: dict[str, Any] | None = None
    """Metadata dict matching the ``AGENT_CONFIG`` shape."""

    registrar_config: dict[str, Any] | None = None
    """Registration dict matching ``CommandRegistrar.AGENT_CONFIGS`` shape."""

    # -- Optional ---------------------------------------------------------

    context_file: str | None = None
    """Relative path to the agent context file (e.g. ``CLAUDE.md``)."""

    # -- Capability flags — set by each subclass ----------------------------

    supports_argument_hints: bool = False
    """Can surface metadata.argument-hint to the user via CLI or IDE UI."""

    supports_handoffs: bool = False
    """Can process ## Handoffs body section and expose suggested next actions."""

    supports_multi_context_files: bool = False
    """Writes multiple per-provider context files (most providers write one)."""

    subagent_char_limit: int | None = None
    """Soft char ceiling for an installed subagent prompt; ``None`` = no limit.

    When set, the installer warns (non-fatal) if a transformed subagent
    exceeds it. Only providers with a documented content cap set this
    (Codex). See ``specs/epic-subagent-per-ai-rendering.md`` AC-008.
    """

    # -- Markers for managed context section ------------------------------

    CONTEXT_MARKER_START = "<!-- Fire Phoenix START -->"
    CONTEXT_MARKER_END = "<!-- Fire Phoenix END -->"

    # -- Public API -------------------------------------------------------

    def gate_unsupported_sections(self, content: str) -> str:
        """Strip capability sections this provider cannot use (adr/0039 / PAR-04).

        Applied on every install path (each integration's ``setup()``), so a
        provider that does not support a capability never receives its content
        — closing the gap where the core install shipped ``## Handoffs``
        verbatim to non-supporting providers while only the preset/extension
        path gated it.

        Currently gates the ``## Handoffs`` body section for providers with
        ``supports_handoffs = False``. Argument-hint gating is intentionally
        omitted here: no shipped ``SKILL.md`` carries an ``argument-hint``
        frontmatter key, so there is nothing to strip on the core path (the
        registrar still gates it for preset/extension-authored commands).
        """
        if not self.supports_handoffs:
            gated = HANDOFFS_SECTION_RE.sub("", content).rstrip()
            content = gated + "\n" if gated else gated
        return content

    @classmethod
    def options(cls) -> list[IntegrationOption]:
        """Return options this integration accepts. Default: none."""
        return []

    def build_exec_args(
        self,
        prompt: str,
        *,
        model: str | None = None,
        output_json: bool = True,
    ) -> list[str] | None:
        """Build CLI arguments for non-interactive execution.

        Returns a list of command-line tokens that will execute *prompt*
        non-interactively using this integration's CLI tool, or ``None``
        if the integration does not support CLI dispatch.

        Subclasses for CLI-based integrations should override this.
        """
        return None

    def build_command_invocation(self, command_name: str, args: str = "") -> str:
        """Build the native slash-command invocation for a fire-phoenix command.

        The CLI tools discover and execute commands from installed files
        on disk.  Per ``adr/0003`` + ``task-0021`` §B: the invocation is
        always ``"/<stem>"`` (bare), matching the installed file's bare
        folder name on disk.  Same scheme for both markdown and skills
        integrations.

        *command_name* may be a full dotted name like
        ``"fire-phoenix.intent"`` or a bare stem like ``"intent"``.
        """
        stem = command_name
        if "." in stem:
            stem = stem.rsplit(".", 1)[-1]

        invocation = f"/{stem}"
        if args:
            invocation = f"{invocation} {args}"
        return invocation

    def unattended_permission_args(self) -> list[str]:
        """Extra CLI args that grant tool permissions for an *unattended* run.

        Default: none — an unattended run relies on ``FIRE_PHOENIX_AGENT_MODE=auto``
        alone (which suppresses the skill's clarifying questionnaire) but does
        not grant tool permissions, so a CLI that gates Bash/Write behind a
        prompt would still be unable to run its creation scripts headlessly.
        CLI integrations that support headless permission grants should override
        this — e.g. Claude Code returns ``["--permission-mode", "bypassPermissions"]``.
        Extension point for other CLIs (Codex, Gemini, …).
        """
        return []

    @staticmethod
    def _to_interactive_args(exec_args: list[str]) -> list[str]:
        """Strip headless/print flags so the agent attaches to the terminal.

        Removes ``-p``/``--print`` and the output-format selectors
        (``--output-format <v>``, ``--json``) that only make sense for a
        captured, non-interactive run. What remains launches the CLI attached
        to the TTY, so the user can approve tools and answer questions live.
        """
        out: list[str] = []
        skip_next = False
        for tok in exec_args:
            if skip_next:
                skip_next = False
                continue
            if tok in ("-p", "--print", "--json"):
                continue
            if tok == "--output-format":
                skip_next = True  # drop the flag AND its value
                continue
            out.append(tok)
        return out

    def dispatch_command(
        self,
        command_name: str,
        args: str = "",
        *,
        project_root: Path | None = None,
        model: str | None = None,
        timeout: int = 600,
        stream: bool = True,
        unattended: bool = False,
    ) -> dict[str, Any]:
        """Dispatch a fire-phoenix command through this integration's CLI.

        By default this builds a slash-command invocation with
        ``build_command_invocation()`` and passes that prompt to
        ``build_exec_args()`` to construct the CLI command line.
        Integrations with custom dispatch behavior can override
        ``build_command_invocation()``, ``build_exec_args()``, or
        ``dispatch_command()`` directly.

        Run mode (``unattended``):

        * ``False`` (default) — *interactive*: the agent is attached to the
          terminal (headless/print flags stripped) and ``FIRE_PHOENIX_AGENT_MODE``
          is set to ``interactive`` so the user approves tools and answers
          clarifications live. Output is never captured in this mode.
        * ``True`` — *unattended*: the agent runs headless with
          ``FIRE_PHOENIX_AGENT_MODE=auto`` and this integration's
          :meth:`unattended_permission_args` appended (tool permissions granted),
          so it proceeds on documented assumptions without prompting. ``stream``
          then chooses live output vs. captured.

        Returns a dict with ``exit_code``, ``stdout``, and ``stderr``.
        Raises ``NotImplementedError`` if the integration does not
        support CLI dispatch.
        """
        import os
        import subprocess

        interactive = not unattended
        prompt = self.build_command_invocation(command_name, args)
        # Interactive runs attach to the terminal, so request text (not JSONL);
        # headless streaming uses text too, headless-captured uses JSON.
        exec_args = self.build_exec_args(
            prompt, model=model, output_json=(not stream and not interactive)
        )

        if exec_args is None:
            msg = (
                f"Integration {self.key!r} does not support CLI dispatch. "
                f"Override build_exec_args() to enable it."
            )
            raise NotImplementedError(msg)

        if interactive:
            exec_args = self._to_interactive_args(exec_args)
        else:
            exec_args = exec_args + self.unattended_permission_args()

        # Signal the skill which mode it is in: interactive walks its clarifying
        # questionnaire; auto skips it and proceeds on documented assumptions.
        env = {**os.environ, "FIRE_PHOENIX_AGENT_MODE": "auto" if unattended else "interactive"}

        cwd = str(project_root) if project_root else None

        # Interactive must run attached to the terminal (no capture possible);
        # otherwise honour the stream flag.
        live = stream or interactive
        if live:
            try:
                proc = subprocess.Popen(exec_args, text=True, cwd=cwd, env=env)
                proc.wait(timeout=timeout)
            except subprocess.TimeoutExpired:
                return _kill_on_timeout(proc, command_name, timeout)
            except KeyboardInterrupt:
                proc.terminate()
                try:
                    proc.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    proc.kill()
                return {
                    "exit_code": 130,
                    "stdout": "",
                    "stderr": "Interrupted by user",
                }
            return {
                "exit_code": proc.returncode,
                "stdout": "",
                "stderr": "",
            }

        try:
            result = subprocess.run(
                exec_args,
                capture_output=True,
                text=True,
                cwd=cwd,
                timeout=timeout,
                env=env,
            )
        except subprocess.TimeoutExpired:
            import sys

            print(
                f"Command '{command_name}' timed out after {timeout}s",
                file=sys.stderr,
            )
            return {"exit_code": 124, "stdout": "", "stderr": ""}
        return {
            "exit_code": result.returncode,
            "stdout": result.stdout,
            "stderr": result.stderr,
        }

    # -- Primitives — building blocks for setup() -------------------------

    def shared_commands_dir(self) -> Path | None:
        """Return path to the ``assets/agent-skills/`` root."""
        from fire_phoenix_cli.skill_assets import agent_skills_root

        return agent_skills_root()

    def list_command_templates(self) -> list[Path]:
        """Return the per-skill command source files under ``assets/agent-skills/``."""
        from fire_phoenix_cli.skill_assets import list_skill_dirs, skill_command_file

        files: list[Path] = []
        for skill_dir in list_skill_dirs():
            cmd = skill_command_file(skill_dir)
            if cmd is not None:
                files.append(cmd)
        return files

    @staticmethod
    def command_base_name(src_file: Path) -> str:
        """Return the unprefixed short name for an ``assets/agent-skills/`` source file.

        Source layout: ``assets/agent-skills/fire-phoenix-<name>/SKILL.md``
        (agentskills.io spec — filename is always ``SKILL.md``). This
        helper returns ``<name>`` (e.g. ``plan``, ``intent``) derived from
        the **parent directory name**. The ``fire-phoenix-`` prefix is
        stripped because subclasses add their own.
        """
        return src_file.parent.name.removeprefix("fire-phoenix-")

    def command_filename(self, template_name: str) -> str:
        """Return the destination filename for a command template.

        Default: ``fire-phoenix.{template_name}.md``.  Subclasses override
        to change the extension or naming convention.
        """
        return f"fire-phoenix.{template_name}.md"

    def commands_dest(self, project_root: Path) -> Path:
        """Return the absolute path to the commands output directory."""
        if not self.config:
            raise ValueError(
                f"{type(self).__name__}.config is not set; integration "
                "subclasses must define a non-empty 'config' mapping."
            )
        folder = self.config.get("folder")
        if not folder:
            raise ValueError(f"{type(self).__name__}.config is missing required 'folder' entry.")
        subdir = self.config.get("skills_subdir", "commands")
        return project_root / folder / subdir

    def custom_agents_dest(self, project_root: Path) -> Path | None:
        """Absolute path where user-defined subagents install for this integration."""
        if not self.config:
            return None
        folder = self.config.get("folder")
        if not folder:
            return None
        if "agents_subdir" in self.config:
            subdir = self.config["agents_subdir"]
        else:
            subdir = "agents"
        if subdir is None:
            return None
        return project_root / folder / subdir

    def custom_agent_filename(self, src_name: str) -> str:
        """Return the destination filename for a bundled custom agent."""
        return src_name

    def transform_custom_agent_content(self, content: str) -> str:
        """Transform a bundled custom-agent file body for this integration."""
        return content

    # -- File operations — granular primitives for setup() ----------------

    @staticmethod
    def copy_command_to_directory(
        src: Path,
        dest_dir: Path,
        filename: str,
    ) -> Path:
        """Copy a command template to *dest_dir* with the given *filename*."""
        dest_dir.mkdir(parents=True, exist_ok=True)
        dst = dest_dir / filename
        shutil.copy2(src, dst)
        return dst

    @staticmethod
    def record_file_in_manifest(
        file_path: Path,
        project_root: Path,
        manifest: IntegrationManifest,
    ) -> None:
        """Hash *file_path* and record it in *manifest*."""
        rel = file_path.resolve().relative_to(project_root.resolve())
        manifest.record_existing(rel)

    @staticmethod
    def write_file_and_record(
        content: str,
        dest: Path,
        project_root: Path,
        manifest: IntegrationManifest,
    ) -> Path:
        """Write *content* to *dest*, hash it, and record in *manifest*."""
        dest.parent.mkdir(parents=True, exist_ok=True)
        normalized = content.replace("\r\n", "\n")
        # Atomic write of a user-owned context file (B9/task-0101).
        atomic_write_bytes(dest, normalized.encode("utf-8"))
        rel = dest.resolve().relative_to(project_root.resolve())
        manifest.record_existing(rel)
        return dest

    def integration_scripts_dir(self) -> Path | None:
        """Return path to this integration's bundled ``scripts/`` directory."""
        import inspect

        cls_file = inspect.getfile(type(self))
        scripts = Path(cls_file).resolve().parent / "scripts"
        return scripts if scripts.is_dir() else None

    def install_scripts(
        self,
        project_root: Path,
        manifest: IntegrationManifest,
    ) -> list[Path]:
        """Copy integration-specific scripts into the project."""
        scripts_src = self.integration_scripts_dir()
        if not scripts_src:
            return []

        created: list[Path] = []
        scripts_dest = project_root / ".fire-phoenix" / "integrations" / self.key / "scripts"
        scripts_dest.mkdir(parents=True, exist_ok=True)

        for src_script in sorted(scripts_src.iterdir()):
            if not src_script.is_file():
                continue
            dst_script = scripts_dest / src_script.name
            shutil.copy2(src_script, dst_script)
            if dst_script.suffix == ".sh":
                dst_script.chmod(dst_script.stat().st_mode | 0o111)
            self.record_file_in_manifest(dst_script, project_root, manifest)
            created.append(dst_script)

        return created

    # -- Agent context file management ------------------------------------

    @staticmethod
    def _ensure_mdc_frontmatter(content: str) -> str:
        """Ensure ``.mdc`` content has YAML frontmatter with ``alwaysApply: true``.

        Thin proxy to :func:`fire_phoenix_cli.integrations.rendering._ensure_mdc_frontmatter`.
        Kept as a static method so subclasses and external callers that
        reference ``IntegrationBase._ensure_mdc_frontmatter`` keep working.
        """
        return _ensure_mdc_frontmatter(content)

    @staticmethod
    def _build_context_section(plan_path: str = "", context_file_name: str = "CLAUDE.md") -> str:
        """Build the content for the managed section between markers.

        Thin proxy to :func:`fire_phoenix_cli.integrations.bootstrap.build_context_section`.
        The full content lives in ``bootstrap.py`` so the bootstrap text
        is discoverable by module name. ``context_file_name`` switches the
        top-of-section context-file references between Claude Code's
        ``@path`` import syntax (``CLAUDE.md``) and standard markdown
        reference links (``AGENTS.md``).
        """
        return _build_context_section_impl(plan_path, context_file_name)

    def _managed_block_anchor(self) -> str:
        """The managed prose's start anchor (``adr/0063`` + amendments).

        The trailing managed prose begins at its first non-empty line (today
        ``"## Safe handling of source changes"``), derived from the live
        template so it tracks content edits. Used to locate where the prose
        starts when stripping it out from the wrapped envelope, leaving the
        body above it intact.
        """
        for line in self._build_context_section().splitlines():
            if line.strip():
                return line
        return ""

    def _strip_managed_block(self, content: str, anchor: str | None = None) -> str:
        """Return *content* with every fire-phoenix managed element removed.

        The managed elements are the ``START``/``END`` envelope markers, the
        context-file imports header, and the managed prose block. What
        remains is the user / scaffold body, preserved verbatim. Handles the
        three on-disk arrangements (``adr/0063`` + its two amendments):

        - **Wrapped envelope** (current, 2nd amendment): ``START`` first, then
          imports header, then body, then managed prose, then ``END`` at EOF.
          The body is *inside* the markers but preserved — only the leading
          ``START``+imports and the trailing ``[anchor … END]`` prose are cut.
        - **END-only** (``adr/0063`` 1st amendment, ``v0.25``–``v0.27``): no
          ``START``; imports header at top, prose + ``END`` at EOF.
        - **Legacy two-marker** (``v0.24``): a compact ``START``…``END`` block
          at the top with the body *after* ``END`` (stripped as a region).

        *anchor* is the managed prose's first line (defaults to the live
        template's). Returns *content* unchanged when no managed element is
        found, or when the prose anchor cannot be located (never drops body).
        """
        start_marker = self.CONTEXT_MARKER_START
        end_marker = self.CONTEXT_MARKER_END
        anchor = anchor if anchor is not None else self._managed_block_anchor()
        is_mdc = bool(self.context_file) and self.context_file.endswith(".mdc")
        imports_header = (
            ""
            if is_mdc or not self.context_file
            else build_imports_header(self.context_file)
        )

        start_idx = content.find(start_marker)
        end_idx = content.find(end_marker, start_idx if start_idx != -1 else 0)

        def _consume_end(idx: int) -> int:
            end_of = idx + len(end_marker)
            if end_of < len(content) and content[end_of] == "\r":
                end_of += 1
            if end_of < len(content) and content[end_of] == "\n":
                end_of += 1
            return end_of

        # No END marker at all.
        if end_idx == -1:
            if start_idx != -1:
                # Corrupt start-only legacy: drop from START through EOF.
                return content[:start_idx]
            return content

        # Is END the last meaningful content? → wrapped envelope or END-only.
        if content[_consume_end(end_idx) :].strip() == "":
            # 1. Cut the trailing managed prose [anchor … END].
            cut = None
            if anchor:
                nl_marker = "\n" + anchor
                a = content.rfind(nl_marker, 0, end_idx)
                if a != -1:
                    cut = a + 1
                elif content.lstrip().startswith(anchor):
                    cut = content.find(anchor)
            if cut is None:
                if start_idx != -1:
                    # START present but the prose anchor is not locatable (a
                    # renamed managed-prose heading — the documented
                    # re-decision trigger — or a hand-built block): remove the
                    # whole [START … END] envelope.
                    return content[:start_idx] + content[_consume_end(end_idx) :]
                # END-only, no START — cannot locate the block start; leave
                # content intact rather than risk dropping user body.
                return content
            body = content[:cut]
            # 2. Remove the START marker line (file top for non-.mdc, or right
            #    after .mdc frontmatter — so search rather than assume line 0).
            si = body.find(start_marker)
            if si != -1:
                after = si + len(start_marker)
                if after < len(body) and body[after] == "\r":
                    after += 1
                if after < len(body) and body[after] == "\n":
                    after += 1
                body = body[:si] + body[after:]
            # 3. Remove the imports header if it leads the remaining body.
            if imports_header and body.lstrip().startswith(imports_header):
                ih = body.find(imports_header)
                body = body[:ih] + body[ih + len(imports_header) :]
            return body

        # END is not the last content → legacy two-marker, body AFTER END.
        if start_idx != -1 and end_idx > start_idx:
            return content[:start_idx] + content[_consume_end(end_idx) :]
        # END mid-file without START (unusual) — cut [anchor … END] in place.
        if anchor:
            nl_marker = "\n" + anchor
            a = content.rfind(nl_marker, 0, end_idx)
            if a != -1:
                return content[: a + 1] + content[_consume_end(end_idx) :]
            if content.startswith(anchor):
                return content[_consume_end(end_idx) :]
        return content

    def upsert_context_section(
        self,
        project_root: Path,
        plan_path: str = "",
    ) -> Path | None:
        """Create or update the managed section in the agent context file.

        Per ``adr/0063`` and its **2nd amendment** the produced layout is a
        whole-file envelope: ``<!-- Fire Phoenix START -->`` on the first
        line, then the context-file imports header, then the pre-existing /
        scaffold body, then the managed prose, then
        ``<!-- Fire Phoenix END -->`` as the final content. The body sits
        inside the markers but is PRESERVED across refreshes — only the
        leading ``START``+imports and the trailing managed prose are
        regenerated (see :meth:`_strip_managed_block`). Any prior managed
        block — this wrapped form, an ``adr/0063`` END-only block
        (``v0.25``–``v0.27``), a legacy ``v0.24`` two-marker block, or a
        pre-0063 block-at-top file — is normalised to the wrapped form. The
        write is idempotent: a second upsert is a byte-for-byte no-op.

        The ``.mdc`` (Cursor) exception: frontmatter must stay first and
        Cursor does not resolve ``@path`` / markdown-link imports
        (``adr/0059``), so ``.mdc`` gets no imports header — the ``START``
        envelope follows the frontmatter, and the read-both-context-files
        intent is carried by the managed prose.

        Returns the path to the context file, or ``None`` when
        ``context_file`` is not set.
        """
        if not self.context_file:
            return None

        ctx_path = project_root / self.context_file
        is_mdc = ctx_path.suffix == ".mdc"

        prose = self._build_context_section(plan_path, self.context_file)
        anchor = next((ln for ln in prose.splitlines() if ln.strip()), "")
        start = self.CONTEXT_MARKER_START
        end = self.CONTEXT_MARKER_END

        if ctx_path.exists():
            content = ctx_path.read_text(encoding="utf-8-sig")
        else:
            ctx_path.parent.mkdir(parents=True, exist_ok=True)
            content = ""

        if is_mdc:
            # Peel any leading YAML frontmatter so it stays first; the START
            # envelope follows it. Cursor gets no imports header (adr/0059).
            fm_match = re.match(r"^\s*---[ \t]*\r?\n.*?\r?\n---[ \t]*\r?\n?", content, re.DOTALL)
            frontmatter = fm_match.group(0) if fm_match else ""
            rest = content[len(frontmatter) :] if frontmatter else content
            body = self._strip_managed_block(rest, anchor).strip("\n")
            inner = "\n\n".join(p for p in (body, prose) if p)
            envelope = f"{start}\n{inner}\n{end}\n"
            # Normalise the frontmatter→START seam to exactly one blank line so
            # repeated upserts are byte-for-byte stable (matches the blank line
            # _ensure_mdc_frontmatter inserts when it prepends fresh frontmatter).
            if frontmatter:
                new_content = frontmatter.rstrip("\n") + "\n\n" + envelope
            else:
                new_content = envelope
            # Ensure frontmatter exists with alwaysApply: true (prepends when absent).
            new_content = _ensure_mdc_frontmatter(new_content)
        else:
            # Strip every existing managed element (envelope markers, imports
            # header, managed prose), leaving only the user / scaffold body;
            # old END-only and legacy two-marker files migrate here.
            body = self._strip_managed_block(content, anchor).strip("\n")
            imports_header = build_imports_header(self.context_file)
            # Whole-file envelope (adr/0063 2nd amendment):
            # START, imports header, body, managed prose, END.
            inner = "\n\n".join(p for p in (imports_header, body, prose) if p)
            new_content = f"{start}\n{inner}\n{end}\n"

        normalized = new_content.replace("\r\n", "\n").replace("\r", "\n")
        # Atomic write of the user-owned agent context file (B9/task-0101).
        atomic_write_bytes(ctx_path, normalized.encode("utf-8"))
        return ctx_path

    def remove_context_section(self, project_root: Path) -> bool:
        """Remove the managed section from the agent context file.

        Returns ``True`` if the section was found and removed.
        """
        if not self.context_file:
            return False

        ctx_path = project_root / self.context_file
        if not ctx_path.exists():
            return False

        content = ctx_path.read_text(encoding="utf-8-sig")

        # Strip the managed block (END-only, or a legacy two-marker block).
        # Returns content unchanged when no block is present.
        stripped = self._strip_managed_block(content, self._managed_block_anchor())
        if stripped == content:
            return False

        # Collapse a doubled blank line left where the block was removed, then
        # normalize line endings before comparisons.
        normalized = stripped.replace("\r\n", "\n").replace("\r", "\n")
        normalized = re.sub(r"\n[ \t]*\n[ \t]*\n+", "\n\n", normalized)

        # For .mdc files, treat Speckit-generated frontmatter-only content as empty
        if ctx_path.suffix == ".mdc":
            # Delete the file if only YAML frontmatter remains (no body content)
            frontmatter_only = re.match(r"^---\n.*?\n---\s*$", normalized, re.DOTALL)
            if not normalized.strip() or frontmatter_only:
                ctx_path.unlink()
                return True

        if not normalized.strip():
            ctx_path.unlink()
        else:
            # Atomic rewrite of the user-owned context file, consistent with
            # upsert_context_section (R-02/task-0110).
            atomic_write_bytes(ctx_path, normalized.encode("utf-8"))

        return True

    @staticmethod
    def process_template(
        content: str,
        agent_name: str,
        script_type: str,
        arg_placeholder: str = "$ARGUMENTS",
        context_file: str = "",
    ) -> str:
        """Process a raw command template into agent-ready content.

        Thin proxy to :func:`fire_phoenix_cli.integrations.rendering.process_template`.
        """
        return _process_template_impl(
            content,
            agent_name,
            script_type,
            arg_placeholder,
            context_file,
        )

    def setup(
        self,
        project_root: Path,
        manifest: IntegrationManifest,
        parsed_options: dict[str, Any] | None = None,
        **opts: Any,
    ) -> list[Path]:
        """Install integration command files into *project_root*.

        Copies raw templates without processing. Returns the list of
        files created. Integrations that need placeholder replacement
        should override ``setup()``.
        """
        templates = self.list_command_templates()
        if not templates:
            return []

        project_root_resolved = project_root.resolve()
        if manifest.project_root != project_root_resolved:
            raise ValueError(
                f"manifest.project_root ({manifest.project_root}) does not match "
                f"project_root ({project_root_resolved})"
            )

        dest = self.commands_dest(project_root).resolve()
        try:
            dest.relative_to(project_root_resolved)
        except ValueError as exc:
            raise ValueError(
                f"Integration destination {dest} escapes project root {project_root_resolved}"
            ) from exc

        created: list[Path] = []

        for src_file in templates:
            dst_name = self.command_filename(self.command_base_name(src_file))
            dst_file = self.copy_command_to_directory(src_file, dest, dst_name)
            self.record_file_in_manifest(dst_file, project_root, manifest)
            created.append(dst_file)

        # adr/0056: `setup()` no longer upserts the managed context section —
        # the caller owns that step. `init` runs a post-scaffold upsert phase
        # (so the scaffold writes the rich project-memory body first); the
        # standalone commands (install/upgrade/switch) call
        # `upsert_context_section` explicitly right after `setup()`.
        return created

    def teardown(
        self,
        project_root: Path,
        manifest: IntegrationManifest,
        *,
        force: bool = False,
    ) -> tuple[list[Path], list[Path]]:
        """Uninstall integration files from *project_root*.

        Only strip the managed context section when no OTHER still-installed
        integration shares this context file. The deliberate ``uninstall``
        command and ``switch`` Phase-1 guard this separately (B6/task-0101);
        the guard here additionally covers the error-rollback callers
        (``install`` / ``switch`` Phase-2 failure) and the high-level
        ``uninstall()`` convenience, so a failed install of one AGENTS.md
        provider can never delete the block a co-installed provider depends
        on (R-01/task-0110).
        """
        if not other_installed_share_context_file(project_root, self.key, self.context_file):
            self.remove_context_section(project_root)
        return manifest.uninstall(project_root, force=force)

    # -- Convenience helpers for subclasses -------------------------------

    # NOTE: there is deliberately no high-level ``install()`` convenience.
    # Post-adr/0056, ``setup()`` no longer upserts the managed context section
    # — the caller owns that step (init's post-scaffold phase; install/upgrade/
    # switch call ``upsert_context_section`` explicitly). A bare
    # ``install()`` alias for ``setup()`` would be a trap: any caller reaching
    # for it would silently get no context section (R-06/task-0111). Call
    # ``setup()`` then ``upsert_context_section()`` directly.

    def uninstall(
        self,
        project_root: Path,
        manifest: IntegrationManifest,
        *,
        force: bool = False,
    ) -> tuple[list[Path], list[Path]]:
        """High-level uninstall — calls ``teardown()``."""
        return self.teardown(project_root, manifest, force=force)


def other_installed_share_context_file(
    project_root: Path, key: str, context_file: str | None
) -> bool:
    """True if an installed integration OTHER than *key* uses the same context file.

    Four providers (Copilot/Codex/Kiro/OpenCode) share a single ``AGENTS.md`` with
    one managed section. Removing that block on any one provider's uninstall/switch
    would silently break the others still installed (B6/task-0101). The installed
    set is the manifests under ``.fire-phoenix/integrations/*.manifest.yml``.
    """
    if not context_file:
        return False
    manifests = project_root / ".fire-phoenix" / "integrations"
    if not manifests.is_dir():
        return False
    from . import get_integration

    for mf in manifests.glob("*.manifest.yml"):
        other_key = mf.name[: -len(".manifest.yml")]
        if other_key == key:
            continue
        impl = get_integration(other_key)
        if impl is not None and impl.context_file == context_file:
            return True
    return False


__all__ = [
    "IntegrationBase",
    "IntegrationOption",
    "other_installed_share_context_file",
    "_FRONTMATTER_RE",
    "_ensure_mdc_frontmatter",
    "_inject_frontmatter_field",
    "_kill_on_timeout",
    "_strip_frontmatter",
    "_strip_frontmatter_field",
]
