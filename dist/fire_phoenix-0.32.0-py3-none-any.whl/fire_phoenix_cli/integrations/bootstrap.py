"""Bootstrap context section for the managed AI-agent context file.

Every fire-phoenix-bootstrapped project ships the output of
``build_context_section()`` inside its ``CLAUDE.md`` / ``AGENTS.md`` as the
trailing managed prose of a whole-file envelope that opens with
``<!-- Fire Phoenix START -->`` and closes with ``<!-- Fire Phoenix END -->``
(adr/0063 2nd amendment). The exact
phrasing is load-bearing — tests assert that the literal phrase
``"read the current plan"`` appears verbatim, and provider integrations
rely on the same content shape across all 7 supported agents.

The function lives in its own module so that "what gets written into a
new project's agent context file" is discoverable by name rather than
buried inside the IntegrationBase class. ``IntegrationBase`` exposes it
as the ``_build_context_section`` static method for backward
compatibility with existing call sites.

The prose itself lives in the sibling package-data template
``templates/context-section.md.tmpl`` rather than inline string
literals, so editing the guidance is a Markdown edit, not a Python
string-concatenation edit. The template is ordinary package data
(shipped inside the wheel next to this module — the same trust boundary
as the code that used to hold the text), loaded via
``Path(__file__).parent`` to match the bundled-file idiom in
``_bundled_catalogs.py``. One sentinel carries the only per-call
dynamic bit in the prose — ``@@PLAN_POINTER@@`` (the optional trailing
plan path). Everything else is static prose.

Per ``adr/0063`` the context-file imports live outside this prose:
``build_imports_header`` renders them, and ``upsert_context_section``
places them just after the opening ``<!-- Fire Phoenix START -->``
marker (2nd amendment), above the preserved body, with this template's
prose trailing just before ``<!-- Fire Phoenix END -->``. The per-target
import syntax (``@path`` for CLAUDE.md, markdown reference links
otherwise — ``adr/0059``) is therefore owned by ``build_imports_header``,
not this template.
"""

from __future__ import annotations

from pathlib import Path

# Package-data template holding the static section prose. Resolved relative
# to this module so it works identically in a source checkout and inside the
# wheel (the template ships as package data under fire_phoenix_cli/, not as a
# core_pack asset, so it carries no separate integrity entry — same as the
# .py that used to hold this text).
_TEMPLATE_PATH = Path(__file__).parent / "templates" / "context-section.md.tmpl"


def build_imports_header(context_file_name: str = "CLAUDE.md") -> str:
    """Render the context-file imports that lead the agent context file.

    Per ``adr/0063`` (2nd amendment) these sit just after the opening
    ``<!-- Fire Phoenix START -->`` marker, above the preserved body, so
    the imports load before any rule prose while the managed prose trails
    just before ``<!-- Fire Phoenix END -->``.

    The syntax differs per target:

    - ``CLAUDE.md`` → the two ``@path`` file-import directives only (Claude
      Code's verified native force-import). The clickable markdown links are
      meant for the OTHER agents, so ``CLAUDE.md`` does not carry them
      (``adr/0059``, amended 2026-07-21).
    - Any other filename (``AGENTS.md``, ``GEMINI.md``, a Cursor ``.mdc``,
      or an unrecognised name) → the two markdown reference links
      ``[name](path)`` only. ``@path`` is Claude-Code-specific and inert
      elsewhere (Gemini CLI documents only ``@./``-prefixed ``.md`` imports;
      Cursor's ``.mdc`` ``@file`` attach is disputed), so those targets get
      just the universally-followable clickable link form (``adr/0059``).

    The non-Claude clickable links are the sole clickable links in a
    generated context file; every other path in the body is plain text. The
    managed prose also tells every agent to *read* both context files.
    """
    if context_file_name == "CLAUDE.md":
        return "@.fire-phoenix/context.yml\n@.fire-phoenix/user-context.yml"
    return (
        "[context.yml](.fire-phoenix/context.yml)\n"
        "[user-context.yml](.fire-phoenix/user-context.yml)"
    )


def build_context_section(plan_path: str = "", context_file_name: str = "CLAUDE.md") -> str:
    """Build the fire-phoenix mechanics prose for the managed marker block.

    *plan_path* is the project-relative path to the current plan
    (e.g. ``"specs/<feature>/plan.md"``).  When empty, the trailing
    plan-pointer paragraph omits the path.

    *context_file_name* is accepted for call-site compatibility but no
    longer affects the returned prose: per ``adr/0063`` the per-target
    context-file imports moved out of this block into
    :func:`build_imports_header` (rendered as a top-of-file header by
    ``upsert_context_section``). This function returns only the static
    mechanics prose that sits between the markers.

    The section instructs the AI agent to read ``.fire-phoenix/context.yml``
    at the start of every session (without printing its contents),
    then points to the current plan for additional context.  Tests
    assert that the phrase ``"read the current plan"`` appears
    verbatim, so callers may rely on the trailing plan-pointer
    remaining present.

    The static prose is loaded from the sibling template
    ``templates/context-section.md.tmpl``; only the ``@@PLAN_POINTER@@``
    dynamic bit is substituted here — see the module docstring.
    """
    # Trailing plan pointer: a newline + "at <path>." only when a plan path
    # is supplied. Empty otherwise, so no bare "\nat " line is emitted.
    plan_pointer = f"\nat {plan_path}." if plan_path else ""

    template = _TEMPLATE_PATH.read_text(encoding="utf-8")
    return template.replace("@@PLAN_POINTER@@", plan_pointer)
