"""opencode integration."""

from ..base import _inject_frontmatter_field, _strip_frontmatter_field
from ..markdown_integration import MarkdownIntegration


class OpencodeIntegration(MarkdownIntegration):
    key = "opencode"
    config = {
        "name": "opencode",
        "folder": ".opencode/",
        "skills_subdir": "skills",
        "install_url": "https://opencode.ai",
        "requires_cli": True,
    }
    registrar_config = {
        "dir": ".opencode/skills",
        "format": "markdown",
        "args": "$ARGUMENTS",
        "extension": ".md",
    }
    context_file = "AGENTS.md"

    supports_argument_hints = True
    supports_handoffs = False
    supports_multi_context_files = False

    def transform_custom_agent_content(self, content: str) -> str:
        """OpenCode: strip color + tools, inject mode: subagent.

        OpenCode's agent schema types ``tools`` as an object map
        (``{tool: bool}``) or ``undefined``. The Claude-format source
        ships ``tools: Read, Write, …`` as a comma-separated string, which
        OpenCode rejects at startup ("Expected object | undefined, got
        '…'"). Stripping the field lets the subagent inherit the global
        tool config and sidesteps OpenCode's now-deprecated ``tools`` map
        (it steers new configs toward ``permission``).
        """
        content = _strip_frontmatter_field(content, "color")
        content = _strip_frontmatter_field(content, "tools")
        return _inject_frontmatter_field(content, "mode", "subagent")
