"""``SkillsIntegration`` — providers that install commands as agent skills.

Uses the ``<name>/SKILL.md`` directory layout from the
agentskills.io spec. Source ``SKILL.md`` files ship verbatim — no
frontmatter rebuild, no body substitution.
"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING, Any

from .base import IntegrationBase

if TYPE_CHECKING:
    from .manifest import IntegrationManifest


class SkillsIntegration(IntegrationBase):
    """Concrete base for integrations that install commands as agent skills.

    Skills use the ``<name>/SKILL.md`` directory layout following
    the `agentskills.io <https://agentskills.io/specification>`_ spec.

    Subclasses set ``key``, ``config``, ``registrar_config`` (and
    optionally ``context_file``) like any integration.  They may also
    override ``options()`` to declare additional CLI flags (e.g.
    ``--skills``).

    ``setup()`` processes each shared command template into a
    ``<name>/SKILL.md`` file with skills-oriented frontmatter.
    """

    def build_exec_args(
        self,
        prompt: str,
        *,
        model: str | None = None,
        output_json: bool = True,
    ) -> list[str] | None:
        if not self.config or not self.config.get("requires_cli"):
            return None
        args = [self.key, "-p", prompt]
        if model:
            args.extend(["--model", model])
        if output_json:
            args.extend(["--output-format", "json"])
        return args

    def skills_dest(self, project_root: Path) -> Path:
        """Return the absolute path to the skills output directory.

        Derived from ``config["folder"]`` and the configured
        ``skills_subdir`` (defaults to ``"skills"``).

        Raises ``ValueError`` when ``config`` or ``folder`` is missing.
        """
        if not self.config:
            raise ValueError(f"{type(self).__name__}.config is not set.")
        folder = self.config.get("folder")
        if not folder:
            raise ValueError(f"{type(self).__name__}.config is missing required 'folder' entry.")
        subdir = self.config.get("skills_subdir", "skills")
        return project_root / folder / subdir

    def build_command_invocation(self, command_name: str, args: str = "") -> str:
        """Skills use ``/<stem>`` — bare name matching the installed skill folder.

        Per ``adr/0003-drop-fire-phoenix-skill-prefix.md`` and ``task-0021`` §B:
        the legacy ``/fire-phoenix-<stem>`` form was a render-layer miss from
        ``task-0007``'s asset-tree-only rename. Installed skills live at
        ``.<integration>/skills/<stem>/SKILL.md`` so the slash command IS
        ``/<stem>``.
        """
        stem = command_name
        if "." in stem:
            stem = stem.rsplit(".", 1)[-1]

        invocation = f"/{stem}"
        if args:
            invocation = f"{invocation} {args}"
        return invocation

    def post_process_skill_content(self, content: str) -> str:
        """Post-process a SKILL.md file's content after generation.

        Called by external skill generators (presets, extensions) to let
        the integration inject agent-specific frontmatter or body
        transformations.  The default implementation returns *content*
        unchanged.  Subclasses may override — see ``ClaudeIntegration``.
        """
        return content

    def setup(
        self,
        project_root: Path,
        manifest: IntegrationManifest,
        parsed_options: dict[str, Any] | None = None,
        **opts: Any,
    ) -> list[Path]:
        """Install command templates as agent skills.

        Creates ``<name>/SKILL.md`` for each shared command
        template.  Source SKILL.md files ship verbatim (per task-0005;
        no frontmatter rebuild) and each skill's ``scripts/``,
        ``templates/``, and ``references/`` are bundled alongside.
        """
        templates = self.list_command_templates()
        if not templates:
            return []

        project_root_resolved = project_root.resolve()
        if manifest.project_root != project_root_resolved:
            raise ValueError(
                f"manifest.project_root ({manifest.project_root}) does not match "
                f"project_root ({project_root_resolved})"
            )

        skills_dir = self.skills_dest(project_root).resolve()
        try:
            skills_dir.relative_to(project_root_resolved)
        except ValueError as exc:
            raise ValueError(
                f"Skills destination {skills_dir} escapes project root {project_root_resolved}"
            ) from exc

        created: list[Path] = []

        for src_file in templates:
            # Per agentskills.io spec, source SKILL.md is shipped verbatim —
            # no frontmatter rebuild, no body substitution. Source bundle IS
            # the canonical artefact. (task-0005 removed the prior transformer;
            # see contracts/task-0005-rename-skill-md-and-remove-transformer.md.)
            # The folder name IS the skill name (e.g. ``plan``).
            skill_name = src_file.parent.name
            skill_content = src_file.read_text(encoding="utf-8")
            # adr/0039 / PAR-04: strip capability sections this provider can't
            # use (e.g. ## Handoffs for copilot/kiro) on the core install path,
            # not only the preset/extension path. No-op for providers that
            # support the capability, preserving the verbatim SKILL.md.
            skill_content = self.gate_unsupported_sections(skill_content)

            # Write <name>/SKILL.md
            skill_dir = skills_dir / skill_name
            skill_file = skill_dir / "SKILL.md"
            dst = self.write_file_and_record(skill_content, skill_file, project_root, manifest)
            created.append(dst)

            # Bundle the scripts and templates this skill depends on
            # into the skill folder so it is fully self-contained.
            from fire_phoenix_cli.skill_assets import bundle_skill_assets

            created.extend(bundle_skill_assets(skill_dir, skill_name, project_root, manifest))

        # adr/0056: the caller owns the managed-section upsert (init's
        # post-scaffold phase / the standalone commands after setup()).

        return created
