"""Kiro IDE integration.

Kiro (kiro.dev) implements the open Agent Skills standard, so skills install as
``SKILL.md`` packages under ``.kiro/skills/<name>/`` — the same on-disk shape
Claude Code and Copilot use (hence :class:`SkillsIntegration`, not the flat
Markdown base). Custom subagents install to ``.kiro/agents/`` as Markdown files
with YAML frontmatter (``name``/``description``/``tools``/``model``), and project
context is read from ``AGENTS.md``. Frontmatter is preserved verbatim.

CLI dispatch is not supported — Kiro is IDE-driven, so ``requires_cli`` is False
and ``build_exec_args`` returns ``None`` (inherited).
"""

from __future__ import annotations

from ..base import IntegrationOption
from ..skills_integration import SkillsIntegration


class KiroIntegration(SkillsIntegration):
    """Integration for the Kiro IDE (open Agent Skills standard)."""

    # Capability matrix (O2) — explicit for every subclass, no implicit inheritance.
    supports_argument_hints = False
    supports_handoffs = False
    supports_multi_context_files = False

    key = "kiro"
    config = {
        "name": "Kiro",
        "folder": ".kiro/",
        "skills_subdir": "skills",
        "agents_subdir": "agents",
        "install_url": "https://kiro.dev",
        "requires_cli": False,
    }
    registrar_config = {
        "dir": ".kiro/skills",
        "format": "markdown",
        "args": "$ARGUMENTS",
        "extension": "/SKILL.md",
    }
    context_file = "AGENTS.md"

    @classmethod
    def options(cls) -> list[IntegrationOption]:
        return [
            IntegrationOption(
                "--skills",
                is_flag=True,
                default=True,
                help="Install as agent skills (default for Kiro)",
            ),
        ]

    # Kiro reads SKILL.md packages and frontmatter-carrying subagents verbatim,
    # so the default (identity) content transform is correct — nothing stripped.
