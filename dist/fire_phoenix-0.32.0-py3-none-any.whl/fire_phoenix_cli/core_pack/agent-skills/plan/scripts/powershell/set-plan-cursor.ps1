#!/usr/bin/env pwsh

# Set the current.plan cursor in .fire-phoenix/user-context.yml.
#
# Per adr/0030: current.* lives in the per-user file (gitignored), NOT
# the team-shared .fire-phoenix/context.yml. This script wraps the
# canonical Write-UserContextValue helper from common.ps1 so the AI
# has a turn-key invocation post-plan creation (task-0068).

param(
    [switch]$Auto,
    [switch]$DryRun,
    [string]$Answers,
    [switch]$Help,
    [Parameter(Position = 0)][string]$PlanPath
)

. "$PSScriptRoot/common.ps1"

if ($Help) {
    @"
Usage: set-plan-cursor.ps1 [-Auto] [-DryRun] [-Answers <file>] <PlanPath>

Set .fire-phoenix/user-context.yml's current.plan to <PlanPath>
(repo-root-relative). Bootstraps user-context.yml when absent.
"@ | Write-Output
    exit 0
}

if ([string]::IsNullOrEmpty($PlanPath)) {
    [Console]::Error.WriteLine("ERROR: set-plan-cursor.ps1 requires <PlanPath>")
    [Console]::Error.WriteLine("Run with -Help for usage.")
    exit 1
}

if ($Auto) { $env:FIRE_PHOENIX_AUTO = '1' }
if ($DryRun) { $env:FIRE_PHOENIX_DRY_RUN = '1' }
if ($Answers) { Import-FirePhoenixAnswers -Path $Answers }

$ctx = Read-Context

if ($env:FIRE_PHOENIX_DRY_RUN -eq '1') {
    Write-Output "DRY-RUN: would set current.plan=$PlanPath in $($ctx.REPO_ROOT)/.fire-phoenix/user-context.yml"
    exit 0
}

Write-UserContextValue -Key current.plan -Value $PlanPath
Write-Output "set current.plan=$PlanPath"
