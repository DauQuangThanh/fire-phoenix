#!/usr/bin/env bash

set -e

# Parse command line arguments
JSON_MODE=false
ARGS=()

for arg in "$@"; do
    case "$arg" in
        --json)
            JSON_MODE=true
            ;;
        --help|-h)
            echo "Usage: $0 [--json]"
            echo "  --json    Output results in JSON format"
            echo "  --help    Show this help message"
            exit 0
            ;;
        *)
            ARGS+=("$arg")
            ;;
    esac
done

# Get script directory and load common functions
SCRIPT_DIR="$(CDPATH="" cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/common.sh"

# IDD-canon prerequisite resolution (β₃ of adr/0023 Option E, task-0043).
read_context

REPO_ROOT="$FIRE_PHOENIX_REPO_ROOT"

# Intent gate (adr/0064): signal the caller to BOOTSTRAP intent (Option A)
# rather than hard-failing when no usable intent exists. exit 3 = needs-intent.
_fp_intent_missing=0
if [[ -z "${FIRE_PHOENIX_CURRENT_INTENT:-}" ]]; then
    _fp_intent_missing=1
elif [[ ! -f "$REPO_ROOT/$FIRE_PHOENIX_CURRENT_INTENT" ]]; then
    _fp_intent_missing=1
fi
if [[ "$_fp_intent_missing" -eq 1 ]]; then
    _fp_status="$(fire_phoenix_intent_status 2>/dev/null || echo absent-greenfield)"
    case "$_fp_status" in
        absent-brownfield|absent-greenfield)
            [[ "$_fp_status" == "absent-brownfield" ]] && _fp_verb="recover" || _fp_verb="intent"
            echo "FIRE_PHOENIX_BOOTSTRAP=${_fp_verb}"
            echo "INTENT_STATUS=${_fp_status}"
            {
                echo "No usable intent for this feature (${_fp_status}). Per adr/0064, bootstrap intent BEFORE planning:"
                echo "  - greenfield: run the 'intent' skill (interactive: confirm first; auto: proceed)."
                echo "  - brownfield: run 'recover-intent' (+ 'recover-spec' for the named module)."
                echo "Then re-run this step."
            } >&2
            exit 3
            ;;
        *)
            echo "ERROR: an intent exists on disk but current.intent is unset (INTENT_STATUS=${_fp_status})." >&2
            echo "Set current.intent (or re-run /intent) to select the feature before planning." >&2
            exit 1
            ;;
    esac
fi

FEATURE_INTENT="$REPO_ROOT/$FIRE_PHOENIX_CURRENT_INTENT"
FEATURE_DIR="$(dirname "$FEATURE_INTENT")"

IMPL_PLAN="${FIRE_PHOENIX_CURRENT_PLAN:+$REPO_ROOT/$FIRE_PHOENIX_CURRENT_PLAN}"
[[ -z "$IMPL_PLAN" ]] && IMPL_PLAN="$FEATURE_DIR/plan.md"
CURRENT_BRANCH="${FIRE_PHOENIX_CURRENT_BRANCH:-${FIRE_PHOENIX_CURRENT_FEATURE:-main}}"
if has_git; then HAS_GIT="true"; else HAS_GIT="false"; fi

# Ensure the feature directory exists
mkdir -p "$FEATURE_DIR"

# Copy plan template if it exists
TEMPLATE=$(resolve_template "plan-template" "$REPO_ROOT") || true
if [[ -n "$TEMPLATE" ]] && [[ -f "$TEMPLATE" ]]; then
    cp "$TEMPLATE" "$IMPL_PLAN"
    echo "Copied plan template to $IMPL_PLAN"
else
    echo "Warning: Plan template not found"
    # Create a basic plan file if template doesn't exist
    touch "$IMPL_PLAN"
fi

# Output results
if $JSON_MODE; then
    if has_jq; then
        jq -cn \
            --arg feature_spec "$FEATURE_INTENT" \
            --arg impl_plan "$IMPL_PLAN" \
            --arg intents_dir "$FEATURE_DIR" \
            --arg branch "$CURRENT_BRANCH" \
            --arg has_git "$HAS_GIT" \
            '{FEATURE_INTENT:$feature_spec,IMPL_PLAN:$impl_plan,INTENTS_DIR:$intents_dir,BRANCH:$branch,HAS_GIT:$has_git}'
    else
        printf '{"FEATURE_INTENT":"%s","IMPL_PLAN":"%s","INTENTS_DIR":"%s","BRANCH":"%s","HAS_GIT":"%s"}\n' \
            "$(json_escape "$FEATURE_INTENT")" "$(json_escape "$IMPL_PLAN")" "$(json_escape "$FEATURE_DIR")" "$(json_escape "$CURRENT_BRANCH")" "$(json_escape "$HAS_GIT")"
    fi
else
    echo "FEATURE_INTENT: $FEATURE_INTENT"
    echo "IMPL_PLAN: $IMPL_PLAN"
    echo "INTENTS_DIR: $FEATURE_DIR"
    echo "BRANCH: $CURRENT_BRANCH"
    echo "HAS_GIT: $HAS_GIT"
fi
