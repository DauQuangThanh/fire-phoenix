---
name: clarify-intent
description: Identifies underspecified areas in the current feature spec by asking
  up to 5 highly targeted clarification questions and encoding answers
  back into the spec. Use when a spec has gaps or ambiguities, before
  implementation starts, or when the team disagrees on scope.
license: MIT
compatibility: Designed for agentskills.io-compatible agents.
metadata:
  author: Dau Quang Thanh
  version: '1.0'
  requires: [intent]
  scripts:
    sh: scripts/bash/check-prerequisites.sh --json --paths-only
    ps: scripts/powershell/check-prerequisites.ps1 -Json -PathsOnly
---

## User Input

```text
$ARGUMENTS
```

You **MUST** consider the user input before proceeding (if not empty).

## Pre-Execution Checks

**Check for extension hooks (before clarification)**:

- If `.fire-phoenix/extensions.yml` does not exist in the project
  root, skip silently.
- If it exists, read `references/extension-hooks.md` §Pre-execution
  and apply the hook protocol there against the
  `hooks.before_clarify-specs` key before proceeding to the Outline.

## Outline

Goal: Detect and reduce ambiguity or missing decision points in the active feature specification and record the clarifications directly in the spec file.

Note: This clarification workflow is expected to run (and be completed) BEFORE invoking `/plan`. If the user explicitly states they are skipping clarification (e.g., exploratory spike), you may proceed, but must warn that downstream rework risk increases.

### Audience and tone (interactive mode)

**Register first — adapt to role level.** Before applying the beginner floor
below, resolve the reader's level from the merged `.fire-phoenix/context.yml`
+ `.fire-phoenix/user-context.yml` (`user-context.yml` wins): use
`preferences.tech_role_level` for technical work (`junior` → hand-hold, one
path; `mid` → ≥2 options with one-line trade-offs; `senior` → defer on
judgment, surface edge cases, be brief; `staff` → be terse, challenge
premises, skip obvious caveats) and `preferences.non_tech_role_level` for
stakeholder work (`non-technical` → outcomes not jargon; `familiar` → simple
jargon glossed; `fluent` → concepts without explanation; `technical` → full
vocabulary). An explicit in-session signal (e.g. "be terse", "skip the
explanation") overrides everything. The plain-English, one-question-at-a-time
floor below applies **only when the relevant level is unset**; never treat
role level as a gate. Full rule: `.fire-phoenix/references/subagents/register-resolution.md`.

If `FIRE_PHOENIX_AGENT_MODE=interactive` (the default), assume the user has
**no technical and no business-domain background**. The taxonomy in
step 2 is for your **internal** coverage map — never expose its
labels (NFR, observability, throughput, RBAC, idempotent, etc.) to
the user.

Before presenting any question in step 4, read
`references/interactive-style.md` (yes/no-first phrasing,
plain-English translations, recommendation duty, default handling).
Do not read it in auto mode.

When `FIRE_PHOENIX_AGENT_MODE=auto` (or `--auto`), skip the question loop
entirely: pick the recommended option for every Partial / Missing
category and log decisions to the business-analyst decision log.

Execution steps:

1. Run `{SCRIPT}` from repo root **once** (combined `--json --paths-only` mode / `-Json -PathsOnly`). Parse minimal JSON payload fields:
   - `FEATURE_DIR`
   - `FEATURE_SPEC`
   - (Optionally capture `IMPL_PLAN`, `TASKS` for future chained flows.)
   - If JSON parsing fails, abort and instruct user to re-run `/intent` to populate `{context.current.intent}` in `.fire-phoenix/context.yml`.
   - For single quotes in args like "I'm Groot", use escape syntax: e.g 'I'\''m Groot' (or double-quote if possible: "I'm Groot").

2. Load the current spec file. Perform a structured ambiguity & coverage scan using the taxonomy in `references/ambiguity-taxonomy.md` — read that file only now, once the spec is loaded (not if aborting because the spec is missing). For each category, mark status: Clear / Partial / Missing. Produce an internal coverage map used for prioritization (do not output raw map unless no questions will be asked).

   For each category with Partial or Missing status, add a candidate question opportunity unless:
   - Clarification would not materially change implementation or validation strategy
   - Information is better deferred to planning phase (note internally)

3. Generate (internally) a prioritized queue of candidate clarification questions (maximum 5). Do NOT output them all at once. Apply these constraints:
    - Maximum of 5 total questions across the whole session.
    - Each question must be answerable with EITHER:
       - A short multiple‑choice selection (2–5 distinct, mutually exclusive options), OR
       - A one-word / short‑phrase answer (explicitly constrain: "Answer in <=5 words").
    - Only include questions whose answers materially impact architecture, data modeling, task decomposition, test design, UX behavior, operational readiness, or compliance validation.
    - Ensure category coverage balance: attempt to cover the highest impact unresolved categories first; avoid asking two low-impact questions when a single high-impact area (e.g., security posture) is unresolved.
    - Exclude questions already answered, trivial stylistic preferences, or plan-level execution details (unless blocking correctness).
    - Favor clarifications that reduce downstream rework risk or prevent misaligned acceptance tests.
    - If more than 5 categories remain unresolved, select the top 5 by (Impact * Uncertainty) heuristic.

4. Sequential questioning loop (interactive):
    - Present EXACTLY ONE question at a time.
    - **Always rewrite the question in plain everyday language before showing it.** Never expose taxonomy labels (NFR, observability, scalability, throughput, idempotent, RBAC, PII, eventual consistency) to the user. Translate the underlying concept into a concrete everyday situation with an example — worked translations are in `references/interactive-style.md` (already read above).
    - Before presenting a multiple-choice or short-answer question,
      read `references/question-formats.md` and render it in the
      format defined there (recommended-option header, options
      table with plain-consequence descriptions, reply
      instructions). Skip that file in auto mode — no questions are
      presented.
    - After the user answers:
       - If the user replies with "yes", "recommended", or "suggested", use your previously stated recommendation/suggestion as the answer.
       - If the user replies with "not sure" or "skip", apply the recommendation/suggestion as a default, mark the resulting spec entry as "(default applied — confirm later)", and continue without blocking.
       - Otherwise, validate the answer maps to one option or fits the <=5 word constraint.
       - If ambiguous, ask for a quick disambiguation in plain words (count still belongs to same question; do not advance).
       - Once satisfactory, record it in working memory (do not yet write to disk) and move to the next queued question.
    - Stop asking further questions when:
       - All critical ambiguities resolved early (remaining queued items become unnecessary), OR
       - User signals completion ("done", "good", "no more", "that's enough"), OR
       - You reach 5 asked questions.
    - Never reveal future queued questions in advance.
    - If no valid questions exist at start, immediately report no critical ambiguities.

5. Integration after EACH accepted answer (incremental update approach):
    - Maintain in-memory representation of the spec (loaded once at start) plus the raw file contents.
    - For the first integrated answer in this session:
       - Ensure a `## Clarifications` section exists (create it just after the highest-level contextual/overview section per the spec template if missing).
       - Under it, create (if not present) a `### Session YYYY-MM-DD` subheading for today.
    - Append a bullet line immediately after acceptance: `- Q: <question> → A: <final answer>`.
    - Then immediately apply the clarification to the most appropriate section(s):
       - Functional ambiguity → Update or add a bullet in Functional Requirements.
       - User interaction / actor distinction → Update User Stories or Actors subsection (if present) with clarified role, constraint, or scenario.
       - Data shape / entities → Update Data Model (add fields, types, relationships) preserving ordering; note added constraints succinctly.
       - Non-functional constraint → Add/modify measurable criteria in Success Criteria > Measurable Outcomes (convert vague adjective to metric or explicit target).
       - Edge case / negative flow → Add a new bullet under Edge Cases / Error Handling (or create such subsection if template provides placeholder for it).
       - Terminology conflict → Normalize term across spec; retain original only if necessary by adding `(formerly referred to as "X")` once.
    - If the clarification invalidates an earlier ambiguous statement, replace that statement instead of duplicating; leave no obsolete contradictory text.
    - Save the spec file AFTER each integration to minimize risk of context loss (atomic overwrite).
    - Preserve formatting: do not reorder unrelated sections; keep heading hierarchy intact.
    - Keep each inserted clarification minimal and testable (avoid narrative drift).

6. Validation (performed after EACH write plus final pass):
   - Clarifications session contains exactly one bullet per accepted answer (no duplicates).
   - Total asked (accepted) questions ≤ 5.
   - Updated sections contain no lingering vague placeholders the new answer was meant to resolve.
   - No contradictory earlier statement remains (scan for now-invalid alternative choices removed).
   - Markdown structure valid; only allowed new headings: `## Clarifications`, `### Session YYYY-MM-DD`.
   - Terminology consistency: same canonical term used across all updated sections.

7. Write the updated spec back to `FEATURE_SPEC`.

8. Report completion (after questioning loop ends or early termination):
   - Number of questions asked & answered.
   - Path to updated spec.
   - Sections touched (list names).
   - Coverage summary table listing each taxonomy category with Status: Resolved (was Partial/Missing and addressed), Deferred (exceeds question quota or better suited for planning), Clear (already sufficient), Outstanding (still Partial/Missing but low impact).
   - If any Outstanding or Deferred remain, recommend whether to proceed to `/plan` or run `/clarify-specs` again later post-plan.
   - Suggested next command.

Behavior rules:

- If no meaningful ambiguities found (or all potential questions would be low-impact), respond: "No critical ambiguities detected worth formal clarification." and suggest proceeding.
- If spec file missing, instruct user to run `/intent` first (do not create a new spec here).
- Never exceed 5 total asked questions (clarification retries for a single question do not count as new questions).
- Avoid speculative tech stack questions unless the absence blocks functional clarity.
- Respect user early termination signals ("stop", "done", "proceed").
- If no questions asked due to full coverage, output a compact coverage summary (all categories Clear) then suggest advancing.
- If quota reached with unresolved high-impact categories remaining, explicitly flag them under Deferred with rationale.

Context for prioritization: $ARGUMENTS

## Post-Execution Checks

**Check for extension hooks (after clarification)**:

- If `.fire-phoenix/extensions.yml` does not exist in the project
  root, skip silently.
- If it exists, read `references/extension-hooks.md`
  §Post-completion and apply the hook protocol there against the
  `hooks.after_clarify-specs` key.

## Inputs

- **Feature Specification** (`{context.current.intent}`)
  - If set: Read the specification file.
  - If null: Search {context.paths.intents} for the most recent intent.md.
  - If not provided (intent gate, adr/0064): clarify-intent operates on an existing intent, so when none exists, bootstrap it first (Option A) rather than only advising — in interactive mode confirm "No intent found — start by developing it?" then run the `intent` skill (greenfield) or `recover-intent`/`recover-spec` (brownfield); in auto mode run it and continue. Do not clarify a non-existent intent.

## Outputs

- **Updated Specification** (`{context.current.intent}`)
  - Behavior: Update the spec file in-place with clarifications. Ask before overwriting if confirm_before_write is true.
  - Overwrite guarded by `{context.preferences.confirm_before_write}`.

## Context Update

This skill does NOT modify `.fire-phoenix/context.yml` or `.fire-phoenix/user-context.yml` (clarifications are in-spec updates only).

## Handoffs

- **Build Technical Plan**: run `/plan` to continue the workflow.
