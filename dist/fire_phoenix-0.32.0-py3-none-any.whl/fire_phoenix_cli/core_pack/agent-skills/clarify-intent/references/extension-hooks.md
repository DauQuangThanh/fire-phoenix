# Extension-hook protocol for `/clarify-intent`

> Read this only when `.fire-phoenix/extensions.yml` exists in the
> project root. Extracted per `adr/0034` — canonical text, not a copy.

## Pre-execution (`hooks.before_clarify-specs`)

- Read `.fire-phoenix/extensions.yml` and look for entries under the
  `hooks.before_clarify-specs` key.
- If the YAML cannot be parsed or is invalid, skip hook checking
  silently and continue normally.
- Filter out hooks where `enabled` is explicitly `false`. Treat hooks
  without an `enabled` field as enabled by default.
- For each remaining hook, do **not** attempt to interpret or evaluate
  hook `condition` expressions:
  - If the hook has no `condition` field, or it is null/empty, treat
    the hook as executable.
  - If the hook defines a non-empty `condition`, skip the hook and
    leave condition evaluation to the HookExecutor implementation.
- For each executable hook, output the following based on its
  `optional` flag:
  - **Optional hook** (`optional: true`):

    ```text
    ## Extension Hooks

    **Optional Pre-Hook**: {extension}
    Command: `/{command}`
    Description: {description}

    Prompt: {prompt}
    To execute: `/{command}`
    ```

  - **Mandatory hook** (`optional: false`):

    ```text
    ## Extension Hooks

    **Automatic Pre-Hook**: {extension}
    Executing: `/{command}`
    EXECUTE_COMMAND: {command}

    Wait for the result of the hook command before proceeding to the Outline.
    ```

- If no hooks are registered, skip silently.

## Post-completion (`hooks.after_clarify-specs`)

Same protocol as above against the `hooks.after_clarify-specs` key,
with these output blocks:

- **Optional hook** (`optional: true`):

  ```text
  ## Extension Hooks

  **Optional Hook**: {extension}
  Command: `/{command}`
  Description: {description}

  Prompt: {prompt}
  To execute: `/{command}`
  ```

- **Mandatory hook** (`optional: false`):

  ```text
  ## Extension Hooks

  **Automatic Hook**: {extension}
  Executing: `/{command}`
  EXECUTE_COMMAND: {command}
  ```

- If no hooks are registered, skip silently.
