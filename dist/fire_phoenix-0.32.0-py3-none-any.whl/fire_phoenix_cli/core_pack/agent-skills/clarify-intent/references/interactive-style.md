# `/clarify-intent` interactive-mode style rules

> Read this only in interactive mode
> (`FIRE_PHOENIX_AGENT_MODE=interactive`), before presenting any
> question in the sequential questioning loop. Do not read it in auto
> mode. Extracted per `adr/0034` — canonical text, not a copy.

When you present a question in step 4:

- **Yes / no first.** Phrase so `yes`, `no`, `not sure`, or `skip`
  is a valid answer.
- **Plain English only.** Translate every technical concept into
  everyday words with concrete examples. "How fast should it feel
  when a user clicks?" not "What's the latency target?".
  "Should each user only see their own things?" not "Is this
  multi-tenant with row-level isolation?". "Are there rules about
  the personal info you collect — for example medical or children's
  data?" not "Is this PII subject to GDPR / HIPAA?".
- **Always recommend.** State the option you would pick and why in
  one sentence so the user can reply "yes" / "ok" to accept it.
- **Choices, not blank fields.** When yes/no isn't enough, offer
  2-4 lettered options (A/B/C/D) with one-line everyday
  descriptions. Always include "Not sure — use the recommended
  default".
- **Treat `not sure` / `skip` as a default-trigger.** Apply the
  recommended default, integrate it into the spec marked
  "(default applied — confirm later)", and continue. Do not block.
