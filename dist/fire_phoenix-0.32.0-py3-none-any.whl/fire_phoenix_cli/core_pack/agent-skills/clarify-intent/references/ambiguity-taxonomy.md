# Ambiguity & coverage-scan taxonomy for `/clarify-intent`

> Read this only when performing the structured ambiguity & coverage
> scan of the loaded spec (Outline step 2), not before. The category
> labels are for your internal coverage map — never expose them to
> the user. Extracted per `adr/0034` — canonical text, not a copy.

Functional Scope & Behavior:

- Core user goals & success criteria
- Explicit out-of-scope declarations
- User roles / personas differentiation

Domain & Data Model:

- Entities, attributes, relationships
- Identity & uniqueness rules
- Lifecycle/state transitions
- Data volume / scale assumptions

Interaction & UX Flow:

- Critical user journeys / sequences
- Error/empty/loading states
- Accessibility or localization notes

Non-Functional Quality Attributes:

- Performance (latency, throughput targets)
- Scalability (horizontal/vertical, limits)
- Reliability & availability (uptime, recovery expectations)
- Observability (logging, metrics, tracing signals)
- Security & privacy (authN/Z, data protection, threat assumptions)
- Compliance / regulatory constraints (if any)

Integration & External Dependencies:

- External services/APIs and failure modes
- Data import/export formats
- Protocol/versioning assumptions

Edge Cases & Failure Handling:

- Negative scenarios
- Rate limiting / throttling
- Conflict resolution (e.g., concurrent edits)

Constraints & Tradeoffs:

- Technical constraints (language, storage, hosting)
- Explicit tradeoffs or rejected alternatives

Terminology & Consistency:

- Canonical glossary terms
- Avoided synonyms / deprecated terms

Completion Signals:

- Acceptance criteria testability
- Measurable Definition of Done style indicators

Misc / Placeholders:

- TODO markers / unresolved decisions
- Ambiguous adjectives ("robust", "intuitive") lacking quantification
