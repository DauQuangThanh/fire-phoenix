---
name: bug-triage
description: Triages open bugs into fix-now / next-sprint / defer / won't-fix
  buckets from severity + priority + age + business cost. Produces
  a dated triage list the bug-fixer / PO can act on. Use when
  prioritising a bug backlog, deciding what to fix next, or preparing
  for a bug-fix sprint.
license: MIT
compatibility: Designed for agentskills.io-compatible agents.
metadata:
  author: Dau Quang Thanh
  version: '1.0'
  requires: []
---

## User Input

```text
$ARGUMENTS
```

## Audience and tone (interactive mode)

**Register first — adapt to role level.** Before applying the beginner floor
below, resolve the reader's level from the merged `.fire-phoenix/context.yml`
+ `.fire-phoenix/user-context.yml` (`user-context.yml` wins): use
`preferences.tech_role_level` for technical work (`junior` → hand-hold, one
path; `mid` → ≥2 options with one-line trade-offs; `senior` → defer on
judgment, surface edge cases, be brief; `staff` → be terse, challenge
premises, skip obvious caveats) and `preferences.non_tech_role_level` for
stakeholder work (`non-technical` → outcomes not jargon; `familiar` → simple
jargon glossed; `fluent` → concepts without explanation; `technical` → full
vocabulary). An explicit in-session signal (e.g. "be terse", "skip the
explanation") overrides everything. The plain-English, one-question-at-a-time
floor below applies **only when the relevant level is unset**; never treat
role level as a gate. Full rule: `.fire-phoenix/references/subagents/register-resolution.md`.

When `FIRE_PHOENIX_AGENT_MODE=interactive` (the default), assume the user
has **limited technical background and limited domain knowledge**
— they may know basics but lack deep expertise in this skill's
area. Run this skill as a guided questionnaire:

- **One question at a time.** No walls of questions.
- **Yes / no first.** Phrase so `yes`, `no`, `not sure`, or `skip`
  is a valid answer.
- **Translate jargon, don't strip it.** Use the technical term but
  always pair it with a plain-English gloss the first time it
  appears.
- **Choices, not blank fields.** When yes/no isn't enough, offer
  2-4 lettered options (A/B/C/D) with one-line plain-language
  descriptions of the trade-off. Always include "Not sure — pick
  a sensible default".
- **Always recommend.** State the option you would pick and why in
  one sentence so the user can reply "yes" / "ok" to accept. Pull
  defaults from upstream artefacts (spec, architecture, ADRs,
  standards) before asking blank.
- **Show, don't ask.** When upstream artefacts already imply an
  answer, propose it as a pre-filled finding and ask for a
  yes / no confirmation rather than asking the user to fill in a
  blank.
- **`not sure` / `skip` triggers a sensible default**, marked
  "(default applied — confirm later)" in the artefact, and a debt
  entry in this skill's debt file.

When `FIRE_PHOENIX_AGENT_MODE=auto` (or `--auto`), skip the questionnaire
entirely: apply sensible defaults from upstream artefacts and log
decisions to the parent agent's decision log.

## Inputs

- `.fire-phoenix/context.yml`
- `{context.paths.docs}/bugs/BUG-*.md`
- `{context.paths.docs}/bugs/change-register.md` (closed bugs)

## Outputs

- `{context.paths.docs}/bugs/triage.md` — overwrites per run
- `{context.paths.docs}/bugs/triage.extract`

## Context Update

Does not mutate `.fire-phoenix/context.yml`.

## Handoffs

- `regression-tests` produces tests for bugs marked fix-now.
- `change-log` records each fix as the bug-fixer closes.
- The PO / business-analyst owns the class-(b) intent decision
  (see below); triage flags (b) bugs as blocked-on-intent until
  that decision is recorded.

## AI authoring scope

**Does:** read open bug files, group by bucket (per
`references/triage-rubric.md` — ordered rules, severity ×
frequency matrix), assign each bug its three-way class (per the
rubric's classification section) with reproduction +
classification evidence, fill the root-cause-known? and AC-linked?
columns, propose an order, call out stale bugs (open > 30 days)
and aging fix-now bugs per the rubric's escalation guideline.

**Does not:** close bugs, reassign, decide won't-fix without
the user, or make the class-(b) intent call — whether an
undocumented "keep" behaviour may change is a human (PO / BA)
decision, and it comes before any fix is scheduled.

## Three-way classification (routing)

Buckets decide *when*; the class decides *how the fix is framed*:

- **(a) violates stated intent** — the fix's task contract cites
  the violated invariant / AC-NNN.
- **(b) undocumented behaviour previously classified "keep"** —
  intent decision FIRST; the fix may in fact be a spec change,
  and behaviour someone depends on is never changed silently.
  **The (b) call is human-owned** (PO / BA); the skill drafts the
  evidence, never the decision.
- **(c) regression against an AC** — regression test first (it
  must fail on the current code), then the fix.

Full definitions live in `references/triage-rubric.md`.

## Usage

> `<SKILL_DIR>` = the integration's skills root (e.g. `.claude/skills/`
> for Claude Code, `.codex/skills/` for Codex,
> `.cursor/skills/` for Cursor, `.kiro/skills/` for Kiro).
> Scripts live at `<SKILL_DIR>/<skill-name>/scripts/…`.

```bash
bash <SKILL_DIR>/bug-triage/scripts/bash/triage.sh --auto
```

### Answer keys

| Key | Meaning | Default |
|---|---|---|
| `BT_STALE_DAYS` | threshold (days) above which a bug is "stale" | `30` |
