---
name: development-design
description: Drafts detailed module / API / data-model / integration design for the active feature under docs/design/<feature>/, from the architecture intake + ADRs + spec. Does not commit to timelines. Use when designing implementation, planning module structure, or before coding starts.
license: MIT
compatibility: Designed for agentskills.io-compatible agents.
metadata:
  author: Dau Quang Thanh
  version: '1.0'
  requires: []
---

## User Input

```text
$ARGUMENTS
```

## Audience and tone (interactive mode)

**Register first — adapt to role level.** Before applying the beginner floor
below, resolve the reader's level from the merged `.fire-phoenix/context.yml`
+ `.fire-phoenix/user-context.yml` (`user-context.yml` wins): use
`preferences.tech_role_level` for technical work (`junior` → hand-hold, one
path; `mid` → ≥2 options with one-line trade-offs; `senior` → defer on
judgment, surface edge cases, be brief; `staff` → be terse, challenge
premises, skip obvious caveats) and `preferences.non_tech_role_level` for
stakeholder work (`non-technical` → outcomes not jargon; `familiar` → simple
jargon glossed; `fluent` → concepts without explanation; `technical` → full
vocabulary). An explicit in-session signal (e.g. "be terse", "skip the
explanation") overrides everything. The plain-English, one-question-at-a-time
floor below applies **only when the relevant level is unset**; never treat
role level as a gate. Full rule: `.fire-phoenix/references/subagents/register-resolution.md`.

When `FIRE_PHOENIX_AGENT_MODE=interactive` (the default), assume the user
has **limited technical background and limited domain knowledge**
— they may know basics but lack deep expertise in this skill's
area. Run this skill as a guided questionnaire:

- **One question at a time.** No walls of questions.
- **Yes / no first.** Phrase so `yes`, `no`, `not sure`, or `skip`
  is a valid answer.
- **Translate jargon, don't strip it.** Use the technical term but
  always pair it with a plain-English gloss the first time it
  appears.
- **Choices, not blank fields.** When yes/no isn't enough, offer
  2-4 lettered options (A/B/C/D) with one-line plain-language
  descriptions of the trade-off. Always include "Not sure — pick
  a sensible default".
- **Always recommend.** State the option you would pick and why in
  one sentence so the user can reply "yes" / "ok" to accept. Pull
  defaults from upstream artefacts (spec, architecture, ADRs,
  standards) before asking blank.
- **Show, don't ask.** When upstream artefacts already imply an
  answer, propose it as a pre-filled finding and ask for a
  yes / no confirmation rather than asking the user to fill in a
  blank.
- **`not sure` / `skip` triggers a sensible default**, marked
  "(default applied — confirm later)" in the artefact, and a debt
  entry in this skill's debt file.

When `FIRE_PHOENIX_AGENT_MODE=auto` (or `--auto`), skip the questionnaire
entirely: apply sensible defaults from upstream artefacts and log
decisions to the parent agent's decision log.

## Inputs

- `.fire-phoenix/context.yml`
- `{context.paths.intents}/<feature>/intent.md`
- `{context.paths.docs}/architecture/intake.md`
- `{context.paths.docs}/architecture/c4-container.md`
- `{context.governance.adr_dir}/NNNN-*.md` (authored via the `adr-author` draft → `promote-governance` path, adr/0053)
- `{context.paths.plans}/<feature>/plan.md` (if `plan` run)

## Outputs

- `{context.paths.docs}/design/<feature>/design.md`
- `{context.paths.docs}/design/<feature>/api-contract.md` (optional)
- `{context.paths.docs}/design/<feature>/data-model.md` (optional)

## Context Update

Does not mutate `.fire-phoenix/context.yml`.

## Handoffs

- `unit-tests` generates test skeletons from the design's
  module boundaries.
- `implement` uses the design as the reference for tasks.
- `test-cases` aligns feature-level tests to the API contract.

## AI authoring scope

**Does:** sketch module structure (hexagonal / onion / MVC as
appropriate), draft API contract (endpoint list + schemas), draft
data-model (tables / collections + relationships), call out
cross-cutting concerns (auth, logging, tracing, feature flags).

**Does not:** commit to an implementation schedule, choose a
library the ADRs haven't covered, assume a pattern the user hasn't
confirmed.

## Design flow

Contract-first: interfaces and error shapes are designed before
any implementation detail, so `unit-tests` skeletons and the
tester's cases can be derived from the contract rather than from
the code.

1. **Restate the ACs.** List the AC-NNN ids (and the intent's
   failure conditions) this design must serve. A design that
   serves no AC is out of scope; an AC no design section serves
   is a gap.
2. **Interfaces before internals.** Draft the public surface
   first: module entry points, API endpoints + schemas, and the
   **error shapes** (status codes, structured error bodies) as
   part of the contract.
3. **Module structure.** Fill the module blocks: responsibility,
   entry points, collaborators, error handling.
4. **Data model.** Entities, relationships, invariants — and who
   enforces each invariant.
5. **Error-handling pass.** Walk
   `references/error-handling-checklist.md`: every failure
   condition from the intent gets a designed response (message,
   retry / backoff decision, no silent swallow).
6. **AC citation check.** Fill the design's AC coverage table:
   every AC-NNN maps to the design section that serves it. A
   design section serving no AC raises a scope question; an AC
   with no section goes back to step 2 — or to the
   business-analyst if the criterion itself is the gap.

## Usage

> `<SKILL_DIR>` = the integration's skills root (e.g. `.claude/skills/`
> for Claude Code, `.codex/skills/` for Codex,
> `.cursor/skills/` for Cursor, `.kiro/skills/` for Kiro).
> Scripts live at `<SKILL_DIR>/<skill-name>/scripts/…`.

```bash
DD_PATTERN=hexagonal DD_API_STYLE=rest bash <SKILL_DIR>/development-design/scripts/bash/draft-design.sh --auto
```

### Answer keys

| Key | Meaning | Default |
|---|---|---|
| `DD_PATTERN` | hexagonal / onion / layered / mvc / clean | `hexagonal` |
| `DD_API_STYLE` | rest / graphql / grpc / trpc / event | `rest` |
| `DD_DATA_STYLE` | relational / document / key-value / mixed | `relational` |
| `DD_INCLUDE_API_CONTRACT` | `true` / `false` | `true` |
| `DD_INCLUDE_DATA_MODEL` | `true` / `false` | `true` |

## References

- `references/design-patterns.md` — hexagonal vs. onion vs. layered
  vs. clean, with a one-line pros/cons.
- `references/error-handling-checklist.md` — per-failure-condition
  design checks (response, message, retry / backoff, no silent
  swallow, AC linkage).
