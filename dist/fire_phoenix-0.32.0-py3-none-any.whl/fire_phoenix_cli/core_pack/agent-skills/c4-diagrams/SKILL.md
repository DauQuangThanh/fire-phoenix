---
name: c4-diagrams
description: Authors C4 model diagrams (Context / Container / Component) as Mermaid flowcharts — three files per project, one per zoom level. Draws what the user has declared; does not invent components. Use when creating architecture diagrams or visualising system structure.
license: MIT
compatibility: Designed for agentskills.io-compatible agents.
metadata:
  author: Dau Quang Thanh
  version: '1.0'
  requires: []
---

## User Input

```text
$ARGUMENTS
```

## Audience and tone (interactive mode)

**Register first — adapt to role level.** Before applying the beginner floor
below, resolve the reader's level from the merged `.fire-phoenix/context.yml`
+ `.fire-phoenix/user-context.yml` (`user-context.yml` wins): use
`preferences.tech_role_level` for technical work (`junior` → hand-hold, one
path; `mid` → ≥2 options with one-line trade-offs; `senior` → defer on
judgment, surface edge cases, be brief; `staff` → be terse, challenge
premises, skip obvious caveats) and `preferences.non_tech_role_level` for
stakeholder work (`non-technical` → outcomes not jargon; `familiar` → simple
jargon glossed; `fluent` → concepts without explanation; `technical` → full
vocabulary). An explicit in-session signal (e.g. "be terse", "skip the
explanation") overrides everything. The plain-English, one-question-at-a-time
floor below applies **only when the relevant level is unset**; never treat
role level as a gate. Full rule: `.fire-phoenix/references/subagents/register-resolution.md`.

When `FIRE_PHOENIX_AGENT_MODE=interactive` (the default), assume the user
has **limited technical background and limited domain knowledge**
— they may know basics but lack deep expertise in this skill's
area. Run this skill as a guided questionnaire:

- **One question at a time.** No walls of questions.
- **Yes / no first.** Phrase so `yes`, `no`, `not sure`, or `skip`
  is a valid answer.
- **Translate jargon, don't strip it.** Use the technical term but
  always pair it with a plain-English gloss the first time it
  appears.
- **Choices, not blank fields.** When yes/no isn't enough, offer
  2-4 lettered options (A/B/C/D) with one-line plain-language
  descriptions of the trade-off. Always include "Not sure — pick
  a sensible default".
- **Always recommend.** State the option you would pick and why in
  one sentence so the user can reply "yes" / "ok" to accept. Pull
  defaults from upstream artefacts (spec, architecture, ADRs,
  standards) before asking blank.
- **Show, don't ask.** When upstream artefacts already imply an
  answer, propose it as a pre-filled finding and ask for a
  yes / no confirmation rather than asking the user to fill in a
  blank.
- **`not sure` / `skip` triggers a sensible default**, marked
  "(default applied — confirm later)" in the artefact, and a debt
  entry in this skill's debt file.

When `FIRE_PHOENIX_AGENT_MODE=auto` (or `--auto`), skip the questionnaire
entirely: apply sensible defaults from upstream artefacts and log
decisions to the parent agent's decision log.

## Inputs

- `.fire-phoenix/context.yml`
- `{context.paths.docs}/architecture/intake.md`
- `{context.governance.adr_dir}/NNNN-*.md` (authored via the `adr-author` draft → `promote-governance` path, adr/0053)

## Outputs

- `{context.paths.docs}/architecture/c4-context.md`
- `{context.paths.docs}/architecture/c4-container.md`
- `{context.paths.docs}/architecture/c4-component.md`

Level 4 (Code) is intentionally omitted — code diagrams belong in
the design skill, not the architecture skill.

## Context Update

Does not mutate `.fire-phoenix/context.yml`.

## Handoffs

- `development-design` uses container diagrams to identify modules.
- `security-review` references container diagrams for attack
  surface.
- `cicd-pipeline` / `deployment-strategy` reference container diagrams to
  align runtime topology with pipelines.

## AI authoring scope

**Does:** draft Mermaid diagrams using the C4 convention; cite
which actors + systems come from which intake entry.

**Does not:** invent containers or components not stated by the
user or an ADR; redraw on unapproved changes without asking.

## Review pass

Before presenting any diagram, walk
`references/diagram-review-checklist.md`:

1. **Ownership** — every container's "Owned by" cell is filled;
   an ownerless container is logged as a `TDEBT-`.
2. **Trust boundaries** — every crossing from a less-trusted to
   a more-trusted zone is visible on the container diagram and
   listed in the trust-boundaries table. This is what the
   security reviewer walks STRIDE against; an unmarked boundary
   never gets threat-modelled.
3. **Consistency with dependency reality** — every edge maps to
   a real dependency and every known dependency has an edge;
   cross-check the extracted architecture / dependency map when
   they exist. A mismatch is recorded as a finding and put to
   the user — never silently redrawn.
4. **Hygiene** — labelled edges, no invented nodes, ≤ ~12 nodes,
   one zoom level per diagram.

## Usage

> `<SKILL_DIR>` = the integration's skills root (e.g. `.claude/skills/`
> for Claude Code, `.codex/skills/` for Codex,
> `.cursor/skills/` for Cursor, `.kiro/skills/` for Kiro).
> Scripts live at `<SKILL_DIR>/<skill-name>/scripts/…`.

```bash
bash <SKILL_DIR>/c4-diagrams/scripts/bash/draft-c4.sh --auto
```

### Answer keys

| Key | Meaning | Default |
|---|---|---|
| `C4_LEVEL` | `context`, `container`, `component`, or `all` | `all` |
| `C4_SYSTEM_NAME` | the subject system | derived from `current.feature` |

## References

- `references/c4-shorthand.md` — how to draw C4 in plain Mermaid
  (no special plugins required).
- `references/diagram-review-checklist.md` — the pre-presentation
  review pass: owners, trust boundaries, dependency consistency,
  hygiene.
- `assets/c4-context-example.mmd`,
  `assets/c4-container-example.mmd` — reference diagrams.
