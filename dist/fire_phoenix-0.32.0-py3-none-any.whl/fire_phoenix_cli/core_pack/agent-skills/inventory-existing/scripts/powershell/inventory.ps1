# Enumerate observable artefacts in an existing (brownfield) project.
# Every line tagged OBSERVED: + cites the path that proves it. The
# skill REFUSES to infer purpose / design / quality.
#
# Per assets/agent-skills/inventory-existing/SKILL.md + adr/0019 §C.

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
. (Join-Path $ScriptDir 'common.ps1')

$RestArgs = Import-FirePhoenixStandardArgs $args

if ($RestArgs.Count -gt 0 -and $RestArgs -contains '-Help') {
    @'
Usage: inventory.ps1 [--auto] [--answers FILE] [--dry-run] [--help]

Enumerate observable artefacts in the project root. Writes an
inventory report at {context.paths.docs}/inventory/initial-inventory-<YYYY-MM-DD>.md.

Each line tagged OBSERVED: + cites the path that proves it.
'@ | Write-Host
    exit 0
}

$ctx = Read-Context
$Today = if ($env:FIRE_PHOENIX_INVENTORY_DATE) { $env:FIRE_PHOENIX_INVENTORY_DATE } else { (Get-Date -Format 'yyyy-MM-dd') }

$OutDir = Get-WorktypeDir -Name 'inventory'
$OutFile = Join-Path $OutDir "initial-inventory-$Today.md"

if ($env:FIRE_PHOENIX_DRY_RUN -eq '1') {
    Write-Host "[dry-run] would write: $OutFile"
    exit 0
}

if (Test-Path $OutFile) {
    Write-Error "Inventory already exists at $OutFile - refusing to overwrite."
    exit 1
}

if (-not (Confirm-BeforeWrite "Write inventory report to $OutFile")) {
    Write-Error "Aborted."
    exit 1
}

$lines = New-Object System.Collections.Generic.List[string]
$lines.Add("# Initial inventory - $Today")
$lines.Add('')
$lines.Add('> OBSERVED-only inventory of an existing (brownfield) project.')
$lines.Add('> Every line below is OBSERVED. No inference about purpose, design, or quality.')
$lines.Add('')
$lines.Add('## Methodology artefacts (top-level)')
$lines.Add('')

$methodologyFiles = 'README.md','AGENTS.md','CLAUDE.md','PRODUCT.md','STATUS.md','decisions.md','CHANGELOG.md','CONTRIBUTING.md','LICENSE'
$methodologyDirs = 'adr','specs','contracts','docs','architecture','ops','.fire-phoenix'

foreach ($f in $methodologyFiles) {
    if (Test-Path (Join-Path $ctx.REPO_ROOT $f)) {
        $lines.Add("- OBSERVED: ``$f`` exists.")
    }
}
foreach ($d in $methodologyDirs) {
    if (Test-Path (Join-Path $ctx.REPO_ROOT $d)) {
        $lines.Add("- OBSERVED: ``$d`` exists.")
    }
}

$lines.Add('')
$lines.Add('## Tests (top-level directories)')
$lines.Add('')
foreach ($d in 'tests','test','__tests__','spec') {
    if (Test-Path (Join-Path $ctx.REPO_ROOT $d)) {
        $lines.Add("- OBSERVED: ``$d`` exists.")
    }
}

$lines.Add('')
$lines.Add('## Build tooling (top-level)')
$lines.Add('')
$buildFiles = 'pyproject.toml','setup.py','setup.cfg','requirements.txt','requirements-dev.txt',
    'package.json','package-lock.json','yarn.lock','pnpm-lock.yaml',
    'pom.xml','build.gradle','build.gradle.kts',
    'Cargo.toml','Cargo.lock',
    'go.mod','go.sum',
    'Makefile','makefile',
    'Gemfile','Gemfile.lock'
foreach ($f in $buildFiles) {
    if (Test-Path (Join-Path $ctx.REPO_ROOT $f)) {
        $lines.Add("- OBSERVED: ``$f`` exists.")
    }
}

$lines.Add('')
$lines.Add('## CI / containerisation / infra')
$lines.Add('')
foreach ($d in '.github','.gitlab','.circleci','.azure-pipelines','terraform','kubernetes','helm') {
    if (Test-Path (Join-Path $ctx.REPO_ROOT $d)) {
        $lines.Add("- OBSERVED: ``$d`` exists.")
    }
}
foreach ($f in 'Dockerfile','docker-compose.yml','docker-compose.yaml','.gitlab-ci.yml') {
    if (Test-Path (Join-Path $ctx.REPO_ROOT $f)) {
        $lines.Add("- OBSERVED: ``$f`` exists.")
    }
}

$lines.Add('')
$lines.Add('## Git age')
$lines.Add('')
if (Test-Path (Join-Path $ctx.REPO_ROOT '.git')) {
    try {
        $firstCommit = & git -C $ctx.REPO_ROOT log --reverse --format=%aI 2>$null | Select-Object -First 1
        if ($firstCommit) {
            $lines.Add("- OBSERVED: first commit date is ``$firstCommit`` (``git log --reverse --format=%aI | head -1``).")
        } else {
            $lines.Add('- OBSERVED: ``.git/`` exists but no commits found (``git log`` empty).')
        }
        $commitCount = & git -C $ctx.REPO_ROOT rev-list --count HEAD 2>$null
        if ($commitCount) {
            $lines.Add("- OBSERVED: total commit count on HEAD is $commitCount (``git rev-list --count HEAD``).")
        }
    } catch {
        $lines.Add('- OBSERVED: ``.git/`` exists; ``git log`` failed (treat as no history available).')
    }
} else {
    $lines.Add('- OBSERVED: ``.git/`` is absent (project is not a git repository).')
}

$lines.Add('')
$lines.Add('## How to use this inventory')
$lines.Add('')
$lines.Add('1. Read every ``OBSERVED:`` line.')
$lines.Add('2. Promote selected rows into ``STATUS.md §What was here at init time``.')
$lines.Add('3. For each observed module / surface you intend to change, run ``/characterise-behaviour <module>`` to pin OBSERVED behaviour first.')
$lines.Add('4. For methodology artefacts conflicting with IDD canon, surface the conflict in a NEW ``adr/NNNN-*.md``.')
$lines.Add('')
$lines.Add('## Refusal scope')
$lines.Add('')
$lines.Add('This skill REFUSES to enumerate: purpose / quality / inferred design / anything not directly observable. Inference belongs to technical-analyst + ``/characterise-behaviour``.')

$lines -join "`n" | Set-Content -Path $OutFile -Encoding UTF8

Write-Host "Inventory written to $OutFile"
