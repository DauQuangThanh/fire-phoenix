---
name: architecture-extraction
description: Extracts architecture from an existing codebase — containers, components, data flow, external dependencies. Produces an architecture doc that can seed ADRs and C4 diagrams. Use when reverse-engineering a codebase, onboarding, or generating architecture docs from existing code.
license: MIT
compatibility: Designed for agentskills.io-compatible agents.
metadata:
  author: Dau Quang Thanh
  version: '1.0'
  requires: []
---

## User Input

```text
$ARGUMENTS
```

## Audience and tone (interactive mode)

**Register first — adapt to role level.** Before applying the beginner floor
below, resolve the reader's level from the merged `.fire-phoenix/context.yml`
+ `.fire-phoenix/user-context.yml` (`user-context.yml` wins): use
`preferences.tech_role_level` for technical work (`junior` → hand-hold, one
path; `mid` → ≥2 options with one-line trade-offs; `senior` → defer on
judgment, surface edge cases, be brief; `staff` → be terse, challenge
premises, skip obvious caveats) and `preferences.non_tech_role_level` for
stakeholder work (`non-technical` → outcomes not jargon; `familiar` → simple
jargon glossed; `fluent` → concepts without explanation; `technical` → full
vocabulary). An explicit in-session signal (e.g. "be terse", "skip the
explanation") overrides everything. The plain-English, one-question-at-a-time
floor below applies **only when the relevant level is unset**; never treat
role level as a gate. Full rule: `.fire-phoenix/references/subagents/register-resolution.md`.

When `FIRE_PHOENIX_AGENT_MODE=interactive` (the default), assume the user
has **limited technical background and limited domain knowledge**
— they may know basics but lack deep expertise in this skill's
area. Run this skill as a guided questionnaire:

- **One question at a time.** No walls of questions.
- **Yes / no first.** Phrase so `yes`, `no`, `not sure`, or `skip`
  is a valid answer.
- **Translate jargon, don't strip it.** Use the technical term but
  always pair it with a plain-English gloss the first time it
  appears.
- **Choices, not blank fields.** When yes/no isn't enough, offer
  2-4 lettered options (A/B/C/D) with one-line plain-language
  descriptions of the trade-off. Always include "Not sure — pick
  a sensible default".
- **Always recommend.** State the option you would pick and why in
  one sentence so the user can reply "yes" / "ok" to accept. Pull
  defaults from upstream artefacts (spec, architecture, ADRs,
  standards) before asking blank.
- **Show, don't ask.** When upstream artefacts already imply an
  answer, propose it as a pre-filled finding and ask for a
  yes / no confirmation rather than asking the user to fill in a
  blank.
- **`not sure` / `skip` triggers a sensible default**, marked
  "(default applied — confirm later)" in the artefact, and a debt
  entry in this skill's debt file.

When `FIRE_PHOENIX_AGENT_MODE=auto` (or `--auto`), skip the questionnaire
entirely: apply sensible defaults from upstream artefacts and log
decisions to the parent agent's decision log.

## Inputs

- `.fire-phoenix/context.yml`
- `{context.paths.docs}/analysis/codebase-scan.md`
- Source tree

## Outputs

- `{context.paths.docs}/architecture/extracted.md`
- `{context.paths.docs}/architecture/extracted.extract`

## Context Update

Does not mutate `.fire-phoenix/context.yml`.

## Handoffs

- `c4-diagrams` converts extracted structure into C4 Mermaid.
- `adr-author` seeds candidate ADRs for decisions embedded in the
  code (e.g. "chose PostgreSQL") that had no prior ADR.

## AI authoring scope

**Does:** read config files (compose / k8s / terraform / ci),
entry-point modules, and infer the container + dependency graph.
Flag decisions that appear to have been made implicitly (no ADR).

**Does not:** modify code; claim intent without evidence; edit or
overwrite existing architecture docs (drift is reported, the
architect decides what to update).

## Extraction flow

1. **Start from the scan** — entry points, hot paths, and
   detected infrastructure files from `codebase-scan.md` seed
   the container hunt.
2. **Extract** containers, integrations, and data flow per
   `references/extraction-heuristics.md`. Every claim carries a
   confidence tag — `OBSERVED` with `file:line`, `INFERRED
   (low|med|high confidence)` with reasoning, or `UNKNOWN` — and
   is re-verified against its source before it lands in the
   artefact.
3. **Reconcile against documented architecture** — read any
   existing `{context.paths.docs}/architecture/c4-*.md`,
   `intake.md`, and ADRs. For each documented element, check the
   code evidence and classify: **match** (docs and code agree),
   **drift** (docs say X, code shows Y), **undocumented** (in
   code, absent from docs), or **unimplemented** (in docs,
   absent from code). Drift and its neighbours are recorded as
   findings in the artefact's drift table — the existing docs
   are never silently rewritten to match the code (or vice
   versa); the architect resolves each row.
4. **Flag implicit decisions** as candidate ADRs — evident from
   implementation, rationale not documented; never invent the
   rationale.
5. **Log gaps** (`TDEBT-` / `ANALYSISDEBT-`) — missing
   rate-limiting, tracing, inconsistent logging, unverifiable
   claims.

## Usage

> `<SKILL_DIR>` = the integration's skills root (e.g. `.claude/skills/`
> for Claude Code, `.codex/skills/` for Codex,
> `.cursor/skills/` for Cursor, `.kiro/skills/` for Kiro).
> Scripts live at `<SKILL_DIR>/<skill-name>/scripts/…`.

```bash
bash <SKILL_DIR>/architecture-extraction/scripts/bash/extract.sh --auto
```
