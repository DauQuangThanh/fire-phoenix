# Environment setup for `pptx-markdown`

> Read this only when the workspace is not yet bootstrapped — no
> project-local `./.venv` with the required Python deps, or
> LibreOffice (`soffice`) needed for visual QA — or when the deps
> must be installed manually. Skip it when the scripts already run
> cleanly. Extracted per `adr/0034` — canonical text, not a copy.

## Setup (cross-platform)

The scripts auto-prefer a project-local `./.venv` in your current working directory. Run the bootstrap helper once per workspace:

**macOS / Linux (bash):**

```bash
cd /path/to/your/workspace          # where your .pptx lives
bash <skill-dir>/scripts/bash/setup_env.sh
```

**Windows (PowerShell):**

```powershell
cd C:\path\to\your\workspace        # where your .pptx lives
pwsh <skill-dir>\scripts\powershell\setup_env.ps1
```

The helper creates `./.venv` next to your files (not inside the skill folder) and `pip install`s `python-pptx` and `PyYAML` from `scripts/requirements.txt`. Subsequent script runs are then automatic — each script detects the venv and re-execs under it.

If the venv is missing when you run a script, you get a clear setup hint and the script exits. If you really want to run against the system Python, pass `--system-python` on the command line:

```bash
python scripts/pptx_to_md.py input.pptx output.md --system-python
```

(On Windows / PowerShell, the same flag works: `python scripts\pptx_to_md.py input.pptx output.md --system-python`.)

## Dependencies

Python deps are installed automatically by `setup_env.sh` / `setup_env.ps1` into the project-local `./.venv`. The list is in `scripts/requirements.txt`:

- `python-pptx`
- `PyYAML`

If you want to install them manually instead of using the bootstrap helper:

macOS / Linux (bash) — into a venv:

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r <skill-dir>/scripts/requirements.txt
```

Windows (PowerShell) — into a venv:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r <skill-dir>\scripts\requirements.txt
```

System dependencies (optional):

- LibreOffice (`soffice`) for visual QA. The scripts find it on PATH; if it is not on PATH the helper also checks the macOS app bundle (`/Applications/LibreOffice.app/Contents/MacOS/soffice`) and the standard Windows install dirs (`C:\Program Files\LibreOffice\program\soffice.exe` and the x86 variant).
