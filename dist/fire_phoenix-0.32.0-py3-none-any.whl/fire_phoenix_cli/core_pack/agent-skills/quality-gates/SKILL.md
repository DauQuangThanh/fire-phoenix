---
name: quality-gates
description: Defines quality gates (coverage thresholds, lint/type/security-scan pass criteria, performance budgets) every PR and release must pass. Produces a gate definition the CI pipeline enforces; does not enforce them itself. Use when setting CI thresholds or pass/fail criteria.
license: MIT
compatibility: Designed for agentskills.io-compatible agents.
metadata:
  author: Dau Quang Thanh
  version: '1.0'
  requires: []
---

## User Input

```text
$ARGUMENTS
```

## Audience and tone (interactive mode)

**Register first — adapt to role level.** Before applying the beginner floor
below, resolve the reader's level from the merged `.fire-phoenix/context.yml`
+ `.fire-phoenix/user-context.yml` (`user-context.yml` wins): use
`preferences.tech_role_level` for technical work (`junior` → hand-hold, one
path; `mid` → ≥2 options with one-line trade-offs; `senior` → defer on
judgment, surface edge cases, be brief; `staff` → be terse, challenge
premises, skip obvious caveats) and `preferences.non_tech_role_level` for
stakeholder work (`non-technical` → outcomes not jargon; `familiar` → simple
jargon glossed; `fluent` → concepts without explanation; `technical` → full
vocabulary). An explicit in-session signal (e.g. "be terse", "skip the
explanation") overrides everything. The plain-English, one-question-at-a-time
floor below applies **only when the relevant level is unset**; never treat
role level as a gate. Full rule: `.fire-phoenix/references/subagents/register-resolution.md`.

When `FIRE_PHOENIX_AGENT_MODE=interactive` (the default), assume the user
has **limited technical background and limited domain knowledge**
— they may know basics but lack deep expertise in this skill's
area. Run this skill as a guided questionnaire:

- **One question at a time.** No walls of questions.
- **Yes / no first.** Phrase so `yes`, `no`, `not sure`, or `skip`
  is a valid answer.
- **Translate jargon, don't strip it.** Use the technical term but
  always pair it with a plain-English gloss the first time it
  appears.
- **Choices, not blank fields.** When yes/no isn't enough, offer
  2-4 lettered options (A/B/C/D) with one-line plain-language
  descriptions of the trade-off. Always include "Not sure — pick
  a sensible default".
- **Always recommend.** State the option you would pick and why in
  one sentence so the user can reply "yes" / "ok" to accept. Pull
  defaults from upstream artefacts (spec, architecture, ADRs,
  standards) before asking blank.
- **Show, don't ask.** When upstream artefacts already imply an
  answer, propose it as a pre-filled finding and ask for a
  yes / no confirmation rather than asking the user to fill in a
  blank.
- **`not sure` / `skip` triggers a sensible default**, marked
  "(default applied — confirm later)" in the artefact, and a debt
  entry in this skill's debt file.

When `FIRE_PHOENIX_AGENT_MODE=auto` (or `--auto`), skip the questionnaire
entirely: apply sensible defaults from upstream artefacts and log
decisions to the parent agent's decision log.

## Inputs

- `.fire-phoenix/context.yml`
- `{context.paths.docs}/testing/<feature>/strategy.md`
- `{context.paths.docs}/testing/<feature>/framework.md`

## Outputs

- `{context.paths.docs}/testing/<feature>/quality-gates.md`
- `{context.paths.docs}/testing/<feature>/quality-gates.extract`

## Context Update

Does not mutate `.fire-phoenix/context.yml`.

## Handoffs

- `cicd-pipeline` reads the gate definitions to shape pipeline stages.
- `deployment-strategy` reads release-level gates.

## AI authoring scope

**Does:** draft gate thresholds per level (PR gate / merge gate /
release gate), list which tools enforce each gate, propose
performance budgets from the intake's operational envelope.

**Does not:** modify CI pipelines, commit thresholds the user
hasn't approved, claim a build passes a gate that it didn't.

## The mechanical gates

Wire these first — each has a real tool and a binary outcome.
They are the minimum PR-gate set; project-specific gates
(performance budgets, security scans) layer on top per the
template.

| Gate | Check | Enforced by |
|---|---|---|
| Lint / format | 0 errors on changed files | project linter + formatter |
| Type check | 0 errors on changed files | project type checker |
| Tests | 100% pass; new behaviour ships with new tests | project test runner |
| Coverage | changed-files line coverage ≥ threshold | coverage tool, diff-filtered |
| AC coverage | no ORPHAN-AC / ORPHAN-CITATION at epic close | `fire-phoenix check ac` (AC→test coverage matrix) |

## Advisory vs. enforcing per rigor profile

Every gate is declared **advisory** (red is reported, never
blocks) or **enforcing** (red blocks merge). Read the declared
rigor profile from the project context; when none is declared,
behave as Profile **F**.

- **P (Prototype / Demo)** — lint + tests enforcing; type check,
  coverage, and AC coverage advisory. Speed beats ceremony, but
  red is still reported, never hidden.
- **M (MVP)** — all mechanical gates enforcing at PR; AC
  coverage advisory per PR, enforcing at epic close.
- **F (Production, default)** — all gates enforcing; AC coverage
  reported per PR and enforcing at epic close; every waiver is
  written, linked, and expires.

The artefact records the profile in force and each gate's
advisory / enforcing status — a gate with an unstated status is
a `TQDEBT-`.

## Usage

> `<SKILL_DIR>` = the integration's skills root (e.g. `.claude/skills/`
> for Claude Code, `.codex/skills/` for Codex,
> `.cursor/skills/` for Cursor, `.kiro/skills/` for Kiro).
> Scripts live at `<SKILL_DIR>/<skill-name>/scripts/…`.

```bash
QG_COVERAGE_PR=80 QG_COVERAGE_RELEASE=85 QG_P95_MS=200 \
  bash <SKILL_DIR>/quality-gates/scripts/bash/draft-gates.sh --auto
```

### Answer keys

| Key | Meaning | Default |
|---|---|---|
| `QG_COVERAGE_PR` | coverage % required on PR | `80` |
| `QG_COVERAGE_RELEASE` | coverage % required for release | `85` |
| `QG_P95_MS` | performance budget — p95 latency | `200` |
| `QG_MAX_HIGH_VULN` | max allowed High-severity CVEs | `0` |
| `QG_MAX_CRIT_VULN` | max allowed Critical CVEs | `0` |
