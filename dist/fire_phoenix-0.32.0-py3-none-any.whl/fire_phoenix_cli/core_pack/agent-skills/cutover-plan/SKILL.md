---
name: cutover-plan
description: 'Authors a per-slice cutover protocol — N-rehearsal parity evidence, shadow/canary comparison, a named-approver gate, an old-path freeze, and a decommission date. Use when scheduling a slice''s cutover after parity-ledger. REFUSES to author a cutover with no named approver or no decommission date.'
license: MIT
compatibility: Designed for agentskills.io-compatible agents.
metadata:
  author: Dau Quang Thanh
  version: '1.0'
  requires: [parity-ledger]
---

## User Input

```text
$ARGUMENTS
```

You **MUST** consider the user input before proceeding (if not empty).

## Pre-Execution Checks

1. **Confirm a named approver.** A cutover changes what real users hit;
   someone must own that decision BY NAME. REJECT a blank, a role
   ("the team"), or "TBD" — the gate needs an accountable human. No
   named approver → the skill REFUSES to author the cutover.
2. **Confirm a decommission date.** A migration with no decommission
   date never ends — two live implementations forever. REJECT "later" /
   "eventually". No decommission date → the skill REFUSES.
3. **Confirm the slice scope.** Pin the CONCRETE old module(s) being
   retired and the CONCRETE new module(s) cutting in — not "the old
   system". Vague scope is rejected.
4. **Confirm the parity ledger.** Point at the `parity-ledger` artefact
   for this slice. A slice with unresolved ledger mismatches cannot pass
   the gate; say so up front.

## Audience and tone (interactive mode)

**Register first — adapt to role level.** Before applying the beginner floor
below, resolve the reader's level from the merged `.fire-phoenix/context.yml`
+ `.fire-phoenix/user-context.yml` (`user-context.yml` wins): use
`preferences.tech_role_level` for technical work (`junior` → hand-hold, one
path; `mid` → ≥2 options with one-line trade-offs; `senior` → defer on
judgment, surface edge cases, be brief; `staff` → be terse, challenge
premises, skip obvious caveats) and `preferences.non_tech_role_level` for
stakeholder work (`non-technical` → outcomes not jargon; `familiar` → simple
jargon glossed; `fluent` → concepts without explanation; `technical` → full
vocabulary). An explicit in-session signal (e.g. "be terse", "skip the
explanation") overrides everything. The plain-English, one-question-at-a-time
floor below applies **only when the relevant level is unset**; never treat
role level as a gate. Full rule: `.fire-phoenix/references/subagents/register-resolution.md`.

When `FIRE_PHOENIX_AGENT_MODE=interactive` (the default), assume the user
has **limited technical background and limited domain knowledge**
— they may know basics but lack deep expertise in this skill's
area. Run this skill as a guided questionnaire:

- **One question at a time.** No walls of questions.
- **Yes / no first.** Phrase so `yes`, `no`, `not sure`, or `skip`
  is a valid answer.
- **Translate jargon, don't strip it.** Use the technical term but
  always pair it with a plain-English gloss the first time it
  appears.
- **Choices, not blank fields.** When yes/no isn't enough, offer
  2-4 lettered options (A/B/C/D) with one-line plain-language
  descriptions of the trade-off. Always include "Not sure — pick
  a sensible default".
- **Always recommend.** State the option you would pick and why in
  one sentence so the user can reply "yes" / "ok" to accept. Pull
  defaults from upstream artefacts (spec, architecture, ADRs,
  standards) before asking blank.
- **Show, don't ask.** When upstream artefacts already imply an
  answer, propose it as a pre-filled finding and ask for a
  yes / no confirmation rather than asking the user to fill in a
  blank.
- **`not sure` / `skip` triggers a sensible default**, marked
  "(default applied — confirm later)" in the artefact, and a debt
  entry in this skill's debt file.

When `FIRE_PHOENIX_AGENT_MODE=auto` (or `--auto`), skip the questionnaire
entirely: read the slice's `parity-ledger`, confirm a named approver AND
a decommission date are both present — REFUSE and stop if either is
missing (a cutover without them is invalid) — draft the per-slice cutover
protocol, and log decisions to the parent agent's decision log.

## Inputs

- `.fire-phoenix/context.yml`
- The migration **slice slug** (kebab-case), plus the concrete old →
  new module scope.
- **Named approver** for the cutover gate (required — no default).
- **Decommission date** for the old path (required — no default).
- The slice's `parity-ledger` output (`tests/parity/<slug>-ledger.md`),
  whose Progress section the gate reads.

## Outputs

- `{context.paths.docs}/migration/cutover-<slug>.md` — the per-slice
  cutover protocol: slice scope, rehearsal record, shadow/canary
  comparison plan, the named-approver cutover gate, the old-path freeze
  declaration, and the decommission date.

## Context Update

Does not mutate `.fire-phoenix/context.yml`. The cutover plan under
`{context.paths.docs}/migration/` is the only on-disk side-effect.

## Handoffs

- **`parity-ledger`** — consumed: the gate reads the slice's ledger
  Progress section; an unresolved mismatch blocks the gate.
- **`seam-analysis`** — pairs on slices: the seam plan defines which
  slices exist and their order; this skill authors the cutover for one.
- **`reconciliation-harness`** — pairs on data: for a data-migration
  slice, reconciliation evidence backs the rehearsal record before the
  gate.

## AI authoring scope

**Does:** author a per-slice cutover protocol from the slice scope,
approver, decommission date, and parity ledger; require an N-rehearsal
record, a shadow/canary live-comparison plan, a named-approver gate, an
old-path freeze declaration, and a decommission date; state that the gate
is BLOCKED while any parity-ledger row is an unresolved mismatch and that
the ledger stays open until decommission.

**Does not:** approve the cutover (that is the named human — no
self-approval); flip traffic, freeze, or decommission anything itself
(the plan is the contract, execution is the engineer's); author a cutover
with no named approver or no decommission date (a hard refusal); decide
the slice boundaries (that is `seam-analysis`).

## Usage

> `<SKILL_DIR>` = the integration's skills root (e.g. `.claude/skills/`
> for Claude Code, `.codex/skills/` for Codex, `.cursor/skills/` for
> Cursor, `.kiro/skills/` for Kiro). Scripts live at
> `<SKILL_DIR>/<skill-name>/scripts/…`.

```bash
CP_APPROVER="Jane Doe" CP_DECOMMISSION_DATE=2026-12-31 \
  bash <SKILL_DIR>/cutover-plan/scripts/bash/build-cutover-plan.sh --auto <slice-slug>
```

### Answer keys

| Key | Default |
|---|---|
| (positional) `<slice-slug>` | required |
| `CP_APPROVER` | required — no default (refuses if empty) |
| `CP_DECOMMISSION_DATE` | required — no default (refuses if empty) |
