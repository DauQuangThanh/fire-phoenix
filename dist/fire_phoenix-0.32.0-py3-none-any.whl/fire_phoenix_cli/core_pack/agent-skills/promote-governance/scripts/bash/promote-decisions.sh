#!/usr/bin/env bash
# promote-decisions.sh (adr/0053) — the SOLE canonical writer of the L4
# decisions log. Appends every pending draft from {governance.decisions_pending_dir}
# to the canonical {governance.decisions_file} (append-only), then clears the
# promoted drafts. Interactive-only: refuses to run in auto mode, because a
# canonical L4 write must have a human in the loop (CLAUDE.md). Idempotent —
# a clean (empty) queue is a no-op.
set -e
SCRIPT_DIR="$(CDPATH="" cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=common.sh
source "$SCRIPT_DIR/common.sh"
read_context

if [ "${FIRE_PHOENIX_AGENT_MODE:-interactive}" = "auto" ]; then
    echo "promote-decisions: refusing to write canonical decisions in auto mode (adr/0053)." >&2
    exit 3
fi

PENDING_DIR="$FIRE_PHOENIX_REPO_ROOT/$FIRE_PHOENIX_DECISIONS_PENDING_DIR"
CANON="$FIRE_PHOENIX_REPO_ROOT/$FIRE_PHOENIX_DECISIONS_FILE"

if [ ! -d "$PENDING_DIR" ]; then
    echo "No pending decisions queue at $PENDING_DIR — nothing to promote."
    exit 0
fi

mkdir -p "$(dirname "$CANON")"
[ -f "$CANON" ] || printf '# Decisions\n' > "$CANON"

count=0
shopt -s nullglob
for f in "$PENDING_DIR"/*.md; do
    # Append-only: a blank separator line, then the entry verbatim.
    { printf '\n'; cat "$f"; } >> "$CANON"
    rm -f "$f" "${f%.md}.extract"
    count=$((count + 1))
done

echo "Promoted $count decision(s) into $CANON"
