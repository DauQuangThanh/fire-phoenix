#!/usr/bin/env bash
# promote-adrs.sh (adr/0053) — the SOLE canonical writer of ADRs. Assigns the
# canonical 4-digit NNNN (scanning {governance.adr_dir}), rewrites the draft's
# provisional "ADR-DRAFT" heading, writes {adr_dir}/NNNN-<slug>.md (via redirect,
# name recognised by `fire-phoenix check trace`), and clears the promoted draft.
# Interactive-only (refuses auto mode). Idempotent — an empty drafts queue is a
# no-op. Carries the legacy-guard relocated from add-adr.sh (contracts/task-0077).
set -e
SCRIPT_DIR="$(CDPATH="" cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=common.sh
source "$SCRIPT_DIR/common.sh"
read_context

if [ "${FIRE_PHOENIX_AGENT_MODE:-interactive}" = "auto" ]; then
    echo "promote-adrs: refusing to write canonical ADRs in auto mode (adr/0053)." >&2
    exit 3
fi

DRAFTS_DIR="$FIRE_PHOENIX_REPO_ROOT/$FIRE_PHOENIX_ADR_DRAFTS_DIR"
ADR_DIR="$FIRE_PHOENIX_REPO_ROOT/$FIRE_PHOENIX_ADR_DIR"

if [ ! -d "$DRAFTS_DIR" ]; then
    echo "No ADR drafts queue at $DRAFTS_DIR — nothing to promote."
    exit 0
fi

# Legacy guard (relocated from add-adr.sh, contracts/task-0077): surface any
# pre-canonical ADRs so promotion never starts a silent second sequence.
LEGACY_DIR="$FIRE_PHOENIX_REPO_ROOT/$FIRE_PHOENIX_DOCS_DIR/decisions"
if [ -d "$LEGACY_DIR" ] && ls "$LEGACY_DIR" 2>/dev/null | grep -Eq '^ADR-[0-9]+'; then
    echo "NOTE: legacy ADR file(s) at $LEGACY_DIR (pre-canonical home); new ADRs go to $ADR_DIR — existing files are never moved or renumbered." >&2
fi

mkdir -p "$ADR_DIR"
count=0
shopt -s nullglob
for f in "$DRAFTS_DIR"/*.md; do
    ext="${f%.md}.extract"
    slug=""
    [ -f "$ext" ] && slug=$(grep '^SLUG=' "$ext" 2>/dev/null | cut -d= -f2- || true)
    [ -n "$slug" ] || slug=$(basename "$f" .md)

    # Next canonical number — re-scanned each iteration so multiple drafts get
    # sequential numbers without collision.
    NEXT=1
    last=$(ls "$ADR_DIR" 2>/dev/null | grep -Eo '^[0-9]{4}' | sort -n | tail -n1 || true)
    [ -n "$last" ] && NEXT=$((10#$last + 1))
    NUM=$(printf '%04d' "$NEXT")
    OUT="$ADR_DIR/$NUM-$slug.md"

    # Rewrite the provisional heading "# ADR-DRAFT:" -> "# ADR-NNNN:".
    sed "s/# ADR-DRAFT:/# ADR-$NUM:/" "$f" > "$OUT"
    write_extract "$OUT" "ADR_ID=$NUM" "SLUG=$slug" "STATUS=promoted" > /dev/null
    rm -f "$f" "$ext"
    count=$((count + 1))
    echo "Promoted ADR $NUM: $OUT"
done

echo "Promoted $count ADR(s) into $ADR_DIR"
