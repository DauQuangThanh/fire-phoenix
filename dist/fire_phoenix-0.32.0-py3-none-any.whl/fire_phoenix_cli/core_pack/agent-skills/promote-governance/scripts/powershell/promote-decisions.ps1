#!/usr/bin/env pwsh
# promote-decisions.ps1 (adr/0053) — sole canonical writer of the L4 decisions
# log. Appends every pending draft from {governance.decisions_pending_dir} to the
# canonical {governance.decisions_file} (append-only), then clears the promoted
# drafts. Interactive-only (refuses auto mode). Idempotent.
$ErrorActionPreference = 'Stop'
$ScriptDir = Split-Path -Parent $PSCommandPath
. (Join-Path $ScriptDir 'common.ps1')
$ctx = Read-Context

if ($env:FIRE_PHOENIX_AGENT_MODE -eq 'auto') {
    Write-Error 'promote-decisions: refusing to write canonical decisions in auto mode (adr/0053).'
    exit 3
}

$pending = Join-Path $ctx.REPO_ROOT $ctx.DECISIONS_PENDING_DIR
$canon = Join-Path $ctx.REPO_ROOT $ctx.DECISIONS_FILE

if (-not (Test-Path -LiteralPath $pending)) {
    Write-Host "No pending decisions queue at $pending - nothing to promote."
    exit 0
}

$parent = Split-Path $canon -Parent
if ($parent -and -not (Test-Path -LiteralPath $parent)) { New-Item -ItemType Directory -Force -Path $parent | Out-Null }
if (-not (Test-Path -LiteralPath $canon)) { Set-Content -LiteralPath $canon -Value "# Decisions" }

$count = 0
Get-ChildItem -LiteralPath $pending -Filter '*.md' -File -ErrorAction SilentlyContinue | ForEach-Object {
    Add-Content -LiteralPath $canon -Value ""
    Add-Content -LiteralPath $canon -Value (Get-Content -LiteralPath $_.FullName -Raw)
    Remove-Item -LiteralPath $_.FullName -Force
    $ext = [System.IO.Path]::ChangeExtension($_.FullName, 'extract')
    if (Test-Path -LiteralPath $ext) { Remove-Item -LiteralPath $ext -Force }
    $count++
}

Write-Host "Promoted $count decision(s) into $canon"
