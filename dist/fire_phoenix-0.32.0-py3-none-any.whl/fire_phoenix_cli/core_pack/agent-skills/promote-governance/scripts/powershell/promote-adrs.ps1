#!/usr/bin/env pwsh
# promote-adrs.ps1 (adr/0053) — sole canonical writer of ADRs. Assigns the
# canonical 4-digit NNNN (scanning {governance.adr_dir}), rewrites the draft's
# provisional "ADR-DRAFT" heading, writes {adr_dir}/NNNN-<slug>.md, and clears
# the promoted draft. Interactive-only (refuses auto mode). Idempotent.
$ErrorActionPreference = 'Stop'
$ScriptDir = Split-Path -Parent $PSCommandPath
. (Join-Path $ScriptDir 'common.ps1')
$ctx = Read-Context

if ($env:FIRE_PHOENIX_AGENT_MODE -eq 'auto') {
    Write-Error 'promote-adrs: refusing to write canonical ADRs in auto mode (adr/0053).'
    exit 3
}

$draftsDir = Join-Path $ctx.REPO_ROOT $ctx.ADR_DRAFTS_DIR
$adrDir = Join-Path $ctx.REPO_ROOT $ctx.ADR_DIR

if (-not (Test-Path -LiteralPath $draftsDir)) {
    Write-Host "No ADR drafts queue at $draftsDir - nothing to promote."
    exit 0
}

# Legacy guard (relocated from add-adr.ps1, contracts/task-0077).
$legacyDir = Join-Path (Join-Path $ctx.REPO_ROOT $ctx.DOCS_DIR) 'decisions'
$legacy = @(Get-ChildItem -LiteralPath $legacyDir -Filter 'ADR-*.md' -ErrorAction SilentlyContinue)
if ($legacy.Count -gt 0) {
    Write-Warning ("legacy ADR file(s) at {0} (pre-canonical home); new ADRs go to {1} - existing files are never moved or renumbered." -f $legacyDir, $adrDir)
}

New-Item -ItemType Directory -Force -Path $adrDir | Out-Null
$count = 0
Get-ChildItem -LiteralPath $draftsDir -Filter '*.md' -File -ErrorAction SilentlyContinue | ForEach-Object {
    $ext = [System.IO.Path]::ChangeExtension($_.FullName, 'extract')
    $slug = ''
    if (Test-Path -LiteralPath $ext) {
        $slugLine = Get-Content -LiteralPath $ext | Where-Object { $_ -like 'SLUG=*' } | Select-Object -First 1
        if ($slugLine) { $slug = $slugLine.Substring(5) }
    }
    if (-not $slug) { $slug = [System.IO.Path]::GetFileNameWithoutExtension($_.FullName) }

    # Next canonical number - re-scanned each iteration.
    $next = 1
    $nums = Get-ChildItem -LiteralPath $adrDir -Filter '*.md' -ErrorAction SilentlyContinue |
        ForEach-Object { if ($_.Name -match '^(\d{4})-') { [int]$Matches[1] } }
    if ($nums) { $next = ($nums | Measure-Object -Maximum).Maximum + 1 }
    $num = '{0:D4}' -f $next
    $out = Join-Path $adrDir ("{0}-{1}.md" -f $num, $slug)

    $content = (Get-Content -LiteralPath $_.FullName -Raw).Replace('# ADR-DRAFT:', "# ADR-${num}:")
    Set-Content -LiteralPath $out -Value $content
    Write-Extract -ArtefactPath $out "ADR_ID=$num" "SLUG=$slug" "STATUS=promoted" | Out-Null
    Remove-Item -LiteralPath $_.FullName -Force
    if (Test-Path -LiteralPath $ext) { Remove-Item -LiteralPath $ext -Force }
    $count++
    Write-Host "Promoted ADR ${num}: $out"
}

Write-Host "Promoted $count ADR(s) into $adrDir"
