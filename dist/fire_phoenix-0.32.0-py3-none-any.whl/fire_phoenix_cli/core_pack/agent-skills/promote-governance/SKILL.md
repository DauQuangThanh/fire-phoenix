---
name: promote-governance
description: Promotes pending L4 governance drafts — ADRs and decisions-log entries — from the pending queues into their canonical, guardrail-protected locations, with a human confirming each. Interactive-only; refuses auto mode. Use when queued governance drafts are ready for a human to accept.
license: MIT
compatibility: Designed for agentskills.io-compatible agents.
metadata:
  author: Dau Quang Thanh
  version: '1.0'
  requires: []
---

## User Input

```text
$ARGUMENTS
```

## Audience and tone (interactive mode)

**Register first — adapt to role level.** Before applying the beginner floor
below, resolve the reader's level from the merged `.fire-phoenix/context.yml`
+ `.fire-phoenix/user-context.yml` (`user-context.yml` wins): use
`preferences.tech_role_level` for technical work (`junior` → hand-hold, one
path; `mid` → ≥2 options with one-line trade-offs; `senior` → defer on
judgment, surface edge cases, be brief; `staff` → be terse, challenge
premises, skip obvious caveats) and `preferences.non_tech_role_level` for
stakeholder work (`non-technical` → outcomes not jargon; `familiar` → simple
jargon glossed; `fluent` → concepts without explanation; `technical` → full
vocabulary). An explicit in-session signal (e.g. "be terse", "skip the
explanation") overrides everything. The plain-English, one-question-at-a-time
floor below applies **only when the relevant level is unset**; never treat
role level as a gate. Full rule: `.fire-phoenix/references/subagents/register-resolution.md`.

This skill writes L4 governance artefacts (per `adr/0053`, the promote step is
the sole canonical writer, and it requires a human in the loop). Run it as a
careful, one-item-at-a-time review:

- **Show each draft before promoting it.** Summarise the pending entry (kind,
  title, body) and ask the human to accept, skip, or edit it first.
- **Never promote in bulk without confirmation.** Yes/no per item.
- **Refuse auto mode.** If `FIRE_PHOENIX_AGENT_MODE=auto`, stop and tell the user
  to re-run interactively — a canonical L4 write must have a human present.

## Inputs

- Pending decisions drafts in `governance.decisions_pending_dir` (written by the
  `record_decision` / `Record-Decision` helper).
- Pending ADR drafts in `governance.adr_drafts_dir` (written by `add-adr` in
  draft mode).

## Outputs

- Appended entries in the canonical `governance.decisions_file` (append-only).
- New numbered ADRs in the canonical `governance.adr_dir` (`NNNN-<slug>.md`,
  numbered at promote time), recognised by `fire-phoenix check trace`.
- Promoted drafts are cleared from the pending queues.

## Context Update

None. This skill does not touch the `current.*` work cursor. It only moves
governance artefacts from the pending queues to their canonical homes.

## Handoffs

- **Upstream producers:** any subagent/skill that recorded a decision via
  `record_decision` or drafted an ADR via `add-adr` (e.g. business-analyst G1
  records, the `change` Critical sign-off, architect ADRs).
- **Downstream consumers:** once promoted, entries are read by
  `fire-phoenix check approval` (Critical sign-offs), `fire-phoenix check ac` /
  `phase-gate` (G1 records), `fire-phoenix check trace` (ADR citations), and the
  subagent Inputs that reference `governance.adr_dir` / `governance.decisions_file`.

## AI authoring scope

This skill is an authoring aid for the single human at the keyboard. It does not
approve anything on the human's behalf — it presents queued drafts and, on the
human's explicit confirmation, moves them into the canonical governance files.
It never runs in auto mode.

## Usage

Interactive review, then promote:

```bash
# Decisions-log entries → canonical decisions_file (append-only)
scripts/bash/promote-decisions.sh
# ADR drafts → canonical adr_dir (numbered at promote time)
scripts/bash/promote-adrs.sh
```

PowerShell siblings: `scripts/powershell/promote-decisions.ps1`,
`scripts/powershell/promote-adrs.ps1`. Both refuse to run when
`FIRE_PHOENIX_AGENT_MODE=auto`, are append-only / additive, and are idempotent
(an empty queue is a no-op).

## References

- `adr/0053` — the sanctioned governance-authoring path (pending → promote).
- `specs/epic-governance-authoring-path.md` — the epic + acceptance criteria.
