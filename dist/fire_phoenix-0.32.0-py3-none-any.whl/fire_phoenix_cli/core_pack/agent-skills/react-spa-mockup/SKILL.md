---
name: react-spa-mockup
description: Scaffolds a runnable React SPA mockup (Vite, TypeScript, Tailwind v4, shadcn/ui, React Router v7, react-i18next, 3-way theming) opened with `npm install && npm run dev`. Use when prototyping a feature UI or bootstrapping a runnable front-end SPA skeleton before the production app.
license: MIT
compatibility: Designed for agentskills.io-compatible agents.
metadata:
  author: Dau Quang Thanh
  version: '1.0'
  requires: []
---

## User Input

```text
$ARGUMENTS
```

Consider the user input before proceeding (if not empty).

## Audience and tone (interactive mode)

**Register first — adapt to role level.** Before applying the beginner floor
below, resolve the reader's level from the merged `.fire-phoenix/context.yml`
+ `.fire-phoenix/user-context.yml` (`user-context.yml` wins): use
`preferences.tech_role_level` for technical work (`junior` → hand-hold, one
path; `mid` → ≥2 options with one-line trade-offs; `senior` → defer on
judgment, surface edge cases, be brief; `staff` → be terse, challenge
premises, skip obvious caveats) and `preferences.non_tech_role_level` for
stakeholder work (`non-technical` → outcomes not jargon; `familiar` → simple
jargon glossed; `fluent` → concepts without explanation; `technical` → full
vocabulary). An explicit in-session signal (e.g. "be terse", "skip the
explanation") overrides everything. The plain-English, one-question-at-a-time
floor below applies **only when the relevant level is unset**; never treat
role level as a gate. Full rule: `.fire-phoenix/references/subagents/register-resolution.md`.

When `FIRE_PHOENIX_AGENT_MODE=interactive` (the default), assume the user
may have limited front-end scaffolding experience. Run this skill
as a guided questionnaire:

- **One question at a time.** Do not present multiple questions together.
- **Yes / no first.** Phrase so `yes`, `no`, `not sure`, or `skip` is
  a valid answer.
- **Always recommend.** State the option you would pick and why in one
  sentence, so the user can reply "yes" / "ok" to accept.
- **Choices, not blank fields.** When yes/no isn't enough, offer 2-4
  lettered options (A/B/C/D) with one-line descriptions. Always include
  "Not sure — pick a sensible default".
- **`not sure` / `skip` triggers a sensible default** — record the
  decision as `default-applied` via `write_decision`.

When `FIRE_PHOENIX_AGENT_MODE=auto` (or `--auto`), skip the questionnaire
entirely: use all documented defaults and record each one with
`write_decision default-applied`.

## Questionnaire (interactive mode only)

Ask these questions in sequence. Stop when you have enough to scaffold:

1. **Output directory** — "Where should the SPA project be created?
   (e.g. `mockup/`, `frontend/`, or a custom path — default is `mockup/`)"

2. **App name** — "What's the npm package name for this app?
   (e.g. `my-feature-mockup` — default: derived from the current feature
   slug, or `my-app` if no feature is set)"

3. **Pages** — "Which pages should be scaffolded?
   A) Just `Home` (default)
   B) `Home` + `About`
   C) Custom list — tell me the page names separated by commas"

4. **Theme** — "Which theme mode should the app start in?
   A) System default — follows the OS dark/light preference (recommended)
   B) Light — always light
   C) Dark — always dark"

5. **Locales** — "Which languages should the app support? The scaffold ships
   English (`en`) and Vietnamese (`vi`) by default. Do you need any others?
   (Reply with BCP-47 codes separated by commas, e.g. `fr,ja` — or press
   Enter to keep the default `en,vi`)"

## Inputs

- `.fire-phoenix/context.yml` (optional — used for feature slug and paths)
- User answers from the questionnaire above

## Outputs

The script writes a fully runnable SPA project under `{FIRE_PHOENIX_SPA_OUTPUT_DIR}`:

```text
{output_dir}/
├── .gitignore
├── components.json          # shadcn/ui config
├── index.html
├── package.json
├── tsconfig.json
├── tsconfig.app.json
├── vite.config.ts
└── src/
    ├── index.css            # Tailwind v4 entry + CSS variables
    ├── main.tsx
    ├── App.tsx
    ├── router.tsx           # React Router v7 browser router
    ├── hooks/
    │   └── useTheme.ts      # 3-way theme hook (system / light / dark)
    ├── i18n/
    │   └── setup.ts         # i18next initialisation
    ├── lib/
    │   └── utils.ts         # clsx + tailwind-merge helper
    ├── locales/
    │   ├── en.json           # English translations
    │   ├── vi.json           # Vietnamese translations
    │   └── <extra>.json      # one file per additional locale
    └── pages/
        └── <Page>.tsx       # one file per requested page
```

The skill does **not** run `npm install`. After scaffolding, the user runs:

```bash
cd {output_dir}
npm install
npm run dev
```

## Context Update

This skill does not mutate `.fire-phoenix/context.yml`.

## Handoffs

- `wireframes` — wireframes produced by that skill can be used as the
  layout reference before running this skill.
- `development-design` — the design doc describes the component model; this
  skill realises it as runnable starter code.
- `unit-tests` — once the skeleton is in place, unit tests can be
  scaffolded against the page components.

## AI authoring scope

**Does:**

- Scaffold a runnable SPA project with the tech stack below.
- Ask the user (interactive) or apply defaults (auto) for output directory,
  app name, and page list.
- Produce one `<Page>.tsx` per requested page with a minimal placeholder UI
  using shadcn/ui primitives and Tailwind utility classes.
- Record all defaults applied in auto mode to the agent-decisions log.
- Log a `SPADEV` debt entry per page that only has placeholder content.

**Does not:**

- Run `npm install` or start the dev server.
- Generate full business-logic or API integration code.
- Modify files outside `{FIRE_PHOENIX_SPA_OUTPUT_DIR}`.

## Component inventory — before generation

When wireframes exist for the feature, build a component
inventory before scaffolding any page: map screens → shared
components so shared pieces are identified once, not rediscovered
per page.

| Component | Screens using it | Source wireframe |
|---|---|---|
| <e.g. OrderCard> | Home, Orders | wireframes.md §Screen: Orders |

- A component used by ≥2 screens is scaffolded as a shared
  component, not duplicated per page.
- Include the inventory in the mockup's README (or a comment in
  `App.tsx`) so the developer inherits the mapping.
- No wireframes? Say so, derive the inventory from the requested
  page list, and flag it as a `SPADEV` debt.

## Acceptance-criteria linkage

List the user-facing acceptance criteria the mockup illustrates,
each cited by id: AC-NNN → the page(s) / flow that satisfies it.
Put the list in the mockup's README. Pages that satisfy no AC are
fine (navigation shells), but an AC with no page is a gap to
surface to the user. Error and empty states carried over from the
wireframes keep their failure-path AC citations.

## Fidelity note

The mockup is an **illustrative exemplar, not production-hardened
code**: placeholder data, no real authentication, no API
integration, no security review. State this in the mockup README.
Production pages go through the normal contract flow; the mockup
is a conversation artefact for validating the UX.

## Tech stack

| Concern         | Choice              | Version pin  |
|-----------------|---------------------|--------------|
| Build tool      | Vite                | ^6.0.0       |
| UI library      | React               | ^19.0.0      |
| Language        | TypeScript          | ~5.6.0       |
| Styling         | Tailwind CSS        | ^4.0.0       |
| Components      | shadcn/ui           | (copy-paste) |
| Routing         | React Router        | ^7.2.0       |
| i18n            | react-i18next + i18next | ^15.0.0  |
| Icon set        | lucide-react        | ^0.475.0     |
| Utility helpers | clsx + tailwind-merge | latest     |

## Usage

> `<SKILL_DIR>` = the integration's skills root (e.g. `.claude/skills/`
> for Claude Code, `.codex/skills/` for Codex,
> `.cursor/skills/` for Cursor, `.kiro/skills/` for Kiro).
> Scripts live at `<SKILL_DIR>/<skill-name>/scripts/…`.

### Interactive (default)

```bash
bash <SKILL_DIR>/react-spa-mockup/scripts/bash/scaffold-spa.sh
```

```powershell
pwsh <SKILL_DIR>/react-spa-mockup/scripts/powershell/scaffold-spa.ps1
```

### Auto

```bash
FIRE_PHOENIX_SPA_OUTPUT_DIR=mockup \
FIRE_PHOENIX_SPA_APP_NAME=my-feature-mockup \
FIRE_PHOENIX_SPA_PAGES=Home,Dashboard,Settings \
FIRE_PHOENIX_SPA_THEME=system \
FIRE_PHOENIX_SPA_LOCALES=en,vi \
bash <SKILL_DIR>/react-spa-mockup/scripts/bash/scaffold-spa.sh --auto
```

```powershell
$env:FIRE_PHOENIX_SPA_OUTPUT_DIR = 'mockup'
$env:FIRE_PHOENIX_SPA_APP_NAME   = 'my-feature-mockup'
$env:FIRE_PHOENIX_SPA_PAGES      = 'Home,Dashboard,Settings'
$env:FIRE_PHOENIX_SPA_THEME      = 'system'
$env:FIRE_PHOENIX_SPA_LOCALES    = 'en,vi'
pwsh <SKILL_DIR>/react-spa-mockup/scripts/powershell/scaffold-spa.ps1 -Auto
```

### Standard flags

| Flag / param      | Meaning                                            | Default |
|-------------------|----------------------------------------------------|---------|
| `--auto` / `-Auto`  | Non-interactive; use env / answers / defaults    | off     |
| `--answers FILE` / `-Answers FILE` | `KEY=VALUE` input file           | —       |
| `--dry-run` / `-DryRun` | Print what would be written, no filesystem changes | off |
| `--help` / `-Help`  | Show usage and exit                              | —       |

### Answer keys

| Key                   | Meaning                               | Default                         |
|-----------------------|---------------------------------------|---------------------------------|
| `FIRE_PHOENIX_SPA_OUTPUT_DIR` | Directory to scaffold the SPA into        | `mockup`                        |
| `FIRE_PHOENIX_SPA_APP_NAME`   | npm package name                          | feature slug, or `my-app`       |
| `FIRE_PHOENIX_SPA_PAGES`      | Comma-separated page names to create      | `Home`                          |
| `FIRE_PHOENIX_SPA_THEME`      | Initial theme: `system` / `light` / `dark` | `system`                      |
| `FIRE_PHOENIX_SPA_LOCALES`    | Comma-separated BCP-47 locale codes        | `en,vi`                        |
