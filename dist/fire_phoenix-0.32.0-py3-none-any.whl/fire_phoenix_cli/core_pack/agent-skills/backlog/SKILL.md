---
name: backlog
description: Maintains the product backlog — an ordered list of user stories by priority, with estimates, acceptance-criteria pointers, and status. Drafts and re-orders from user-stated priorities; does not decide priority or commit a team. Use when managing a backlog, adding stories, or reprioritising.
license: MIT
compatibility: Designed for agentskills.io-compatible agents.
metadata:
  author: Dau Quang Thanh
  version: '1.0'
  requires: []
---

## User Input

```text
$ARGUMENTS
```

## Audience and tone (interactive mode)

**Register first — adapt to role level.** Before applying the beginner floor
below, resolve the reader's level from the merged `.fire-phoenix/context.yml`
+ `.fire-phoenix/user-context.yml` (`user-context.yml` wins): use
`preferences.tech_role_level` for technical work (`junior` → hand-hold, one
path; `mid` → ≥2 options with one-line trade-offs; `senior` → defer on
judgment, surface edge cases, be brief; `staff` → be terse, challenge
premises, skip obvious caveats) and `preferences.non_tech_role_level` for
stakeholder work (`non-technical` → outcomes not jargon; `familiar` → simple
jargon glossed; `fluent` → concepts without explanation; `technical` → full
vocabulary). An explicit in-session signal (e.g. "be terse", "skip the
explanation") overrides everything. The plain-English, one-question-at-a-time
floor below applies **only when the relevant level is unset**; never treat
role level as a gate. Full rule: `.fire-phoenix/references/subagents/register-resolution.md`.

When `FIRE_PHOENIX_AGENT_MODE=interactive` (the default), assume the user
has **no technical or business-domain background**. Run this skill
as a guided questionnaire:

- **One question at a time.** No walls of questions.
- **Yes / no first.** Phrase so `yes`, `no`, `not sure`, or `skip`
  is a valid answer.
- **No jargon.** Translate domain terms into everyday words with
  concrete examples (avoid MoSCoW, WSJF, RICE, INVEST, story
  points, T-shirt, velocity, MVP). Use plain alternatives:
  "must-have / nice-to-have / maybe-later" for priority,
  "Small / Medium / Large / Extra-Large" for size.
- **Choices, not blank fields.** When yes/no isn't enough, offer
  2-4 lettered options (A/B/C/D) with one-line everyday
  descriptions. Always include "Not sure — pick a sensible default".
- **Always recommend.** State the option you would pick and why in
  one sentence so the user can reply "yes" / "ok" to accept.
- **`not sure` / `skip` triggers a sensible default**, marked
  "(default applied — confirm later)" in the backlog row, and a
  `PODEBT-` entry in `product-debts.md`.

When `FIRE_PHOENIX_AGENT_MODE=auto` (or `--auto`), skip the questionnaire
entirely: apply sensible defaults and log decisions to the
product-owner agent's decision log.

## Inputs

- `.fire-phoenix/context.yml` → `paths.docs`, `paths.intents`, `current.feature`
- `{context.paths.intents}/**/intent.md` — user stories source
- `{context.paths.docs}/product/acceptance.md` — ties items to criteria

## Outputs

- `{context.paths.docs}/product/backlog.md` — the ordered backlog.
- `{context.paths.docs}/product/backlog.extract` — summary counts.

## Context Update

Does not mutate `.fire-phoenix/context.yml`.

## Handoffs

- `roadmap` reads the backlog to propose release windows.
- `taskify` converts prioritised items into tasks.
- `tasks-to-issues` emits GitHub issues once the PO approves.
- `sprint-planning` pulls top-N items into a sprint plan.

## AI authoring scope

This skill **does**: append backlog items, re-order by priority the
user provides, estimate T-shirt sizes the user confirms, link each
item to its spec + acceptance criteria.

This skill **does not**: decide which items to promote / demote,
commit a team to deliver anything, negotiate with stakeholders.

## Usage

> `<SKILL_DIR>` = the integration's skills root (e.g. `.claude/skills/`
> for Claude Code, `.codex/skills/` for Codex,
> `.cursor/skills/` for Cursor, `.kiro/skills/` for Kiro).
> Scripts live at `<SKILL_DIR>/<skill-name>/scripts/…`.

```bash
# Add a new item.
BL_TITLE="Forgot-password flow" BL_PRIORITY=2 BL_SIZE=M BL_STORY_REF="specs/user-auth/intent.md#us-04" \
  bash <SKILL_DIR>/backlog/scripts/bash/add-item.sh --auto

# Reorder (interactive).
bash <SKILL_DIR>/backlog/scripts/bash/add-item.sh
```

### Answer keys

| Key | Meaning | Default |
|---|---|---|
| `BL_TITLE` | Item title (user story summary) | *(required)* |
| `BL_PRIORITY` | 1 = highest; integer | `99` |
| `BL_SIZE` | XS / S / M / L / XL | `M` |
| `BL_STATUS` | New / Ready / In progress / Done / Cut | `New` |
| `BL_STORY_REF` | Path or anchor into the spec | empty |

## Interactive flow

For each item: title → priority (1 = highest) → size (XS–XL) → spec
reference → status. Loop with "add another? (y/n)".

## Story readiness

An item may only move to Status `Ready` when its story has
BA-authored `AC-NNN` acceptance criteria and the parent epic's
`## G1 agreement` record exists — decomposition is blocked until
then. Flag must-have or top-two-priority items without `AC-NNN`
criteria as `PODEBT-` entries and point the user at the
business-analyst; this skill never drafts criteria itself.

## Debt register

File `{context.paths.docs}/product/product-debts.md`, prefix
`PODEBT-`. Log when an item has no priority, no acceptance-criteria
link, or an ambiguous size — and when a must-have item's story has
no `AC-NNN` criteria or its epic lacks a `## G1 agreement` record.

## References

- `references/prioritization-frames.md` — MoSCoW, WSJF, RICE quick
  reference.
- `references/prioritization-rubric.md` — qualitative
  value / risk / effort / dependency bands and tie-break rules
  (no scoring numbers).
- `references/estimation-t-shirt.md` — T-shirt sizing anchors.
