---
name: coordinate-team
description: Assembles and runs a dynamic team of role-based subagents for a complex, multi-phase task. Interviews you to size and staff the team, drafts a coordinator plan plus per-role briefs, generates a gated workflow, then launches it. Use for multi-role work spanning several phases.
license: MIT
compatibility: Designed for agentskills.io-compatible agents.
metadata:
  author: Dau Quang Thanh
  version: '1.0'
  requires: []
  scripts:
    sh: scripts/bash/plan-team.sh
    ps: scripts/powershell/plan-team.ps1
---

# Coordinate Team

Turn one complex, multi-phase task into a running **team** of role-based
subagents. You act as the *coordinator*: decompose the task, decide who
does what, and set the human checkpoints. This skill drafts that plan as
artefacts and generates a workflow that launches the team — it never
facilitates meetings, contacts stakeholders, or approves work above the
Routine lane. Autonomy is bounded by the project's autonomy envelope (an
`autonomy-envelope.yml` policy file that lists which change lanes may
auto-close); everything Consequential or Critical parks at a human gate.

The output is a **coordinator triad**:

1. **Team plan** — the decomposition, the staffed roster with rationale,
   the phase → role → gate mapping.
2. **Role briefs** — one `brief-<role>.md` per staffed role; each worker
   receives only its slice (its phase, its inputs, its "done means").
3. **Team workflow** — a generated `workflow.yml` (a linear
   `command`/`gate` spine) you launch with `fire-phoenix workflow run`.

## Audience and tone (interactive mode)

**Register first — adapt to role level.** Before applying the beginner floor
below, resolve the reader's level from the merged `.fire-phoenix/context.yml`
+ `.fire-phoenix/user-context.yml` (`user-context.yml` wins): use
`preferences.tech_role_level` for technical work (`junior` → hand-hold, one
path; `mid` → ≥2 options with one-line trade-offs; `senior` → defer on
judgment, surface edge cases, be brief; `staff` → be terse, challenge
premises, skip obvious caveats) and `preferences.non_tech_role_level` for
stakeholder work (`non-technical` → outcomes not jargon; `familiar` → simple
jargon glossed; `fluent` → concepts without explanation; `technical` → full
vocabulary). An explicit in-session signal (e.g. "be terse", "skip the
explanation") overrides everything. The plain-English, one-question-at-a-time
floor below applies **only when the relevant level is unset**; never treat
role level as a gate. Full rule: `.fire-phoenix/references/subagents/register-resolution.md`.

When `FIRE_PHOENIX_AGENT_MODE=interactive` (the default), run the staffing
decisions as a guided interview, not an interrogation:

- **One question at a time.** Never dump the whole staffing plan as a
  wall of questions.
- **Choices, not blank fields.** Offer 2-4 lettered options (A/B/C/D) with
  a one-line trade-off each, plus "Not sure — pick a sensible default".
- **Always recommend.** State the option you would pick and why in one
  sentence, so the user can reply "yes" to accept.
- **Pull defaults from upstream artefacts** — the spec, plan, ADRs, and
  `STATUS.md` — before asking blank. If the intent already implies a role,
  propose it pre-filled and ask only for a yes/no.
- **`not sure` / `skip` applies a sensible default**, marked
  "(default applied — confirm later)" in the plan.

When `FIRE_PHOENIX_AGENT_MODE=auto` (or `--auto`), skip the interview:
apply defaults from upstream artefacts, staff the smallest team that
covers the task, and log every non-trivial choice via `write_decision` to
`{context.paths.docs}/agent-decisions/coordinate-team/`.

## When to use / when not to

Use it when a task spans **several phases and more than one role** —
e.g. "design, build, and test this feature with a review before merge".
Do **not** use it for single-role, single-phase work (invoke that role's
skill directly), and never to coordinate multiple *humans*.

## Inputs

- **Task description** — free-form, via the interactive prompt or `args`.
  If empty or too thin to decompose, ask (interactive) or park a debt
  (auto) — never guess a team.
- **Roster** (optional) — an explicit list of roles to staff. Each must
  match a subagent in `references/subagent-roster.md`; an unknown role is
  a hard error naming the gap (no partial workflow).
- **Mode** — `interactive` (default) or `auto`, per the keyword in your
  first message or `FIRE_PHOENIX_AGENT_MODE`.
- **Rigor posture** (optional) — Prototype / Standard / Full; controls how
  many gates the generated workflow carries.
- **Upstream artefacts** — the current feature's intent/spec/plan and
  `STATUS.md`, read to pre-fill staffing and phase decomposition.

## Procedure — the coordinator triad

1. **Read the context.** Load the merged project context and the current
   feature's upstream artefacts. Derive a `<slug>` for this team run from
   the task (kebab-case, stable — the same task yields the same slug so
   re-runs are idempotent).
2. **Decompose.** Break the task into ordered phases. For each phase, name
   the single role that owns it. Classify each phase boundary by change
   lane (Mechanical / Routine / Consequential / Critical) — this decides
   whether it gets a gate.
3. **Staff.** Map each role to a subagent from the roster. In interactive
   mode, confirm the roster one question at a time with a recommendation;
   in auto mode, staff the smallest covering team and log the choice.
4. **Draft the plan.** Write `team-plan.md` from `templates/team-plan-template.md`
   into `{context.paths.docs}/orchestration/<slug>/`.
5. **Draft the briefs.** For each *distinct* staffed role, write one
   `brief-<role>.md` from `templates/brief-template.md` — least-context:
   only that role's phase, inputs, and done-means. Never hand a worker the
   whole plan.
6. **Generate the workflow.** Emit `.fire-phoenix/workflows/<slug>/workflow.yml`
   from `templates/team-workflow-template.yml`: one `command` step per
   phase (dispatching the fire-phoenix command whose agent delegates to
   the staffed subagent), a `gate` (`on_reject: abort`) at every
   Consequential/Critical boundary, `produces:` guards as false-success
   fences, and `execution:` set from the chosen mode. Use only
   `command`/`prompt`/`gate` step types — the workflow engine runs a
   linear sequence of steps with no branching or looping, so never emit
   `if`/`switch`/`while`/`fan`.
7. **Hand off.** Print the launch instruction:
   `fire-phoenix workflow run <slug>` (add `--auto` for unattended). The
   run mode propagates to every delegated subagent, so the team runs in
   one consistent mode end to end.

The `plan-team.sh` / `plan-team.ps1` action scaffolds steps 4-6
idempotently (content-hash guard): re-running on unchanged inputs leaves
the triad byte-identical.

## Autonomy boundary

The coordinator decides nothing above the Routine lane. It **encodes**
Consequential/Critical decisions as `gate` steps and defers the approval
verdict to `fire-phoenix check approval`, which consults the project's
autonomy envelope. In AUTO, if no valid envelope permits a phase's lane,
that phase is **gated for a human** — never self-closed. Consequential and
Critical always park at a human gate, in every mode.

## Modes

- **`interactive`** (default) — run the staffing interview; pause at each
  workflow gate for the user.
- **`auto`** — skip the interview; staff from defaults; invoke the action
  with `--auto` / `-Auto`; log assumptions and decisions to the
  agent-decisions log. Delegated subagents inherit `FIRE_PHOENIX_AGENT_MODE`
  — never downgrade `interactive` → `auto`.

## Outputs

- `{context.paths.docs}/orchestration/<slug>/team-plan.md` — the coordinator plan.
- `{context.paths.docs}/orchestration/<slug>/brief-<role>.md` — one per staffed role.
- `.fire-phoenix/workflows/<slug>/workflow.yml` — the runnable gated team workflow.
- In `auto`: decision records under `{context.paths.docs}/agent-decisions/coordinate-team/`.

## Context Update

This skill writes only the orchestration triad and (in `auto`) its
decision log. It does not modify the shared project configuration or the
per-user work cursor, and it does not sign off or promote any governance
artefact. If the team run produces a governance draft (an ADR or a
`{context.governance.decisions_file}` entry), that draft goes to a pending
queue and the `promote-governance` skill publishes it after a human
confirms — this skill never writes the canonical
`{context.governance.adr_dir}` or decisions file directly.

## Handoffs

- **To each staffed subagent** — via the generated workflow's `command`
  steps; each receives its `brief-<role>.md` as least-context.
- **To `fire-phoenix check approval`** — at every gate boundary, for the
  lane-graduated approval verdict.
- **To `promote-governance`** — if a worker drafts an ADR or decisions
  entry that the user later chooses to promote.

## References, templates, scripts

| Kind | Path | Purpose |
|---|---|---|
| Reference | `references/subagent-roster.md` | The 14 bundled subagents + when to staff each; how a user-defined subagent joins. |
| Reference | `references/orchestration-patterns.md` | Decomposition → staffing → gating patterns; the lane → gate mapping. |
| Template | `templates/team-plan-template.md` | The coordinator plan skeleton. |
| Template | `templates/brief-template.md` | A single role brief (least-context). |
| Template | `templates/team-workflow-template.yml` | The generated gated workflow skeleton. |
| Script | `scripts/bash/plan-team.sh` / `scripts/powershell/plan-team.ps1` | Scaffold the triad idempotently. |
