---
name: containerization
description: Drafts Dockerfile / compose / image-build strategy — a multi-stage Dockerfile starter, a local-dev compose file, and the design doc. Does not build or push images. Use when dockerising an application or planning a container strategy.
license: MIT
compatibility: Designed for agentskills.io-compatible agents.
metadata:
  author: Dau Quang Thanh
  version: '1.0'
  requires: []
---

## User Input

```text
$ARGUMENTS
```

## Audience and tone (interactive mode)

**Register first — adapt to role level.** Before applying the beginner floor
below, resolve the reader's level from the merged `.fire-phoenix/context.yml`
+ `.fire-phoenix/user-context.yml` (`user-context.yml` wins): use
`preferences.tech_role_level` for technical work (`junior` → hand-hold, one
path; `mid` → ≥2 options with one-line trade-offs; `senior` → defer on
judgment, surface edge cases, be brief; `staff` → be terse, challenge
premises, skip obvious caveats) and `preferences.non_tech_role_level` for
stakeholder work (`non-technical` → outcomes not jargon; `familiar` → simple
jargon glossed; `fluent` → concepts without explanation; `technical` → full
vocabulary). An explicit in-session signal (e.g. "be terse", "skip the
explanation") overrides everything. The plain-English, one-question-at-a-time
floor below applies **only when the relevant level is unset**; never treat
role level as a gate. Full rule: `.fire-phoenix/references/subagents/register-resolution.md`.

When `FIRE_PHOENIX_AGENT_MODE=interactive` (the default), assume the user
has **limited technical background and limited domain knowledge**
— they may know basics but lack deep expertise in this skill's
area. Run this skill as a guided questionnaire:

- **One question at a time.** No walls of questions.
- **Yes / no first.** Phrase so `yes`, `no`, `not sure`, or `skip`
  is a valid answer.
- **Translate jargon, don't strip it.** Use the technical term but
  always pair it with a plain-English gloss the first time it
  appears.
- **Choices, not blank fields.** When yes/no isn't enough, offer
  2-4 lettered options (A/B/C/D) with one-line plain-language
  descriptions of the trade-off. Always include "Not sure — pick
  a sensible default".
- **Always recommend.** State the option you would pick and why in
  one sentence so the user can reply "yes" / "ok" to accept. Pull
  defaults from upstream artefacts (spec, architecture, ADRs,
  standards) before asking blank.
- **Show, don't ask.** When upstream artefacts already imply an
  answer, propose it as a pre-filled finding and ask for a
  yes / no confirmation rather than asking the user to fill in a
  blank.
- **`not sure` / `skip` triggers a sensible default**, marked
  "(default applied — confirm later)" in the artefact, and a debt
  entry in this skill's debt file.

When `FIRE_PHOENIX_AGENT_MODE=auto` (or `--auto`), skip the questionnaire
entirely: apply sensible defaults from upstream artefacts and log
decisions to the parent agent's decision log.

## Inputs

- `.fire-phoenix/context.yml`
- `{context.paths.docs}/architecture/c4-container.md`
- Project root (to detect language / framework)

## Outputs

- `{context.paths.docs}/operations/containers.md`
- `assets/Dockerfile.sample` — multi-stage starter
- `assets/compose.sample.yml` — local dev compose

## Context Update

Does not mutate `.fire-phoenix/context.yml`.

## Handoffs

- `cicd-pipeline` reads the build stage in containers.md.
- `deployment-strategy` reads runtime requirements.
- `security-review` reviews the image base + layers.

## AI authoring scope

**Does:** design multi-stage builds (build → test → runtime),
propose non-root users, size-optimised final stage, healthchecks,
signal handling.

**Does not:** build, push, or deploy images; commit secrets.

## Image hygiene gate

Every Dockerfile this skill drafts passes the pre-handoff
checklist in `references/image-hygiene.md` before it is handed
on: base pinned by digest, non-root runtime user, minimal layers
(build toolchain stripped, caches cleaned), **no secrets in any
layer** (build args and deleted-later files included — deletion
does not scrub earlier layers), healthcheck present, SIGTERM
handled. Unmet items become `OPSDEBT-` entries.

## Usage

> `<SKILL_DIR>` = the integration's skills root (e.g. `.claude/skills/`
> for Claude Code, `.codex/skills/` for Codex,
> `.cursor/skills/` for Cursor, `.kiro/skills/` for Kiro).
> Scripts live at `<SKILL_DIR>/<skill-name>/scripts/…`.

```bash
CONT_RUNTIME=node bash <SKILL_DIR>/containerization/scripts/bash/draft-containers.sh --auto
```

### Answer keys

| Key | Default |
|---|---|
| `CONT_RUNTIME` | detected from project |
| `CONT_BASE_IMAGE` | one of distroless / slim / alpine (default `slim`) |
