# Environment setup for `docx-markdown`

> Read this only when the workspace is not yet bootstrapped — no
> project-local `./.venv` with the required Python deps, `pandoc`
> missing, or LibreOffice (`soffice`) needed for `--accept-changes`
> or `.doc` → `.docx` conversion. Skip it when the scripts already
> run cleanly. Extracted per `adr/0034` — canonical text, not a copy.

## Setup (cross-platform)

The scripts auto-prefer a project-local `./.venv` in your current working directory. Run the bootstrap helper once per workspace:

**macOS / Linux (bash):**

```bash
cd /path/to/your/workspace            # where your .docx lives
bash <skill-dir>/scripts/bash/setup_env.sh
```

**Windows (PowerShell):**

```powershell
cd C:\path\to\your\workspace          # where your .docx lives
pwsh <skill-dir>\scripts\powershell\setup_env.ps1
```

The helper creates `./.venv` next to your files (not inside the skill folder) and `pip install`s the deps from `scripts/requirements.txt`. Subsequent script runs are then automatic — each script detects the venv and re-execs under it.

If the venv is missing when you run a script, you get a clear setup hint and the script exits. Pass `--system-python` on the command line to force the current interpreter:

```bash
# macOS / Linux
python scripts/docx_to_md.py input.docx output.md --system-python
```

```powershell
# Windows
python scripts\docx_to_md.py input.docx output.md --system-python
```

`pandoc` is a separate system dependency (not pip-installable). Install via your package manager:

```bash
# macOS
brew install pandoc

# Debian / Ubuntu
sudo apt-get install pandoc
```

```powershell
# Windows (Chocolatey)
choco install pandoc
```

Or download from [pandoc.org/installing.html](https://pandoc.org/installing.html).

If you also need `soffice` (LibreOffice — used for `--accept-changes` and `.doc` → `.docx`), the docx scripts find it on PATH and additionally fall back to:

- macOS: `/Applications/LibreOffice.app/Contents/MacOS/soffice`
- Windows: `C:\Program Files\LibreOffice\program\soffice.exe` (and the x86 variant)
- Linux: `/usr/bin/soffice`, `/usr/local/bin/soffice`, `/snap/bin/libreoffice`

To convert a `.doc` to `.docx` directly:

```bash
soffice --headless --convert-to docx input.doc
```

```powershell
& "C:\Program Files\LibreOffice\program\soffice.exe" --headless --convert-to docx input.doc
```

## Dependencies

Python deps are installed automatically by `setup_env.sh` / `setup_env.ps1` into the project-local `./.venv`. The list is in `scripts/requirements.txt`:

- `python-docx`
- `lxml`
- `PyYAML`

If you want to install them manually instead of using the bootstrap helper:

macOS / Linux (bash) — into a venv:

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r <skill-dir>/scripts/requirements.txt
```

Windows (PowerShell) — into a venv:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r <skill-dir>\scripts\requirements.txt
```

System dependencies:

- `pandoc` (>= 2.18) — required for the docx ↔ md conversion. Install via `brew`, `apt`, `choco`, or [pandoc.org](https://pandoc.org/installing.html).
- LibreOffice (`soffice`) — optional, required only for `--accept-changes` and for `.doc` → `.docx` conversion. The scripts also look in standard install locations on macOS / Linux / Windows even when not on PATH.
