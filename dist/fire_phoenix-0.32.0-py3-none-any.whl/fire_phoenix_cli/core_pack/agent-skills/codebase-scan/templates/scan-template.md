# Codebase scan

**Date:** {date}
**Project root:** {root}
**Excluded:** {excludes}

> Every finding below carries a confidence tag — `OBSERVED`
> (with `file:line`), `INFERRED (low|med|high confidence)`
> (with reasoning), or `UNKNOWN` (open question, not a guess).

## Languages + LOC

| Language | Files | LOC | Share |
|---|---:|---:|---:|
| TypeScript | | | |
| Python | | | |
| YAML | | | |

## Top-level layout

```text
<tree — one line per top-level dir with one-line purpose>
```

## Detected frameworks + tooling

| Category | Finding | Evidence |
|---|---|---|
| Runtime | Node 20 | `package.json` engines |
| Web framework | Express | `package.json` deps |
| Test framework | Vitest | `package.json` deps |
| Linter | ESLint | `.eslintrc*` |
| Formatter | Prettier | `.prettierrc*` |
| Build | esbuild | `package.json` deps |

## Entry points

- `src/server.ts` — HTTP server bootstrap
- `src/cli.ts` — CLI entry
- `workers/main.py` — background worker

## Test signals

- Test folder: `tests/` (or co-located)
- Coverage artefact present? y/n
- Recent pass rate: unknown (scan does not run tests)

## Hot paths

- <most-imported module / largest file / most-churned area — one
  line each, with the evidence>

## Risk areas

- <untested dirs, generated/vendored code in source, dynamic
  typing walls, secrets-shaped config — flagged, not fixed>

## Unknowns

Logged as `ANALYSISDEBT-NN` in `docs/analysis/analysis-debts.md`.
