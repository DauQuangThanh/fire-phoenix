---
name: api-docs
description: 'Generates API documentation from source code: endpoints / RPC methods / queue topics with schemas and auth, working backward from routes + OpenAPI / proto / gql definitions. Use when documenting an API, generating endpoint reference docs, or documenting OpenAPI/gRPC/GraphQL schemas.'
license: MIT
compatibility: Designed for agentskills.io-compatible agents.
metadata:
  author: Dau Quang Thanh
  version: '1.0'
  requires: []
---

## User Input

```text
$ARGUMENTS
```

## Audience and tone (interactive mode)

**Register first — adapt to role level.** Before applying the beginner floor
below, resolve the reader's level from the merged `.fire-phoenix/context.yml`
+ `.fire-phoenix/user-context.yml` (`user-context.yml` wins): use
`preferences.tech_role_level` for technical work (`junior` → hand-hold, one
path; `mid` → ≥2 options with one-line trade-offs; `senior` → defer on
judgment, surface edge cases, be brief; `staff` → be terse, challenge
premises, skip obvious caveats) and `preferences.non_tech_role_level` for
stakeholder work (`non-technical` → outcomes not jargon; `familiar` → simple
jargon glossed; `fluent` → concepts without explanation; `technical` → full
vocabulary). An explicit in-session signal (e.g. "be terse", "skip the
explanation") overrides everything. The plain-English, one-question-at-a-time
floor below applies **only when the relevant level is unset**; never treat
role level as a gate. Full rule: `.fire-phoenix/references/subagents/register-resolution.md`.

When `FIRE_PHOENIX_AGENT_MODE=interactive` (the default), assume the user
has **limited technical background and limited domain knowledge**
— they may know basics but lack deep expertise in this skill's
area. Run this skill as a guided questionnaire:

- **One question at a time.** No walls of questions.
- **Yes / no first.** Phrase so `yes`, `no`, `not sure`, or `skip`
  is a valid answer.
- **Translate jargon, don't strip it.** Use the technical term but
  always pair it with a plain-English gloss the first time it
  appears.
- **Choices, not blank fields.** When yes/no isn't enough, offer
  2-4 lettered options (A/B/C/D) with one-line plain-language
  descriptions of the trade-off. Always include "Not sure — pick
  a sensible default".
- **Always recommend.** State the option you would pick and why in
  one sentence so the user can reply "yes" / "ok" to accept. Pull
  defaults from upstream artefacts (spec, architecture, ADRs,
  standards) before asking blank.
- **Show, don't ask.** When upstream artefacts already imply an
  answer, propose it as a pre-filled finding and ask for a
  yes / no confirmation rather than asking the user to fill in a
  blank.
- **`not sure` / `skip` triggers a sensible default**, marked
  "(default applied — confirm later)" in the artefact, and a debt
  entry in this skill's debt file.

When `FIRE_PHOENIX_AGENT_MODE=auto` (or `--auto`), skip the questionnaire
entirely: apply sensible defaults from upstream artefacts and log
decisions to the parent agent's decision log.

## Inputs

- `.fire-phoenix/context.yml`
- `{context.paths.docs}/analysis/codebase-scan.md`
- Route modules + OpenAPI / proto / GraphQL schema files

## Outputs

- `{context.paths.docs}/analysis/api-docs.md`
- `{context.paths.docs}/analysis/api-docs.extract`

## Context Update

Does not mutate `.fire-phoenix/context.yml`.

## Handoffs

- `development-design` (architect / developer) references api-docs
  when evolving contracts.
- `security-review` uses the endpoint list for authZ review.

## AI authoring scope

**Does:** enumerate endpoints, include request / response
schemas, auth requirement, error responses, idempotency notes,
and one example per endpoint; annotate with source `file:line`.

**Does not:** invent routes; guess schemas where the code doesn't
declare them; hit live endpoints; present a constructed example
as captured traffic.

## Completeness gate

Before presenting the artefact, walk
`references/completeness-checklist.md` per endpoint: route +
method cited, auth requirement explicit (public is stated, never
implied), schema or logged gap, error shapes the code actually
produces, idempotency note, one example. An endpoint failing an
item is completed or its gap logged as an `ANALYSISDEBT-`.

Because these docs are extracted (brownfield), every documented
behaviour carries a confidence tag — `OBSERVED` with `file:line`,
`INFERRED (low|med|high confidence)` with reasoning, or
`UNKNOWN`. An error shape read from a shared handler is
`INFERRED` for a given route unless that route's path through
the handler was traced. Close with the checklist's coverage
line: endpoints found vs fully documented.

## Usage

> `<SKILL_DIR>` = the integration's skills root (e.g. `.claude/skills/`
> for Claude Code, `.codex/skills/` for Codex,
> `.cursor/skills/` for Cursor, `.kiro/skills/` for Kiro).
> Scripts live at `<SKILL_DIR>/<skill-name>/scripts/…`.

```bash
API_STYLE=rest bash <SKILL_DIR>/api-docs/scripts/bash/generate-api-docs.sh --auto
```

### Answer keys

| Key | Default |
|---|---|
| `API_STYLE` (`rest`/`graphql`/`grpc`/`trpc`/`events`) | `rest` |

## References

- `references/extraction-by-style.md` — where the authoritative
  contract lives per API style (OpenAPI, GraphQL schema, proto,
  tRPC routers, topic schemas).
- `references/completeness-checklist.md` — the per-endpoint
  completeness items, the brownfield tagging rule, and the
  coverage summary.
