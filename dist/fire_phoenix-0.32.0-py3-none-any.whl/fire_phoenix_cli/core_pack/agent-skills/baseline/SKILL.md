---
name: baseline
description: 'Snapshots requirements, design, or test artefacts as a named, immutable baseline under docs/baselines/ and tags the git repo. Pairs with change-control: the baseline is the ''from'' state a change request references. Use after a phase-gate passes or when a CCB needs a reference snapshot.'
license: MIT
compatibility: Designed for agentskills.io-compatible agents.
metadata:
  author: Dau Quang Thanh
  version: '1.0'
  requires: []
---

## User Input

```text
$ARGUMENTS
```

Consider the user input before proceeding (if not empty). If the
argument names a baseline type (e.g. `requirements`, `design`,
`test`, `release`) or a label (e.g. `v1.0-srs`), use it directly.

## Audience and tone (interactive mode)

**Register first — adapt to role level.** Before applying the beginner floor
below, resolve the reader's level from the merged `.fire-phoenix/context.yml`
+ `.fire-phoenix/user-context.yml` (`user-context.yml` wins): use
`preferences.tech_role_level` for technical work (`junior` → hand-hold, one
path; `mid` → ≥2 options with one-line trade-offs; `senior` → defer on
judgment, surface edge cases, be brief; `staff` → be terse, challenge
premises, skip obvious caveats) and `preferences.non_tech_role_level` for
stakeholder work (`non-technical` → outcomes not jargon; `familiar` → simple
jargon glossed; `fluent` → concepts without explanation; `technical` → full
vocabulary). An explicit in-session signal (e.g. "be terse", "skip the
explanation") overrides everything. The plain-English, one-question-at-a-time
floor below applies **only when the relevant level is unset**; never treat
role level as a gate. Full rule: `.fire-phoenix/references/subagents/register-resolution.md`.

When `FIRE_PHOENIX_AGENT_MODE=interactive` (the default), assume the user
has **limited technical background and limited domain knowledge**.
Run this skill as a guided questionnaire:

- **One question at a time.** No walls of questions.
- **Yes / no first.** Phrase so `yes`, `no`, `not sure`, or `skip`
  is a valid answer.
- **Translate jargon, don't strip it.** Explain baseline, freeze,
  git tag, change-control reference on first use.
- **Choices, not blank fields.** Offer lettered options (A/B/C/D).
  Always include "Not sure — sensible default".
- **Always recommend.** State which option you would pick and why.
- **Show, don't ask.** Pre-fill from upstream artefacts.
- **`not sure` / `skip` triggers a sensible default**, marked
  "(default applied)" and a BASEDEBT entry.

When `FIRE_PHOENIX_AGENT_MODE=auto`, skip the questionnaire and log
decisions.

## Baseline types

| Type | Artefacts included | When to use |
|---|---|---|
| `requirements` | srs.md, all intent.md files, srs.extract | After SRR gate passes |
| `design` | srs.md, all design/*.md, ADRs, C4 diagrams | After CDR gate passes |
| `test` | test-strategy, test-cases, quality-gates | After TRR gate passes |
| `release` | all of the above + tasks, deployment-strategy | After ORR / Go-Live gate |
| `custom` | user-specified list of files | Any point in time |

## Inputs

- `.fire-phoenix/context.yml`
- Source artefacts for the chosen baseline type (see table above)
- `{context.paths.docs}/project/project-plan.extract` —
  project name, revision context
- Git repository state (commit SHA, current branch)

## Outputs

- `{context.paths.docs}/baselines/<label>/manifest.md` — manifest
  listing every snapshotted file with its SHA-256 hash, source path,
  and baseline date
- `{context.paths.docs}/baselines/<label>/manifest.extract` —
  companion KEY=VALUE ledger
  (BASELINE_LABEL, BASELINE_TYPE, BASELINE_DATE, GIT_TAG, FILE_COUNT)
- Frozen copies of all included artefacts placed under
  `{context.paths.docs}/baselines/<label>/artefacts/`
- A git tag `baseline/<label>` pointing at the current HEAD

## Context Update

Does not mutate `.fire-phoenix/context.yml`.

## Handoffs

- `change-control` references the baseline label in every
  change request to indicate which version is being changed.
- `phase-gate` can call this skill at the end of a gate
  checklist to freeze the deliverables.
- `status-report` mentions the active baseline label in the
  project status narrative.

## AI authoring scope

**Does:**

- Determine which files to include based on baseline type.
- Compute SHA-256 hashes of each file.
- Copy artefacts under the baseline directory.
- Write the manifest.
- Instruct the user to run the git tag command (or run it if the
  user confirms git write permission).

**Does not:**

- Modify any source artefact.
- Force-push tags or alter existing baselines.
- Delete old baselines.

## Re-baseline triggers

A baseline is immutable — it is never edited, only **superseded**
by a new one whose manifest names its predecessor. Re-baseline
when any of these fires:

- An approved change request records the **re-plan** disposition
  (H scope / schedule impact, a moved milestone, or an altered
  Definition of Done — see the change-control skill's decision
  guide).
- A phase gate passes and freezes a new artefact set (SRR → new
  requirements baseline, CDR → design, and so on).
- The plan is re-run for any reason and downstream skills would
  otherwise compare against a stale "from" state.

Absorbed changes (M-or-below impact) do **not** re-baseline; they
accumulate against the current one.

## Baseline vs. actual

The baseline earns its keep at review time. When comparing:

- Diff the current artefacts against the frozen copies under
  `artefacts/` (hashes in the manifest make drift detection
  mechanical); every difference must trace to an approved CR in
  the change log. **Unexplained drift is a finding** — either an
  unlogged change or a tampered artefact; raise a BASEDEBT and
  surface it, never quietly re-freeze.
- Report variance against the **baseline** the work was committed
  under, not against the latest re-plan — otherwise every re-plan
  silently resets the score.

## Outline

1. **Determine baseline type and label**:
   - From user input, or ask:
     A) requirements, B) design, C) test, D) release, E) custom.
   - Label default: `<type>-v<date>` (e.g. `requirements-v2026-05-01`).

2. **Collect file list** — based on type, resolve the list of
   files to snapshot. In interactive mode, show the list and ask
   for confirmation or additions.

3. **Verify files exist** — for any missing file, raise a BASEDEBT
   entry and ask whether to proceed without it.

4. **Copy artefacts** to `docs/baselines/<label>/artefacts/`
   preserving relative paths.

5. **Write manifest** — one row per file: source path, destination
   path, SHA-256, size.

6. **Git tag** — output the exact command the user should run:

   ```sh
   git tag -a baseline/<label> -m "Baseline <label> — <type> phase"
   ```

   In auto mode with `BASELINE_GIT_TAG_AUTO=true`, run the command
   directly.

7. **Write outputs** — manifest.md, manifest.extract.

8. **Summary** — print:
   - Baseline label, type, date, file count.
   - Git tag command (if not auto-run).
   - Next suggested action.

## Usage

> `<SKILL_DIR>` = the integration's skills root.

```bash
BASELINE_TYPE="requirements" \
BASELINE_LABEL="requirements-v2026-05-01" \
BASELINE_GIT_TAG_AUTO=false \
  bash <SKILL_DIR>/baseline/scripts/bash/create-baseline.sh --auto
```

### Answer keys

| Key | Meaning | Default |
|---|---|---|
| `BASELINE_TYPE` | `requirements` / `design` / `test` / `release` / `custom` | *(required)* |
| `BASELINE_LABEL` | Directory / tag name | `<type>-v<YYYY-MM-DD>` |
| `BASELINE_GIT_TAG_AUTO` | `true` / `false` — create git tag automatically | `false` |
| `BASELINE_EXTRA_FILES` | Colon-separated extra file paths to include | *(empty)* |
