---
name: observability-plan
description: Drafts the observability plan — logs, metrics, traces, SLIs/SLOs,
  alerts, dashboards. Produces a design doc + starter
  dashboard/alert YAML. Does not provision monitoring. Use when
  setting up monitoring for a project, defining SLOs/SLIs, or
  planning alerting and observability strategy.
license: MIT
compatibility: Designed for agentskills.io-compatible agents.
metadata:
  author: Dau Quang Thanh
  version: '1.0'
  requires: []
---

## User Input

```text
$ARGUMENTS
```

## Audience and tone (interactive mode)

**Register first — adapt to role level.** Before applying the beginner floor
below, resolve the reader's level from the merged `.fire-phoenix/context.yml`
+ `.fire-phoenix/user-context.yml` (`user-context.yml` wins): use
`preferences.tech_role_level` for technical work (`junior` → hand-hold, one
path; `mid` → ≥2 options with one-line trade-offs; `senior` → defer on
judgment, surface edge cases, be brief; `staff` → be terse, challenge
premises, skip obvious caveats) and `preferences.non_tech_role_level` for
stakeholder work (`non-technical` → outcomes not jargon; `familiar` → simple
jargon glossed; `fluent` → concepts without explanation; `technical` → full
vocabulary). An explicit in-session signal (e.g. "be terse", "skip the
explanation") overrides everything. The plain-English, one-question-at-a-time
floor below applies **only when the relevant level is unset**; never treat
role level as a gate. Full rule: `.fire-phoenix/references/subagents/register-resolution.md`.

When `FIRE_PHOENIX_AGENT_MODE=interactive` (the default), assume the user
has **limited technical background and limited domain knowledge**
— they may know basics but lack deep expertise in this skill's
area. Run this skill as a guided questionnaire:

- **One question at a time.** No walls of questions.
- **Yes / no first.** Phrase so `yes`, `no`, `not sure`, or `skip`
  is a valid answer.
- **Translate jargon, don't strip it.** Use the technical term but
  always pair it with a plain-English gloss the first time it
  appears.
- **Choices, not blank fields.** When yes/no isn't enough, offer
  2-4 lettered options (A/B/C/D) with one-line plain-language
  descriptions of the trade-off. Always include "Not sure — pick
  a sensible default".
- **Always recommend.** State the option you would pick and why in
  one sentence so the user can reply "yes" / "ok" to accept. Pull
  defaults from upstream artefacts (spec, architecture, ADRs,
  standards) before asking blank.
- **Show, don't ask.** When upstream artefacts already imply an
  answer, propose it as a pre-filled finding and ask for a
  yes / no confirmation rather than asking the user to fill in a
  blank.
- **`not sure` / `skip` triggers a sensible default**, marked
  "(default applied — confirm later)" in the artefact, and a debt
  entry in this skill's debt file.

When `FIRE_PHOENIX_AGENT_MODE=auto` (or `--auto`), skip the questionnaire
entirely: apply sensible defaults from upstream artefacts and log
decisions to the parent agent's decision log.

## Inputs

- `.fire-phoenix/context.yml`
- `{context.paths.docs}/architecture/intake.md` (SLA)
- `{context.paths.docs}/architecture/c4-container.md`

## Outputs

- `{context.paths.docs}/operations/monitoring.md`
- `assets/alerts.sample.yml` — alert rules starter
- `assets/dashboard.sample.json` — dashboard starter

## Context Update

Does not mutate `.fire-phoenix/context.yml`.

## Handoffs

- `deployment-strategy` reads SLI/SLO to set deploy-time canary bake.
- `cicd-pipeline` reads alert definitions to wire post-deploy checks.

## AI authoring scope

**Does:** design three pillars (logs / metrics / traces), propose
SLIs (request latency, error rate, saturation, duration) + SLOs
aligned with the intake SLA, draft alert thresholds.

**Does not:** provision dashboards or alerts; page on-call;
modify infra.

## SLI selection and alert quality

Select SLIs per service type using the checklist in
`references/sli-slo-basics.md` (availability / latency for
request-driven, freshness / correctness / completion for
pipelines and jobs — qualitative sets, 2-4 per service). Every
service on the C4 diagram is either measured or the plan says why
not.

Every alert passes the rules in `references/alert-quality.md`:
actionable, runbook-linked by name, page-vs-ticket separated, and
burn-rate based where an SLO exists. **Thresholds are user
decisions** — the skill proposes candidates marked "(default
applied — confirm later)"; the user's confirmed value is logged
as a decision, never invented. Note next to each alert which
intent artefact a repeat firing feeds (incident → intent loop).

## Usage

> `<SKILL_DIR>` = the integration's skills root (e.g. `.claude/skills/`
> for Claude Code, `.codex/skills/` for Codex,
> `.cursor/skills/` for Cursor, `.kiro/skills/` for Kiro).
> Scripts live at `<SKILL_DIR>/<skill-name>/scripts/…`.

```bash
MON_STACK=otel bash <SKILL_DIR>/observability-plan/scripts/bash/draft-monitoring.sh --auto
```

### Answer keys

| Key | Default |
|---|---|
| `MON_STACK` (`otel`/`datadog`/`newrelic`/`cloudwatch`/`prometheus-grafana`) | `otel` |
| `MON_SLO_AVAILABILITY` | `99.9` |
| `MON_SLO_P95_MS` | `300` |
