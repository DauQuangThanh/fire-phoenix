# Review dimensions — per-dimension checklists

One pass per dimension, in this order. The first five mirror the
project standards established via `standardize` (the standards
file at `{context.paths.docs}/standards.md` wins where it sets
different thresholds). Report the three worst offenders per
dimension, not every hit — the goal is action, not noise.

## 1. Simplicity and dead code

- [ ] No abstraction (helper, layer, framework) without at least
      two concrete call sites that need it today.
- [ ] No "just in case" branches, unused parameters, unused
      exports, or configuration knobs no requirement asks for.
- [ ] Dead code, commented-out code, and obsolete feature flags
      deleted, not preserved — version history is the archive.
- [ ] The change takes the simplest path that satisfies the
      stated requirement; cleverness needs a justification.

## 2. Unit size and complexity

- [ ] Functions fit on one screen and stay under the project's
      cyclomatic threshold (see
      `references/complexity-thresholds.md` for the bands).
- [ ] Each function does one thing — needing "and" to describe
      it is a split signal.
- [ ] Nesting depth within the green band; deeper is a refactor
      signal, not a style preference.
- [ ] A module's public surface is the smallest set of names its
      callers need; everything else private.

## 3. Purity and side-effect isolation

- [ ] Business logic is pure: same inputs, same outputs. IO,
      clock, randomness, and process state are injected, not
      reached for via globals.
- [ ] Functions whose behaviour depends on time / randomness /
      environment accept a clock / RNG / config so tests can
      substitute fakes.
- [ ] No shared mutable state across modules without an explicit,
      documented justification.
- [ ] Side-effects live at the edges (adapters, gateways), not
      interleaved with domain logic.

## 4. Refactoring debt

- [ ] The touched code is at least as simple after the change as
      before it.
- [ ] New complexity (abstraction, dependency, knob, oversized
      function) is justified by a concrete requirement, not
      anticipation.
- [ ] TODO / FIXME markers link to a tracked item; they are not
      the canonical record of debt.
- [ ] Behaviour-preserving refactors are separated from behaviour
      changes; tests were not rewritten to make a refactor pass.

## 5. Readability

- [ ] Names say what things are for; no abbreviations a newcomer
      must decode.
- [ ] Control flow reads top-to-bottom; early returns beat arrow
      nesting.
- [ ] Comments explain *why*, not *what*; a comment restating the
      code is noise, a comment excusing a hack is a finding.
- [ ] Magic numbers and strings are named constants where they
      carry meaning.

## 6. Duplication

- [ ] No **knowledge duplication**: two places that would both
      change in response to the same business rule (see
      `references/solid-dry-kiss.md` — text similarity alone is
      not a violation).
- [ ] Copy-pasted blocks with small edits are flagged with the
      shared abstraction outlined — but only when the third use
      case exists (dimension 1 wins otherwise).
- [ ] Duplicated validation or error handling across entry points
      is a finding: the copies will drift.
