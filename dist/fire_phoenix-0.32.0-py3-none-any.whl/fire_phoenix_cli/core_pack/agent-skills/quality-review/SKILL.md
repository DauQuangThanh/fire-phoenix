---
name: quality-review
description: Reviews a feature's code for maintainability, SOLID/DRY compliance, cyclomatic complexity, and project-standards adherence. Produces a feature-scoped review with findings, severity, and recommended fixes. Does not modify code. Use when reviewing code quality or doing a pre-merge review.
license: MIT
compatibility: Designed for agentskills.io-compatible agents.
metadata:
  author: Dau Quang Thanh
  version: '1.0'
  requires: []
---

## User Input

```text
$ARGUMENTS
```

## Audience and tone (interactive mode)

**Register first — adapt to role level.** Before applying the beginner floor
below, resolve the reader's level from the merged `.fire-phoenix/context.yml`
+ `.fire-phoenix/user-context.yml` (`user-context.yml` wins): use
`preferences.tech_role_level` for technical work (`junior` → hand-hold, one
path; `mid` → ≥2 options with one-line trade-offs; `senior` → defer on
judgment, surface edge cases, be brief; `staff` → be terse, challenge
premises, skip obvious caveats) and `preferences.non_tech_role_level` for
stakeholder work (`non-technical` → outcomes not jargon; `familiar` → simple
jargon glossed; `fluent` → concepts without explanation; `technical` → full
vocabulary). An explicit in-session signal (e.g. "be terse", "skip the
explanation") overrides everything. The plain-English, one-question-at-a-time
floor below applies **only when the relevant level is unset**; never treat
role level as a gate. Full rule: `.fire-phoenix/references/subagents/register-resolution.md`.

When `FIRE_PHOENIX_AGENT_MODE=interactive` (the default), assume the user
has **limited technical background and limited domain knowledge**
— they may know basics but lack deep expertise in this skill's
area. Run this skill as a guided questionnaire:

- **One question at a time.** No walls of questions.
- **Yes / no first.** Phrase so `yes`, `no`, `not sure`, or `skip`
  is a valid answer.
- **Translate jargon, don't strip it.** Use the technical term but
  always pair it with a plain-English gloss the first time it
  appears.
- **Choices, not blank fields.** When yes/no isn't enough, offer
  2-4 lettered options (A/B/C/D) with one-line plain-language
  descriptions of the trade-off. Always include "Not sure — pick
  a sensible default".
- **Always recommend.** State the option you would pick and why in
  one sentence so the user can reply "yes" / "ok" to accept. Pull
  defaults from upstream artefacts (spec, architecture, ADRs,
  standards) before asking blank.
- **Show, don't ask.** When upstream artefacts already imply an
  answer, propose it as a pre-filled finding and ask for a
  yes / no confirmation rather than asking the user to fill in a
  blank.
- **`not sure` / `skip` triggers a sensible default**, marked
  "(default applied — confirm later)" in the artefact, and a debt
  entry in this skill's debt file.

When `FIRE_PHOENIX_AGENT_MODE=auto` (or `--auto`), skip the questionnaire
entirely: apply sensible defaults from upstream artefacts and log
decisions to the parent agent's decision log.

## Inputs

- `.fire-phoenix/context.yml`
- Source files changed for `current.feature`
- `{context.paths.docs}/architecture/intake.md`
- Project standards (from `standardize` output)

## Outputs

- `{context.paths.docs}/reviews/<feature>/quality.md`
- `{context.paths.docs}/reviews/<feature>/quality.extract`

## Context Update

Does not mutate `.fire-phoenix/context.yml`.

## Handoffs

- `bug-fixer` reads findings with severity ≥ High to drive fixes.
- `standardize` is updated when recurring violations indicate
  a missing standard.

## AI authoring scope

**Does:** read source files, cite exact file:line refs for each
finding, score complexity, flag SOLID/DRY/Fire Phoenix violations, propose
a fix outline per finding.

**Does not:** refactor code (bug-fixer / developer applies fixes),
assign findings to individuals.

## Review flow

1. **Scope** — resolve `QR_SCOPE` and the project standards
   (from `standardize`); record what is in and out of scope.
2. **Walk the dimensions** — one pass per dimension per
   `references/review-dimensions.md`: simplicity / dead code,
   unit size / complexity, purity / side-effect isolation,
   refactoring debt, readability, duplication. Every candidate
   finding gets a `file:line`.
3. **Verification pass** — before a candidate becomes a reported
   finding, re-read its code path end to end. A framework- or
   tooling-level mitigation kills the finding: a "long function"
   that is generated code, a "duplicate" the type system derives,
   a "magic number" the framework mandates. Record the outcome
   per finding: **verified** (code path re-read, the smell is
   real) or **unverified** (state why it could not be confirmed).
   Drop candidates a real mitigation covers — do not report them
   "to be safe".
4. **Severity** — assign qualitative bands (High / Medium / Low
   per `references/solid-dry-kiss.md` §When to flag). The band
   discipline mirrors the security reviewer's rubric
   (`security-review/references/severity-rubric.md`): defensible
   qualitative bands, never invented numeric scores; effort to
   fix and authorship never change severity.
5. **Write the artefact** — fill every section of the template;
   each High / Medium finding carries a fix outline and lands in
   `quality-debts.md` as a `CQDEBT-` entry.

## Usage

> `<SKILL_DIR>` = the integration's skills root (e.g. `.claude/skills/`
> for Claude Code, `.codex/skills/` for Codex,
> `.cursor/skills/` for Cursor, `.kiro/skills/` for Kiro).
> Scripts live at `<SKILL_DIR>/<skill-name>/scripts/…`.

```bash
QR_SCOPE="src/**/*.ts" bash <SKILL_DIR>/quality-review/scripts/bash/review.sh --auto
```

### Answer keys

| Key | Meaning | Default |
|---|---|---|
| `QR_SCOPE` | glob of files to review | `src/**` |
| `QR_MAX_CYCLOMATIC` | threshold for complexity finding | `10` |
| `QR_MAX_FUNCTION_LINES` | threshold for long-function finding | `50` |

## References

- `references/solid-dry-kiss.md` — canonical definitions + smell
  signals + the High / Medium / Low flagging bands.
- `references/complexity-thresholds.md` — per-language guidance.
- `references/review-dimensions.md` — per-dimension checklists
  (simplicity / dead code, unit size / complexity, purity /
  side-effect isolation, refactoring debt, readability,
  duplication).
- `security-review/references/severity-rubric.md` (sibling skill)
  — the band discipline this skill mirrors: qualitative bands,
  no invented numbers.
