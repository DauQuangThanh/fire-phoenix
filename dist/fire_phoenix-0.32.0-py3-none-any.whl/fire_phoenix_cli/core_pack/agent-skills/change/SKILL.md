---
name: change
description: Dispatches one change-workflow verb (new, intent, design, tasks, implement, verify, archive, baseline) to its step over a living baseline. Use to drive any unit of work — feature, bug, refactor, migration slice — through the unified spine instead of separate slash commands.
license: MIT
compatibility: Designed for agentskills.io-compatible agents.
metadata:
  author: Dau Quang Thanh
  version: '1.0'
  requires: []
---

## User Input

```text
$ARGUMENTS
```

The first token of `$ARGUMENTS` is the **verb**; the rest is that verb's input.
You **MUST** parse the verb before doing anything. If `$ARGUMENTS` is empty or the
verb is unknown, print the verb list from the Routing table and stop.

## What this skill is

`change` is the **single command surface** for the Living Baseline + Intent Delta
workflow (adr/0049). Every unit of work is a change delta under
`{context.paths.docs}/changes/<id>/` that folds into `{context.paths.docs}/baseline/`
on archive. This dispatcher is a **thin router** (migration stage 2): it maps each
verb to the step that owns it and hands off. It does **not** reimplement the spine —
it routes to the existing skills, so behaviour is unchanged.

> Not yet active (later migration stages): blast-radius **classification** at `new`
> (stage 3), **fold-on-archive** at `archive` (stage 4), and the headless engine
> executing these same verbs (stage 5). Where a verb's full behaviour is deferred,
> this skill does the thin part and says so.

## Routing table

| Verb | Routes to | Does now (stage 2) |
|---|---|---|
| `new <id>` | — (new) | Scaffold `{context.paths.docs}/changes/<id>/` with `intent.md`, `design.md`, `tasks.md`, `spec-delta.md` skeletons. **Classify the blast-radius lane** (see below), write it to `changes/<id>/lane`, and set `{context.current.feature}` to `<id>`. Then, per `adr/0064`, do not leave the `intent.md` skeleton empty: in interactive mode offer to run `intent` now; in auto mode run it. |
| `intent` | `intent` skill | Follow the `intent` skill against the current delta's `intent.md`. |
| `recover` | `recover-intent` (+ `recover-spec`) | Brownfield/migration bootstrap (`adr/0064`): reconstruct L1 product intent from a supplied document (`recover-intent`) and L2 spec from a named legacy module (`recover-spec`), each row tagged OBSERVED/INFERRED/UNKNOWN. Use when code exists but no intent/baseline does. |
| `design` | `plan` skill | Follow the `plan` skill (technical approach + EARS) against `design.md`. |
| `tasks` | `taskify` skill | Follow the `taskify` skill against `tasks.md`. |
| `implement` | `implement` skill | Follow the `implement` skill. |
| `verify` | `verify-tasks` skill | Follow the `verify-tasks` skill (every AC has a covering check). |
| `analyze` | `fire-phoenix change analyze <id>` | Read-only cross-artifact consistency gate — AC→task coverage, orphan tasks, unresolved placeholders, missing artifacts (severity-tiered). Run before `implement`; fix CRITICAL/HIGH findings first. |
| `status` | `fire-phoenix change status [<id>]` | Report which delta artifacts exist, the lane, baseline capability count, and the next verb. Ask the tool "where am I / what's next" instead of guessing. |
| `archive` | `fire-phoenix change archive <id>` | **Fold** the delta's `spec-delta.md` into `{context.paths.docs}/baseline/` (one file per capability; last-fold-wins, conflicts flagged) and move the delta to `changes/archive/<date>-<id>/`. Run the command — do not hand-fold. |
| `baseline [query]` | — (new) | Read `{context.paths.docs}/baseline/` (one `<cap-id>.md` file per capability) and report what the system does today, optionally filtered by `query`. Surface any `baseline/.conflicts/` for the approver. |

## Dispatch protocol

1. Parse `verb` = first token, `rest` = remainder of `$ARGUMENTS`.
2. Look the verb up in the Routing table.
3. **Intent gate (`adr/0064`)** — for the downstream routing verbs (`design`,
   `tasks`, `implement`, `verify`), first confirm a usable intent exists. The
   mapped skill's prerequisite script exits 3 with `FIRE_PHOENIX_BOOTSTRAP=intent|recover`
   (or call the `fire_phoenix_intent_status` helper) when it does not. On `absent-*`,
   **bootstrap first**: route to `intent` (greenfield) or `recover` (brownfield) —
   in interactive mode confirm with the user ("No intent found for this feature —
   start by developing it?"), in auto mode proceed and log — then resume the
   originally requested verb. Never run `design`/`tasks`/`implement`/`verify` while
   intent is absent.
4. **Routing verbs** (`intent`, `recover`, `design`, `tasks`, `implement`, `verify`):
   carry out that step by following the mapped skill's instructions (installed as its
   own slash command) with `rest` as its input. Do not duplicate its logic here.
5. **New verbs** (`new`, `archive`, `baseline`): perform the "Does now" column
   directly. Never touch the network. Honour
   `{context.preferences.confirm_before_write}` before writing files.
6. Unknown/empty verb: print the verb list and stop — do not guess.

## Blast-radius classification (verb `new`)

When `change new <id>` runs, classify the change into ONE lane from its intent.
**Bias toward the more severe lane when signals conflict** — over-ceremonying a
trivial change is cheap; under-governing a risky one is not.

| Lane | Signals |
|---|---|
| `mechanical` | typo, comment/docstring, wording, formatting, one-line, rename a local — no behaviour change. |
| `routine` | add/fix a single localized feature, flag, field, endpoint, helper. |
| `consequential` | multi-file; touches a production path, an integration/provider, the installer, or the workflow engine; a public interface. |
| `critical` | new system, platform/architecture decision, an ADR, a schema/state-format break, a security boundary, a migration cutover/decommission, removing a provider — anything irreversible. |

**Override (required, logged).** Show the proposed lane and let the user accept or
**change it in either direction** (a "typo in the installer" is still mechanical
even though it touches a production path). Write the final lane to
`changes/<id>/lane`. If the user overrides, log the override + their reason via the
`record_decision` helper (a pending draft) and promote it with the `promote-governance`
skill (adr/0053) — never hand-write `{context.governance.decisions_file}`. Never
silently keep a lane the user rejected.

## Lane → gate activation

The lane activates the spine steps + gates automatically (adr/0049 §4.4):

| Lane | Active gates | Approval |
|---|---|---|
| `mechanical` | G3 | single approver |
| `routine` | G0, G3 | single approver |
| `consequential` | G0, G1 (advisory), G2, G3 | single approver + advisory three-amigos |
| `critical` | G0, G1 (**required**), G2, G3 + spec-delta review | **graduated** (adr/0050) |

- **G0** intent + acceptance agreed. **G1** three-amigos (dev feasibility, tester
  testability, PO business fit). **G2** design/plan approved before decomposition.
  **G3** every AC has a covering check (lint-enforced by `fire-phoenix check ac`).
- **Graduated approval (critical only, adr/0050):** the change cannot be signed off
  without recorded dev/tester/PO confirmations. Record them via `record_decision`
  (kind `critical-signoff`, a pending draft) and promote with the `promote-governance`
  skill (adr/0053) — the promoted entry lands under a decisions-file heading naming
  the change and reading `Critical sign-off`, e.g.:

  ```
  ## <date> — <id> Critical sign-off (adr/0050)
  - Dev (feasibility): <name> — confirmed
  - Tester (testability): <name> — confirmed
  - PO (business fit): <name> — confirmed
  ```

  `fire-phoenix check approval --change <id>` enforces this. Non-critical lanes
  pass on the single-approver floor (adr/0012).

> Rigor is now a property of the change's lane, not a preset someone selects. The
> `lean`/`scaffold`/`self-test` presets map to default lanes and are **deprecated**
> in favour of classification.

## spec-delta.md format (folded on `archive`)

`change new` scaffolds `spec-delta.md`; fill it as the change proceeds. Three
sections — the fold (`fire-phoenix change archive`) applies them to `baseline/`:

```
# Spec delta — <id>

## Added
- <cap-id>: <one-line capability statement>

## Modified
- <cap-id>: <new statement>

## Removed
- <cap-id>
```

Each `<cap-id>` becomes one `baseline/<cap-id>.md` file. A fold conflict
(add-exists / modify-absent / remove-absent) is applied last-fold-wins and flagged
under `baseline/.conflicts/` for the approver — never resolved silently.

## Inputs

- `$ARGUMENTS` — `<verb> [verb-specific input]`.
- The current delta id from `{context.current.feature}` when a verb operates on the
  in-flight change (all verbs except `new`, which sets it).
- The living baseline at `{context.paths.docs}/baseline/` (read by `baseline`).

## Outputs

- For `new`: a scaffolded `{context.paths.docs}/changes/<id>/` delta folder.
- For routing verbs: whatever the mapped skill produces (unchanged), located in the
  current delta.
- For `archive`: the delta relocated under `{context.paths.docs}/changes/archive/`.
- For `baseline`: a read-only report of current system capabilities.

## Context Update

- `new` sets `{context.current.feature}` to `<id>` (the active delta).
- Routing verbs update the same current-work cursors their underlying skill
  updates (e.g. `{context.current.intent}`, `{context.current.plan}`,
  `{context.current.task}`) — this dispatcher adds no extra state.
- `archive` clears `{context.current.feature}` once the delta is moved.

## Handoffs

- `new` → `change intent` (agree the intent + acceptance criteria).
- `intent` → `change design` (consequential+) or `change tasks` (routine).
- `design` → `change tasks`; `tasks` → `change implement`; `implement` →
  `change verify`; `verify` → `change archive`.
- `archive` → `baseline` (confirm the current-truth surface once fold lands).
