---
name: feature-checklist
description: Generates a custom checklist for the current feature based on user
  requirements, validating quality and completeness of requirements
  in a given domain. Use when reviewing feature completeness, running
  pre-implementation checks, or verifying that requirements meet
  acceptance standards.
license: MIT
compatibility: Designed for agentskills.io-compatible agents.
metadata:
  author: Dau Quang Thanh
  version: '1.0'
  requires: [plan]
  scripts:
    sh: scripts/bash/check-prerequisites.sh --json
    ps: scripts/powershell/check-prerequisites.ps1 -Json
---

## Checklist Purpose: "Unit Tests for English"

**CRITICAL CONCEPT**: Checklists are **UNIT TESTS FOR REQUIREMENTS WRITING** - they validate the quality, clarity, and completeness of requirements in a given domain.

Every item tests the requirements themselves — NOT whether the
implementation works. If unsure whether an item tests requirements
or implementation, read `references/item-examples.md` (✅/❌
catalogues); skip it when the distinction is clear.

**Metaphor**: If your spec is code written in English, the checklist is its unit test suite. You're testing whether the requirements are well-written, complete, unambiguous, and ready for implementation - NOT whether the implementation works.

## Milestone / DoD and ceremony-prep checklists

The project-manager and scrum-master agents also use this skill
for **milestone, Definition-of-Done, and ceremony-prep**
checklists (domains B–D in the interactive questionnaire). These
are a deliberate second mode: they check **delivery completeness
with evidence**, not requirements wording, so the
"unit tests for English" rules above govern only the
requirements-quality domain. When building a delivery checklist
(domains B–D), read `references/dod-anatomy.md` and follow it
instead — falsifiable claim + named evidence per item, evidence
sources, DoD inheritance, and the unticked-item rule. Do
not read it for requirements-quality (domain A) checklists.

Everything else in this skill (questionnaire, file handling, CHK
numbering, template structure) applies to both modes.

## User Input

```text
$ARGUMENTS
```

You **MUST** consider the user input before proceeding (if not empty).

## Audience and tone (interactive mode)

**Register first — adapt to role level.** Before applying the beginner floor
below, resolve the reader's level from the merged `.fire-phoenix/context.yml`
+ `.fire-phoenix/user-context.yml` (`user-context.yml` wins): use
`preferences.tech_role_level` for technical work (`junior` → hand-hold, one
path; `mid` → ≥2 options with one-line trade-offs; `senior` → defer on
judgment, surface edge cases, be brief; `staff` → be terse, challenge
premises, skip obvious caveats) and `preferences.non_tech_role_level` for
stakeholder work (`non-technical` → outcomes not jargon; `familiar` → simple
jargon glossed; `fluent` → concepts without explanation; `technical` → full
vocabulary). An explicit in-session signal (e.g. "be terse", "skip the
explanation") overrides everything. The plain-English, one-question-at-a-time
floor below applies **only when the relevant level is unset**; never treat
role level as a gate. Full rule: `.fire-phoenix/references/subagents/register-resolution.md`.

When `FIRE_PHOENIX_AGENT_MODE=interactive` (the default), assume the user
has **no technical or business-domain background** and run this
skill as a guided questionnaire. Before asking the user anything,
read `references/interactive-questionnaire.md` (conversational
rules, domain phrasing, `not sure` / `skip` handling). Do not read
it in auto mode.

When `FIRE_PHOENIX_AGENT_MODE=auto` (or `--auto`), skip the questionnaire
entirely: pick a sensible domain from upstream artefacts and
generate the checklist; log decisions to the parent agent's
decision log.

## Pre-Execution Checks

**Check for extension hooks (before checklist generation)**:

- If `.fire-phoenix/extensions.yml` does not exist in the project
  root, skip silently.
- If it exists, read `references/extension-hooks.md` §Pre-execution
  and apply the hook protocol there against the
  `hooks.before_checklist` key before proceeding to the Execution
  Steps.

## Execution Steps

1. **Setup**: Run `{SCRIPT}` from repo root and parse JSON for FEATURE_DIR and AVAILABLE_DOCS list.
   - All file paths must be absolute.
   - For single quotes in args like "I'm Groot", use escape syntax: e.g 'I'\''m Groot' (or double-quote if possible: "I'm Groot").

2. **Clarify intent (dynamic)**: Derive up to THREE initial contextual clarifying questions (no pre-baked catalog). They MUST:
   - Be generated from the user's phrasing + extracted signals from spec/plan/tasks
   - Only ask about information that materially changes checklist content
   - Be skipped individually if already unambiguous in `$ARGUMENTS`
   - Prefer precision over breadth

   Before formulating or presenting any clarifying question, read
   `references/clarifying-questions.md` (generation algorithm,
   question formatting rules, defaults when interaction is
   impossible, and the Q4/Q5 escalation rule). Skip the reference
   when zero questions are needed because `$ARGUMENTS` is already
   unambiguous, and in auto mode.

3. **Understand user request**: Combine `$ARGUMENTS` + clarifying answers:
   - Derive checklist theme (e.g., security, review, deploy, ux)
   - Consolidate explicit must-have items mentioned by user
   - Map focus selections to category scaffolding
   - Infer any missing context from spec/plan/tasks (do NOT hallucinate)

4. **Load feature context**: Read from FEATURE_DIR:
   - intent.md: Feature requirements and scope
   - plan.md (if exists): Technical details, dependencies
   - tasks.md (if exists): Implementation tasks

   **Context Loading Strategy**:
   - Load only necessary portions relevant to active focus areas (avoid full-file dumping)
   - Prefer summarizing long sections into concise scenario/requirement bullets
   - Use progressive disclosure: add follow-on retrieval only if gaps detected
   - If source docs are large, generate interim summary items instead of embedding raw text

5. **Generate checklist** - Create "Unit Tests for Requirements":
   - Create `FEATURE_DIR/checklists/` directory if it doesn't exist
   - Generate unique checklist filename:
     - Use short, descriptive name based on domain (e.g., `ux.md`, `api.md`, `security.md`)
     - Format: `[domain].md`
   - File handling behavior:
     - If file does NOT exist: Create new file and number items starting from CHK001
     - If file exists: Append new items to existing file, continuing from the last CHK ID (e.g., if last item is CHK015, start new items at CHK016)
   - Never delete or replace existing checklist content - always preserve and append

   **CORE PRINCIPLE - Test the Requirements, Not the Implementation**:
   Every checklist item MUST evaluate the REQUIREMENTS THEMSELVES for:
   - **Completeness**: Are all necessary requirements present?
   - **Clarity**: Are requirements unambiguous and specific?
   - **Consistency**: Do requirements align with each other?
   - **Measurability**: Can requirements be objectively verified?
   - **Coverage**: Are all scenarios/edge cases addressed?

   **Category Structure** - Group items by requirement quality dimensions:
   - **Requirement Completeness** (Are all necessary requirements documented?)
   - **Requirement Clarity** (Are requirements specific and unambiguous?)
   - **Requirement Consistency** (Do requirements align without conflicts?)
   - **Acceptance Criteria Quality** (Are success criteria measurable?)
   - **Scenario Coverage** (Are all flows/cases addressed?)
   - **Edge Case Coverage** (Are boundary conditions defined?)
   - **Non-Functional Requirements** (Performance, Security, Accessibility, etc. - are they specified?)
   - **Dependencies & Assumptions** (Are they documented and validated?)
   - **Ambiguities & Conflicts** (What needs clarification?)

   **ITEM STRUCTURE**:
   Each item should follow this pattern:
   - Question format asking about requirement quality
   - Focus on what's WRITTEN (or not written) in the spec/plan
   - Include quality dimension in brackets [Completeness/Clarity/Consistency/etc.]
   - Reference spec section `[Spec §X.Y]` when checking existing requirements
   - Use `[Gap]` marker when checking for missing requirements

   **Scenario Classification & Coverage** (Requirements Quality Focus):
   - Check if requirements exist for: Primary, Alternate, Exception/Error, Recovery, Non-Functional scenarios
   - For each scenario class, ask: "Are [scenario type] requirements complete, clear, and consistent?"
   - If scenario class missing: "Are [scenario type] requirements intentionally excluded or missing? [Gap]"
   - Include resilience/rollback when state mutation occurs: "Are rollback requirements defined for migration failures? [Gap]"

   **Traceability Requirements**:
   - MINIMUM: ≥80% of items MUST include at least one traceability reference
   - Each item should reference: spec section `[Spec §X.Y]`, or use markers: `[Gap]`, `[Ambiguity]`, `[Conflict]`, `[Assumption]`
   - If no ID system exists: "Is a requirement & acceptance criteria ID scheme established? [Traceability]"

   **Surface & Resolve Issues** (Requirements Quality Problems):
   Ask questions about the requirements themselves — ambiguities,
   conflicts, assumptions, dependencies, missing definitions (if
   unsure how to phrase one, see the worked examples in
   `references/item-examples.md`).

   **Content Consolidation**:
   - Soft cap: If raw candidate items > 40, prioritize by risk/impact
   - Merge near-duplicates checking the same requirement aspect
   - If >5 low-impact edge cases, create one item: "Are edge cases X, Y, Z addressed in requirements? [Coverage]"

   **🚫 PROHIBITED / ✅ REQUIRED**: any item starting with
   "Verify", "Test", "Confirm", "Check" + implementation behavior
   is an implementation test and is prohibited; required items ask
   whether requirements are defined, quantified, consistent, and
   measurable. If a drafted item might cross that line, read the
   full catalogues in `references/item-examples.md` §Prohibited /
   §Required patterns; otherwise skip that file.

6. **Structure Reference**: Generate the checklist following the canonical template in `templates/checklist-template.md` for title, meta section, category headings, and ID formatting. If template is unavailable, use: H1 title, purpose/created meta lines, `##` category sections containing `- [ ] CHK### <requirement item>` lines with globally incrementing IDs starting at CHK001.

7. **Report**: Output full path to checklist file, item count, and summarize whether the run created a new file or appended to an existing one. Summarize:
   - Focus areas selected
   - Depth level
   - Actor/timing
   - Any explicit user-specified must-have items incorporated

**Important**: Each `/checklist` command invocation uses a short, descriptive checklist filename and either creates a new file or appends to an existing one. This allows:

- Multiple checklists of different types (e.g., `ux.md`, `test.md`, `security.md`)
- Simple, memorable filenames that indicate checklist purpose
- Easy identification and navigation in the `checklists/` folder

To avoid clutter, use descriptive types and clean up obsolete checklists when done.

## Example Catalogues

When phrasing items for an unfamiliar domain, read
`references/item-examples.md` — per-dimension examples, sample
items per domain, and anti-example CHK lists. Do not read it when
your items already follow the required question form.

## Post-Execution Checks

**Check for extension hooks (after checklist generation)**:

- If `.fire-phoenix/extensions.yml` does not exist in the project
  root, skip silently.
- If it exists, read `references/extension-hooks.md`
  §Post-completion and apply the hook protocol there against the
  `hooks.after_checklist` key.

## Inputs

- **Feature Specification** (`{context.current.intent}`)
  - If set: Read the specification file.
  - If null: Search {context.paths.intents} for the most recent intent.md.
  - If not provided: Ask the user to run /intent first.

## Outputs

- **Checklist File** (`{context.paths.intents}/{context.current.feature}/checklists/{domain}.md`)
  - Behavior: Write the checklist file. If it exists and confirm_before_write is true, ask the user.
  - Overwrite guarded by `{context.preferences.confirm_before_write}`.

## Context Update

This skill does NOT modify `.fire-phoenix/context.yml` or `.fire-phoenix/user-context.yml` (checklists are validation, not workflow progression).
