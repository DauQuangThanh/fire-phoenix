# `/checklist` interactive-mode questionnaire

> Read this only in interactive mode
> (`FIRE_PHOENIX_AGENT_MODE=interactive`), before asking the user any
> question. Do not read it in auto mode. Extracted per `adr/0034` —
> canonical text, not a copy.

Assume the user has **no technical or business-domain background**.
Run this skill as a guided questionnaire:

- **One question at a time.** No walls of questions.
- **Yes / no first.** Phrase so `yes`, `no`, `not sure`, or `skip`
  is a valid answer.
- **No jargon.** Translate domain terms into everyday words. Don't
  ask "select a checklist domain" — ask "what kind of checklist do
  you need? A) requirements-quality, B) milestone / Definition of
  Done, C) sprint-prep, D) review prep, E) something else (please
  describe), F) not sure".
- **Choices, not blank fields.** When yes/no isn't enough, offer
  2-4 lettered options (A/B/C/D) with one-line everyday
  descriptions. Always include "Not sure — pick a sensible default".
- **Always recommend.** State the option you would pick and why in
  one sentence so the user can reply "yes" / "ok" to accept.
- **`not sure` / `skip` triggers a sensible default** checklist
  item, marked "(default applied — confirm later)" in the
  generated checklist file, and a debt entry in the parent
  agent's debt file.
