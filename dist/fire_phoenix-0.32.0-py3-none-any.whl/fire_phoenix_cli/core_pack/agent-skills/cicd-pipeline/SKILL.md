---
name: cicd-pipeline
description: Drafts CI/CD pipeline design — stages, triggers, quality-gate integration, artefact flow. Produces a provider-neutral doc + a provider-specific YAML skeleton. Does not provision CI or run pipelines. Use when designing a pipeline or choosing between GitHub Actions, GitLab CI, etc.
license: MIT
compatibility: Designed for agentskills.io-compatible agents.
metadata:
  author: Dau Quang Thanh
  version: '1.0'
  requires: []
---

## User Input

```text
$ARGUMENTS
```

## Audience and tone (interactive mode)

**Register first — adapt to role level.** Before applying the beginner floor
below, resolve the reader's level from the merged `.fire-phoenix/context.yml`
+ `.fire-phoenix/user-context.yml` (`user-context.yml` wins): use
`preferences.tech_role_level` for technical work (`junior` → hand-hold, one
path; `mid` → ≥2 options with one-line trade-offs; `senior` → defer on
judgment, surface edge cases, be brief; `staff` → be terse, challenge
premises, skip obvious caveats) and `preferences.non_tech_role_level` for
stakeholder work (`non-technical` → outcomes not jargon; `familiar` → simple
jargon glossed; `fluent` → concepts without explanation; `technical` → full
vocabulary). An explicit in-session signal (e.g. "be terse", "skip the
explanation") overrides everything. The plain-English, one-question-at-a-time
floor below applies **only when the relevant level is unset**; never treat
role level as a gate. Full rule: `.fire-phoenix/references/subagents/register-resolution.md`.

When `FIRE_PHOENIX_AGENT_MODE=interactive` (the default), assume the user
has **limited technical background and limited domain knowledge**
— they may know basics but lack deep expertise in this skill's
area. Run this skill as a guided questionnaire:

- **One question at a time.** No walls of questions.
- **Yes / no first.** Phrase so `yes`, `no`, `not sure`, or `skip`
  is a valid answer.
- **Translate jargon, don't strip it.** Use the technical term but
  always pair it with a plain-English gloss the first time it
  appears.
- **Choices, not blank fields.** When yes/no isn't enough, offer
  2-4 lettered options (A/B/C/D) with one-line plain-language
  descriptions of the trade-off. Always include "Not sure — pick
  a sensible default".
- **Always recommend.** State the option you would pick and why in
  one sentence so the user can reply "yes" / "ok" to accept. Pull
  defaults from upstream artefacts (spec, architecture, ADRs,
  standards) before asking blank.
- **Show, don't ask.** When upstream artefacts already imply an
  answer, propose it as a pre-filled finding and ask for a
  yes / no confirmation rather than asking the user to fill in a
  blank.
- **`not sure` / `skip` triggers a sensible default**, marked
  "(default applied — confirm later)" in the artefact, and a debt
  entry in this skill's debt file.

When `FIRE_PHOENIX_AGENT_MODE=auto` (or `--auto`), skip the questionnaire
entirely: apply sensible defaults from upstream artefacts and log
decisions to the parent agent's decision log.

## Inputs

- `.fire-phoenix/context.yml`
- `{context.paths.docs}/testing/*/quality-gates.md` (gates per feature)
- `{context.paths.docs}/architecture/c4-container.md` (build units)

## Outputs

- `{context.paths.docs}/operations/cicd.md` — design doc.
- `{context.paths.docs}/operations/cicd.extract`
- `assets/ci-pipeline.sample.yml` — provider-specific starter
  (GitHub Actions / GitLab CI / Azure Pipelines / CircleCI /
  Buildkite).

## Context Update

Does not mutate `.fire-phoenix/context.yml`.

## Handoffs

- `deployment-strategy` references the pipeline's release stage.

## AI authoring scope

**Does:** design stage ordering (lint → unit → integration →
security → build → deploy-to-staging → e2e → approve → deploy-to-prod),
draft a YAML skeleton matching the chosen provider.

**Does not:** provision CI; push YAML to the repo; run pipelines.

## Pipeline gates

Every pipeline this skill drafts carries the required-gate
checklist in `references/pipeline-gates.md`: lint + format, type
check, tests, **coverage on changed files** (not the repo
average), security / integrity scans, immutable build. Stages are
ordered fail-fast — cheap checks first, expensive tails last —
for the feedback-economics rationale spelled out there.

Non-negotiable: **a required gate is never bypassed silently.** A
bypass is a recorded decision (who, which gate, why, what re-arms
it) in the decision log, plus an `OPSDEBT-` if the gate stays
weakened. Provider trade-offs live in `references/providers.md`.

## Usage

> `<SKILL_DIR>` = the integration's skills root (e.g. `.claude/skills/`
> for Claude Code, `.codex/skills/` for Codex,
> `.cursor/skills/` for Cursor, `.kiro/skills/` for Kiro).
> Scripts live at `<SKILL_DIR>/<skill-name>/scripts/…`.

```bash
CI_PROVIDER=github-actions bash <SKILL_DIR>/cicd-pipeline/scripts/bash/draft-cicd.sh --auto
```

### Answer keys

| Key | Meaning | Default |
|---|---|---|
| `CI_PROVIDER` | github-actions / gitlab-ci / azure-pipelines / circleci / buildkite | `github-actions` |
| `CI_REQUIRES_MANUAL_RELEASE` | `true` / `false` | `true` |
