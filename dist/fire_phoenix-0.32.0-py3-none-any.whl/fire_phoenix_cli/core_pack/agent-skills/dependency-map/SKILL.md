---
name: dependency-map
description: Renders the project's internal module-dependency graph + external
  dependency list as a Mermaid diagram. Works from imports + the
  lockfile produced by codebase-scan. Use when visualising
  module dependencies, understanding code structure, or identifying
  circular dependencies and coupling.
license: MIT
compatibility: Designed for agentskills.io-compatible agents.
metadata:
  author: Dau Quang Thanh
  version: '1.0'
  requires: [codebase-scan]
---

## User Input

```text
$ARGUMENTS
```

## Audience and tone (interactive mode)

**Register first — adapt to role level.** Before applying the beginner floor
below, resolve the reader's level from the merged `.fire-phoenix/context.yml`
+ `.fire-phoenix/user-context.yml` (`user-context.yml` wins): use
`preferences.tech_role_level` for technical work (`junior` → hand-hold, one
path; `mid` → ≥2 options with one-line trade-offs; `senior` → defer on
judgment, surface edge cases, be brief; `staff` → be terse, challenge
premises, skip obvious caveats) and `preferences.non_tech_role_level` for
stakeholder work (`non-technical` → outcomes not jargon; `familiar` → simple
jargon glossed; `fluent` → concepts without explanation; `technical` → full
vocabulary). An explicit in-session signal (e.g. "be terse", "skip the
explanation") overrides everything. The plain-English, one-question-at-a-time
floor below applies **only when the relevant level is unset**; never treat
role level as a gate. Full rule: `.fire-phoenix/references/subagents/register-resolution.md`.

When `FIRE_PHOENIX_AGENT_MODE=interactive` (the default), assume the user
has **limited technical background and limited domain knowledge**
— they may know basics but lack deep expertise in this skill's
area. Run this skill as a guided questionnaire:

- **One question at a time.** No walls of questions.
- **Yes / no first.** Phrase so `yes`, `no`, `not sure`, or `skip`
  is a valid answer.
- **Translate jargon, don't strip it.** Use the technical term but
  always pair it with a plain-English gloss the first time it
  appears.
- **Choices, not blank fields.** When yes/no isn't enough, offer
  2-4 lettered options (A/B/C/D) with one-line plain-language
  descriptions of the trade-off. Always include "Not sure — pick
  a sensible default".
- **Always recommend.** State the option you would pick and why in
  one sentence so the user can reply "yes" / "ok" to accept. Pull
  defaults from upstream artefacts (spec, architecture, ADRs,
  standards) before asking blank.
- **Show, don't ask.** When upstream artefacts already imply an
  answer, propose it as a pre-filled finding and ask for a
  yes / no confirmation rather than asking the user to fill in a
  blank.
- **`not sure` / `skip` triggers a sensible default**, marked
  "(default applied — confirm later)" in the artefact, and a debt
  entry in this skill's debt file.

When `FIRE_PHOENIX_AGENT_MODE=auto` (or `--auto`), skip the questionnaire
entirely: apply sensible defaults from upstream artefacts and log
decisions to the parent agent's decision log.

## Inputs

- `.fire-phoenix/context.yml`
- `{context.paths.docs}/analysis/codebase-scan.md`
- Source imports; project lockfile

## Outputs

- `{context.paths.docs}/analysis/dependencies.md`
- `assets/module-graph.mmd`

## Context Update

Does not mutate `.fire-phoenix/context.yml`.

## Handoffs

- `dependency-audit` extends this with CVEs + licences.
- `quality-review` flags circular / high-fan-out modules.

## AI authoring scope

**Does:** list top-N internal modules by fan-in + fan-out,
render a Mermaid flowchart, list external deps with versions,
flag circular imports, annotate risk flags per external
dependency.

**Does not:** modify imports; install / upgrade packages; run
the full CVE / licence audit (that is `dependency-audit`'s job —
this skill only raises flags for it).

## Risk flags

Annotate each external dependency (and any suspicious edge) with
the flags below. The vocabulary matches `dependency-audit` —
see `dependency-audit/references/supply-chain-checklist.md` (sibling skill) for the full
check definitions; do not restate them here, cross-reference.

- **`unpinned`** — no exact version resolved via a committed
  lockfile (supply-chain check 1).
- **`abandoned`** — no commits or releases in 18+ months
  (supply-chain check 5's abandonware rule; the audit assigns
  the severity).
- **`licence`** — copyleft or unknown licence in a context whose
  intake constraints exclude it; the audit's licence pass makes
  the call, this map just raises the flag.
- **`single-maintainer`** — bus-factor risk: one active
  maintainer visible on the registry / repository. Pair with the
  audit's provenance and typosquatting checks.

Internal-edge risks stay in `references/graph-heuristics.md`
territory: dashed (dynamic) edges are less safe than static
imports, and every cycle is logged as an `ANALYSISDEBT-`.

Risk flags here are pointers, tagged `OBSERVED` or `INFERRED
(low|med|high confidence)` like every other claim; the
authoritative CVE / licence / abandonware verdicts live in the
`dependency-audit` output.

## Usage

> `<SKILL_DIR>` = the integration's skills root (e.g. `.claude/skills/`
> for Claude Code, `.codex/skills/` for Codex,
> `.cursor/skills/` for Cursor, `.kiro/skills/` for Kiro).
> Scripts live at `<SKILL_DIR>/<skill-name>/scripts/…`.

```bash
DM_MAX_MODULES=25 bash <SKILL_DIR>/dependency-map/scripts/bash/build-map.sh --auto
```

### Answer keys

| Key | Default |
|---|---|
| `DM_MAX_MODULES` | `25` |
