---
name: infrastructure-plan
description: Drafts an infrastructure-as-code plan — cloud accounts, networks, compute/storage/database, IAM boundaries. Produces a tool-neutral design + a starter module for the chosen IaC tool. Does not provision. Use when planning cloud infrastructure or designing IaC with Terraform or Bicep.
license: MIT
compatibility: Designed for agentskills.io-compatible agents.
metadata:
  author: Dau Quang Thanh
  version: '1.0'
  requires: []
---

## User Input

```text
$ARGUMENTS
```

## Audience and tone (interactive mode)

**Register first — adapt to role level.** Before applying the beginner floor
below, resolve the reader's level from the merged `.fire-phoenix/context.yml`
+ `.fire-phoenix/user-context.yml` (`user-context.yml` wins): use
`preferences.tech_role_level` for technical work (`junior` → hand-hold, one
path; `mid` → ≥2 options with one-line trade-offs; `senior` → defer on
judgment, surface edge cases, be brief; `staff` → be terse, challenge
premises, skip obvious caveats) and `preferences.non_tech_role_level` for
stakeholder work (`non-technical` → outcomes not jargon; `familiar` → simple
jargon glossed; `fluent` → concepts without explanation; `technical` → full
vocabulary). An explicit in-session signal (e.g. "be terse", "skip the
explanation") overrides everything. The plain-English, one-question-at-a-time
floor below applies **only when the relevant level is unset**; never treat
role level as a gate. Full rule: `.fire-phoenix/references/subagents/register-resolution.md`.

When `FIRE_PHOENIX_AGENT_MODE=interactive` (the default), assume the user
has **limited technical background and limited domain knowledge**
— they may know basics but lack deep expertise in this skill's
area. Run this skill as a guided questionnaire:

- **One question at a time.** No walls of questions.
- **Yes / no first.** Phrase so `yes`, `no`, `not sure`, or `skip`
  is a valid answer.
- **Translate jargon, don't strip it.** Use the technical term but
  always pair it with a plain-English gloss the first time it
  appears.
- **Choices, not blank fields.** When yes/no isn't enough, offer
  2-4 lettered options (A/B/C/D) with one-line plain-language
  descriptions of the trade-off. Always include "Not sure — pick
  a sensible default".
- **Always recommend.** State the option you would pick and why in
  one sentence so the user can reply "yes" / "ok" to accept. Pull
  defaults from upstream artefacts (spec, architecture, ADRs,
  standards) before asking blank.
- **Show, don't ask.** When upstream artefacts already imply an
  answer, propose it as a pre-filled finding and ask for a
  yes / no confirmation rather than asking the user to fill in a
  blank.
- **`not sure` / `skip` triggers a sensible default**, marked
  "(default applied — confirm later)" in the artefact, and a debt
  entry in this skill's debt file.

When `FIRE_PHOENIX_AGENT_MODE=auto` (or `--auto`), skip the questionnaire
entirely: apply sensible defaults from upstream artefacts and log
decisions to the parent agent's decision log.

## Inputs

- `.fire-phoenix/context.yml`
- `{context.paths.docs}/architecture/intake.md` (cloud preference,
  compliance regime)
- `{context.paths.docs}/architecture/c4-container.md` (compute +
  storage needs)

## Outputs

- `{context.paths.docs}/operations/infra.md`
- `{context.paths.docs}/operations/infra.extract`
- `assets/infra-starter.tf` or `assets/infra-starter.bicep` —
  tool-specific starter module.

## Context Update

Does not mutate `.fire-phoenix/context.yml`.

## Handoffs

- `containerization` reads compute decisions.
- `deployment-strategy` reads environment layout.
- `cicd-pipeline` reads deploy targets.

## AI authoring scope

**Does:** design the resource tree (accounts / subscriptions →
networks → compute / storage / data), IAM boundaries, per-env
separation. Draft a starter module in the chosen tool.

**Does not:** run `terraform apply`, create cloud resources,
store credentials.

## Review checklist

Before the plan is handed on, walk
`references/review-checklist.md`: least privilege (one role per
service, no wildcards), secret handling (managed store, state
treated as sensitive), network boundaries cross-checked against
the architect's C4 trust boundaries (a mismatch is a finding for
the architect), cost visibility (tagging + attributable spend),
and environment parity (same module shape, different variables).
Unmet items become `OPSDEBT-` entries. Tool trade-offs live in
`references/tool-comparison.md`.

## Usage

> `<SKILL_DIR>` = the integration's skills root (e.g. `.claude/skills/`
> for Claude Code, `.codex/skills/` for Codex,
> `.cursor/skills/` for Cursor, `.kiro/skills/` for Kiro).
> Scripts live at `<SKILL_DIR>/<skill-name>/scripts/…`.

```bash
INFRA_TOOL=terraform INFRA_CLOUD=aws bash <SKILL_DIR>/infrastructure-plan/scripts/bash/draft-infra.sh --auto
```

### Answer keys

| Key | Default |
|---|---|
| `INFRA_TOOL` (`terraform`/`opentofu`/`bicep`/`pulumi`/`cloudformation`) | `terraform` |
| `INFRA_CLOUD` (`aws`/`azure`/`gcp`/`on-prem`/`multi`) | `aws` |
| `INFRA_ENVS` | `dev,staging,prod` |
