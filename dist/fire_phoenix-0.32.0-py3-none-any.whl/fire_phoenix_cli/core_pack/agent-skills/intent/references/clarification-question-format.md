# Clarification-question presentation format for `/intent`

> Read this only when `[NEEDS CLARIFICATION]` markers remain after
> validation (Outline step 7c). Extracted per `adr/0034` — canonical
> text, not a copy.

For each clarification needed (max 3), present options to the user.
**In interactive mode**, phrase each question in plain everyday
language for a user with no technical background, prefer yes / no,
recommend a sensible default, and describe each option's effect in
plain consequences (no jargon — say "users wait a bit longer" instead
of "added latency"; say "rules about user data" instead of "GDPR /
compliance"):

```markdown
## Question [N]: [Topic in plain words]

**Where this came up**: [Quote relevant spec section]

**What we need to know**: [Restate the NEEDS CLARIFICATION as a simple, everyday-language question; example: "Should users be able to undo a delete?"]

**Recommended**: Option [X] — [one-sentence reason in plain words]

**Your options**:

| Option | Plain-language answer | What this means for you |
|--------|------------------------|--------------------------|
| A      | [Everyday-language answer, e.g., "Yes, keep deleted items for 30 days"] | [Plain consequence, e.g., "Users can recover mistakes; you store a bit more data"] |
| B      | [Everyday-language answer]                                              | [Plain consequence]                                                                |
| C      | [Everyday-language answer]                                              | [Plain consequence]                                                                |
| Not sure | Use the recommended default                                          | [What the default is, in plain words]                                              |
| Custom | Tell me in your own words                                              | I'll translate it into the spec for you                                            |

**Reply with**: a letter (e.g., "A"), "yes" to accept the recommendation, "not sure" to use the default, or your own short answer.
```

**CRITICAL — table formatting**: ensure markdown tables are properly
formatted:

- Use consistent spacing with pipes aligned.
- Each cell should have spaces around content: `| Content |` not
  `|Content|`.
- Header separator must have at least 3 dashes: `|--------|`.
- Test that the table renders correctly in markdown preview.
