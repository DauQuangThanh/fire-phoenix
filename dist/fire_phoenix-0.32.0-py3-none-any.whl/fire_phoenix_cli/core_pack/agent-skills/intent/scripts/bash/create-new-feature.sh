#!/usr/bin/env bash

# Create a new intent (feature). Entry point of the IDD lifecycle.
#
# IDD-canon write semantics (β₂ of adr/0023 Option E, task-0042; branch
# decoupling per task-0089).
# Pre-β₂: the script hardcoded "specs/" as the intents directory and
# relied on SDD-era feature-branch helpers for path resolution.
# Post-β₂: the intents directory is read from .fire-phoenix/context.yml
# via read_context ($FIRE_PHOENIX_INTENTS_DIR), and on successful
# (non-dry-run) creation the new intent.md's relative path is written
# into context.yml's current.intent cursor.
#
# Branch ownership (task-0089): this core command creates the intent
# DIRECTORY + intent.md + current.intent cursor ONLY. It does NOT create
# or switch git branches — the git extension's `before_specify` hook
# (fire-phoenix.git.feature) is the sole brancher (see SKILL.md:150).
# Intent-directory numbering derives from the intents directory alone and
# is independent of git branches (SKILL.md:74). The `BRANCH_NAME` /
# `FEATURE_NUM` JSON keys are retained for interface stability: `BRANCH_NAME`
# now names the intent-directory prefix (`<FEATURE_NUM>-<suffix>`), not a
# branch this script created. `--allow-existing-branch` is accepted but is
# a no-op (retained for CLI-surface stability).

set -e

JSON_MODE=false
DRY_RUN=false
# Deprecated no-op (task-0089): the core command no longer touches git
# branches, so there is no existing branch to switch to. Accepted so the
# CLI surface is unchanged for callers/hooks that still pass it.
ALLOW_EXISTING=false
SHORT_NAME=""
BRANCH_NUMBER=""
USE_TIMESTAMP=false
ARGS=()
i=1
while [ $i -le $# ]; do
    arg="${!i}"
    case "$arg" in
        --json)
            JSON_MODE=true
            ;;
        --dry-run)
            DRY_RUN=true
            ;;
        --allow-existing-branch)
            ALLOW_EXISTING=true
            ;;
        --short-name)
            if [ $((i + 1)) -gt $# ]; then
                echo 'Error: --short-name requires a value' >&2
                exit 1
            fi
            i=$((i + 1))
            next_arg="${!i}"
            # Check if the next argument is another option (starts with --)
            if [[ "$next_arg" == --* ]]; then
                echo 'Error: --short-name requires a value' >&2
                exit 1
            fi
            SHORT_NAME="$next_arg"
            ;;
        --number)
            if [ $((i + 1)) -gt $# ]; then
                echo 'Error: --number requires a value' >&2
                exit 1
            fi
            i=$((i + 1))
            next_arg="${!i}"
            if [[ "$next_arg" == --* ]]; then
                echo 'Error: --number requires a value' >&2
                exit 1
            fi
            BRANCH_NUMBER="$next_arg"
            ;;
        --timestamp)
            USE_TIMESTAMP=true
            ;;
        --help|-h)
            echo "Usage: $0 [--json] [--dry-run] [--allow-existing-branch] [--short-name <name>] [--number N] [--timestamp] <feature_description>"
            echo ""
            echo "Creates the intent directory + intent.md + current.intent cursor."
            echo "Git branch creation is handled by the git extension's before_specify"
            echo "hook, not by this command."
            echo ""
            echo "Options:"
            echo "  --json              Output in JSON format"
            echo "  --dry-run           Compute the name and paths without creating directories or files"
            echo "  --allow-existing-branch  Deprecated no-op (retained for CLI-surface stability)"
            echo "  --short-name <name> Provide a custom short name (2-4 words) for the directory prefix"
            echo "  --number N          Specify the sequential number manually (overrides auto-detection)"
            echo "  --timestamp         Use timestamp prefix (YYYYMMDD-HHMMSS) instead of sequential numbering"
            echo "  --help, -h          Show this help message"
            echo ""
            echo "Examples:"
            echo "  $0 'Add user authentication system' --short-name 'user-auth'"
            echo "  $0 'Implement OAuth2 integration for API' --number 5"
            echo "  $0 --timestamp --short-name 'user-auth' 'Add user authentication'"
            exit 0
            ;;
        *)
            ARGS+=("$arg")
            ;;
    esac
    i=$((i + 1))
done

FEATURE_DESCRIPTION="${ARGS[*]}"
if [ -z "$FEATURE_DESCRIPTION" ]; then
    echo "Usage: $0 [--json] [--dry-run] [--allow-existing-branch] [--short-name <name>] [--number N] [--timestamp] <feature_description>" >&2
    exit 1
fi

# Trim whitespace and validate description is not empty (e.g., user passed only whitespace)
FEATURE_DESCRIPTION=$(echo "$FEATURE_DESCRIPTION" | xargs)
if [ -z "$FEATURE_DESCRIPTION" ]; then
    echo "Error: Feature description cannot be empty or contain only whitespace" >&2
    exit 1
fi

# Load canonical helpers (read_context, resolve_template, json_escape, …) and
# the shared branch/dir naming helpers (get_highest_from_specs,
# clean_branch_name, generate_branch_name) — single source per adr/0048.
# Intent-directory numbering derives from the intents directory ALONE
# (task-0089), deliberately independent of git branches.
SCRIPT_DIR="$(CDPATH="" cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/common.sh"
source "$SCRIPT_DIR/branch-naming.sh"

# Resolve repo root + intents directory from .fire-phoenix/context.yml.
# read_context exports FIRE_PHOENIX_REPO_ROOT and FIRE_PHOENIX_INTENTS_DIR
# (with documented defaults when context.yml is absent).
read_context

REPO_ROOT="$FIRE_PHOENIX_REPO_ROOT"

cd "$REPO_ROOT"

INTENTS_DIR="$REPO_ROOT/$FIRE_PHOENIX_INTENTS_DIR"
if [ "$DRY_RUN" != true ]; then
    mkdir -p "$INTENTS_DIR"
fi

# Generate directory suffix
if [ -n "$SHORT_NAME" ]; then
    # Use provided short name, just clean it up
    BRANCH_SUFFIX=$(clean_branch_name "$SHORT_NAME")
else
    # Generate from description with smart filtering
    BRANCH_SUFFIX=$(generate_branch_name "$FEATURE_DESCRIPTION")
fi

# Warn if --number and --timestamp are both specified
if [ "$USE_TIMESTAMP" = true ] && [ -n "$BRANCH_NUMBER" ]; then
    >&2 echo "[intent] Warning: --number is ignored when --timestamp is used"
    BRANCH_NUMBER=""
fi

# Determine directory prefix
if [ "$USE_TIMESTAMP" = true ]; then
    FEATURE_NUM=$(date +%Y%m%d-%H%M%S)
    BRANCH_NAME="${FEATURE_NUM}-${BRANCH_SUFFIX}"
else
    # Sequential number: intents directory only (independent of git branches).
    if [ -z "$BRANCH_NUMBER" ]; then
        HIGHEST=$(get_highest_from_specs "$INTENTS_DIR")
        BRANCH_NUMBER=$((HIGHEST + 1))
    fi

    # Force base-10 interpretation to prevent octal conversion (e.g., 010 → 8 in octal, but should be 10 in decimal)
    FEATURE_NUM=$(printf "%03d" "$((10#$BRANCH_NUMBER))")
    BRANCH_NAME="${FEATURE_NUM}-${BRANCH_SUFFIX}"
fi

# GitHub enforces a 244-byte limit on branch names; the git extension will
# use this prefix as its branch name, so keep the directory prefix within
# the same limit for parity.
MAX_BRANCH_LENGTH=244
if [ ${#BRANCH_NAME} -gt $MAX_BRANCH_LENGTH ]; then
    # Account for prefix length: timestamp (15) + hyphen (1) = 16, or sequential (3) + hyphen (1) = 4
    PREFIX_LENGTH=$(( ${#FEATURE_NUM} + 1 ))
    MAX_SUFFIX_LENGTH=$((MAX_BRANCH_LENGTH - PREFIX_LENGTH))

    # Truncate suffix at word boundary if possible
    TRUNCATED_SUFFIX=$(echo "$BRANCH_SUFFIX" | cut -c1-$MAX_SUFFIX_LENGTH)
    # Remove trailing hyphen if truncation created one
    TRUNCATED_SUFFIX=$(echo "$TRUNCATED_SUFFIX" | sed 's/-$//')

    ORIGINAL_BRANCH_NAME="$BRANCH_NAME"
    BRANCH_NAME="${FEATURE_NUM}-${TRUNCATED_SUFFIX}"

    >&2 echo "[intent] Warning: Name exceeded GitHub's 244-byte branch limit"
    >&2 echo "[intent] Original: $ORIGINAL_BRANCH_NAME (${#ORIGINAL_BRANCH_NAME} bytes)"
    >&2 echo "[intent] Truncated to: $BRANCH_NAME (${#BRANCH_NAME} bytes)"
fi

FEATURE_DIR="$INTENTS_DIR/$BRANCH_NAME"
INTENT_FILE="$FEATURE_DIR/intent.md"
# Relative path used for the context.yml current.intent cursor (always
# stored repo-root-relative so the cursor survives a repo move).
INTENT_REL="$FIRE_PHOENIX_INTENTS_DIR/$BRANCH_NAME/intent.md"

# current.intent cursor writes flow through the canonical helper
# `write_user_context_value` sourced from common.sh (per task-0066,
# closing adr/0030 §Skill helper changes). The helper targets
# .fire-phoenix/user-context.yml exclusively and bootstraps the file
# if absent.

if [ "$DRY_RUN" != true ]; then
    # No git branch is created here (task-0089): the git extension's
    # before_specify hook owns branch creation. This command only writes
    # the intent directory, intent.md, and the current.intent cursor.
    mkdir -p "$FEATURE_DIR"

    if [ ! -f "$INTENT_FILE" ]; then
        TEMPLATE=$(resolve_template "intent-template" "$REPO_ROOT") || true
        if [ -n "$TEMPLATE" ] && [ -f "$TEMPLATE" ]; then
            cp "$TEMPLATE" "$INTENT_FILE"
        else
            echo "Warning: Spec template not found; created empty spec file" >&2
            touch "$INTENT_FILE"
        fi
    fi

    # Persist the new intent path into .fire-phoenix/context.yml's
    # current.intent cursor so downstream skills (/plan, /taskify, …)
    # see this feature as the active one without further env-var glue.
    write_user_context_value current.intent "$INTENT_REL"

    # Inform the user how to persist the feature variable in their own shell
    printf '# To persist: export FIRE_PHOENIX_FEATURE=%q\n' "$BRANCH_NAME" >&2
fi

if $JSON_MODE; then
    if command -v jq >/dev/null 2>&1; then
        if [ "$DRY_RUN" = true ]; then
            jq -cn \
                --arg branch_name "$BRANCH_NAME" \
                --arg spec_file "$INTENT_FILE" \
                --arg feature_num "$FEATURE_NUM" \
                '{BRANCH_NAME:$branch_name,INTENT_FILE:$spec_file,FEATURE_NUM:$feature_num,DRY_RUN:true}'
        else
            jq -cn \
                --arg branch_name "$BRANCH_NAME" \
                --arg spec_file "$INTENT_FILE" \
                --arg feature_num "$FEATURE_NUM" \
                '{BRANCH_NAME:$branch_name,INTENT_FILE:$spec_file,FEATURE_NUM:$feature_num}'
        fi
    else
        if [ "$DRY_RUN" = true ]; then
            printf '{"BRANCH_NAME":"%s","INTENT_FILE":"%s","FEATURE_NUM":"%s","DRY_RUN":true}\n' "$(json_escape "$BRANCH_NAME")" "$(json_escape "$INTENT_FILE")" "$(json_escape "$FEATURE_NUM")"
        else
            printf '{"BRANCH_NAME":"%s","INTENT_FILE":"%s","FEATURE_NUM":"%s"}\n' "$(json_escape "$BRANCH_NAME")" "$(json_escape "$INTENT_FILE")" "$(json_escape "$FEATURE_NUM")"
        fi
    fi
else
    echo "BRANCH_NAME: $BRANCH_NAME"
    echo "INTENT_FILE: $INTENT_FILE"
    echo "FEATURE_NUM: $FEATURE_NUM"
    if [ "$DRY_RUN" != true ]; then
        printf '# To persist in your shell: export FIRE_PHOENIX_FEATURE=%q\n' "$BRANCH_NAME"
    fi
fi
