---
name: intent
description: Captures or updates the feature intent (the why and desired outcome) from a natural-language description, and derives the specification from it. Use when starting a new feature or turning a user story or idea into a traceable intent record.
license: MIT
compatibility: Designed for agentskills.io-compatible agents.
metadata:
  author: Dau Quang Thanh
  version: '1.0'
  requires: []
---

## User Input

```text
$ARGUMENTS
```

You **MUST** consider the user input before proceeding (if not empty).

## Pre-Execution Checks

**Check for extension hooks (before specification)**:

- If `.fire-phoenix/extensions.yml` does not exist in the project
  root, skip silently.
- If it exists, read `references/extension-hooks.md` §Pre-execution
  and apply the hook protocol there against the
  `hooks.before_specify` key before proceeding to the Outline.

## Interactive Mode (beginner-friendly questionnaire)

If `FIRE_PHOENIX_AGENT_MODE=interactive` (the default) **and** the
natural-language feature description is too sparse to populate every
mandatory section of the spec template — for example the user typed
only "build me a booking app" and key facts about users, data,
devices, or success are missing — pause before step 5 of the
Outline, read `references/interactive-questionnaire.md`, and walk
the user through it (conversational rules, seven question batches,
and the answers-to-spec-sections mapping). Do not read it when the
description is already complete.

When `FIRE_PHOENIX_AGENT_MODE=auto` (or `--auto`), **skip the
questionnaire entirely** (do not read the reference): apply sensible
defaults, document them in the Assumptions section, and let the
business-analyst agent log decisions to its decision log.

## Outline

The text the user typed after `/intent` in the triggering message **is** the feature description. Assume you always have it available in this conversation even if `$ARGUMENTS` appears literally below. Do not ask the user to repeat it unless they provided an empty command.

Given that feature description, do this:

1. **Generate a concise short name** (2-4 words) for the feature:
   - Analyze the feature description and extract the most meaningful keywords
   - Create a 2-4 word short name that captures the essence of the feature
   - Use action-noun format when possible (e.g., "add-user-auth", "fix-payment-bug")
   - Preserve technical terms and acronyms (OAuth2, API, JWT, etc.)
   - Keep it concise but descriptive enough to understand the feature at a glance
   - Examples: "I want to add user authentication" → "user-auth";
     "Fix payment processing timeout bug" → "fix-payment-timeout"

2. **Branch creation** (optional, via hook):

   If a `before_specify` hook ran successfully in the Pre-Execution Checks above, it will have created/switched to a git branch and output JSON containing `BRANCH_NAME` and `FEATURE_NUM`. Note these values for reference, but the branch name does **not** dictate the spec directory name.

   If the user explicitly provided `GIT_BRANCH_NAME`, pass it through to the hook so the branch script uses the exact value as the branch name (bypassing all prefix/suffix generation).

3. **Create the intent feature directory**:

   New intents live under `{context.paths.intents}/` (resolved from `.fire-phoenix/context.yml` — default `docs/intents/`). The action script `scripts/bash/create-new-feature.sh` (or the PowerShell sibling) handles all path resolution, creates the `<prefix>-<short-name>` directory, copies `templates/intent-template.md` to `intent.md`, and updates the `current.intent` cursor — invoke it rather than re-implementing any of that. Only when the action script cannot run, read `references/feature-directory-resolution.md` and follow its manual resolution steps.

   **IMPORTANT**:
   - You must only create one feature per `/intent` invocation
   - The intent directory name and the git branch name are independent — they may be the same but that is the user's choice
   - The intent directory, intent file, and the `current.intent` cursor are always written by the action script, never by the hook

4. Load `templates/intent-template.md` to understand required sections.

5. Follow this execution flow:
    1. Parse user description from arguments
       If empty: ERROR "No feature description provided"
    2. Extract key concepts from description
       Identify: actors, actions, data, constraints
    3. For unclear aspects:
       - Make informed guesses based on context and industry standards
       - Only mark with [NEEDS CLARIFICATION: specific question] if:
         - The choice significantly impacts feature scope or user experience
         - Multiple reasonable interpretations exist with different implications
         - No reasonable default exists
       - **LIMIT: Maximum 3 [NEEDS CLARIFICATION] markers total**
       - Prioritize clarifications by impact: scope > security/privacy > user experience > technical details
    4. Fill User Scenarios & Testing section
       If no clear user flow: ERROR "Cannot determine user scenarios"
    5. Generate Functional Requirements
       Each requirement must be testable
       Use reasonable defaults for unspecified details (document assumptions in Assumptions section)
    6. Define Success Criteria
       Create measurable, technology-agnostic outcomes
       Include both quantitative metrics (time, performance, volume) and qualitative measures (user satisfaction, task completion)
       Each criterion must be verifiable without implementation details
    7. Identify Key Entities (if data involved)
    8. Return: SUCCESS (spec ready for planning)

6. Write the specification to the intent file at `{context.current.intent}` (the action script populates this cursor in `.fire-phoenix/user-context.yml` after creating the feature directory) using the template structure, replacing placeholders with concrete details derived from the feature description (arguments) while preserving section order and headings.

7. **Specification Quality Validation**: After writing the initial spec, validate it against quality criteria:

   a. **Create Spec Quality Checklist**: Generate a checklist file at `{context.paths.intents}/<feature-dir>/checklists/requirements.md` (i.e. `checklists/requirements.md` alongside the newly written `intent.md`). When creating it, read `templates/requirements-checklist.md` and use it as the structure, filling the `[FEATURE NAME]` / `[DATE]` / link placeholders.

   b. **Run Validation Check**: Review the spec against each checklist item:
      - For each item, determine if it passes or fails
      - Document specific issues found (quote relevant spec sections)

   c. **Handle Validation Results**:

      - **If all items pass**: Mark checklist complete and proceed to step 7

      - **If items fail (excluding [NEEDS CLARIFICATION])**:
        1. List the failing items and specific issues
        2. Update the spec to address each issue
        3. Re-run validation until all items pass (max 3 iterations)
        4. If still failing after 3 iterations, document remaining issues in checklist notes and warn user

      - **If [NEEDS CLARIFICATION] markers remain**:
        1. Extract all [NEEDS CLARIFICATION: ...] markers from the spec
        2. **LIMIT CHECK**: If more than 3 markers exist, keep only the 3 most critical (by scope/security/UX impact) and make informed guesses for the rest
        3. Read `references/clarification-question-format.md` (only
           now — when markers remain) and present each question (max
           3) in that format, following its table-formatting rules
        4. Number questions sequentially (Q1, Q2, Q3 - max 3 total)
        5. Present all questions together before waiting for responses
        6. Wait for user to respond with their choices for all questions (e.g., "Q1: A, Q2: Custom - [details], Q3: B")
        7. Update the spec by replacing each [NEEDS CLARIFICATION] marker with the user's selected or provided answer
        8. Re-run validation after all clarifications are resolved

   d. **Update Checklist**: After each validation iteration, update the checklist file with current pass/fail status

8. **Report completion** to the user with:
   - The feature directory path (`dirname` of `{context.current.intent}`)
   - The intent file path (`{context.current.intent}` — also surfaced as `INTENT_FILE` in the action script's JSON output)
   - Checklist results summary
   - Readiness for the next phase (`/clarify-intent` or `/plan`)

9. **Check for extension hooks**: After reporting completion, check if `.fire-phoenix/extensions.yml` exists in the project root.
   - If it does not exist, skip silently.
   - If it exists, read `references/extension-hooks.md`
     §Post-completion and apply the hook protocol there against the
     `hooks.after_specify` key.

**NOTE:** Branch creation is handled by the `before_specify` hook (git extension). Spec directory and file creation are always handled by this core command.

## Quick Guidelines

- Focus on **WHAT** users need and **WHY**.
- Avoid HOW to implement (no tech stack, APIs, code structure).
- Written for business stakeholders, not developers.
- DO NOT create any checklists that are embedded in the spec. That will be a separate command.
- In interactive mode, **the user may have no technical or
  domain background** — never present jargon, blank fields, or
  multi-question prompts (see Interactive Mode above).

### Section Requirements

- **Mandatory sections**: Must be completed for every feature
- **Optional sections**: Include only when relevant to the feature
- When a section doesn't apply, remove it entirely (don't leave as "N/A")

### Authoring guidelines

When filling the intent template (step 5) and when authoring or
validating Success Criteria (steps 5-7), read
`references/authoring-guidelines.md` — informed-guess rules, the
3-marker clarification budget, reasonable defaults that never need
asking, and good/bad success-criteria examples. Consult it at those
steps, not before.

## Inputs

- **Feature Description** (`{context.current.feature}`)
  - If set: Use the provided feature description as the specification subject.
  - If null: Ask the user to describe the feature they want to specify.
  - If not provided: Ask the user to provide a feature description; do not proceed without one.

- **Upstream artifact** (optional) — if a `recover-spec` output
  (`recovered/<capability>.md`) or `brainstorm` record exists, prefer it over
  the raw description so upstream work carries forward.

## Outputs

- **Specification** (`{context.paths.intents}/{context.current.feature}/intent.md`)
  - Behavior: Create the spec file at this path. If the file exists and confirm_before_write is true, ask the user.
  - Overwrite guarded by `{context.preferences.confirm_before_write}`.

- **Specification Quality Checklist** (`{context.paths.intents}/{context.current.feature}/checklists/requirements.md`)
  - Behavior: Create the checklist file. Overwrite if exists.
  - Overwrite guarded by `{context.preferences.confirm_before_write}`.

## Context Update

After this skill completes successfully, update `.fire-phoenix/user-context.yml`:

- Set current.intent to the path of the created specification file
- Set current.feature to the feature slug
- Leave all other current.* fields unchanged
- Do not modify paths.*or preferences.*

Use `write_user_context_value current.<key> <value>` (bash) or `Write-UserContextValue -Key current.<key> -Value <value>` (PowerShell) from the helpers sourced by every skill bundle. Hand-editing `.fire-phoenix/user-context.yml` directly is also fine; do NOT modify `.fire-phoenix/context.yml`.

## Handoffs

- **Build Technical Plan**: run `/plan` to continue the workflow.
- **Clarify Spec Requirements**: run `/clarify-intent` to continue the workflow.
