#!/usr/bin/env pwsh
# PowerShell parity of scripts/bash/common.sh.
#
# Every role-skill's action scripts dot-source this file to get:
#   - Read-Context             : parse .fire-phoenix/context.yml into $script:FirePhoenixCtx
#   - Get-WorktypeDir <name>   : resolve docs/<work-type>/
#   - Get-FeatureScopedDir <n> : resolve docs/<work-type>/<feature>/
#   - Append-Debt              : append a numbered debt entry
#   - Write-Extract            : write a .extract companion file
#   - Confirm-BeforeWrite      : honour preferences.confirm_before_write
#   - Resolve-Auto <key>       : -Auto / env / answers / .extract lookup

# -------------------------------------------------------------------
# Repo-root discovery.
# -------------------------------------------------------------------

function Find-FirePhoenixRoot {
    param([string]$StartDir = (Get-Location).Path)
    $resolved = Resolve-Path -LiteralPath $StartDir -ErrorAction SilentlyContinue
    $current = if ($resolved) { $resolved.Path } else { $null }
    if (-not $current) { return $null }

    while ($true) {
        if (Test-Path -LiteralPath (Join-Path $current ".fire-phoenix") -PathType Container) {
            return $current
        }
        $parent = Split-Path $current -Parent
        if ([string]::IsNullOrEmpty($parent) -or $parent -eq $current) {
            return $null
        }
        $current = $parent
    }
}

function Get-RepoRoot {
    $firephoenixRoot = Find-FirePhoenixRoot
    if ($firephoenixRoot) { return $firephoenixRoot }

    try {
        $result = git rev-parse --show-toplevel 2>$null
        if ($LASTEXITCODE -eq 0 -and $result) { return $result }
    } catch {}

    return (Resolve-Path -LiteralPath (Join-Path $PSScriptRoot "../../../..")).Path
}

# -------------------------------------------------------------------
# Context-file parsing.
# -------------------------------------------------------------------

$script:FirePhoenixDefaults = @{
    DOCS_DIR              = 'docs'
    INTENTS_DIR           = 'docs/intents'
    PLANS_DIR             = 'docs/plans'
    TASKS_DIR             = 'docs/tasks'
    TEMPLATES_DIR         = 'templates'
    SCRIPTS_DIR           = 'scripts'
    # governance.adr_dir — canonical ADR home (contracts/task-0077).
    ADR_DIR               = 'docs/adr'
    # governance.decisions_file — canonical L4 decisions log (append-only).
    DECISIONS_FILE        = 'docs/decisions.md'
    # governance pending queues for the sanctioned authoring path (adr/0053).
    ADR_DRAFTS_DIR        = 'docs/adr-drafts'
    DECISIONS_PENDING_DIR = 'docs/decisions-pending'
    CONFIRM_BEFORE_WRITE  = $true
    OUTPUT_FORMAT         = 'markdown'
}

$script:FirePhoenixCtxWarned = $false

function Write-FirePhoenixContextWarning {
    if (-not $script:FirePhoenixCtxWarned) {
        Write-Warning '[fire-phoenix] .fire-phoenix/context.yml not found — applying documented defaults'
        $script:FirePhoenixCtxWarned = $true
    }
}

function _FirePhoenixParseContextMinimal {
    param([string]$Path)

    $data = @{
        paths       = @{}
        current     = @{}
        preferences = @{}
    }

    $section = $null
    Get-Content -LiteralPath $Path -ErrorAction Stop | ForEach-Object {
        $line = $_.TrimEnd()
        if ([string]::IsNullOrWhiteSpace($line)) { return }
        if ($line.TrimStart().StartsWith('#')) { return }

        if ($line -match '^([a-z_]+):\s*$') {
            $section = $Matches[1]
            if (-not $data.ContainsKey($section)) {
                $data[$section] = @{}
            }
            return
        }

        if ($line -match '^\s+([a-z_]+):\s*(.*)$') {
            $key   = $Matches[1]
            $value = $Matches[2].Trim()

            if ($value.StartsWith('"') -and $value.EndsWith('"')) {
                $value = $value.Substring(1, $value.Length - 2)
            } elseif ($value.StartsWith("'") -and $value.EndsWith("'")) {
                $value = $value.Substring(1, $value.Length - 2)
            }

            if ($value -in @('null', '~', '')) {
                $value = $null
            }

            if ($section -and $data.ContainsKey($section)) {
                $data[$section][$key] = $value
            }
        }
    }

    return $data
}

function Read-Context {
    $repoRoot = Get-RepoRoot
    $contextFile = Join-Path $repoRoot ".fire-phoenix/context.yml"

    # Start with defaults
    $script:FirePhoenixCtx = [pscustomobject]@{
        REPO_ROOT              = $repoRoot
        DOCS_DIR               = $script:FirePhoenixDefaults.DOCS_DIR
        INTENTS_DIR            = $script:FirePhoenixDefaults.INTENTS_DIR
        PLANS_DIR              = $script:FirePhoenixDefaults.PLANS_DIR
        TASKS_DIR              = $script:FirePhoenixDefaults.TASKS_DIR
        TEMPLATES_DIR          = $script:FirePhoenixDefaults.TEMPLATES_DIR
        SCRIPTS_DIR            = $script:FirePhoenixDefaults.SCRIPTS_DIR
        ADR_DIR                = $script:FirePhoenixDefaults.ADR_DIR
        DECISIONS_FILE         = $script:FirePhoenixDefaults.DECISIONS_FILE
        ADR_DRAFTS_DIR         = $script:FirePhoenixDefaults.ADR_DRAFTS_DIR
        DECISIONS_PENDING_DIR  = $script:FirePhoenixDefaults.DECISIONS_PENDING_DIR
        CURRENT_FEATURE        = $null
        CURRENT_INTENT         = $null
        CURRENT_PLAN           = $null
        CURRENT_TASK           = $null
        CURRENT_CHECKLIST      = $null
        CURRENT_BRANCH         = $null
        CONFIRM_BEFORE_WRITE   = $script:FirePhoenixDefaults.CONFIRM_BEFORE_WRITE
        OUTPUT_FORMAT          = $script:FirePhoenixDefaults.OUTPUT_FORMAT
    }

    if (-not (Test-Path -LiteralPath $contextFile)) {
        Write-FirePhoenixContextWarning
        return $script:FirePhoenixCtx
    }

    try {
        $parsed = _FirePhoenixParseContextMinimal -Path $contextFile
    } catch {
        Write-Warning ("[fire-phoenix] Failed to parse .fire-phoenix/context.yml: {0}" -f $_.Exception.Message)
        return $script:FirePhoenixCtx
    }

    $paths    = $parsed['paths']
    $current  = $parsed['current']
    $prefs    = $parsed['preferences']

    if ($paths) {
        if ($paths['docs'])      { $script:FirePhoenixCtx.DOCS_DIR      = $paths['docs'] }
        if ($paths['intents'])   { $script:FirePhoenixCtx.INTENTS_DIR   = $paths['intents'] }
        if ($paths['plans'])     { $script:FirePhoenixCtx.PLANS_DIR     = $paths['plans'] }
        if ($paths['tasks'])     { $script:FirePhoenixCtx.TASKS_DIR     = $paths['tasks'] }
        if ($paths['templates']) { $script:FirePhoenixCtx.TEMPLATES_DIR = $paths['templates'] }
        if ($paths['scripts'])   { $script:FirePhoenixCtx.SCRIPTS_DIR   = $paths['scripts'] }
    }
    $gov = $parsed['governance']
    if ($gov -and $gov['adr_dir']) {
        $script:FirePhoenixCtx.ADR_DIR = $gov['adr_dir']
    }
    if ($gov -and $gov['decisions_file']) {
        $script:FirePhoenixCtx.DECISIONS_FILE = $gov['decisions_file']
    }
    if ($gov -and $gov['adr_drafts_dir']) {
        $script:FirePhoenixCtx.ADR_DRAFTS_DIR = $gov['adr_drafts_dir']
    }
    if ($gov -and $gov['decisions_pending_dir']) {
        $script:FirePhoenixCtx.DECISIONS_PENDING_DIR = $gov['decisions_pending_dir']
    }
    if ($current) {
        $script:FirePhoenixCtx.CURRENT_FEATURE   = $current['feature']
        $script:FirePhoenixCtx.CURRENT_INTENT    = $current['intent']
        $script:FirePhoenixCtx.CURRENT_PLAN      = $current['plan']
        $script:FirePhoenixCtx.CURRENT_TASK      = $current['task']
        $script:FirePhoenixCtx.CURRENT_CHECKLIST = $current['checklist']
        $script:FirePhoenixCtx.CURRENT_BRANCH    = $current['branch']
    }
    if ($prefs) {
        if ($prefs.ContainsKey('confirm_before_write')) {
            $raw = $prefs['confirm_before_write']
            $script:FirePhoenixCtx.CONFIRM_BEFORE_WRITE = ($raw -eq 'true' -or $raw -eq $true)
        }
        if ($prefs['output_format']) {
            $script:FirePhoenixCtx.OUTPUT_FORMAT = $prefs['output_format']
        }
    }

    # adr/0030: parse .fire-phoenix/user-context.yml when present.
    # User-context values OVERRIDE project context values on conflict.
    # current.* lives ONLY in user-context.yml.
    $userContextFile = Join-Path $repoRoot ".fire-phoenix/user-context.yml"
    if (Test-Path -LiteralPath $userContextFile) {
        try {
            $userParsed = _FirePhoenixParseContextMinimal -Path $userContextFile
            $userCurrent = $userParsed['current']
            $userPrefs   = $userParsed['preferences']
            if ($userCurrent) {
                $script:FirePhoenixCtx.CURRENT_FEATURE   = $userCurrent['feature']
                $script:FirePhoenixCtx.CURRENT_INTENT    = $userCurrent['intent']
                $script:FirePhoenixCtx.CURRENT_PLAN      = $userCurrent['plan']
                $script:FirePhoenixCtx.CURRENT_TASK      = $userCurrent['task']
                $script:FirePhoenixCtx.CURRENT_CHECKLIST = $userCurrent['checklist']
                $script:FirePhoenixCtx.CURRENT_BRANCH    = $userCurrent['branch']
            }
            if ($userPrefs) {
                if ($userPrefs.ContainsKey('confirm_before_write')) {
                    $rawU = $userPrefs['confirm_before_write']
                    $script:FirePhoenixCtx.CONFIRM_BEFORE_WRITE = ($rawU -eq 'true' -or $rawU -eq $true)
                }
                if ($userPrefs['output_format']) {
                    $script:FirePhoenixCtx.OUTPUT_FORMAT = $userPrefs['output_format']
                }
            }
        } catch {
            Write-Warning ("[fire-phoenix] Failed to parse .fire-phoenix/user-context.yml: {0}" -f $_.Exception.Message)
        }
    }

    # Agent mode (auto | interactive). When `auto`, enable FIRE_PHOENIX_AUTO
    # so skill action scripts take non-interactive paths.
    if (-not $env:FIRE_PHOENIX_AGENT_MODE) { $env:FIRE_PHOENIX_AGENT_MODE = 'interactive' }
    if ($env:FIRE_PHOENIX_AGENT_MODE -in @('auto','AUTO','Auto')) {
        $env:FIRE_PHOENIX_AGENT_MODE = 'auto'
        if (-not $env:FIRE_PHOENIX_AUTO) { $env:FIRE_PHOENIX_AUTO = '1' }
    } else {
        $env:FIRE_PHOENIX_AGENT_MODE = 'interactive'
    }

    return $script:FirePhoenixCtx
}

# -------------------------------------------------------------------
# Intent bootstrap gate (adr/0064).
#
# Detect whether an intent exists for the current feature, classifying
# absence as greenfield vs brownfield so entry points can bootstrap
# `intent` (greenfield) or `recover-intent`/`recover-spec` (brownfield).
# Returns exactly ONE token: 'present' | 'absent-brownfield' | 'absent-greenfield'.
# Pure detection: no writes, no side effects.
# -------------------------------------------------------------------
function Get-FirePhoenixIntentStatus {
    if (-not $script:FirePhoenixCtx) { Read-Context | Out-Null }
    $ctx = $script:FirePhoenixCtx
    $repoRoot   = $ctx.REPO_ROOT
    $intentsRel = if ($ctx.INTENTS_DIR) { $ctx.INTENTS_DIR } else { 'docs/intents' }
    $docsRel    = if ($ctx.DOCS_DIR)    { $ctx.DOCS_DIR }    else { 'docs' }
    $intentsAbs = Join-Path $repoRoot $intentsRel
    $docsAbs    = Join-Path $repoRoot $docsRel

    # present: current feature has an intent.md, or any intent.md exists.
    $feature = $ctx.CURRENT_FEATURE
    if ($feature -and (Test-Path -LiteralPath (Join-Path $intentsAbs (Join-Path $feature 'intent.md')))) {
        return 'present'
    }
    if ((Test-Path -LiteralPath $intentsAbs) -and
        (Get-ChildItem -Path $intentsAbs -Recurse -Filter 'intent.md' -File -ErrorAction SilentlyContinue | Select-Object -First 1)) {
        return 'present'
    }

    # absent: brownfield = existing source AND no recovered baseline.
    $baselineAbs = Join-Path $docsAbs 'baseline'
    $baselinePresent = $false
    if ((Test-Path -LiteralPath $baselineAbs) -and
        (Get-ChildItem -Path $baselineAbs -Filter '*.md' -File -ErrorAction SilentlyContinue | Select-Object -First 1)) {
        $baselinePresent = $true
    }

    $sourcePresent = $false
    $git = Get-Command git -ErrorAction SilentlyContinue
    if ($git -and (& git -C $repoRoot rev-parse --is-inside-work-tree 2>$null)) {
        $tracked = & git -C $repoRoot ls-files -- . ':(exclude)docs' ':(exclude).fire-phoenix' ':(exclude)*.md' ':(exclude).git*' 2>$null
        if ($tracked) { $sourcePresent = $true }
    } else {
        $marker = Get-ChildItem -Path $repoRoot -Recurse -Depth 2 -File -ErrorAction SilentlyContinue |
            Where-Object {
                $_.FullName -notmatch '[\\/](\.fire-phoenix|docs)[\\/]' -and
                (($_.Extension -in '.py','.ts','.js','.go','.java','.rs') -or
                 ($_.Name -in 'package.json','pyproject.toml','go.mod'))
            } | Select-Object -First 1
        if ($marker) { $sourcePresent = $true }
    }

    if ($sourcePresent -and -not $baselinePresent) { return 'absent-brownfield' }
    return 'absent-greenfield'
}

# -------------------------------------------------------------------
# user-context.yml read/write helpers (adr/0030 §Skill helper changes).
#
# `current.*` and per-user overrides of `preferences.*` / `language.*`
# live in `.fire-phoenix/user-context.yml`. These functions are the
# canonical write path for those keys. They MUST NOT touch the project
# `.fire-phoenix/context.yml`.
# -------------------------------------------------------------------

# Internal: emit a YAML scalar with quoting when needed.
function _FirePhoenixEmitScalar {
    param($Value)
    if ($null -eq $Value) { return 'null' }
    $s = [string]$Value
    if ($s -eq '' -or $s -in @('null','~') -or $s -match '[ :#"'']') {
        $escaped = $s.Replace('\', '\\').Replace('"', '\"')
        return '"' + $escaped + '"'
    }
    return $s
}

# Internal: re-emit a parsed dict back to user-context.yml. Bootstrap-aware
# (always emits schema_version + current: block). Accepts OrderedDictionary
# so emit order is deterministic across writes (required for idempotency).
function _FirePhoenixEmitUserContext {
    param($Data, [string]$Path)

    $schema = if ($Data.Contains('schema_version')) { [string]$Data['schema_version'] } else { '3.0' }
    $lines = New-Object System.Collections.Generic.List[string]
    [void]$lines.Add('schema_version: "' + $schema + '"')
    [void]$lines.Add('')

    $emitted = @{ 'schema_version' = $true }
    foreach ($top in @($Data.Keys)) {
        if ($emitted.ContainsKey($top)) { continue }
        $block = $Data[$top]
        if ($block -isnot [System.Collections.Specialized.OrderedDictionary] -and $block -isnot [hashtable]) {
            [void]$lines.Add(("{0}: {1}" -f $top, (_FirePhoenixEmitScalar $block)))
            $emitted[$top] = $true
            continue
        }
        [void]$lines.Add("${top}:")
        foreach ($k in @($block.Keys)) {
            [void]$lines.Add(("  {0}: {1}" -f $k, (_FirePhoenixEmitScalar $block[$k])))
        }
        [void]$lines.Add('')
        $emitted[$top] = $true
    }

    Set-Content -LiteralPath $Path -Value (($lines -join "`n").TrimEnd() + "`n") -NoNewline -Encoding utf8
}

# Internal: load a user-context-style YAML file via the minimal 2-level
# parser. Returns $null when the file is absent. Uses ordered dicts so
# subsequent emit preserves source order (required for idempotency).
function _FirePhoenixLoadUserContext {
    param([string]$Path)
    if (-not (Test-Path -LiteralPath $Path)) { return $null }
    $parsed = [ordered]@{}
    $cur = $null
    foreach ($raw in Get-Content -LiteralPath $Path) {
        $line = $raw.TrimEnd()
        if ([string]::IsNullOrWhiteSpace($line)) { continue }
        if ($line.TrimStart().StartsWith('#')) { continue }
        if ($line -match '^([A-Za-z_][\w-]*):\s*$') {
            $cur = $Matches[1]
            if (-not $parsed.Contains($cur)) { $parsed[$cur] = [ordered]@{} }
            continue
        }
        if (-not $line.StartsWith(' ') -and $line -match '^([A-Za-z_][\w-]*):\s*(.*)$') {
            $k = $Matches[1]; $v = $Matches[2].Trim().Trim('"').Trim("'")
            if ($v -in @('null','~','')) { $v = $null }
            $parsed[$k] = $v
            $cur = $null
            continue
        }
        if ($line -match '^\s+([A-Za-z_][\w-]*):\s*(.*)$' -and $cur) {
            $k = $Matches[1]; $v = $Matches[2].Trim().Trim('"').Trim("'")
            if ($v -in @('null','~','')) { $v = $null }
            $parsed[$cur][$k] = $v
        }
    }
    return $parsed
}

$script:FirePhoenixDefaultCurrent = [ordered]@{
    feature   = $null
    intent    = $null
    plan      = $null
    tasks     = $null
    checklist = $null
    branch    = $null
}

# Read a dotted key (e.g. "current.feature") from .fire-phoenix/user-context.yml.
# Falls back to .fire-phoenix/context.yml if the key is absent or null in
# user-context.yml. Returns the value as a string, or empty string when
# absent from both files.
function Read-UserContextValue {
    param([Parameter(Mandatory=$true)][string]$Key)

    $section, $leaf = $Key -split '\.', 2
    if (-not $section -or -not $leaf) { throw 'Read-UserContextValue: <dotted.key> required (e.g. "current.feature")' }

    $repoRoot = if ($script:FirePhoenixCtx) { $script:FirePhoenixCtx.REPO_ROOT } else { Get-RepoRoot }
    $userFile = Join-Path $repoRoot '.fire-phoenix/user-context.yml'
    $projectFile = Join-Path $repoRoot '.fire-phoenix/context.yml'

    foreach ($path in @($userFile, $projectFile)) {
        $data = _FirePhoenixLoadUserContext -Path $path
        if (-not $data) { continue }
        $block = $data[$section]
        if ($block -isnot [hashtable]) { continue }
        $val = $block[$leaf]
        if ($null -eq $val -or $val -eq '') { continue }
        return [string]$val
    }
    return ''
}

# Write a dotted key (e.g. "current.feature") to .fire-phoenix/user-context.yml
# ONLY. Creates the file with a minimal schema-3.0 stub if absent.
# Idempotent: a no-op when the value already matches. NEVER touches
# .fire-phoenix/context.yml.
#
# Pass the literal string "null" as the value to set YAML null.
function Write-UserContextValue {
    param(
        [Parameter(Mandatory=$true)][string]$Key,
        [Parameter(Mandatory=$true)][AllowEmptyString()][string]$Value
    )

    $section, $leaf = $Key -split '\.', 2
    if (-not $section -or -not $leaf) { throw 'Write-UserContextValue: <dotted.key> required (e.g. "current.feature")' }

    $repoRoot = if ($script:FirePhoenixCtx) { $script:FirePhoenixCtx.REPO_ROOT } else { Get-RepoRoot }
    $fpDir = Join-Path $repoRoot '.fire-phoenix'
    if (-not (Test-Path -LiteralPath $fpDir)) {
        New-Item -ItemType Directory -Force -Path $fpDir | Out-Null
    }
    $userFile = Join-Path $fpDir 'user-context.yml'

    $val = if ($Value -eq 'null') { $null } else { $Value }

    $data = _FirePhoenixLoadUserContext -Path $userFile
    if (-not $data) { $data = [ordered]@{} }
    if (-not $data.Contains('schema_version')) { $data['schema_version'] = '3.0' }
    if ($data['current'] -isnot [System.Collections.Specialized.OrderedDictionary]) {
        $data['current'] = [ordered]@{}
        foreach ($k in $script:FirePhoenixDefaultCurrent.Keys) {
            $data['current'][$k] = $script:FirePhoenixDefaultCurrent[$k]
        }
    } else {
        foreach ($k in $script:FirePhoenixDefaultCurrent.Keys) {
            if (-not $data['current'].Contains($k)) {
                $data['current'][$k] = $script:FirePhoenixDefaultCurrent[$k]
            }
        }
    }
    if ($data[$section] -isnot [System.Collections.Specialized.OrderedDictionary]) {
        $data[$section] = [ordered]@{}
    }

    # Idempotency
    if ($data[$section].Contains($leaf) -and $data[$section][$leaf] -eq $val) { return }

    $data[$section][$leaf] = $val
    _FirePhoenixEmitUserContext -Data $data -Path $userFile
}

# -------------------------------------------------------------------
# Path resolution.
# -------------------------------------------------------------------

function Get-WorktypeDir {
    param([Parameter(Mandatory=$true)][string]$Name)
    if (-not $script:FirePhoenixCtx) { Read-Context | Out-Null }
    $dir = Join-Path (Join-Path $script:FirePhoenixCtx.REPO_ROOT $script:FirePhoenixCtx.DOCS_DIR) $Name
    New-Item -ItemType Directory -Force -Path $dir | Out-Null
    return $dir
}

function Get-FeatureScopedDir {
    param([Parameter(Mandatory=$true)][string]$Name)
    if (-not $script:FirePhoenixCtx) { Read-Context | Out-Null }
    if ([string]::IsNullOrEmpty($script:FirePhoenixCtx.CURRENT_FEATURE)) {
        throw "Get-FeatureScopedDir: .fire-phoenix/context.yml 'current.feature' is not set"
    }
    $dir = Join-Path `
        (Join-Path (Join-Path $script:FirePhoenixCtx.REPO_ROOT $script:FirePhoenixCtx.DOCS_DIR) $Name) `
        $script:FirePhoenixCtx.CURRENT_FEATURE
    New-Item -ItemType Directory -Force -Path $dir | Out-Null
    return $dir
}

# -------------------------------------------------------------------
# Agent-decisions log (see common.sh for the full contract).
# -------------------------------------------------------------------

function Write-Decision {
    param(
        [Parameter(Mandatory=$true)][ValidateSet('default-applied','alternative-picked','autonomous-action','debt-overridden')][string]$Kind,
        [Parameter(Mandatory=$true)][string]$What,
        [string]$Why = '',
        [string]$Alternatives = ''
    )

    if (-not $script:FirePhoenixCtx) { Read-Context | Out-Null }
    $agent = if ($env:FIRE_PHOENIX_AGENT) { $env:FIRE_PHOENIX_AGENT } else { 'shared' }
    $dateS = Get-Date -Format 'yyyy-MM-dd'
    $dir = Join-Path (Join-Path (Join-Path $script:FirePhoenixCtx.REPO_ROOT $script:FirePhoenixCtx.DOCS_DIR) 'agent-decisions') $agent
    $file = Join-Path $dir ("{0}-decisions.md" -f $dateS)
    New-Item -ItemType Directory -Force -Path $dir | Out-Null

    $next = 1
    if (Test-Path -LiteralPath $file) {
        $matches = Select-String -LiteralPath $file -Pattern '^### D-(\d+)' -AllMatches -ErrorAction SilentlyContinue |
            ForEach-Object { $_.Matches } | ForEach-Object { [int]$_.Groups[1].Value }
        if ($matches) { $next = ($matches | Measure-Object -Maximum).Maximum + 1 }
    } else {
        $header = @"
# Agent decisions — $agent — $dateS

**Mode:** $(if ($env:FIRE_PHOENIX_AGENT_MODE) { $env:FIRE_PHOENIX_AGENT_MODE } else { 'interactive' })

"@
        Set-Content -LiteralPath $file -Value $header
    }

    $id = '{0}-{1:D2}' -f 'D', $next
    $iso = (Get-Date).ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ssZ')

    $block = @"
### $id — $Kind

- **What:** $What
"@
    if ($Why) { $block += "`n- **Why:** $Why" }
    if ($Alternatives) { $block += "`n- **Alternatives considered:** $Alternatives" }
    $block += "`n- **Time:** $iso`n"

    Add-Content -LiteralPath $file -Value $block
    return $id
}

# -------------------------------------------------------------------
# Record-Decision — sanctioned L4 governance-authoring path (adr/0053).
# Writes an L4 decisions entry as a DRAFT into the pending queue
# (DECISIONS_PENDING_DIR); NEVER the canonical decisions_file. The
# promote-governance skill is the sole canonical writer. Identical in
# interactive and auto mode. Idempotent via a content-hash filename.
#   Record-Decision -Kind <kind> -Title <title> [-BodyFile <path>|-BodyText <text>]
# Emits the pending draft path; writes a .extract sidecar.
# -------------------------------------------------------------------

function _FirePhoenixShortHash {
    param([string]$Text)
    $sha = [System.Security.Cryptography.SHA256]::Create()
    try {
        $bytes = [System.Text.Encoding]::UTF8.GetBytes($Text)
        $hash = $sha.ComputeHash($bytes)
        $hex = -join ($hash | ForEach-Object { $_.ToString('x2') })
        return $hex.Substring(0, 12)
    } finally {
        $sha.Dispose()
    }
}

function Record-Decision {
    param(
        [Parameter(Mandatory=$true)][string]$Kind,
        [Parameter(Mandatory=$true)][string]$Title,
        [string]$BodyFile = '',
        [string]$BodyText = ''
    )

    if (-not $script:FirePhoenixCtx) { Read-Context | Out-Null }
    $dir = Join-Path $script:FirePhoenixCtx.REPO_ROOT $script:FirePhoenixCtx.DECISIONS_PENDING_DIR
    New-Item -ItemType Directory -Force -Path $dir | Out-Null

    $body = $BodyText
    if (-not $body -and $BodyFile -and (Test-Path -LiteralPath $BodyFile)) {
        $body = Get-Content -LiteralPath $BodyFile -Raw
    }

    $dateS = Get-Date -Format 'yyyy-MM-dd'
    $slug = ($Title.ToLower() -replace '[^a-z0-9]+', '-').Trim('-')
    if ($slug.Length -gt 50) { $slug = $slug.Substring(0, 50) }
    if (-not $slug) { $slug = 'decision' }

    $hash = _FirePhoenixShortHash ("{0}`0{1}`0{2}" -f $Kind, $Title, $body)
    $out = Join-Path $dir ("{0}-{1}-{2}.md" -f $dateS, $slug, $hash)

    if (Test-Path -LiteralPath $out) { return $out }

    $content = "## $dateS — $Title`n`n<!-- kind: $Kind | pending governance entry (adr/0053); promote via the promote-governance skill -->`n`n"
    if ($body) { $content += "$body`n" }
    Set-Content -LiteralPath $out -Value $content -NoNewline

    Write-Extract -ArtefactPath $out -Pairs @("KIND=$Kind", "TITLE=$Title", "DATE=$dateS", "STATUS=pending") | Out-Null
    return $out
}

# -------------------------------------------------------------------
# Debt register.
# -------------------------------------------------------------------

function Append-Debt {
    param(
        [Parameter(Mandatory=$true)][string]$File,
        [Parameter(Mandatory=$true)][string]$Prefix,
        [Parameter(Mandatory=$true)][string]$Body
    )

    $dir = Split-Path $File -Parent
    if ($dir -and -not (Test-Path -LiteralPath $dir)) {
        New-Item -ItemType Directory -Force -Path $dir | Out-Null
    }

    $next = 1
    if (Test-Path -LiteralPath $File) {
        $pattern = "^{0}-(\d+)" -f [regex]::Escape($Prefix)
        $nums = @()
        Get-Content -LiteralPath $File | ForEach-Object {
            if ($_ -match $pattern) { $nums += [int]$Matches[1] }
        }
        if ($nums.Count -gt 0) {
            $next = ($nums | Measure-Object -Maximum).Maximum + 1
        }
    } else {
        Set-Content -LiteralPath $File -Value "# Debt register ($Prefix)`n" -NoNewline
    }

    $id = '{0}-{1:D2}' -f $Prefix, $next
    Add-Content -LiteralPath $File -Value ("{0}: {1}" -f $id, $Body)
    return $id
}

# -------------------------------------------------------------------
# .extract companion files.
# -------------------------------------------------------------------

function Write-Extract {
    param(
        [Parameter(Mandatory=$true)][string]$ArtefactPath,
        [Parameter(ValueFromRemainingArguments=$true)][string[]]$Pairs
    )

    $extract = [System.IO.Path]::ChangeExtension($ArtefactPath, 'extract')
    $dir = Split-Path $extract -Parent
    if ($dir -and -not (Test-Path -LiteralPath $dir)) {
        New-Item -ItemType Directory -Force -Path $dir | Out-Null
    }

    Set-Content -LiteralPath $extract -Value "" -NoNewline
    foreach ($pair in $Pairs) {
        Add-Content -LiteralPath $extract -Value $pair
    }
    return $extract
}

# -------------------------------------------------------------------
# Confirm-BeforeWrite.
# -------------------------------------------------------------------

function Confirm-BeforeWrite {
    param([string]$Message = 'About to write.')

    if ($env:FIRE_PHOENIX_AUTO -eq '1') { return $true }
    if (-not $script:FirePhoenixCtx) { Read-Context | Out-Null }
    if (-not $script:FirePhoenixCtx.CONFIRM_BEFORE_WRITE) { return $true }

    $answer = Read-Host -Prompt "$Message  Proceed? [y/N]"
    return ($answer -match '^(y|yes)$')
}

# -------------------------------------------------------------------
# -Auto / env / answers / .extract resolution.
# -------------------------------------------------------------------

function Import-FirePhoenixAnswers {
    param([Parameter(Mandatory=$true)][string]$Path)
    if (-not (Test-Path -LiteralPath $Path)) { return }
    Get-Content -LiteralPath $Path | ForEach-Object {
        $line = $_.Trim()
        if ([string]::IsNullOrWhiteSpace($line)) { return }
        if ($line.StartsWith('#')) { return }
        $eq = $line.IndexOf('=')
        if ($eq -le 0) { return }
        $key = $line.Substring(0, $eq)
        $val = $line.Substring($eq + 1)
        $val = $val.Trim('"').Trim("'")
        if (-not (Test-Path -LiteralPath "env:$key")) {
            Set-Item -LiteralPath "env:$key" -Value $val
        }
    }
}

function Resolve-Auto {
    param(
        [Parameter(Mandatory=$true)][string]$Key,
        [string]$Default = ''
    )

    # 1. env var
    $val = [System.Environment]::GetEnvironmentVariable($Key)
    if ($val) { return $val }

    # 2. answers file
    if ($env:FIRE_PHOENIX_ANSWERS -and (Test-Path -LiteralPath $env:FIRE_PHOENIX_ANSWERS)) {
        $match = Get-Content -LiteralPath $env:FIRE_PHOENIX_ANSWERS |
            Where-Object { $_ -match "^$([regex]::Escape($Key))=" } |
            Select-Object -First 1
        if ($match) { return ($match -replace "^$([regex]::Escape($Key))=", '') }
    }

    # 3. .extract chain
    if ($env:FIRE_PHOENIX_EXTRACTS) {
        foreach ($extract in ($env:FIRE_PHOENIX_EXTRACTS -split ':')) {
            if (-not (Test-Path -LiteralPath $extract)) { continue }
            $match = Get-Content -LiteralPath $extract |
                Where-Object { $_ -match "^$([regex]::Escape($Key))=" } |
                Select-Object -First 1
            if ($match) { return ($match -replace "^$([regex]::Escape($Key))=", '') }
        }
    }

    return $Default
}

function Import-FirePhoenixStandardArgs {
    # Parses -Auto, -Answers FILE, -DryRun, -Help from $args.
    # Returns the remaining positional args so the caller can treat
    # them as its own inputs:
    #   $rest = Import-FirePhoenixStandardArgs $args
    param([Parameter(ValueFromRemainingArguments=$true)][string[]]$ArgList)

    $rest = @()
    $i = 0
    while ($i -lt $ArgList.Count) {
        switch -Regex ($ArgList[$i]) {
            '^-Auto$'    { $env:FIRE_PHOENIX_AUTO = '1' }
            '^-DryRun$'  { $env:FIRE_PHOENIX_DRY_RUN = '1' }
            '^-Answers$' {
                if ($i + 1 -ge $ArgList.Count) { throw '-Answers requires a file path' }
                $env:FIRE_PHOENIX_ANSWERS = $ArgList[$i + 1]
                $i++
            }
            '^-Help$|^-h$|^--help$' { $rest += '-Help' }
            default      { $rest += $ArgList[$i] }
        }
        $i++
    }
    if ($env:FIRE_PHOENIX_ANSWERS) { Import-FirePhoenixAnswers -Path $env:FIRE_PHOENIX_ANSWERS }
    return $rest
}

# =============================================================================
# === General utility helpers                                               ===
# === Available to every skill bundle's action scripts via `. common.ps1`.  ===
# === Per adr/0024: the SDD-era feature-branch helpers that previously sat  ===
# === here (Get-CurrentBranch / Test-FeatureBranch / Get-FeaturePathsEnv /  ===
# === Find-FeatureDirByPrefix / Get-FirePhoenixEffectiveBranchName /        ===
# === Get-FeatureDirFromBranchPrefixOrExit) were removed once the β-track   ===
# === skill re-architecture (adr/0023 Option E) closed. Action scripts read ===
# === .fire-phoenix/context.yml cursors via Read-Context instead.           ===
# =============================================================================

function Test-HasGit {
    if (-not (Get-Command git -ErrorAction SilentlyContinue)) {
        return $false
    }
    $repoRoot = Get-RepoRoot
    if (-not (Test-Path -LiteralPath (Join-Path $repoRoot ".git"))) {
        return $false
    }
    try {
        $null = git -C $repoRoot rev-parse --is-inside-work-tree 2>$null
        return ($LASTEXITCODE -eq 0)
    } catch {
        return $false
    }
}


function Test-FileExists {
    param([string]$Path, [string]$Description)
    if (Test-Path -Path $Path -PathType Leaf) {
        Write-Output "  ✓ $Description"
        return $true
    } else {
        Write-Output "  ✗ $Description"
        return $false
    }
}

function Test-DirHasFiles {
    param([string]$Path, [string]$Description)
    if ((Test-Path -Path $Path -PathType Container) -and (Get-ChildItem -Path $Path -ErrorAction SilentlyContinue | Where-Object { -not $_.PSIsContainer } | Select-Object -First 1)) {
        Write-Output "  ✓ $Description"
        return $true
    } else {
        Write-Output "  ✗ $Description"
        return $false
    }
}

# Resolve a template name to a file path using the priority stack:
#   1. .fire-phoenix/templates/overrides/
#   2. .fire-phoenix/presets/<preset-id>/templates/ (sorted by priority from .registry)
#   3. .fire-phoenix/extensions/<ext-id>/templates/
#   4. .fire-phoenix/templates/ (core)
#   5. Skill's own bundled templates (self-contained fallback)
function Resolve-Template {
    param(
        [Parameter(Mandatory=$true)][string]$TemplateName,
        [Parameter(Mandatory=$true)][string]$RepoRoot
    )

    $base = Join-Path $RepoRoot '.fire-phoenix/templates'

    # Priority 1: Project overrides
    $override = Join-Path $base "overrides/$TemplateName.md"
    if (Test-Path $override) { return $override }

    # Priority 2: Installed presets (sorted by priority from .registry)
    $presetsDir = Join-Path $RepoRoot '.fire-phoenix/presets'
    if (Test-Path $presetsDir) {
        $registryFile = Join-Path $presetsDir '.registry'
        $sortedPresets = @()
        if (Test-Path $registryFile) {
            try {
                $registryData = Get-Content $registryFile -Raw | ConvertFrom-Json
                $presets = $registryData.presets
                if ($presets) {
                    $sortedPresets = $presets.PSObject.Properties |
                        Sort-Object { if ($null -ne $_.Value.priority) { $_.Value.priority } else { 10 } } |
                        ForEach-Object { $_.Name }
                }
            } catch {
                $sortedPresets = @()
            }
        }

        if ($sortedPresets.Count -gt 0) {
            foreach ($presetId in $sortedPresets) {
                $candidate = Join-Path $presetsDir "$presetId/templates/$TemplateName.md"
                if (Test-Path $candidate) { return $candidate }
            }
        } else {
            foreach ($preset in Get-ChildItem -Path $presetsDir -Directory -ErrorAction SilentlyContinue | Where-Object { $_.Name -notlike '.*' }) {
                $candidate = Join-Path $preset.FullName "templates/$TemplateName.md"
                if (Test-Path $candidate) { return $candidate }
            }
        }
    }

    # Priority 3: Extension-provided templates
    $extDir = Join-Path $RepoRoot '.fire-phoenix/extensions'
    if (Test-Path $extDir) {
        foreach ($ext in Get-ChildItem -Path $extDir -Directory -ErrorAction SilentlyContinue | Where-Object { $_.Name -notlike '.*' } | Sort-Object Name) {
            $candidate = Join-Path $ext.FullName "templates/$TemplateName.md"
            if (Test-Path $candidate) { return $candidate }
        }
    }

    # Priority 4: Core templates
    $core = Join-Path $base "$TemplateName.md"
    if (Test-Path $core) { return $core }

    # Priority 5: Skill's own bundled templates (self-contained fallback)
    if ($PSScriptRoot) {
        $skillTpl = Join-Path (Split-Path (Split-Path $PSScriptRoot)) "templates" "$TemplateName.md"
        if (Test-Path $skillTpl) { return $skillTpl }
    }

    return $null
}
