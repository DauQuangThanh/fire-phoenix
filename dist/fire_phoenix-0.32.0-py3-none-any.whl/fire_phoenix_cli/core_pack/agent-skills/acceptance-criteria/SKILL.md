---
name: acceptance-criteria
description: Authors Given/When/Then acceptance criteria for user stories from the spec; user refines, AI does not approve or sign off. Produces the single file testers and product-owner reference. Use when writing acceptance criteria or defining what 'done' means for a story.
license: MIT
compatibility: Designed for agentskills.io-compatible agents.
metadata:
  author: Dau Quang Thanh
  version: '1.0'
  requires: [intent]
---

## User Input

```text
$ARGUMENTS
```

## Audience and tone (interactive mode)

**Register first — adapt to role level.** Before applying the beginner floor
below, resolve the reader's level from the merged `.fire-phoenix/context.yml`
+ `.fire-phoenix/user-context.yml` (`user-context.yml` wins): use
`preferences.tech_role_level` for technical work (`junior` → hand-hold, one
path; `mid` → ≥2 options with one-line trade-offs; `senior` → defer on
judgment, surface edge cases, be brief; `staff` → be terse, challenge
premises, skip obvious caveats) and `preferences.non_tech_role_level` for
stakeholder work (`non-technical` → outcomes not jargon; `familiar` → simple
jargon glossed; `fluent` → concepts without explanation; `technical` → full
vocabulary). An explicit in-session signal (e.g. "be terse", "skip the
explanation") overrides everything. The plain-English, one-question-at-a-time
floor below applies **only when the relevant level is unset**; never treat
role level as a gate. Full rule: `.fire-phoenix/references/subagents/register-resolution.md`.

When `FIRE_PHOENIX_AGENT_MODE=interactive` (the default), assume the user
has **no technical or business-domain background**. This questionnaire
**is** the non-technical authoring path: Given/When/Then is the
plain-language layer of acceptance, and a non-technical member must
be able to author and confirm every criterion through it. Run this
skill as a guided questionnaire:

- **One question at a time.** No walls of questions.
- **Yes / no first.** Phrase so `yes`, `no`, `not sure`, or `skip`
  is a valid answer.
- **No jargon.** Translate domain terms into everyday words. Don't
  ask "give me Given / When / Then" — ask "When the feature works,
  what's the **simplest test** a user can do to prove it? What
  would clearly fail it?" Then *you* turn it into Given / When /
  Then in the file.
- **Choices, not blank fields.** When yes/no isn't enough, offer
  2-4 lettered options (A/B/C/D) with one-line everyday
  descriptions. Always include "Not sure — pick a sensible default".
- **Always recommend.** State the option you would pick and why in
  one sentence so the user can reply "yes" / "ok" to accept.
- **`not sure` / `skip` triggers a sensible default** acceptance
  criterion, marked "(default applied — confirm later)" in
  `acceptance.md`, and a `PODEBT-` entry in `product-debts.md`.

When `FIRE_PHOENIX_AGENT_MODE=auto` (or `--auto`), skip the questionnaire
entirely: draft criteria from the spec and log assumptions to the
product-owner agent's decision log.

## Inputs

- `.fire-phoenix/context.yml` → `paths.docs`, `paths.intents`, `current.feature`
- `{context.paths.intents}/**/intent.md` — user stories source

## Outputs

- `{context.paths.docs}/product/acceptance.md` — all acceptance
  criteria keyed by user-story id.
- `{context.paths.docs}/product/acceptance.extract` — counts of
  stories covered / missing.

## Context Update

Does not mutate `.fire-phoenix/context.yml`.

## Handoffs

- `test-cases` consumes acceptance criteria to generate
  test cases.
- `backlog` links each backlog item to its acceptance entry.

## AI authoring scope

**Does:** draft Given/When/Then criteria from the spec's user
stories; propose edge-case criteria; log stories with no criteria
as debts.

**Does not:** approve or sign off criteria; commit to scope; decide
what "done" means without user confirmation.

## Usage

> `<SKILL_DIR>` = the integration's skills root (e.g. `.claude/skills/`
> for Claude Code, `.codex/skills/` for Codex,
> `.cursor/skills/` for Cursor, `.kiro/skills/` for Kiro).
> Scripts live at `<SKILL_DIR>/<skill-name>/scripts/…`.

```bash
# Re-draft acceptance criteria for the active feature from intent.md.
bash <SKILL_DIR>/acceptance-criteria/scripts/bash/draft-acceptance.sh --auto
```

## AC numbering

Number every criterion **AC-NNN** (AC-001, AC-002, …), sequential
per user story and zero-padded to three digits. AC-IDs are stable
once written: append new criteria, never renumber existing ones —
downstream artefacts (task contracts, test cases, unit tests) cite
AC-IDs, and a renumber breaks that traceability.

## Failure-path coverage

Where the intent names a failure condition (invalid input, denied
access, timeout, quota exceeded, …), the story MUST carry at least
one negative / failure-path AC covering it. Under rigor profile
**P** (Prototype/Demo), a happy-path-only set is acceptable — state
that explicitly in `acceptance.md` when applying it. Read the
declared profile from the project context; when no profile is
declared, behave as profile **F** (full weight).

## Interactive flow

Read the active feature's `intent.md`. For each user story (US-NN):

1. Propose 2–4 Given/When/Then criteria covering the happy path
   and obvious edge cases, numbered AC-NNN per story. Include at
   least one failure-path criterion for every failure condition the
   intent names (see Failure-path coverage above).
2. Ask the user to accept / edit / add more.
3. Write into `{context.paths.docs}/product/acceptance.md` under a heading matching
   the user-story id.

## Recording the G1 agreement

Once the acceptance gate resolves (developer confirms feasibility,
tester confirms testability, product owner confirms business fit —
advisory inputs to the single human approver), the canonical record
is a **dated entry in the project's decisions file**
(`{context.governance.decisions_file}`) naming the epic/feature and
each confirmation by name — recorded via the `record_decision` helper
(a pending draft) and promoted with the `promote-governance` skill
(adr/0053), never hand-written into the canonical file. Under rigor
Profile P a single confirmer
is acceptable — name that confirmer in the entry. A `## G1
agreement` section in `acceptance.md` (per the template) MAY mirror
the entry for convenience, but the decisions entry is the record
gates check: a sign-off block in `acceptance.md` alone does not
satisfy the gate. Decomposition (`/taskify`) before the dated
decisions entry exists is a lint finding (R9).

## Debt register

File `{context.paths.docs}/product/product-debts.md`, prefix
`PODEBT-`. Log when a user story has no criteria, or when criteria
are ambiguous (no measurable outcome).

## References

- `references/gwt-style-guide.md` — how to write Given/When/Then
  cleanly.
