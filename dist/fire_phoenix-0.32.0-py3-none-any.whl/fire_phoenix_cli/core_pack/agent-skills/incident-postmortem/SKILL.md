---
name: incident-postmortem
description: Runs the blameless incident-postmortem loop. Drafts a postmortem
  under ops/postmortem-<slug>.md, captures the evidence chain + root
  cause, and ENFORCES the "Which intent artefact changes?" section so
  every incident feeds back into the IDD intent layer (otherwise the
  incident can recur).
license: MIT
compatibility: Designed for agentskills.io-compatible agents.
metadata:
  author: Dau Quang Thanh
  version: '1.0'
  requires: []
---

## User Input

```text
$ARGUMENTS
```

You **MUST** consider the user input before proceeding (if not empty).

## Pre-Execution Checks

1. **Ask** for the incident slug (kebab-case, e.g.
   `payment-queue-2026-04-30`). If a postmortem already exists at
   `{context.paths.docs}/ops/postmortem-<slug>.md`, REFUSE to overwrite.
2. **Confirm blameless framing** with the user: focus on systems, not
   individuals. If the user insists on blame language, surface the
   blameless-postmortem rule (root cause stops at the absent
   guardrail / missing test / unstated invariant, never at a person's
   action) and ask them to reframe.
3. **Ask** for the timeline of observable events with UTC timestamps.
   Each row must link to a log / metric / alert / commit — not a
   recollection.

## Outline

Draft all 9 sections from `templates/postmortem-template.md`:

1. **Summary** — one paragraph: what happened, blast radius, detection
   time, resolution time.
2. **Timeline** — UTC observable events only.
3. **Evidence chain** — "we saw X, which means Y" chain. Each link
   defensible from a log / metric.
4. **Root cause(s)** — Five-whys to the SYSTEMIC cause. Stop at the
   absent guardrail / missing test / unstated invariant — NEVER at a
   person's action.
5. **Contributing factors** — load spike, deploy timing, on-call
   coverage gaps.
6. **Detection gap** — incident start to detection. Surface the SLO
   question.
7. **Response gap** — detection to resolution. Surface the runbook
   question.
8. **Which intent artefact changes? (MANDATORY)** — the load-bearing
   section.
9. **Re-occurrence risk after these changes** — honest assessment.

## The MANDATORY incident → intent loop

The "Which intent artefact changes?" section is what makes a postmortem
USEFUL beyond catharsis. It enforces that every production incident
feeds back into the intent layer.

For each finding the postmortem surfaces, propose AT LEAST ONE
amendment:

- **New characterisation test** at `tests/characterisation/test_<surface>.py`
  pinning the observed-correct behaviour, so a future regression is
  caught at CI not at 2 AM.
- **New L1 invariant** in `PRODUCT.md §Invariants` — what must always
  hold that didn't. Promotion requires a human (BA / architect).
- **New guardrail** in `CLAUDE.md` negative constraints — what must
  never be done that was done.
- **New failure-path AC** in the feature's acceptance list — the
  failure condition becomes a negative acceptance criterion the
  harness can check (hand off to the business-analyst).
- **Strengthened SLO** at `ops/slo-*.yml` — tighter target, or a new
  SLO entirely (hand off to `slo-define` skill).
- **Amended runbook** at `ops/runbook-*.md` — what step was wrong /
  missing (hand off to `runbook-author` skill).
- **New ADR** at `adr/NNNN-*.md` — what structural decision needs a
  revisit.

Each corrective action lands as a task contract **citing the amended
intent artefact** — that is how the harness gains the checks that would
have caught the incident. For each checked box, **the postmortem MUST
link the realised contract / PR / commit** that lands the change. The
postmortem closes only when every checked box has a realised landing.

If a postmortem reaches the §9 closure without §8 amendments named, the
skill SURFACES the gap — "the incident → intent loop is broken; what
amends?" — and refuses to mark the postmortem closed.

## Containment fast track (what precedes this skill)

Containment usually lands before the postmortem starts. WHEN an
incident or vulnerability requires immediate containment, THE
first-hour actions (pin, flag off, rollback, WAF rule) proceed WITHOUT
a task contract; THE persistent fix SHALL get its contract, spec
citation, and regression test within the next working day. The
postmortem's Timeline lists the containment actions, and they are
recorded retroactively in the project's `decisions.md` via the
`record_decision` helper (a pending draft) and promoted with the
`promote-governance` skill (adr/0053). The persistent
fix is reviewed at the change class its blast radius earns — not the
class the urgency tempts. This allowance is rigor-profile-independent
(P / M / F alike).

## Post-Execution Checks

- All 9 sections present.
- Timeline rows have observables (links, not prose).
- Root cause stops at a systemic cause, not a person.
- §8 has at least one checked box.
- §8 checked boxes each link to a realised landing OR a tracking
  contract that does.

## Inputs

- `.fire-phoenix/context.yml` (`{context.paths.docs}` for output root).
- User input: incident slug + timeline events + evidence pointers.
- Existing runbook (if any) that fired during the incident — link from
  §3 / §7.
- Existing SLO (if any) for the affected surface — link from §6.

## Outputs

- `{context.paths.docs}/ops/postmortem-<slug>.md` — the 9-section
  postmortem draft. The user reviews, fills, and commits.

## Context Update

This skill does NOT mutate `.fire-phoenix/context.yml`. The postmortem
under `{context.paths.docs}/ops/` is the only on-disk side-effect.

## Handoffs

- **`runbook-author` skill** — if §7 Response gap surfaces a runbook
  amendment (or a missing runbook entirely).
- **`slo-define` skill** — if §6 Detection gap surfaces an SLO
  amendment.
- **BA / architect** (subagent or human) — for §8 L1 invariant
  promotion / new ADR / failure-path AC.
- **`characterise-behaviour` skill** (task-0035) — for §8
  characterisation test authoring.

## Refusal modes (negative constraints)

- **Refuse** to author a postmortem with blame language. Surface
  the framing requirement and ask the user to reframe.
- **Refuse** to close a postmortem with §8 empty — the incident →
  intent loop must complete.
- **Refuse** to overwrite an existing postmortem.
- **No autonomous remediation.** The skill drafts findings,
  hypotheses, and amendments; deciding and executing remediation is
  human-owned — AI-assisted investigation is the norm, autonomous
  remediation the exception.
- **No ITSM / publishing.** This skill drafts the document; broadcast
  / archival / executive-summary distribution is the user's call,
  outside the skill's scope.
