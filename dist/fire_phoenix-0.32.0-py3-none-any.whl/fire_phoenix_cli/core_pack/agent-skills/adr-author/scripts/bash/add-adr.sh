#!/usr/bin/env bash
set -e
SCRIPT_DIR="$(CDPATH="" cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=common.sh
source "$SCRIPT_DIR/common.sh"
fire_phoenix_parse_standard_args "$@"
set -- "${FIRE_PHOENIX_REST_ARGS[@]}"

if [ "${1:-}" = "--help" ]; then
    cat <<'USAGE'
Usage: add-adr.sh [--auto] [--answers FILE] [--dry-run]
Writes an ADR DRAFT to {governance.adr_drafts_dir}/<slug>-<hash>.md (adr/0053).
The canonical NNNN number and the final location under {governance.adr_dir}
are assigned later by the promote-governance skill (interactive, human-confirmed)
— this script never writes the canonical adr_dir. adr_drafts_dir defaults to
docs/adr-drafts.
Answer keys: ADR_TITLE, ADR_DECIDER, ADR_CONTEXT, ADR_DECISION,
  ADR_CONSEQUENCES, ADR_STATUS, ADR_SUPERSEDES.
USAGE
    exit 0
fi

read_context
SKILL_DIR="$(CDPATH="" cd "$SCRIPT_DIR/../.." && pwd)"
# adr/0053: producers write DRAFTS to the pending queue in every mode; the
# promote-governance skill is the sole writer of the canonical adr_dir. The
# legacy-guard + canonical numbering (contracts/task-0077) moved to promote-adrs.
DIR="$FIRE_PHOENIX_REPO_ROOT/$FIRE_PHOENIX_ADR_DRAFTS_DIR"
DEBTS="$FIRE_PHOENIX_REPO_ROOT/$FIRE_PHOENIX_DOCS_DIR/architecture/tech-debts.md"

TITLE=$(resolve_auto ADR_TITLE "") || missing_title=1
DECIDER=$(resolve_auto ADR_DECIDER "") || missing_decider=1
CONTEXT=$(resolve_auto ADR_CONTEXT "") || missing_context=1
DECISION=$(resolve_auto ADR_DECISION "") || missing_decision=1
CONSEQ=$(resolve_auto ADR_CONSEQUENCES "") || true
STATUS=$(resolve_auto ADR_STATUS "Proposed") || true
SUP=$(resolve_auto ADR_SUPERSEDES "") || true

case "$STATUS" in Proposed|Accepted|Deprecated|Superseded|Inferred) ;; *) STATUS="Proposed";; esac

if [ -z "$TITLE" ]; then echo "ERROR: ADR_TITLE is required" >&2; exit 2; fi

# slug + content hash (idempotency: same title+decision -> same draft file).
SLUG=$(echo "$TITLE" | tr '[:upper:]' '[:lower:]' | sed 's/[^a-z0-9]/-/g; s/-\+/-/g; s/^-//; s/-$//' | cut -c1-60)
[ -n "$SLUG" ] || SLUG="adr"
HASH=$(printf '%s\0%s' "$TITLE" "${DECISION:-}" | _fire_phoenix_short_hash)
OUT="$DIR/$SLUG-$HASH.md"
SUP_LINE=""
[ -n "$SUP" ] && SUP_LINE="**Supersedes:** $SUP"

if [ "${FIRE_PHOENIX_DRY_RUN:-0}" = "1" ]; then
    echo "[dry-run] would write draft: $OUT"
    echo "  title=$TITLE  status=$STATUS  decider=${DECIDER:-<TBD>}"
    exit 0
fi

if ! confirm_before_write "Write ADR draft at $OUT (promote later via the promote-governance skill)."; then
    echo "Aborted." >&2; exit 1
fi

mkdir -p "$DIR"
if [ -f "$OUT" ]; then echo "ADR draft already exists (idempotent): $OUT"; exit 0; fi

# Provisional number "DRAFT" — promote-adrs assigns the canonical NNNN and
# rewrites the heading + filename when the human promotes.
TPL="$SKILL_DIR/templates/adr-template.md"
CTX_FILE=$(mktemp -t adr.XXXXXX)
DEC_FILE=$(mktemp -t adr.XXXXXX)
CON_FILE=$(mktemp -t adr.XXXXXX)
printf '%s\n' "${CONTEXT:-<TBD>}"   > "$CTX_FILE"
printf '%s\n' "${DECISION:-<TBD>}"  > "$DEC_FILE"
printf '%s\n' "${CONSEQ:-<TBD>}"    > "$CON_FILE"

awk -v number="DRAFT" \
    -v title="$TITLE" \
    -v datev="$(date +%Y-%m-%d)" \
    -v status="$STATUS" \
    -v decider="${DECIDER:-<TBD>}" \
    -v supline="$SUP_LINE" \
    -v ctxfile="$CTX_FILE" \
    -v decfile="$DEC_FILE" \
    -v confile="$CON_FILE" '
    function slurp(f,   line, out) {
        while ((getline line < f) > 0) { out = out line "\n" }
        close(f)
        return out
    }
    {
        gsub(/\{number\}/, number)
        gsub(/\{title\}/, title)
        gsub(/\{date\}/, datev)
        gsub(/\{status\}/, status)
        gsub(/\{decider\}/, decider)
        gsub(/\{supersedes_line\}/, supline)
        if (index($0, "{context}")) {
            sub(/\{context\}/, slurp(ctxfile))
        }
        if (index($0, "{decision}")) {
            sub(/\{decision\}/, slurp(decfile))
        }
        if (index($0, "{consequences}")) {
            sub(/\{consequences\}/, slurp(confile))
        }
        print
    }
' "$TPL" > "$OUT"

rm -f "$CTX_FILE" "$DEC_FILE" "$CON_FILE"

# Sidecar carries SLUG so promote-adrs can build the canonical filename.
write_extract "$OUT" "ADR_ID=DRAFT" "SLUG=$SLUG" "TITLE=$TITLE" "STATUS=$STATUS" "DECIDER=$DECIDER" > /dev/null
echo "Wrote draft $OUT"
echo "Promote to ${FIRE_PHOENIX_ADR_DIR} via the promote-governance skill (interactive, human-confirmed)."

if [ -n "${missing_context:-}" ] || [ -n "${missing_decision:-}" ]; then
    append_debt "$DEBTS" TDEBT "ADR draft '$TITLE' has incomplete context or decision — flesh out before promoting" > /dev/null
fi
if [ -n "${missing_decider:-}" ]; then
    append_debt "$DEBTS" TDEBT "ADR draft '$TITLE' has no decider recorded" > /dev/null
fi
