---
name: adr-author
description: Authors Architecture Decision Records (ADRs) in the Michael Nygard template — one per file, auto-numbered, under governance.adr_dir (default docs/adr/). Records the decision the user made; does not make decisions. Use when documenting why a technical or design choice was selected.
license: MIT
compatibility: Designed for agentskills.io-compatible agents.
metadata:
  author: Dau Quang Thanh
  version: '1.0'
  requires: []
---

## User Input

```text
$ARGUMENTS
```

## Audience and tone (interactive mode)

**Register first — adapt to role level.** Before applying the beginner floor
below, resolve the reader's level from the merged `.fire-phoenix/context.yml`
+ `.fire-phoenix/user-context.yml` (`user-context.yml` wins): use
`preferences.tech_role_level` for technical work (`junior` → hand-hold, one
path; `mid` → ≥2 options with one-line trade-offs; `senior` → defer on
judgment, surface edge cases, be brief; `staff` → be terse, challenge
premises, skip obvious caveats) and `preferences.non_tech_role_level` for
stakeholder work (`non-technical` → outcomes not jargon; `familiar` → simple
jargon glossed; `fluent` → concepts without explanation; `technical` → full
vocabulary). An explicit in-session signal (e.g. "be terse", "skip the
explanation") overrides everything. The plain-English, one-question-at-a-time
floor below applies **only when the relevant level is unset**; never treat
role level as a gate. Full rule: `.fire-phoenix/references/subagents/register-resolution.md`.

When `FIRE_PHOENIX_AGENT_MODE=interactive` (the default), assume the user
has **limited technical background and limited domain knowledge**
— they may know basics but lack deep expertise in this skill's
area. Run this skill as a guided questionnaire:

- **One question at a time.** No walls of questions.
- **Yes / no first.** Phrase so `yes`, `no`, `not sure`, or `skip`
  is a valid answer.
- **Translate jargon, don't strip it.** Use the technical term but
  always pair it with a plain-English gloss the first time it
  appears.
- **Choices, not blank fields.** When yes/no isn't enough, offer
  2-4 lettered options (A/B/C/D) with one-line plain-language
  descriptions of the trade-off. Always include "Not sure — pick
  a sensible default".
- **Always recommend.** State the option you would pick and why in
  one sentence so the user can reply "yes" / "ok" to accept. Pull
  defaults from upstream artefacts (spec, architecture, ADRs,
  standards) before asking blank.
- **Show, don't ask.** When upstream artefacts already imply an
  answer, propose it as a pre-filled finding and ask for a
  yes / no confirmation rather than asking the user to fill in a
  blank.
- **`not sure` / `skip` triggers a sensible default**, marked
  "(default applied — confirm later)" in the artefact, and a debt
  entry in this skill's debt file.

When `FIRE_PHOENIX_AGENT_MODE=auto` (or `--auto`), skip the questionnaire
entirely: apply sensible defaults from upstream artefacts and log
decisions to the parent agent's decision log.

## Inputs

- `.fire-phoenix/context.yml`
- `{context.paths.docs}/architecture/intake.md`
- `{context.paths.docs}/research/*.md`

## Outputs

- `{context.governance.adr_dir}/NNNN-<slug>.md`

## Context Update

Does not mutate `.fire-phoenix/context.yml`.

## Handoffs

- `c4-diagrams` cross-links ADRs from container-level
  diagrams where the decision manifests in the architecture.
- `architecture-extraction` (technical-analyst) references existing
  ADRs when reverse-engineering a codebase.

## AI authoring scope

**Does:** scaffold the ADR with the template, pre-fill
context/consequences from linked research, record Status =
"Proposed" until the user updates it to "Accepted".

**Does not:** accept or supersede an ADR on the user's behalf;
declare something "the decision" unless the user stated it.

## Authoring flow

1. **Confirm the decision is ripe** — the user can state the
   context, the candidates, and the consequence of choosing.
   If not, route back to `technology-research` or
   `clarify-intent` first.
2. **One decision per ADR** — if the request bundles several
   choices (database + cache + queue), split before drafting.
3. **Scaffold and pre-fill** — use the template; pull Context
   and Alternatives evidence from the linked research file.
4. **Quality gate** — walk
   `references/adr-quality-checklist.md` field by field: the
   Decision imperative and one sentence, each Alternative a real
   candidate with its trade-off, the Re-decision trigger
   falsifiable, the Door type stating its reversal cost. Fix
   failures or log a debt naming the missing field.
5. **Hand to the decider** — present the draft; Status stays
   `Proposed` until the human accepts. Retrospective ADRs
   (recording an already-made or code-extracted decision) say so
   explicitly.

## Inferred-ADR mode

Brownfield / migration recovery surfaces decisions the original team made
but never recorded. To capture one WITHOUT claiming it was a deliberate,
reviewed decision, run with `ADR_STATUS=Inferred`:

- **`Status: Inferred (confidence: low|med|high)`** — the ADR records a
  decision *reverse-engineered from the code*, not one a human stated.
  Cite the evidence (`file:line`, commit, config) in Context.
- **Never auto-promote.** An Inferred ADR stays Inferred until a human
  reviews it and sets Status to `Decided` (or supersedes it). The skill
  NEVER writes `Decided` for an inferred decision on the user's behalf —
  that is the human gate.
- **INFERRED is not OBSERVED.** If the code shows *what* was chosen but
  not *why*, mark the rationale `INFERRED` and leave the true rationale a
  `TBD-source` for the human to confirm — do not invent one.

Pairs with `recover-spec`: recovered behaviours whose *why* is a decision
become Inferred ADRs, promoted to `Decided` only after human review.

## Usage

> `<SKILL_DIR>` = the integration's skills root (e.g. `.claude/skills/`
> for Claude Code, `.codex/skills/` for Codex,
> `.cursor/skills/` for Cursor, `.kiro/skills/` for Kiro).
> Scripts live at `<SKILL_DIR>/<skill-name>/scripts/…`.

```bash
ADR_TITLE="Choose PostgreSQL as primary store" \
ADR_DECIDER="tech-lead" \
ADR_CONTEXT="Need ACID + relational joins" \
ADR_DECISION="Use PostgreSQL 16 on managed RDS" \
ADR_CONSEQUENCES="Vendor lock-in to AWS RDS; HA story via Multi-AZ" \
ADR_STATUS="Proposed" \
  bash <SKILL_DIR>/adr-author/scripts/bash/add-adr.sh --auto
```

### Answer keys

| Key | Meaning | Default |
|---|---|---|
| `ADR_TITLE` | decision title | *(required)* |
| `ADR_DECIDER` | person / role making the call (Owner) | *(required)* |
| `ADR_DEADLINE` | when the decision lands (or `n/a` for retrospective) | `n/a` |
| `ADR_DOOR_TYPE` | `one-way` (irreversible) / `two-way` (reversible) | *(required → log debt if empty)* |
| `ADR_CONTEXT` | situation + forces | *(required → log debt if empty)* |
| `ADR_DECISION` | what was decided | *(required → log debt if empty)* |
| `ADR_ALTERNATIVES` | candidates evaluated with one-line trade-off each | *(required → log debt if empty)* |
| `ADR_SUCCESS_CRITERIA` | falsifiable, harness-checkable conditions confirming implementation | *(required → log debt if empty)* |
| `ADR_RE_DECISION_TRIGGER` | specific events that would force a new ADR to supersede this one | *(required → log debt if empty)* |
| `ADR_CONSEQUENCES` | trade-offs accepted | empty |
| `ADR_STATUS` | `Proposed` / `Decided` / `Superseded` / `Inferred` (see Inferred-ADR mode) | `Proposed` |
| `ADR_SUPERSEDES` | ADR id this replaces | empty |

## References

- `references/nygard-style.md` — section layout, voice, and
  versioning rules.
- `references/adr-quality-checklist.md` — per-field quality bars
  for the full anatomy + anti-patterns (retro-fitted ADRs,
  bundled decisions, strawman alternatives).
