---
name: parity-ledger
description: Drafts a parity ledger + parity-harness runner skeleton for a migration cutover — {input → expected old → expected new → assertion} rows run against BOTH implementations; rows immutable; mismatches block cutover unless different-but-traced. See references/migration-discipline.md.
license: MIT
compatibility: Designed for agentskills.io-compatible agents.
metadata:
  author: Dau Quang Thanh
  version: '1.0'
  requires: []
---

## User Input

```text
$ARGUMENTS
```

You **MUST** consider the user input before proceeding (if not empty).

## Pre-Execution Checks

1. **Confirm migration scope.** Ask which OLD module(s) the migration
   retires and which NEW module(s) replace them. Vague answers ("the
   old system") are rejected — pin down specific pointers.
2. **Confirm cutover target date + owner.** A migration without a
   cutover date is open-ended; a migration without a named owner is
   un-decideable. Both go into the ledger's scope section.
3. **Confirm at least one ledger row.** A parity ledger with zero
   rows is empty — the user must seed at least one
   {input → expected old → expected new → assertion} row. The skill
   refuses to author an empty ledger.

## Outline

Author two files at `tests/parity/<slug>-ledger.md` and
`tests/parity/<slug>-harness.py`:

1. **`<slug>-ledger.md`** per `templates/parity-ledger-template.md`:
   - Migration scope section (old, new, cutover target, owner).
   - Ledger rows table — 4-column row + supersedes:
     `# | Input | Expected OLD | Expected NEW | Assertion | Supersedes`.
   - Assertion vocabulary section.
   - Progress & percent-automated section (one status per row).
   - Cutover-blocking issues protocol.
2. **`<slug>-harness.py`** per `templates/parity-harness-template.py`:
   - Reads the ledger, parses rows.
   - Exercises both implementations via `run_row()` (skeleton; the
     engineer wires the actual imports + calls).
   - Reports mismatches + an overall in-parity ratio; after each
     run, results are recorded row by row into the ledger's
     Progress section.

## The immutable-rows discipline

Once a row is captured (engineer verified what old code DOES with the
input + agreed what new code SHOULD do), the row is FROZEN. Amendments
are NEW rows that explicitly cite `Supersedes: #<N>` in the Supersedes
column.

The skill REFUSES to edit an existing row in place. If the user wants
to change a row, the skill:

1. Asks for the supersedes target (`#<N>`).
2. Authors a NEW row at the bottom of the table with `Supersedes: #N`.
3. Marks the prior row as superseded (does NOT delete it).

This preserves the audit trail; post-cutover review can read the full
chain of "we decided X, then we re-decided Y because Z".

## The honest metric: percent automated

The migration pipeline is hybrid — deterministic transforms where
possible, an AI pass only where necessary, with a validation gate
per unit (row). The ledger's summary metric is **percent
automated**, never "fully automated". Each row carries exactly one
status in the Progress section:

- **pending**: not yet exercised.
- **automated**: passed its assertion with no human intervention.
- **human-finished**: passed only after a human completed or
  corrected the work.
- **blocked**: retries exhausted; waiting on a human decision.

The summary reports the split side by side
(`automated / human-finished / blocked / pending`). Plan for a
human tail — a ledger that claims 100% automation up front has not
met its data yet.

Status lives in its own Progress section, NOT in the row table:
rows stay immutable (the decision record), status is mutable (the
progress record). The two never mix.

## Resumable units + the retry loop

Sessions are stateless; the ledger in the repo is the system of
record for progress. Each row is an independently resumable unit:

- A harness re-run resumes from rows whose status is not
  `automated`; completed rows are never redone (idempotent re-run).
- Any fresh session picks the migration up by reading the ledger —
  no session memory required.
- When a row mismatches, the harness's failure output (the OLD/NEW
  diff) is fed back into the next fix attempt as context. Retries
  are bounded (default 2); when exhausted, mark the row `blocked`
  and surface it for a human — never brute-force the loop.

## Assertion vocabulary

Bounded set (free-text assertions rejected):

- **equals**: byte-identical.
- **equivalent**: structurally identical (whitespace / ordering tolerant).
- **subset**: new output ⊂ old (lossy migration; spec MUST authorise).
- **superset**: new output ⊃ old.
- **different-but-traced**: divergence intentional; the row MUST cite
  the spec section (e.g. `specs/epic-billing-v2.md §3.2`).

## Post-Execution Checks

- Both files exist at `tests/parity/<slug>-ledger.md` and
  `tests/parity/<slug>-harness.py`.
- Ledger has ≥1 row.
- Every row's Assertion column matches one of the 5 vocabulary
  entries OR cites a spec section.
- The Progress section carries exactly one status per row, drawn
  from `pending` / `automated` / `human-finished` / `blocked`.
- Migration scope section names the owner.

## Inputs

- The migration slug (kebab-case).
- Pointer(s) to old + new implementations.
- Cutover target date.
- Initial seed rows.

## Outputs

- `tests/parity/<slug>-ledger.md` — the parity ledger.
- `tests/parity/<slug>-harness.py` — the harness runner skeleton.

## Context Update

This skill does NOT mutate `.fire-phoenix/context.yml`. The parity
bundle under `tests/parity/` is the only on-disk side-effect.

## Handoffs

- **Engineer** — wires the harness's actual imports + `run_row()`
  logic against the project's old/new implementations.
- **Architect** — reviews assertion choices; ensures `subset` /
  `different-but-traced` rows trace to spec sections that
  authorise the divergence.
- **`characterise-behaviour` skill** — paired use when the old
  implementation's behaviour itself needs pinning before the
  migration starts. Characterisation rows seed the parity ledger's
  "Expected OLD" column.

## Refusal modes (negative constraints)

- **Refuse** to author a ledger with zero rows.
- **Refuse** to author a row whose Assertion column is free text not
  matching the bounded vocabulary AND not citing a spec section.
- **Refuse** to EDIT an existing row — amend by superseding only.
- **Refuse** to overwrite existing parity artefacts (use a different
  slug or edit by superseding).
- **Refuse** to summarise the migration as "fully automated" while
  any row is `human-finished` or `blocked` — percent automated is
  the honest metric.
- **No cutover scheduling.** This skill drafts the parity contract;
  the cutover itself (deploy timing / traffic shift / rollback wire)
  is the engineer's call, not the skill's.
