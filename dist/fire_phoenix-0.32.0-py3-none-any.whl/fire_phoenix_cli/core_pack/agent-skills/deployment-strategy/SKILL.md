---
name: deployment-strategy
description: Drafts the deployment strategy + release runbook — canary/blue-green/rolling, promotion flow, rollback, feature flags, release-notes seed. Produces a runbook the on-call team uses. Does not deploy. Use when planning a deployment strategy or choosing a deployment pattern.
license: MIT
compatibility: Designed for agentskills.io-compatible agents.
metadata:
  author: Dau Quang Thanh
  version: '1.0'
  requires: []
---

## User Input

```text
$ARGUMENTS
```

## Audience and tone (interactive mode)

**Register first — adapt to role level.** Before applying the beginner floor
below, resolve the reader's level from the merged `.fire-phoenix/context.yml`
+ `.fire-phoenix/user-context.yml` (`user-context.yml` wins): use
`preferences.tech_role_level` for technical work (`junior` → hand-hold, one
path; `mid` → ≥2 options with one-line trade-offs; `senior` → defer on
judgment, surface edge cases, be brief; `staff` → be terse, challenge
premises, skip obvious caveats) and `preferences.non_tech_role_level` for
stakeholder work (`non-technical` → outcomes not jargon; `familiar` → simple
jargon glossed; `fluent` → concepts without explanation; `technical` → full
vocabulary). An explicit in-session signal (e.g. "be terse", "skip the
explanation") overrides everything. The plain-English, one-question-at-a-time
floor below applies **only when the relevant level is unset**; never treat
role level as a gate. Full rule: `.fire-phoenix/references/subagents/register-resolution.md`.

When `FIRE_PHOENIX_AGENT_MODE=interactive` (the default), assume the user
has **limited technical background and limited domain knowledge**
— they may know basics but lack deep expertise in this skill's
area. Run this skill as a guided questionnaire:

- **One question at a time.** No walls of questions.
- **Yes / no first.** Phrase so `yes`, `no`, `not sure`, or `skip`
  is a valid answer.
- **Translate jargon, don't strip it.** Use the technical term but
  always pair it with a plain-English gloss the first time it
  appears.
- **Choices, not blank fields.** When yes/no isn't enough, offer
  2-4 lettered options (A/B/C/D) with one-line plain-language
  descriptions of the trade-off. Always include "Not sure — pick
  a sensible default".
- **Always recommend.** State the option you would pick and why in
  one sentence so the user can reply "yes" / "ok" to accept. Pull
  defaults from upstream artefacts (spec, architecture, ADRs,
  standards) before asking blank.
- **Show, don't ask.** When upstream artefacts already imply an
  answer, propose it as a pre-filled finding and ask for a
  yes / no confirmation rather than asking the user to fill in a
  blank.
- **`not sure` / `skip` triggers a sensible default**, marked
  "(default applied — confirm later)" in the artefact, and a debt
  entry in this skill's debt file.

When `FIRE_PHOENIX_AGENT_MODE=auto` (or `--auto`), skip the questionnaire
entirely: apply sensible defaults from upstream artefacts and log
decisions to the parent agent's decision log.

## Inputs

- `.fire-phoenix/context.yml`
- `{context.paths.docs}/operations/cicd.md`
- `{context.paths.docs}/operations/infra.md`
- `{context.paths.docs}/operations/monitoring.md`
- `{context.paths.docs}/bugs/change-register.md` (for release
  notes)

## Outputs

- `{context.paths.docs}/operations/deployment.md`
- `{context.paths.docs}/operations/release-notes-<date>.md` (on
  each release)

## Context Update

Does not mutate `.fire-phoenix/context.yml`.

## Handoffs

- `project-planning` references the release model in milestones.
- `status-report` references the most recent release.
- `observability-plan` is consulted for canary bake thresholds.

## AI authoring scope

**Does:** pick a release model (canary / blue-green / rolling),
draft the promotion flow across environments, specify rollback
criteria + commands, propose feature-flag usage, seed release
notes from the change register.

**Does not:** deploy; run kubectl / terraform / any cloud CLI;
toggle feature flags.

## Picking the release model

Recommend, never pre-select: walk the qualitative decision guide
in `references/release-models.md` (traffic control, rollback
speed, infra cost, state / schema constraints) and let the user
pick. State the one constraint most likely to override the
default — usually a backwards-incompatible schema change or the
absence of per-version metrics.

## Rollback readiness

No release model is complete until the rollback-readiness
checklist in `references/rollback-readiness.md` passes: trigger
defined, decision owner named, data reversibility stated (or the
point of no return documented), command rehearsed, verify step
tied to the SLIs. Unmet items become `OPSDEBT-` entries; rollback
triggers double as candidate failure-path criteria handed to the
business-analyst.

## Usage

> `<SKILL_DIR>` = the integration's skills root (e.g. `.claude/skills/`
> for Claude Code, `.codex/skills/` for Codex,
> `.cursor/skills/` for Cursor, `.kiro/skills/` for Kiro).
> Scripts live at `<SKILL_DIR>/<skill-name>/scripts/…`.

```bash
DP_MODEL=canary DP_CANARY_BAKE_MIN=30 bash <SKILL_DIR>/deployment-strategy/scripts/bash/draft-deployment.sh --auto
```

### Answer keys

| Key | Default |
|---|---|
| `DP_MODEL` (`canary`/`blue-green`/`rolling`/`recreate`) | `canary` |
| `DP_CANARY_BAKE_MIN` | `30` |
| `DP_ENVIRONMENTS` | `dev,staging,prod` |
