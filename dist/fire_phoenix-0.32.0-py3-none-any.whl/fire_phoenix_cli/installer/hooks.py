"""Pre/post hook orchestration — shelling out, checking tools, git init.

Owns the "talk to the surrounding environment" half of the installer:
running external commands, probing for installed binaries (``claude``,
``git``, etc.), and bootstrapping a git repo after an ``init``.

These are the operations that fire during pre-install probes and
post-install finalization — distinct from the per-asset disk writes in
``write``.
"""

import shutil
import subprocess
from pathlib import Path

from ..ui import console


def _get_step_tracker_class():
    """Lazy load StepTracker to avoid circular imports."""
    try:
        from ..tracker import StepTracker

        return StepTracker
    except ImportError:
        return None


def run_command(cmd: list[str], check_return: bool = True, capture: bool = False) -> str | None:
    """Run an external command from an argv list and optionally capture output.

    ``cmd`` MUST be a list of arguments; there is no ``shell=`` escape hatch
    (F-05). Passing a string — or reaching for shell metacharacters — is a
    programming error and raises ``TypeError``: commands run with
    ``shell=False`` so untrusted values can never be interpreted by a shell.
    """
    if not isinstance(cmd, list):
        raise TypeError(f"run_command expects a list of arguments, got {type(cmd).__name__}.")
    try:
        if capture:
            result = subprocess.run(cmd, check=check_return, capture_output=True, text=True)
            return result.stdout.strip()
        else:
            subprocess.run(cmd, check=check_return)
            return None
    except subprocess.CalledProcessError as e:
        if check_return:
            console.print(f"[red]Error running command:[/red] {' '.join(cmd)}")
            console.print(f"[red]Exit code:[/red] {e.returncode}")
            if hasattr(e, "stderr") and e.stderr:
                console.print(f"[red]Error output:[/red] {e.stderr}")
            raise
        return None


def check_tool(tool: str, tracker=None) -> bool:
    """Check if a tool is installed. Optionally update tracker.

    Args:
        tool: Name of the tool to check
        tracker: Optional StepTracker to update with results

    Returns:
        True if tool is found, False otherwise
    """
    # Special handling for Claude CLI local installs
    # See: https://github.com/DauQuangThanh/fire-phoenix/issues/123
    # See: https://github.com/DauQuangThanh/fire-phoenix/issues/550
    # Claude Code can be installed in two local paths:
    #   1. ~/.claude/local/claude          (after `claude migrate-installer`)
    #   2. ~/.claude/local/node_modules/.bin/claude  (npm-local install, e.g. via nvm)
    # Neither path may be on the system PATH, so we check them explicitly.
    if tool == "claude":
        # Look up constants via the package namespace so tests that patch
        # ``fire_phoenix_cli.installer.CLAUDE_LOCAL_PATH`` etc. take effect.
        from . import (
            CLAUDE_LOCAL_PATH as _CLAUDE_LOCAL_PATH,
        )
        from . import (
            CLAUDE_NPM_LOCAL_PATH as _CLAUDE_NPM_LOCAL_PATH,
        )

        if _CLAUDE_LOCAL_PATH.is_file() or _CLAUDE_NPM_LOCAL_PATH.is_file():
            if tracker:
                tracker.complete(tool, "available")
            return True

    found = shutil.which(tool) is not None

    if tracker:
        if found:
            tracker.complete(tool, "available")
        else:
            tracker.error(tool, "not found")

    return found


def is_git_repo(path: Path = None) -> bool:  # type: ignore[assignment]
    """Check if the specified path is inside a git repository."""
    if path is None:
        path = Path.cwd()

    if not path.is_dir():
        return False

    try:
        subprocess.run(
            ["git", "rev-parse", "--is-inside-work-tree"],
            check=True,
            capture_output=True,
            cwd=path,
        )
        return True
    except (subprocess.CalledProcessError, FileNotFoundError):
        return False


def init_git_repo(
    project_path: Path, quiet: bool = False, commit_initial: bool = True
) -> tuple[bool, str | None]:
    """Initialize a git repository in the specified path.

    When ``commit_initial=True`` (default for backward compatibility),
    stages everything currently in the project and creates a single commit
    "Initial commit from fire-phoenix template". When False, only runs
    ``git init`` — useful for callers that author their own initial commit
    later in the flow (per adr/0031 the ``fire-phoenix init`` command does
    its own auto-commit after all scaffolding is complete, so it passes
    ``commit_initial=False`` here to avoid producing two commits per init).
    """
    try:
        # F-21: pass cwd= to each git call instead of mutating the process CWD
        # (global os.chdir is a shared-state hazard, especially under the
        # project lock / concurrent invocations).
        cwd = str(project_path)
        if not quiet:
            console.print("[cyan]Initializing git repository...[/cyan]")
        subprocess.run(["git", "init"], check=True, capture_output=True, text=True, cwd=cwd)
        if commit_initial:
            subprocess.run(["git", "add", "."], check=True, capture_output=True, text=True, cwd=cwd)
            subprocess.run(
                ["git", "commit", "-m", "Initial commit from fire-phoenix template"],
                check=True,
                capture_output=True,
                text=True,
                cwd=cwd,
            )
        if not quiet:
            console.print("[green]✓[/green] Git repository initialized")
        return True, None
    except subprocess.CalledProcessError as e:
        error_msg = f"Command: {' '.join(e.cmd)}\nExit code: {e.returncode}"
        if e.stderr:
            error_msg += f"\nError: {e.stderr.strip()}"
        elif e.stdout:
            error_msg += f"\nOutput: {e.stdout.strip()}"
        if not quiet:
            console.print(f"[red]Error initializing git repository:[/red] {e}")
        return False, error_msg


__all__ = [
    "_get_step_tracker_class",
    "run_command",
    "check_tool",
    "is_git_repo",
    "init_git_repo",
]
