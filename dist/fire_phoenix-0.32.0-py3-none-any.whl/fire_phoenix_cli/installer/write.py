"""Disk writes — the side-effect surface of the installer.

Owns the I/O that mutates the project filesystem: creating ``.fire-phoenix/``,
deploying bundled custom agents into each integration's agent dir,
chmod-ing scripts, and reading/writing ``.fire-phoenix/integration.yml``.

Path lookups live in ``plan``; content transformation lives in ``render``.
This module is where the bytes actually hit disk.
"""

import os
import shutil
from pathlib import Path
from typing import Any

import typer
import yaml

from ..fsutil import atomic_write_text
from ..ui import console
from ..version import get_fire_phoenix_version
from .journal import InstallJournal
from .plan import INTEGRATION_YAML, _locate_custom_agents_source


def _install_shared_infra(
    project_path: Path,
    tracker=None,
    force: bool = False,
) -> bool:
    """Initialise the ``.fire-phoenix/`` state directory.

    Scripts and templates are no longer installed to a shared
    ``.fire-phoenix/scripts/`` / ``.fire-phoenix/templates/`` location — each skill
    bundles its own copy during integration setup. This function
    simply creates the ``.fire-phoenix/`` directory so subsequent state files
    (``context.yml``, ``integration.yml``, extension/preset installs)
    have a place to live.

    Returns ``True`` on success.
    """
    (project_path / ".fire-phoenix").mkdir(parents=True, exist_ok=True)
    return True


def install_custom_agents(
    project_path: Path,
    integration_keys: list[str],
    *,
    force: bool = False,
    journal: InstallJournal | None = None,
) -> dict[str, int]:
    """Deploy bundled custom agents into each installed integration's agent dir.

    For every integration in *integration_keys*, copies every ``*.md``
    under ``subagents/`` into the integration's
    ``custom_agents_dest(project_path)`` directory. Each file is also
    recorded in the integration's ``fire-phoenix-<key>.manifest.yml`` so
    teardown removes it cleanly (unless the user modified it).

    Integrations with ``config["agents_subdir"] = None`` (e.g. ``generic``)
    are skipped.

    Journal ownership (``adr/0061`` Stage 1): when *journal* is ``None`` (the
    standalone ``integration install``/``upgrade`` path) this creates and
    clears its own journal per integration — unchanged behaviour. When a
    caller supplies a *journal* (e.g. ``init`` owning one journal across all
    its writes), paths are recorded into it but it is NOT cleared here — the
    caller owns the lifecycle and clears only on full success.

    Returns a mapping of integration key → number of files written.
    """
    from ..integrations import get_integration
    from ..integrations.manifest import IntegrationManifest

    src_root = _locate_custom_agents_source()
    if src_root is None:
        return {}

    agent_files = sorted(src_root.glob("*.md"))
    if not agent_files:
        return {}

    # When the caller owns a journal, record into it and never clear here; the
    # caller clears on full success (adr/0061 Stage 1). Otherwise each
    # integration gets its own create+clear, exactly as before.
    owns_journal = journal is None

    results: dict[str, int] = {}
    for key in integration_keys:
        integration = get_integration(key)
        if integration is None:
            continue
        dest = integration.custom_agents_dest(project_path)
        if dest is None:
            continue

        try:
            manifest = IntegrationManifest.load(key, project_path)
        except FileNotFoundError:
            manifest = IntegrationManifest(key, project_path, version=get_fire_phoenix_version())

        dest.mkdir(parents=True, exist_ok=True)
        active_journal = journal if journal is not None else InstallJournal(project_path)
        count = 0
        for src in agent_files:
            dst = dest / integration.custom_agent_filename(src.name)
            rel_existing = dst.relative_to(project_path).as_posix()
            if dst.exists() and not force:
                # Preserve the user's file, but keep it in the manifest so an
                # `integration upgrade` stale-file sweep never treats a still-
                # shipped subagent as removable (SAF-01).
                manifest.record_existing(rel_existing)
                continue
            content = src.read_text(encoding="utf-8")
            transformed = integration.transform_custom_agent_content(content)
            limit = getattr(integration, "subagent_char_limit", None)
            if limit is not None and len(transformed) > limit:
                console.print(
                    f"[yellow]Warning:[/yellow] subagent {dst.name!r} for "
                    f"{key} is {len(transformed):,} chars, exceeding the "
                    f"~{limit:,}-char limit; installing anyway."
                )
            rel = dst.relative_to(project_path).as_posix()
            # F-09: journal the path BEFORE the write so a crash mid-loop leaves
            # a recoverable trail even though the manifest is saved only once.
            active_journal.record(rel)
            if transformed == content:
                shutil.copy2(src, dst)
            else:
                dst.write_text(transformed, encoding="utf-8")
            manifest.record_existing(rel)
            count += 1
        manifest.save()
        # Manifest is now authoritative for these files. Clear only a journal we
        # own; a caller-supplied journal is cleared by the caller on full success.
        if owns_journal:
            active_journal.clear()
        results[key] = count

    return results


def install_subagent_references(project_path: Path) -> int:
    """Ship ``assets/subagents/references/`` to ``.fire-phoenix/references/subagents/``.

    Shared infrastructure per ``adr/0034`` (epic-token-efficient-assets
    AC-006): subagent bodies point at these files for mode-conditional
    content (per-role interactive questionnaires, shared auto-mode
    logging rules, role playbooks). One copy serves every installed
    integration, like ``context.yml`` — so the files are not recorded
    in any per-integration manifest and teardown of one integration
    leaves them in place.

    Preserve-existing semantics unconditionally: a file the user
    modified (or that already exists) is never overwritten; re-running
    is a no-op on a populated project.

    Returns the number of files written.
    """
    src_root = _locate_custom_agents_source()
    if src_root is None:
        return 0
    refs_src = src_root / "references"
    if not refs_src.is_dir():
        return 0

    dest = project_path / ".fire-phoenix" / "references" / "subagents"
    count = 0
    for src in sorted(refs_src.glob("*.md")):
        dst = dest / src.name
        if dst.exists():
            continue
        dest.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)
        count += 1
    return count


def ensure_executable_scripts(project_path: Path, tracker=None) -> None:
    """Ensure POSIX .sh scripts have execute bits (no-op on Windows).

    Scans ``.fire-phoenix/extensions/`` (for extension scripts) and every
    registered integration's config folder (where installed skills live
    with their bundled ``scripts/bash/…`` subdirectories).
    """
    if os.name == "nt":
        return  # Windows: skip silently
    from ..integrations import INTEGRATION_REGISTRY

    # Scan only INSTALLED integrations' folders (+ our extensions dir), NOT every
    # registered provider's folder. Copilot's folder is `.github/`; scanning it
    # unconditionally chmod-ed user-owned `.github/*.sh` on every init even when
    # Copilot was not selected (B7/task-0101). The installed set is the manifests
    # under `.fire-phoenix/integrations/*.manifest.yml`.
    manifests_dir = project_path / ".fire-phoenix" / "integrations"
    installed_keys = (
        {mf.name[: -len(".manifest.yml")] for mf in manifests_dir.glob("*.manifest.yml")}
        if manifests_dir.is_dir()
        else set()
    )
    scan_roots = [project_path / ".fire-phoenix" / "extensions"]
    for key in installed_keys:
        integration = INTEGRATION_REGISTRY.get(key)
        if integration is None:
            continue
        folder = (integration.config or {}).get("folder") if integration.config else None
        if folder:
            scan_roots.append(project_path / folder)
    failures: list[str] = []
    updated = 0
    for scripts_root in scan_roots:
        if not scripts_root.is_dir():
            continue
        for script in scripts_root.rglob("*.sh"):
            try:
                if script.is_symlink() or not script.is_file():
                    continue
                try:
                    with script.open("rb") as f:
                        if f.read(2) != b"#!":
                            continue
                except OSError:
                    continue
                st = script.stat()
                mode = st.st_mode
                if mode & 0o111:
                    continue
                new_mode = mode
                if mode & 0o400:
                    new_mode |= 0o100
                if mode & 0o040:
                    new_mode |= 0o010
                if mode & 0o004:
                    new_mode |= 0o001
                if not (new_mode & 0o100):
                    new_mode |= 0o100
                os.chmod(script, new_mode)
                updated += 1
            except OSError as e:
                failures.append(f"{script.relative_to(project_path)}: {e}")
    if tracker:
        detail = f"{updated} updated" + (f", {len(failures)} failed" if failures else "")
        tracker.add("chmod", "Set script permissions recursively")
        (tracker.error if failures else tracker.complete)("chmod", detail)
    else:
        if updated:
            console.print(
                f"[cyan]Updated execute permissions on {updated} script(s) recursively[/cyan]"
            )
        if failures:
            console.print("[yellow]Some scripts could not be updated:[/yellow]")
            for f in failures:  # type: ignore[assignment]
                console.print(f"  - {f}")


def _read_integration_json(project_root: Path) -> dict[str, Any]:
    """Load ``.fire-phoenix/integration.yml``, migrating old format on read.

    Old format ``{"integration": "claude"}`` is transparently converted
    to ``{"integrations": ["claude"]}``.  Returns ``{}`` when missing.
    """
    path = project_root / INTEGRATION_YAML
    if not path.exists():
        return {}
    try:
        data = yaml.safe_load(path.read_text(encoding="utf-8"))
    except yaml.YAMLError as exc:
        console.print(f"[red]Error:[/red] {path} contains invalid YAML.")
        console.print(f"Please fix or delete {INTEGRATION_YAML} and retry.")
        console.print(f"[dim]Details:[/dim] {exc}")
        raise typer.Exit(1)  # noqa: B904
    except OSError as exc:
        console.print(f"[red]Error:[/red] Could not read {path}.")
        console.print(f"Please fix file permissions or delete {INTEGRATION_YAML} and retry.")
        console.print(f"[dim]Details:[/dim] {exc}")
        raise typer.Exit(1)  # noqa: B904
    if data is None:
        return {}
    if not isinstance(data, dict):
        console.print(
            f"[red]Error:[/red] {path} must contain a YAML mapping, got {type(data).__name__}."
        )
        console.print(f"Please fix or delete {INTEGRATION_YAML} and retry.")
        raise typer.Exit(1)
    # Migrate old single-key format to new list format on read.
    if "integration" in data and "integrations" not in data:
        old_key = data.pop("integration")
        data["integrations"] = [old_key] if old_key else []
    return data


def _write_integration_json(
    project_root: Path,
    integrations: list[str] | str,
) -> None:
    """Write ``.fire-phoenix/integration.yml`` in the multi-integration format.

    Accepts a list of integration keys (new) or a single string (compat).
    """
    if isinstance(integrations, str):
        integrations = [integrations]
    dest = project_root / INTEGRATION_YAML
    dest.parent.mkdir(parents=True, exist_ok=True)
    atomic_write_text(
        dest,
        yaml.safe_dump(
            {
                "integrations": integrations,
                "version": get_fire_phoenix_version(),
            },
            sort_keys=False,
            default_flow_style=False,
            allow_unicode=True,
        ),
    )


def _add_integration_to_json(project_root: Path, key: str) -> None:
    """Append *key* to the integrations list (no-op if already present)."""
    data = _read_integration_json(project_root)
    keys = data.get("integrations", [])
    if key not in keys:
        keys.append(key)
    _write_integration_json(project_root, keys)


def _remove_integration_from_json(project_root: Path, key: str) -> None:
    """Remove *key* from the integrations list.  File always persists."""
    data = _read_integration_json(project_root)
    keys = data.get("integrations", [])
    if key in keys:
        keys.remove(key)
    _write_integration_json(project_root, keys)


def _remove_integration_json(project_root: Path) -> None:
    """Remove ``.fire-phoenix/integration.yml`` if it exists.

    .. deprecated:: Kept for backward compatibility with callers that
       haven't migrated to ``_remove_integration_from_json``. Will be
       removed once all callers are updated (WP-2/3/4/8).
    """
    path = project_root / INTEGRATION_YAML
    if path.exists():
        path.unlink()


__all__ = [
    "_install_shared_infra",
    "install_custom_agents",
    "install_subagent_references",
    "ensure_executable_scripts",
    "_read_integration_json",
    "_write_integration_json",
    "_add_integration_to_json",
    "_remove_integration_from_json",
    "_remove_integration_json",
]
