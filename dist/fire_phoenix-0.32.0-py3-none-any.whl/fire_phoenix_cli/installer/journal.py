"""Install journal for crash recovery (improving-pro-plan.md §P1-5, F-09).

Pattern: this solves *orphan files left by a crash mid-install* — a multi-file
install that dies after writing some files but before the manifest is saved
leaves files that ``uninstall`` cannot find. It accepts a lightweight
write-ahead record rather than full directory-level transactionality (rejected
as non-portable on Windows).

Contract (interface first):

    WHEN the installer begins writing an integration's files, THE installer
    SHALL append each path to ``.fire-phoenix/.install-journal.yml`` *before*
    writing it, and clear the journal once the manifest is saved.
    WHEN a mutating command starts and finds a non-empty journal, THE CLI SHALL
    surface the orphan candidates so the user can repair (see
    :func:`orphans` / :func:`repair`).

The journal is a YAML sequence of project-relative paths, appended a line at a
time so a partial append is still parseable (unknown trailing bytes are ignored
by the loader). New, optional, and ignorable by older versions — it never
breaks existing ``.fire-phoenix/`` state.

Extension point (named, not built — §2.5): an interactive ``fire-phoenix repair``
command that offers "remove orphans" vs "complete the manifest". Today
:func:`repair` performs the safe subset (remove untracked orphans on explicit
request); the negative constraint "never delete user-modified files without
confirmation" keeps auto-deletion out of the default start-up path.
"""

from __future__ import annotations

from pathlib import Path

import yaml

JOURNAL_NAME = ".install-journal.yml"


class InstallJournal:
    """Write-ahead journal of files an install is about to create."""

    def __init__(self, project_root: Path) -> None:
        self.project_root = Path(project_root)
        self.path = self.project_root / ".fire-phoenix" / JOURNAL_NAME

    def record(self, rel_path: str) -> None:
        """Append *rel_path* to the journal before the file is written."""
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with open(self.path, "a", encoding="utf-8") as f:
            f.write(f"- {rel_path}\n")

    def pending(self) -> list[str]:
        """Return the project-relative paths currently recorded (may be empty)."""
        if not self.path.exists():
            return []
        try:
            data = yaml.safe_load(self.path.read_text(encoding="utf-8")) or []
        except yaml.YAMLError:
            return []
        return [str(p) for p in data if isinstance(p, str)]

    def is_empty(self) -> bool:
        return not self.pending()

    def clear(self) -> None:
        """Remove the journal after a successful manifest save."""
        try:
            self.path.unlink()
        except FileNotFoundError:
            pass


def orphans(project_root: Path) -> list[str]:
    """Journaled files that exist on disk but are tracked by no manifest.

    These are the true crash orphans — written before the manifest save that
    never happened. Files that a manifest already records are not orphans.
    """
    journal = InstallJournal(project_root)
    pending = journal.pending()
    if not pending:
        return []
    tracked = _manifest_tracked_files(project_root)
    return [p for p in pending if (project_root / p).exists() and p not in tracked]


def repair(project_root: Path, *, remove_orphans: bool = False) -> list[str]:
    """Repair after a crashed install. Returns the orphan paths found.

    With ``remove_orphans=True`` the orphan files are deleted (explicit request
    only — never on the default start-up path). The journal is cleared either
    way, since its recovery information has been surfaced/acted on.
    """
    found = orphans(project_root)
    if remove_orphans:
        for rel in found:
            try:
                (project_root / rel).unlink()
            except OSError:
                pass
    InstallJournal(project_root).clear()
    return found


def _manifest_tracked_files(project_root: Path) -> set[str]:
    """Union of files recorded across all integration manifests."""
    tracked: set[str] = set()
    manifests_dir = project_root / ".fire-phoenix"
    if not manifests_dir.exists():
        return tracked
    for manifest_file in manifests_dir.glob("**/*.manifest.yml"):
        try:
            data = yaml.safe_load(manifest_file.read_text(encoding="utf-8")) or {}
        except yaml.YAMLError:
            continue
        files = data.get("files") or {}
        # IntegrationManifest stores files as a mapping {rel_path: sha256}.
        if isinstance(files, dict):
            tracked.update(str(k) for k in files)
        elif isinstance(files, list):  # tolerate a list form defensively
            for entry in files:
                if isinstance(entry, dict) and "path" in entry:
                    tracked.add(str(entry["path"]))
                elif isinstance(entry, str):
                    tracked.add(entry)
    return tracked
