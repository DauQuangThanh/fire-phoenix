"""Per-skill asset bundling.

The source-of-truth layout for every fire-phoenix skill follows the
agentskills.io specification verbatim —
``assets/agent-skills/<name>/SKILL.md``::

    assets/agent-skills/
    └── intent/
        ├── SKILL.md                           # command prompt (canonical filename)
        ├── scripts/bash/{create-new-feature,common}.sh
        ├── scripts/powershell/{create-new-feature,common}.ps1
        └── templates/spec-template.md

Each folder is a self-contained install unit. For ``SkillsIntegration``
subclasses (Claude, Codex, Copilot, Cursor) the source ``SKILL.md`` is
shipped verbatim to the destination (no frontmatter rebuild, no body
substitution — per task-0005). For ``MarkdownIntegration`` and
``TomlIntegration`` subclasses, the command file is still processed
through their per-integration pipeline. In all cases the sibling
``scripts/``, ``templates/``, and ``references/`` directories are
copied verbatim alongside the installed command file (``references/``
per ``adr/0034`` — SKILL.md bodies point into it for
condition-specific content).

This module resolves the ``assets/agent-skills/`` root (either the
bundled ``core_pack/agent-skills/`` in a wheel install or the
checked-out source tree) and copies each skill's assets next to its
installed ``SKILL.md`` at install time.
"""

from __future__ import annotations

import inspect
import shutil
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .integrations.manifest import IntegrationManifest


def agent_skills_root() -> Path | None:
    """Locate the bundled ``assets/agent-skills/`` directory.

    Checks the wheel's ``core_pack/agent-skills/`` first, then
    the source-checkout ``assets/agent-skills/`` tree. Returns
    ``None`` if neither exists.
    """
    from .integrations.base import IntegrationBase

    pkg_dir = Path(inspect.getfile(IntegrationBase)).resolve().parent.parent
    for candidate in [
        pkg_dir / "core_pack" / "agent-skills",
        pkg_dir.parent.parent / "assets" / "agent-skills",
    ]:
        if candidate.is_dir():
            return candidate
    return None


def list_skill_dirs() -> list[Path]:
    """Return the list of per-skill source folders under ``assets/agent-skills/``.

    Sorted alphabetically so install order is deterministic. Folders
    whose name starts with ``_`` are developer scaffolding and are
    excluded. The canonical skill-bundle template lives at repo-level
    ``templates/agent-skill-template/`` (outside ``assets/``) so the
    wheel ships only runtime-needed bundles.
    """
    root = agent_skills_root()
    if root is None:
        return []
    return sorted(d for d in root.iterdir() if d.is_dir() and not d.name.startswith("_"))


def skill_command_file(skill_dir: Path) -> Path | None:
    """Return the command prompt file for a skill folder.

    Convention: ``assets/agent-skills/<name>/SKILL.md`` (agentskills.io spec).
    Returns ``None`` if it doesn't exist (e.g. a partially-authored skill).
    """
    candidate = skill_dir / "SKILL.md"
    return candidate if candidate.is_file() else None


def bundle_skill_assets(
    install_folder: Path,
    skill_name: str,
    project_root: Path,
    manifest: IntegrationManifest,
) -> list[Path]:
    """Copy a skill's ``scripts/``, ``templates/``, and ``references/``
    into its install folder.

    The source is ``assets/agent-skills/<skill_name>/`` (everything except
    the top-level ``SKILL.md`` which is handled separately by the
    integration's setup code). Recursively mirrors the subfolders so
    each installed skill carries its own copies.

    Args:
        install_folder: Absolute directory the skill is being installed
            into (e.g. ``.claude/skills/intent/`` or
            ``.kiro/skills/fire-phoenix.intent/``).
        skill_name: Short skill name — the folder name under
            ``assets/agent-skills/`` (e.g. ``specify``, ``plan``).
        project_root: Project root — used to record manifest-relative
            paths.
        manifest: Integration manifest to record written files in.

    Returns the list of files that were copied.
    """
    root = agent_skills_root()
    if root is None:
        return []
    src = root / skill_name
    if not src.is_dir():
        return []

    written: list[Path] = []
    for subdir in ("scripts", "templates", "references"):
        sub_src = src / subdir
        if not sub_src.is_dir():
            continue
        for entry in sub_src.rglob("*"):
            if not entry.is_file():
                continue
            if "__pycache__" in entry.parts:
                continue
            rel = entry.relative_to(src)
            dst = install_folder / rel
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(entry, dst)
            manifest.record_existing(dst.relative_to(project_root).as_posix())
            written.append(dst)

    return written
