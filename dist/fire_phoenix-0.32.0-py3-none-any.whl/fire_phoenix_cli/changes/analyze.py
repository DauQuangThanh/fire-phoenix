"""Cross-artifact consistency analyzer for a change delta (task-0097).

A read-only pass over a `changes/<id>/` delta — the deterministic core of a
Spec-Kit-style `analyze` gate. Reports requirement→task coverage gaps, orphan
tasks, unresolved placeholders, and missing artifacts, severity-tiered. No LLM,
no network, no fire_phoenix_cli layer imports (stdlib-only leaf domain package,
per the module-boundary contract). A richer LLM semantic-drift layer may wrap
this later.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path

# Accepts scoped `AC-<KEY>-NNN` (adr/0051) and legacy bare `AC-NNN`.
_AC_ID_RE = re.compile(r"\bAC-(?:[A-Z0-9]+-)?\d{3}\b")
_PLACEHOLDER_RE = re.compile(r"\b(TODO|FIXME|TBD-source|\?\?\?)\b")

_SEVERITY_RANK = {"CRITICAL": 3, "HIGH": 2, "MEDIUM": 1, "LOW": 0}


@dataclass
class Finding:
    kind: str  # coverage | orphan-task | ambiguity | missing-artifact
    severity: str  # CRITICAL | HIGH | MEDIUM | LOW
    detail: str


@dataclass
class AnalyzeResult:
    findings: list[Finding] = field(default_factory=list)

    @property
    def exit_code(self) -> int:
        # CRITICAL / HIGH fail the gate; MEDIUM / LOW are advisory.
        return 1 if any(f.severity in ("CRITICAL", "HIGH") for f in self.findings) else 0


def _read(path: Path) -> str | None:
    return path.read_text(encoding="utf-8") if path.is_file() else None


def analyze_change(change_dir: Path) -> AnalyzeResult:
    """Read-only consistency analysis of the delta at ``change_dir``."""
    result = AnalyzeResult()
    intent = _read(change_dir / "intent.md")
    tasks = _read(change_dir / "tasks.md")
    spec_delta = _read(change_dir / "spec-delta.md")

    # Missing-artifact checks.
    if intent is None:
        result.findings.append(
            Finding("missing-artifact", "CRITICAL", "intent.md is absent — no traceable intent")
        )
    if spec_delta is None:
        result.findings.append(
            Finding("missing-artifact", "HIGH", "spec-delta.md is absent — nothing to fold")
        )

    # Coverage + orphan-task checks (only when both artifacts exist).
    if intent is not None and tasks is not None:
        intent_acs = set(_AC_ID_RE.findall(intent))
        task_acs = set(_AC_ID_RE.findall(tasks))
        for ac in sorted(intent_acs - task_acs):
            result.findings.append(
                Finding("coverage", "HIGH", f"{ac} has no covering task in tasks.md")
            )
        for ac in sorted(task_acs - intent_acs):
            result.findings.append(
                Finding("orphan-task", "MEDIUM", f"task cites {ac}, absent from intent.md")
            )

    # Ambiguity: unresolved placeholders in any present delta artifact.
    for name, text in (
        ("intent.md", intent),
        ("design.md", _read(change_dir / "design.md")),
        ("tasks.md", tasks),
        ("spec-delta.md", spec_delta),
    ):
        if not text:
            continue
        for m in sorted(set(_PLACEHOLDER_RE.findall(text))):
            result.findings.append(
                Finding("ambiguity", "LOW", f"unresolved '{m}' placeholder in {name}")
            )

    result.findings.sort(key=lambda f: -_SEVERITY_RANK.get(f.severity, 0))
    return result
