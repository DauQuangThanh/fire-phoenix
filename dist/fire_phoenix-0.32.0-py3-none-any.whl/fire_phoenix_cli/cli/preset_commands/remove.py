"""`fire-phoenix preset remove` — remove an installed preset."""

from __future__ import annotations

import typer

from fire_phoenix_cli._lock import guarded_mutation
from fire_phoenix_cli.ui import console

from ..preset import preset_app
from ._common import require_fire_phoenix_project


@preset_app.command("remove")
@guarded_mutation
def preset_remove(
    preset_id: str = typer.Argument(..., help="Preset ID to remove"),
) -> None:
    """Remove an installed preset."""
    from fire_phoenix_cli.presets import PresetManager

    project_root = require_fire_phoenix_project()

    manager = PresetManager(project_root)

    if not manager.registry.is_installed(preset_id):
        console.print(f"[red]Error:[/red] Preset '{preset_id}' is not installed")
        raise typer.Exit(1)

    if manager.remove(preset_id):
        console.print(f"[green]✓[/green] Preset '{preset_id}' removed successfully")
    else:
        console.print(f"[red]Error:[/red] Failed to remove preset '{preset_id}'")
        raise typer.Exit(1)
