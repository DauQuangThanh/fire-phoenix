"""`fire-phoenix preset add` — install a preset (bundled or --dev path)."""

from __future__ import annotations

from pathlib import Path

import typer

from fire_phoenix_cli._lock import guarded_mutation
from fire_phoenix_cli.ui import console

from .. import preset as _preset_module
from ..preset import preset_app
from ._common import require_fire_phoenix_project


@preset_app.command("add")
@guarded_mutation
def preset_add(
    preset_id: str = typer.Argument(None, help="Preset ID to install from catalog"),
    dev: str = typer.Option(None, "--dev", help="Install from local directory (development mode)"),
    priority: int = typer.Option(
        10, "--priority", help="Resolution priority (lower = higher precedence, default 10)"
    ),
) -> None:
    """Install a preset."""
    from fire_phoenix_cli.presets import (
        PresetCompatibilityError,
        PresetError,
        PresetManager,
        PresetValidationError,
    )

    project_root = require_fire_phoenix_project()

    # Validate priority
    if priority < 1:
        console.print("[red]Error:[/red] Priority must be a positive integer (1 or higher)")
        raise typer.Exit(1)

    manager = PresetManager(project_root)
    # Dereferenced via the cli.preset module so tests can
    # mock.patch("fire_phoenix_cli.cli.preset.get_fire_phoenix_version", ...).
    fire_phoenix_version = _preset_module.get_fire_phoenix_version()

    try:
        if dev:
            dev_path = Path(dev).resolve()
            if not dev_path.exists():
                console.print(f"[red]Error:[/red] Directory not found: {dev}")
                raise typer.Exit(1)

            console.print(f"Installing preset from [cyan]{dev_path}[/cyan]...")
            manifest = manager.install_from_directory(dev_path, fire_phoenix_version, priority)
            console.print(
                f"[green]✓[/green] Preset '{manifest.name}' v{manifest.version} installed (priority {priority})"
            )

        elif preset_id:
            # Verify the bundle before installing from it (F-08).
            from ..integrity_guard import verify_core_pack_or_exit

            verify_core_pack_or_exit()
            # fire-phoenix is offline-only: only bundled presets are installable.
            # Dereferenced via the cli.preset module so tests can
            # mock.patch("fire_phoenix_cli.cli.preset._locate_bundled_preset", ...).
            bundled_path = _preset_module._locate_bundled_preset(preset_id)
            if bundled_path is None:
                from fire_phoenix_cli.extensions import REINSTALL_COMMAND

                console.print(
                    f"[red]Error:[/red] Preset '{preset_id}' is not bundled with fire-phoenix."
                )
                console.print(
                    "fire-phoenix is offline-only; only bundled presets can be installed."
                )
                console.print(
                    "If this preset should be bundled, your installation may be corrupted. "
                    f"Try reinstalling fire-phoenix: [cyan]{REINSTALL_COMMAND}[/cyan]"
                )
                raise typer.Exit(1)
            console.print(f"Installing bundled preset [cyan]{preset_id}[/cyan]...")
            manifest = manager.install_from_directory(bundled_path, fire_phoenix_version, priority)
            console.print(
                f"[green]✓[/green] Preset '{manifest.name}' v{manifest.version} installed (priority {priority})"
            )
        else:
            console.print("[red]Error:[/red] Specify a preset ID or --dev path")
            raise typer.Exit(1)

    except PresetCompatibilityError as e:
        console.print(f"[red]Compatibility Error:[/red] {e}")
        raise typer.Exit(1)  # noqa: B904
    except PresetValidationError as e:
        console.print(f"[red]Validation Error:[/red] {e}")
        raise typer.Exit(1)  # noqa: B904
    except PresetError as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1)  # noqa: B904
