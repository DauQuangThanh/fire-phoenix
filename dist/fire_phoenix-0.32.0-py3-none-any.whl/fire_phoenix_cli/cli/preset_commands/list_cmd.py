"""`fire-phoenix preset list` — list installed presets."""

from __future__ import annotations

from fire_phoenix_cli.ui import console

from ..preset import preset_app
from ._common import require_fire_phoenix_project


@preset_app.command("list")
def preset_list() -> None:
    """List installed presets."""
    from fire_phoenix_cli.presets import PresetManager

    project_root = require_fire_phoenix_project()

    manager = PresetManager(project_root)
    installed = manager.list_installed()

    if not installed:
        console.print("[yellow]No presets installed.[/yellow]")
        console.print("\nInstall a preset with:")
        console.print("  [cyan]fire-phoenix preset add <pack-name>[/cyan]")
        return

    console.print("\n[bold cyan]Installed Presets:[/bold cyan]\n")
    for pack in installed:
        status = "[green]enabled[/green]" if pack.get("enabled", True) else "[red]disabled[/red]"
        pri = pack.get("priority", 10)
        console.print(
            f"  [bold]{pack['name']}[/bold] ({pack['id']}) v{pack['version']} — {status} — priority {pri}"
        )
        console.print(f"    {pack['description']}")
        if pack.get("tags"):
            tags_str = ", ".join(pack["tags"])
            console.print(f"    [dim]Tags: {tags_str}[/dim]")
        console.print(f"    [dim]Templates: {pack['template_count']}[/dim]")
        console.print()
