"""Shared helpers for preset_commands/ submodules."""

from __future__ import annotations

from pathlib import Path

import typer

from fire_phoenix_cli.ui import console


def require_fire_phoenix_project() -> Path:
    """Return cwd and exit(1) if it's not a fire-phoenix project root.

    A fire-phoenix project root contains a ``.fire-phoenix/`` directory.
    Emits the same error message previously used inline in cli/preset.py
    so externally-observable behaviour is unchanged.
    """
    project_root = Path.cwd()
    fire_phoenix_dir = project_root / ".fire-phoenix"
    if not fire_phoenix_dir.exists():
        console.print("[red]Error:[/red] Not a fire-phoenix project (no .fire-phoenix/ directory)")
        console.print("Run this command from a fire-phoenix project root")
        raise typer.Exit(1)
    return project_root
