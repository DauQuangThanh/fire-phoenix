"""``fire-phoenix extension add`` — install a bundled extension."""

from __future__ import annotations

import contextlib
from pathlib import Path

import typer

from fire_phoenix_cli._lock import guarded_mutation
from fire_phoenix_cli.ui import console, owns_terminal
from fire_phoenix_cli.version import get_fire_phoenix_version

from ._common import _require_fire_phoenix_project, _resolve_catalog_extension


@guarded_mutation
def extension_add(
    extension: str = typer.Argument(help="Extension name or path"),
    dev: bool = typer.Option(False, "--dev", help="Install from local directory"),
    priority: int = typer.Option(
        10, "--priority", help="Resolution priority (lower = higher precedence, default 10)"
    ),
):
    """Install an extension."""
    # Late import via the parent ``cli.extension`` module so test patches against
    # ``fire_phoenix_cli.cli.extension._locate_bundled_extension`` are honoured.
    from fire_phoenix_cli.cli import extension as _ext_module
    from fire_phoenix_cli.extensions import (
        REINSTALL_COMMAND,
        CompatibilityError,
        ExtensionCatalog,
        ExtensionError,
        ExtensionManager,
        ValidationError,
    )

    project_root = _require_fire_phoenix_project()

    # Validate priority
    if priority < 1:
        console.print("[red]Error:[/red] Priority must be a positive integer (1 or higher)")
        raise typer.Exit(1)

    manager = ExtensionManager(project_root)
    fire_phoenix_version = get_fire_phoenix_version()

    try:
        # Animated status only when fire-phoenix owns an interactive terminal;
        # under an agent / non-TTY stay quiet so nothing overlaps its UI.
        _status = (
            console.status(f"[cyan]Installing extension: {extension}[/cyan]")
            if owns_terminal()
            else contextlib.nullcontext()
        )
        with _status:
            if dev:
                # Install from local directory
                source_path = Path(extension).expanduser().resolve()
                if not source_path.exists():
                    console.print(f"[red]Error:[/red] Directory not found: {source_path}")
                    raise typer.Exit(1)

                if not (source_path / "extension.yml").exists():
                    console.print(f"[red]Error:[/red] No extension.yml found in {source_path}")
                    raise typer.Exit(1)

                manifest = manager.install_from_directory(
                    source_path, fire_phoenix_version, priority=priority
                )

            else:
                # Verify the bundle before installing from it (F-08).
                from ..integrity_guard import verify_core_pack_or_exit

                verify_core_pack_or_exit()
                # fire-phoenix is offline-only: only bundled extensions are installable.
                bundled_path = _ext_module._locate_bundled_extension(extension)
                resolved_info = None
                if bundled_path is None:
                    # Try resolving display name → ID via the bundled catalog.
                    catalog = ExtensionCatalog(project_root)
                    resolved_info, _ = _resolve_catalog_extension(extension, catalog, "add")
                    if resolved_info is not None:
                        bundled_path = _ext_module._locate_bundled_extension(resolved_info["id"])
                if bundled_path is None:
                    if resolved_info is not None and resolved_info.get("bundled"):
                        console.print(
                            f"[red]Error:[/red] Extension '{resolved_info['id']}' is bundled with fire-phoenix "
                            f"but could not be found in the installed package."
                        )
                        console.print(
                            "This usually means the fire-phoenix installation is incomplete or corrupted."
                        )
                        console.print("Try reinstalling fire-phoenix:")
                        console.print(f"  [cyan]{REINSTALL_COMMAND}[/cyan]")
                    else:
                        console.print(
                            f"[red]Error:[/red] Extension '{extension}' is not bundled with fire-phoenix."
                        )
                        console.print(
                            "fire-phoenix is offline-only; only bundled extensions can be installed. "
                            "If this extension should be bundled, try reinstalling fire-phoenix:"
                        )
                        console.print(f"  [cyan]{REINSTALL_COMMAND}[/cyan]")
                    raise typer.Exit(1)
                manifest = manager.install_from_directory(
                    bundled_path, fire_phoenix_version, priority=priority
                )

        console.print("\n[green]✓[/green] Extension installed successfully!")
        console.print(f"\n[bold]{manifest.name}[/bold] (v{manifest.version})")
        console.print(f"  {manifest.description}")

        for warning in manifest.warnings:
            console.print(f"\n[yellow]⚠  Compatibility warning:[/yellow] {warning}")

        console.print("\n[bold cyan]Provided commands:[/bold cyan]")
        for cmd in manifest.commands:
            console.print(f"  • {cmd['name']} - {cmd.get('description', '')}")

        # Report agent skills registration
        reg_meta = manager.registry.get(manifest.id)
        reg_skills = reg_meta.get("registered_skills", []) if reg_meta else []
        # Normalize to guard against corrupted registry entries
        if not isinstance(reg_skills, list):
            reg_skills = []
        if reg_skills:
            console.print(f"\n[green]✓[/green] {len(reg_skills)} agent skill(s) auto-registered")

        console.print("\n[yellow]⚠[/yellow]  Configuration may be required")
        console.print(f"   Check: .fire-phoenix/extensions/{manifest.id}/")

    except ValidationError as e:
        console.print(f"\n[red]Validation Error:[/red] {e}")
        raise typer.Exit(1)  # noqa: B904
    except CompatibilityError as e:
        console.print(f"\n[red]Compatibility Error:[/red] {e}")
        raise typer.Exit(1)  # noqa: B904
    except ExtensionError as e:
        console.print(f"\n[red]Error:[/red] {e}")
        raise typer.Exit(1)  # noqa: B904
