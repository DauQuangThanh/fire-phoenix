"""``fire-phoenix extension update`` — report installed extensions with a newer bundled version.

fire-phoenix is offline-only: extensions are installed from the bundled
package and there is no remote download path (the remote-catalog surface was
removed per ``adr/0062``), so there is no in-place download/swap update path.
This command therefore *reports* which
installed extensions have a newer version in the bundled catalog and directs
the user to reinstall fire-phoenix to pick them up. It never mutates an
installed extension, so it is always safe to run offline.

See ``adr/0045-drop-offline-extension-update.md`` — the prior download →
backup → swap → rollback machinery was dead in production (the download step
could never succeed) and has been removed in favour of this honest, fail-safe
contract.
"""

from __future__ import annotations

import typer

from fire_phoenix_cli._lock import guarded_mutation
from fire_phoenix_cli.ui import console

from ._common import _require_fire_phoenix_project, _resolve_installed_extension


@guarded_mutation
def extension_update(
    extension: str = typer.Argument(None, help="Extension ID or name to check (or all)"),
):
    """Report extension(s) with a newer bundled version.

    Offline-only: never downloads or swaps files. When updates are available it
    prints the reinstall guidance and exits 0 without mutating anything.
    """
    from fire_phoenix_cli.extensions import (
        REINSTALL_COMMAND,
        ExtensionCatalog,
        ExtensionError,
        ExtensionManager,
        ValidationError,
    )
    from packaging import version as pkg_version

    project_root = _require_fire_phoenix_project()

    manager = ExtensionManager(project_root)
    catalog = ExtensionCatalog(project_root)

    try:
        # Get list of extensions to check
        installed = manager.list_installed()
        if extension:
            # Resolve ID from argument (handles ambiguous names)
            extension_id, _ = _resolve_installed_extension(extension, installed, "update")
            extensions_to_check = [extension_id]
        else:
            extensions_to_check = [ext["id"] for ext in installed]

        if not extensions_to_check:
            console.print("[yellow]No extensions installed[/yellow]")
            raise typer.Exit(0)

        console.print("🔄 Checking for updates...\n")

        updates_available = []

        for ext_id in extensions_to_check:
            # Get installed version
            metadata = manager.registry.get(ext_id)  # type: ignore[arg-type]
            if metadata is None or not isinstance(metadata, dict) or "version" not in metadata:
                console.print(f"⚠  {ext_id}: Registry entry corrupted or missing (skipping)")
                continue
            try:
                installed_version = pkg_version.Version(metadata["version"])
            except pkg_version.InvalidVersion:
                console.print(
                    f"⚠  {ext_id}: Invalid installed version '{metadata.get('version')}' in registry (skipping)"
                )
                continue

            # Get catalog info
            ext_info = catalog.get_extension_info(ext_id)  # type: ignore[arg-type]
            if not ext_info:
                console.print(f"⚠  {ext_id}: Not found in catalog (skipping)")
                continue

            # Skip extensions the catalog disallows updating
            if not ext_info.get("_install_allowed", True):
                console.print(
                    f"⚠  {ext_id}: Updates not allowed from '{ext_info.get('_catalog_name', 'catalog')}' (skipping)"
                )
                continue

            try:
                catalog_version = pkg_version.Version(ext_info["version"])
            except pkg_version.InvalidVersion:
                console.print(
                    f"⚠  {ext_id}: Invalid catalog version '{ext_info.get('version')}' (skipping)"
                )
                continue

            if catalog_version > installed_version:
                updates_available.append(
                    {
                        "id": ext_id,
                        "name": ext_info.get("name", ext_id),  # Display name
                        "installed": str(installed_version),
                        "available": str(catalog_version),
                    }
                )
            else:
                console.print(f"✓ {ext_id}: Up to date (v{installed_version})")

        if not updates_available:
            console.print("\n[green]All extensions are up to date![/green]")
            raise typer.Exit(0)

        # Report available updates. fire-phoenix is offline-only: there is no
        # download/swap path, so nothing is mutated here. Newer bundled
        # extensions arrive by reinstalling fire-phoenix itself.
        console.print("\n[bold]Updates available:[/bold]\n")
        for update in updates_available:
            console.print(f"  • {update['id']}: {update['installed']} → {update['available']}")

        console.print(
            "\nfire-phoenix is offline-only, so installed extensions cannot be updated in place.\n"
            "To pick up newer bundled extensions, reinstall fire-phoenix, then re-run your "
            "init/add:\n"
            f"  [cyan]{REINSTALL_COMMAND}[/cyan]"
        )
        raise typer.Exit(0)

    except ValidationError as e:
        console.print(f"\n[red]Validation Error:[/red] {e}")
        raise typer.Exit(1)  # noqa: B904
    except ExtensionError as e:
        console.print(f"\n[red]Error:[/red] {e}")
        raise typer.Exit(1)  # noqa: B904
