"""``fire-phoenix extension set-priority`` — set resolution priority of an installed extension."""

from __future__ import annotations

import typer

from fire_phoenix_cli._lock import guarded_mutation
from fire_phoenix_cli.ui import console

from ._common import _require_fire_phoenix_project, _resolve_installed_extension


@guarded_mutation
def extension_set_priority(
    extension: str = typer.Argument(help="Extension ID or name"),
    priority: int = typer.Argument(help="New priority (lower = higher precedence)"),
):
    """Set the resolution priority of an installed extension."""
    from fire_phoenix_cli.extensions import ExtensionManager, normalize_priority

    project_root = _require_fire_phoenix_project()

    # Validate priority
    if priority < 1:
        console.print("[red]Error:[/red] Priority must be a positive integer (1 or higher)")
        raise typer.Exit(1)

    manager = ExtensionManager(project_root)

    # Resolve extension ID from argument (handles ambiguous names)
    installed = manager.list_installed()
    extension_id, display_name = _resolve_installed_extension(extension, installed, "set-priority")

    # Get current metadata
    metadata = manager.registry.get(extension_id)  # type: ignore[arg-type]
    if metadata is None or not isinstance(metadata, dict):
        console.print(
            f"[red]Error:[/red] Extension '{extension_id}' not found in registry (corrupted state)"
        )
        raise typer.Exit(1)

    raw_priority = metadata.get("priority")
    # Only skip if the stored value is already a valid int equal to requested priority
    # This ensures corrupted values (e.g., "high") get repaired even when setting to default (10)
    if isinstance(raw_priority, int) and raw_priority == priority:
        console.print(
            f"[yellow]Extension '{display_name}' already has priority {priority}[/yellow]"
        )
        raise typer.Exit(0)

    old_priority = normalize_priority(raw_priority)

    # Update priority
    manager.registry.update(extension_id, {"priority": priority})  # type: ignore[arg-type]

    console.print(
        f"[green]✓[/green] Extension '{display_name}' priority changed: {old_priority} → {priority}"
    )
    console.print("\n[dim]Lower priority = higher precedence in template resolution[/dim]")
