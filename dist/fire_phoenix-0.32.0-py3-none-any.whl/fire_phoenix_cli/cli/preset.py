"""Preset management commands (`fire-phoenix preset ...`).

This module owns the Typer app declaration for the `preset` command group; the
per-command implementations live in ``cli/preset_commands/`` (one module per
subcommand) and register themselves at import time on the app declared below.

The submodule imports MUST happen after ``preset_app`` is constructed so the
``@preset_app.command(...)`` decorators in each submodule fire against the same
app instance.
"""

import typer

# Imported here (in addition to where they are used by per-command modules) so
# test fixtures can patch them at this module path. The bundled-preset add path
# in cli/preset_commands/add.py reads these names via the ``cli.preset`` module
# reference so ``mock.patch("fire_phoenix_cli.cli.preset.<name>", ...)`` works.
from fire_phoenix_cli.installer import _locate_bundled_preset  # noqa: F401

# Shared helpers (kept for Typer command-registration parity with the historical
# monolithic layout).
from fire_phoenix_cli.ui import (
    BannerGroup,  # noqa: F401  — Typer command-registration parity
    _version_callback,  # noqa: F401  — Typer command-registration parity
)
from fire_phoenix_cli.version import get_fire_phoenix_version  # noqa: F401

# The main Typer app created in fire_phoenix_cli.cli.__init__
from . import app

preset_app = typer.Typer(
    name="preset",
    help="Manage fire-phoenix presets",
    add_completion=False,
)

app.add_typer(preset_app, name="preset")

# Per-subcommand modules. Each registers exactly one command on `preset_app`
# via its module-level decorator. Imports MUST come after the app above is
# defined. (The remote `preset catalog` surface was removed per adr/0062 —
# fire-phoenix is offline-only and it wrote a stack `search` ignored.)
from .preset_commands import (  # noqa: E402, F401
    add,
    disable,
    enable,
    info,
    list_cmd,
    remove,
    resolve,
    search,
    set_priority,
)
