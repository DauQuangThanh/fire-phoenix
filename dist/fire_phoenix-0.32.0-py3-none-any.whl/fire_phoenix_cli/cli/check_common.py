"""Shared primitives for the `fire-phoenix check` sub-commands.

Holds the finding dataclass, the shared Rich console + findings renderer, and
the project-introspection helpers (installed-integration list + install-dir
resolution) used by more than one validator. Each validator lives in its own
`check_<domain>.py` module (skills / integrations / context) and the Typer
wiring stays in `check.py` — this keeps every file under the 500-LOC ceiling
(adr/0005 + adr/0058; D-05).
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import yaml
from rich.console import Console
from rich.table import Table

from fire_phoenix_cli.installer import _read_integration_json
from fire_phoenix_cli.integrations import get_integration

console = Console()


@dataclass
class CheckFinding:
    """A single finding from a fire-phoenix check sub-command."""

    file: str
    check: str  # "skills", "integrations", "context"
    expected: str
    actual: str
    fix: str


# Integration key to default install directory mapping
INTEGRATION_INSTALL_DIRS = {
    "claude": ".claude/skills",
    "copilot": ".github/skills",
    "cursor-agent": ".cursor/skills",
    "opencode": ".opencode/skills",
    "kiro": ".kiro/skills",
    "gemini": ".gemini/skills",
    "codex": ".codex/skills",
}


def _get_integration_install_dir(integration_key: str) -> Path | None:
    """Get the install directory for an integration.

    First tries to read from the integration's config (folder + skills_subdir).
    Falls back to hardcoded map if not available.
    """
    integration = get_integration(integration_key)
    if integration and integration.config:
        folder = integration.config.get("folder")
        subdir = integration.config.get("skills_subdir", "commands")
        if folder:
            return Path(folder) / subdir

    # Fallback to hardcoded map. Unknown keys return None (not Path(""),
    # which is Path(".") — truthy — and made callers silently scan the
    # project root instead of flagging the unknown integration).
    install_dir = INTEGRATION_INSTALL_DIRS.get(integration_key)
    return Path(install_dir) if install_dir else None


def _get_installed_integrations(project_root: Path) -> list[str]:
    """Get the list of installed integrations from integration.yml or init-options.yml."""
    data = _read_integration_json(project_root)
    keys = data.get("integrations", [])
    if keys:
        return keys
    # Fallback to init-options.yml
    init_options_path = project_root / ".fire-phoenix" / "init-options.yml"
    if init_options_path.exists():
        try:
            opts = yaml.safe_load(init_options_path.read_text(encoding="utf-8")) or {}
            return opts.get("integrations", [])
        except Exception:
            pass
    return []


def _render_findings(findings: list[CheckFinding]) -> None:
    """Render a Rich table of check findings."""
    table = Table(title="Findings", show_lines=True)
    table.add_column("File", style="cyan")
    table.add_column("Check", style="bold")
    table.add_column("Issue")
    table.add_column("Suggested Fix", style="green")
    for f in findings:
        table.add_row(f.file, f.check, f.actual, f.fix)
    console.print(table)
