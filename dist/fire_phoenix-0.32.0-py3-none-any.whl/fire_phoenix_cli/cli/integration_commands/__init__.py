"""Per-command modules for ``fire-phoenix integration ...``.

Each subcommand lives in its own module and registers on the shared
``integration_app`` Typer instance from ``_common``. The thin
``cli/integration.py`` shim imports this package so all decorators
fire at CLI bootstrap time.
"""

from . import install as install  # noqa: F401
from . import list as list  # noqa: A004, F401
from . import switch as switch  # noqa: F401
from . import uninstall as uninstall  # noqa: F401
from . import upgrade as upgrade  # noqa: F401
