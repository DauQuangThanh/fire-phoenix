"""`fire-phoenix check ac` — AC→test coverage matrix per epic.

Extends the adr/0025 trace family per `adr/0032` and
`contracts/task-3dd-02-check-trace-ac-coverage.md`: collects every
`AC-NNN` declared in epic specs (`{governance.specs_dir}/epic-*.md`)
and in the shared acceptance artifact
(`{paths.docs}/product/acceptance.md`), scans `tests/**/test_*.py` for
citing tests (`@pytest.mark.ac("AC-NNN")` marker or `_acNNN` name
suffix per `docs/standards.md` §II), honours named manual reviews, and
emits a matrix of `(epic, ac_id, status, covered_by)` rows with
`status` ∈ {COVERED, ORPHAN-AC, ORPHAN-CITATION}.

Default output is a Markdown table written to
`{paths.docs}/trace/ac-coverage-<timestamp>.md`. `--json` switches to
a JSON envelope on stdout.

Rigor profile (3DD-plan §D4): under `governance.rigor_profile: P` the
findings are reported but the exit code stays 0. Undeclared ⇒ F
(enforcing). Pre-3DD epics are grandfathered (excluded from the
matrix), mirroring `scripts/lint_idd.py` R10.

Offline: static file reads only — no network, no test collection, no
imports of scanned test modules. Per `PRODUCT.md` §Invariants.
"""

from __future__ import annotations

import ast
import json
import re
from dataclasses import asdict, dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from rich.console import Console
from rich.table import Table

from fire_phoenix_cli.context import load_context_file

from . import app

# AC-id and citation patterns — kept in sync by hand with
# `scripts/lint_idd.py` R9/R10 (src cannot import from scripts;
# build-time separation, same precedent as check_trace._CITATION_RE).
# adr/0051: AC-ids are epic-scoped `AC-<KEY>-NNN` (e.g. AC-LBID-003); the legacy
# bare `AC-NNN` form is still accepted for grandfathered/archived epics. The
# optional `[A-Z0-9]+-` group is the epic key.
_AC_ID_RE = re.compile(r"\bAC-(?:[A-Z0-9]+-)?\d{3}\b")
_AC_NAME_SUFFIX_RE = re.compile(r"_ac(\d{3})$")
_MANUAL_REVIEW_RE = re.compile(r"^[-*]?\s*Manual review:", re.IGNORECASE)

# Pre-3DD epics excluded from the enforcing set — mirrors
# `scripts/lint_idd.py` GRANDFATHERED_EPICS (task-3dd-01).
_GRANDFATHERED_EPICS: frozenset[str] = frozenset(
    {
        "epic-fire-phoenix-check.md",
        "epic-multi-integration-refactor.md",
        "epic-narrow-to-seven-ais.md",
        "epic-skill-renames.md",
        "epic-step-timeout-override.md",
        "epic-subagent-per-ai-rendering.md",
    }
)

console = Console()


@dataclass
class AcRow:
    """One row of the AC-coverage matrix.

    Attributes:
        epic: Repo-relative path of the declaring artifact (empty for
            ORPHAN-CITATION rows — the cited id has no declaring epic).
        ac_id: The `AC-NNN` identifier.
        status: "COVERED", "ORPHAN-AC", or "ORPHAN-CITATION".
        covered_by: Citing test names / markers, or the manual-review
            line; empty for ORPHAN-AC.
    """

    epic: str
    ac_id: str
    status: str
    covered_by: list[str]


def _load_context(project_root: Path) -> dict[str, Any]:
    try:
        context = load_context_file(project_root)
    except Exception:  # SchemaVersionError or any parse/read failure
        return {}
    return context if isinstance(context, dict) else {}


def _resolve_docs_dir(context: dict[str, Any]) -> str:
    paths = context.get("paths")
    if isinstance(paths, dict):
        docs = paths.get("docs")
        if isinstance(docs, str) and docs.strip():
            return docs.strip().rstrip("/")
    return "docs"


def _resolve_specs_dir(context: dict[str, Any]) -> str:
    governance = context.get("governance")
    if isinstance(governance, dict):
        specs_dir = governance.get("specs_dir")
        if isinstance(specs_dir, str) and specs_dir.strip():
            return specs_dir.strip().rstrip("/")
    return "specs"


def _resolve_rigor_profile(context: dict[str, Any]) -> str:
    governance = context.get("governance")
    if isinstance(governance, dict):
        profile = governance.get("rigor_profile")
        if isinstance(profile, str) and profile.strip().upper() in {"P", "M", "F"}:
            return profile.strip().upper()
    return "F"


def _declaring_artifacts(project_root: Path, context: dict[str, Any]) -> list[Path]:
    """Epic specs (top-level + archived, non-grandfathered) + shared acceptance.md.

    Archived epics (``<specs_dir>/archive/``, per ``adr/0033``) still
    declare their AC ids: their citing tests remain living regression
    fences after delivery, so the coverage matrix must keep resolving
    those citations (archive-aware trace, matching contracts/metrics).
    """
    artifacts: list[Path] = []
    specs_dir = project_root / _resolve_specs_dir(context)
    if specs_dir.is_dir():
        candidates = sorted(specs_dir.glob("epic-*.md")) + sorted(
            (specs_dir / "archive").glob("epic-*.md")
        )
        artifacts.extend(
            p for p in candidates if p.is_file() and p.name not in _GRANDFATHERED_EPICS
        )
    acceptance = project_root / _resolve_docs_dir(context) / "product" / "acceptance.md"
    if acceptance.is_file():
        artifacts.append(acceptance)
    return artifacts


def _marker_ac_ids(node: ast.FunctionDef | ast.AsyncFunctionDef) -> list[str]:
    """AC ids cited via `@pytest.mark.ac("AC-NNN")` decorators on `node`."""
    ids: list[str] = []
    for decorator in node.decorator_list:
        if not isinstance(decorator, ast.Call):
            continue
        func = decorator.func
        # Match the `pytest.mark.ac` attribute chain (or bare `mark.ac`).
        if not (isinstance(func, ast.Attribute) and func.attr == "ac"):
            continue
        for arg in decorator.args:
            if isinstance(arg, ast.Constant) and isinstance(arg.value, str):
                ids.extend(_AC_ID_RE.findall(arg.value))
    return ids


def _citing_tests(project_root: Path) -> dict[str, list[str]]:
    """Map AC-NNN → citing test references from `tests/**/test_*.py`.

    Static AST scan — files are never imported or collected, and AC
    citations inside string literals (test fixtures) do NOT count;
    only real `@pytest.mark.ac(...)` decorators and `_acNNN` test-name
    suffixes do.
    """
    citations: dict[str, list[str]] = {}
    tests_dir = project_root / "tests"
    if not tests_dir.is_dir():
        return citations
    for test_file in sorted(tests_dir.rglob("test_*.py")):
        rel = test_file.relative_to(project_root).as_posix()
        try:
            tree = ast.parse(test_file.read_text(encoding="utf-8"))
        except (OSError, SyntaxError):
            continue
        for node in ast.walk(tree):
            if not isinstance(node, ast.FunctionDef | ast.AsyncFunctionDef):
                continue
            if not node.name.startswith("test_"):
                continue
            for ac_id in _marker_ac_ids(node):
                citations.setdefault(ac_id, []).append(f"{rel}::{node.name} (marker)")
            suffix = _AC_NAME_SUFFIX_RE.search(node.name)
            if suffix:
                citations.setdefault(f"AC-{suffix.group(1)}", []).append(f"{rel}::{node.name}")
    return citations


def _manually_reviewed(spec_text: str) -> dict[str, str]:
    """AC ids whose `### AC-NNN` section carries a `Manual review:` line."""
    reviewed: dict[str, str] = {}
    current_ac: str | None = None
    for line in spec_text.splitlines():
        heading = re.match(r"^#{2,4}\s+.*?\b(AC-(?:[A-Z0-9]+-)?\d{3})\b", line)
        if heading:
            current_ac = heading.group(1)
            continue
        if re.match(r"^#{1,4}\s", line):
            current_ac = None
            continue
        stripped = line.strip()
        if current_ac and _MANUAL_REVIEW_RE.match(stripped):
            reviewed[current_ac] = stripped.lstrip("-* ").strip()
    return reviewed


def _build_rows(
    project_root: Path,
    context: dict[str, Any],
    epic_filter: str | None,
) -> list[AcRow]:
    """Assemble the coverage matrix for the project."""
    citations = _citing_tests(project_root)
    rows: list[AcRow] = []
    declared_ids: set[str] = set()

    for artifact in _declaring_artifacts(project_root, context):
        rel = artifact.relative_to(project_root).as_posix()
        if epic_filter and epic_filter.lower() not in artifact.name.lower():
            continue
        text = artifact.read_text(encoding="utf-8")
        reviewed = _manually_reviewed(text)
        for ac_id in sorted(set(_AC_ID_RE.findall(text))):
            declared_ids.add(ac_id)
            covered_by = list(citations.get(ac_id, []))
            if ac_id in reviewed:
                covered_by.append(reviewed[ac_id])
            status = "COVERED" if covered_by else "ORPHAN-AC"
            rows.append(AcRow(epic=rel, ac_id=ac_id, status=status, covered_by=covered_by))

    # Orphaned citations: cited ids no artifact declares. Suppressed when
    # --epic filters the matrix — a cross-epic citation is not an orphan.
    if not epic_filter:
        # Ids declared ANYWHERE (including filtered-out artifacts) are not
        # orphans; recompute the full declared set for correctness.
        all_declared = set(declared_ids)
        for artifact in _declaring_artifacts(project_root, context):
            all_declared.update(_AC_ID_RE.findall(artifact.read_text(encoding="utf-8")))
        for ac_id in sorted(set(citations) - all_declared):
            rows.append(
                AcRow(epic="", ac_id=ac_id, status="ORPHAN-CITATION", covered_by=citations[ac_id])
            )

    return rows


def _summary(rows: list[AcRow]) -> dict[str, int]:
    return {
        "total": len(rows),
        "covered": sum(1 for r in rows if r.status == "COVERED"),
        "orphaned_acs": sum(1 for r in rows if r.status == "ORPHAN-AC"),
        "orphaned_citations": sum(1 for r in rows if r.status == "ORPHAN-CITATION"),
    }


def _render_markdown(rows: list[AcRow]) -> str:
    header = "| Epic | AC | Status | Covered by |\n|---|---|---|---|\n"
    if not rows:
        return header + "| _(no acceptance criteria declared)_ |  |  |  |\n"
    body: list[str] = []
    for row in rows:
        covered = "; ".join(row.covered_by).replace("|", "\\|") or "—"
        body.append(f"| `{row.epic or '—'}` | {row.ac_id} | {row.status} | {covered} |")
    return header + "\n".join(body) + "\n"


def _render_console_table(rows: list[AcRow]) -> Table:
    table = Table(title="AC coverage matrix", show_lines=False)
    table.add_column("Epic", style="cyan")
    table.add_column("AC", style="magenta")
    table.add_column("Status", style="bold")
    table.add_column("Covered by", style="dim")
    for row in rows:
        status_style = "green" if row.status == "COVERED" else "red"
        table.add_row(
            row.epic or "—",
            row.ac_id,
            f"[{status_style}]{row.status}[/{status_style}]",
            "; ".join(row.covered_by) or "—",
        )
    return table


def _write_markdown_report(project_root: Path, context: dict[str, Any], rows: list[AcRow]) -> Path:
    docs_dir = _resolve_docs_dir(context)
    timestamp = datetime.now(UTC).strftime("%Y%m%d-%H%M%S")
    out_dir = project_root / docs_dir / "trace"
    out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / f"ac-coverage-{timestamp}.md"

    summary = _summary(rows)
    header = (
        f"# AC coverage matrix — {timestamp} UTC\n\n"
        f"Generated by `fire-phoenix check ac` per "
        f"`adr/0032-three-amigos-advisory-confirmations.md`.\n\n"
        f"- Total: {summary['total']}\n"
        f"- Covered: {summary['covered']}\n"
        f"- Orphaned ACs: {summary['orphaned_acs']}\n"
        f"- Orphaned citations: {summary['orphaned_citations']}\n\n"
        f"## Matrix\n\n"
    )
    out_path.write_text(header + _render_markdown(rows), encoding="utf-8")
    return out_path


def run_ac_coverage(
    epic: str | None,
    json_output: bool,
    project_root: Path | None = None,
) -> int:
    """Build the AC→test coverage matrix and report it.

    Args:
        epic: Optional slug filter; restricts to declaring artifacts whose
            filename contains the slug substring (case-insensitive).
        json_output: If True, emit JSON to stdout. Otherwise write a
            Markdown report to `{paths.docs}/trace/ac-coverage-<timestamp>.md`.
        project_root: Project root (defaults to `Path.cwd()`).

    Returns:
        Exit code: 0 when every row is COVERED (or the matrix is empty,
        or rigor profile P downgrades findings to advisory), 1 when any
        orphan row exists under an enforcing profile (M/F/undeclared).
    """
    if project_root is None:
        project_root = Path.cwd()

    context = _load_context(project_root)
    rows = _build_rows(project_root, context, epic)
    summary = _summary(rows)
    profile = _resolve_rigor_profile(context)

    if json_output:
        payload: dict[str, Any] = {
            "rows": [asdict(r) for r in rows],
            "summary": summary,
        }
        print(json.dumps(payload, indent=2, ensure_ascii=False))
    else:
        if rows:
            console.print(_render_console_table(rows))
        else:
            console.print("[dim]No acceptance criteria declared — empty matrix.[/dim]")
        out_path = _write_markdown_report(project_root, context, rows)
        try:
            rel = out_path.relative_to(project_root)
        except ValueError:
            rel = out_path
        console.print(f"\n[bold]Report written:[/bold] {rel}")
        console.print(
            f"[dim]Total: {summary['total']} | Covered: {summary['covered']} | "
            f"Orphaned ACs: {summary['orphaned_acs']} | "
            f"Orphaned citations: {summary['orphaned_citations']}[/dim]"
        )

    orphans = summary["orphaned_acs"] + summary["orphaned_citations"]
    if orphans and profile == "P":
        if not json_output:
            console.print(
                "[yellow]Rigor profile P — findings are advisory; exit code stays 0.[/yellow]"
            )
        return 0
    return 0 if orphans == 0 else 1


__all__ = ["run_ac_coverage", "AcRow"]

# Parity with sibling modules whose `app` reference is implicit via
# decorators on the shared Typer group.
_ = app
