"""`fire-phoenix workflow run` — execute a workflow by ID or YAML path."""

import uuid
from typing import Any

import typer

from fire_phoenix_cli._lock import guarded_mutation
from fire_phoenix_cli.ui import console, owns_terminal

from ._common import (
    STATUS_COLORS,
    ProgressReporter,
    print_needs_input,
    print_run_failure,
    require_fire_phoenix_project,
)


@guarded_mutation
def workflow_run(
    source: str = typer.Argument(..., help="Workflow ID or YAML file path"),
    input_values: list[str] | None = typer.Option(  # noqa: B008
        None, "--input", "-i", help="Input values as key=value pairs"
    ),
    stream: bool = typer.Option(  # noqa: B008
        False,
        "--stream/--no-stream",
        help="Stream agent CLI output live instead of a progress spinner (default: spinner). "
        "Ignored in interactive mode, where the agent is always attached to the terminal.",
    ),
    auto: bool | None = typer.Option(  # noqa: B008
        None,
        "--auto/--interactive",
        help="Unattended run: agent steps run headless with tool permissions granted and "
        "FIRE_PHOENIX_AGENT_MODE=auto (no prompts; the review gates are the checkpoints). "
        "Default is interactive — the agent is attached to your terminal so you approve tools "
        "and answer questions live. Overrides the workflow's `execution:` setting.",
    ),
) -> None:
    """Run a workflow from an installed ID or local YAML path."""
    from fire_phoenix_cli.workflows.engine import WorkflowEngine

    project_root = require_fire_phoenix_project()
    engine = WorkflowEngine(project_root)
    engine.stream_output = stream

    try:
        definition = engine.load_workflow(source)
    except FileNotFoundError:
        console.print(f"[red]Error:[/red] Workflow not found: {source}")
        raise typer.Exit(1)  # noqa: B904
    except ValueError as exc:
        console.print(f"[red]Error:[/red] Invalid workflow: {exc}")
        raise typer.Exit(1)  # noqa: B904

    # Run mode: explicit --auto/--interactive wins; otherwise the workflow's
    # `execution:` setting; otherwise interactive (safe default).
    engine.unattended = auto if auto is not None else (definition.execution == "auto")
    if engine.unattended:
        console.print(
            "[yellow]Unattended mode:[/yellow] agent steps run headless with tool "
            "permissions granted. Review gates remain your checkpoints."
        )

    # Animate the per-step spinner ONLY when fire-phoenix exclusively owns the
    # terminal: an unattended run whose agent output is captured (not streamed)
    # on a real TTY. In interactive/streamed/non-TTY runs the agent CLI draws to
    # this same terminal, so fire-phoenix stays static — no overlapping
    # animation. Integration-agnostic (holds for every agent CLI).
    reporter = ProgressReporter(animate=owns_terminal() and engine.unattended and not stream)
    engine.on_step_start = reporter.start
    engine.on_step_complete = reporter.complete

    # Validate
    errors = engine.validate(definition)
    if errors:
        console.print("[red]Workflow validation failed:[/red]")
        for err in errors:
            console.print(f"  • {err}")
        raise typer.Exit(1)

    # Parse inputs
    inputs: dict[str, Any] = {}
    if input_values:
        for kv in input_values:
            if "=" not in kv:
                console.print(
                    f"[red]Error:[/red] Invalid input format: {kv!r} (expected key=value)"
                )
                raise typer.Exit(1)
            key, _, value = kv.partition("=")
            inputs[key.strip()] = value.strip()

    run_id = str(uuid.uuid4())[:8]
    console.print(f"\n[bold cyan]Running workflow:[/bold cyan] {definition.name} ({definition.id})")
    console.print(f"[dim]Version: {definition.version}[/dim]")
    console.print(f"[dim]Run ID: {run_id}   inspect: fire-phoenix workflow status {run_id}[/dim]\n")

    try:
        state = engine.execute(definition, inputs, run_id=run_id)
    except ValueError as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(1)  # noqa: B904
    except Exception as exc:
        console.print(f"[red]Workflow failed:[/red] {exc}")
        raise typer.Exit(1)  # noqa: B904

    color = STATUS_COLORS.get(state.status.value, "white")
    console.print(f"\n[{color}]Status: {state.status.value}[/{color}]")
    console.print(f"[dim]Run ID: {state.run_id}[/dim]")

    if state.status.value in ("failed", "aborted"):
        print_run_failure(state)

    if state.status.value == "paused":
        console.print(f"\nResume with: [cyan]fire-phoenix workflow resume {state.run_id}[/cyan]")

    if state.status.value == "needs_input":
        print_needs_input(state)
