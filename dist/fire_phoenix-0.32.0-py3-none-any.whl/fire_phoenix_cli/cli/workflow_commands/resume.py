"""`fire-phoenix workflow resume` — resume a paused or failed workflow run."""

import typer

from fire_phoenix_cli._lock import guarded_mutation
from fire_phoenix_cli.ui import console, owns_terminal

from ._common import (
    STATUS_COLORS,
    ProgressReporter,
    print_needs_input,
    print_run_failure,
    require_fire_phoenix_project,
)


@guarded_mutation
def workflow_resume(
    run_id: str = typer.Argument(..., help="Run ID to resume"),
    stream: bool = typer.Option(  # noqa: B008
        False,
        "--stream/--no-stream",
        help="Stream agent CLI output live instead of a progress spinner (default: spinner). "
        "Ignored in interactive mode, where the agent is always attached to the terminal.",
    ),
    auto: bool = typer.Option(  # noqa: B008
        False,
        "--auto/--interactive",
        help="Resume unattended: agent steps run headless with tool permissions granted and "
        "FIRE_PHOENIX_AGENT_MODE=auto. Default is interactive (agent attached to the terminal).",
    ),
) -> None:
    """Resume a paused or failed workflow run."""
    from fire_phoenix_cli.workflows.engine import WorkflowEngine

    project_root = require_fire_phoenix_project()
    engine = WorkflowEngine(project_root)
    engine.stream_output = stream
    engine.unattended = auto
    # Spinner only when fire-phoenix owns the terminal (unattended + captured +
    # TTY); otherwise static lines so nothing overlaps the agent's own UI.
    reporter = ProgressReporter(animate=owns_terminal() and engine.unattended and not stream)
    engine.on_step_start = reporter.start
    engine.on_step_complete = reporter.complete
    if engine.unattended:
        console.print(
            "[yellow]Unattended mode:[/yellow] agent steps run headless with tool "
            "permissions granted. Review gates remain your checkpoints."
        )

    try:
        state = engine.resume(run_id)
    except FileNotFoundError:
        console.print(f"[red]Error:[/red] Run not found: {run_id}")
        raise typer.Exit(1)  # noqa: B904
    except ValueError as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(1)  # noqa: B904
    except Exception as exc:
        console.print(f"[red]Resume failed:[/red] {exc}")
        raise typer.Exit(1)  # noqa: B904

    color = STATUS_COLORS.get(state.status.value, "white")
    console.print(f"\n[{color}]Status: {state.status.value}[/{color}]")
    console.print(f"[dim]Run ID: {state.run_id}[/dim]")

    if state.status.value in ("failed", "aborted"):
        print_run_failure(state)

    if state.status.value == "paused":
        console.print(f"\nResume with: [cyan]fire-phoenix workflow resume {state.run_id}[/cyan]")

    if state.status.value == "needs_input":
        print_needs_input(state)
