"""`fire-phoenix workflow search` — search workflow catalogs."""

import typer

from fire_phoenix_cli.ui import console

from ._common import require_fire_phoenix_project


def workflow_search(
    query: str | None = typer.Argument(None, help="Search query"),
    tag: str | None = typer.Option(None, "--tag", help="Filter by tag"),
) -> None:
    """Search workflow catalogs."""
    from fire_phoenix_cli.workflows.catalog import WorkflowCatalog, WorkflowCatalogError

    project_root = require_fire_phoenix_project()
    catalog = WorkflowCatalog(project_root)

    try:
        results = catalog.search(query=query, tag=tag)
    except WorkflowCatalogError as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(1)  # noqa: B904

    if not results:
        console.print("[yellow]No workflows found.[/yellow]")
        return

    console.print(f"\n[bold cyan]Workflows ({len(results)}):[/bold cyan]\n")
    for wf in results:
        console.print(
            f"  [bold]{wf.get('name', wf.get('id', '?'))}[/bold] "
            f"({wf.get('id', '?')}) v{wf.get('version', '?')}"
        )
        desc = wf.get("description", "")
        if desc:
            console.print(f"    {desc}")
        tags = wf.get("tags", [])
        if tags:
            console.print(f"    [dim]Tags: {', '.join(tags)}[/dim]")
        console.print()
