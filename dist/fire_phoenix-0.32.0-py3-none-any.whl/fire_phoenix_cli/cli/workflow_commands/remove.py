"""`fire-phoenix workflow remove` — uninstall a workflow."""

import shutil

import typer

from fire_phoenix_cli.ui import console

from ._common import require_fire_phoenix_project


def workflow_remove(
    workflow_id: str = typer.Argument(..., help="Workflow ID to uninstall"),
) -> None:
    """Uninstall a workflow."""
    from fire_phoenix_cli.workflows.catalog import WorkflowRegistry

    project_root = require_fire_phoenix_project()
    registry = WorkflowRegistry(project_root)

    if not registry.is_installed(workflow_id):
        console.print(f"[red]Error:[/red] Workflow '{workflow_id}' is not installed")
        raise typer.Exit(1)

    # Remove workflow files
    workflow_dir = project_root / ".fire-phoenix" / "workflows" / workflow_id
    if workflow_dir.exists():
        shutil.rmtree(workflow_dir)

    registry.remove(workflow_id)
    console.print(f"[green]✓[/green] Workflow '{workflow_id}' removed")
