"""`fire-phoenix metrics` — compute the five handbook ch. 16 §3 loop metrics.

Reads repo artefacts only (contracts/, decisions.md, `git log`). Never reads
session logs, the network, or anything outside the repo root. Per
`adr/0028-fire-phoenix-metrics.md`.

Public surface:
- `run_metrics(since, by_class, json_output) -> int` — pure entry-point.
- The `metrics` typer command, registered on the main app at module-import
  time (see the `@app.command()` decorator at the bottom).

The five metrics (handbook ch. 16 §3 + appendix "Measuring the loop"):
1. Gate latency  — contract-ready → approval-recorded (median + p90, days).
2. Loop time     — first intent commit → last referencing commit (median + p90,
                   days, per change class).
3. Contract rework rate — contracts amended after first implementation
                   session ÷ contracts closed.
4. Escape rate   — fix-shaped commits ÷ total commits in window (proxy;
                   see ADR 0028 §Decision for limits).
5. Evidence completeness — contracts with Spec citation AND ≥1 referencing
                   commit ÷ total contracts.

Every metric defaults to ``None`` (JSON ``null``) when there is no data —
the command never raises on missing data; that *is* the data.
"""

from __future__ import annotations

import json
import re
import statistics
import subprocess
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import typer
from rich.console import Console
from rich.table import Table

from . import app

# Must match scripts/lint_idd.py::_CITATION_RE — if either changes, both must.
_CITATION_RE = re.compile(
    r"PRODUCT\.md|specs/epic-[a-z0-9-]+\.md|adr/\d{4}-[a-z0-9-]+\.md", re.IGNORECASE
)

# Contract filename: contracts/task-NNNN-<slug>.md
_CONTRACT_FILENAME_RE = re.compile(r"^task-(\d{4})-[a-z0-9-]+\.md$")
# Match a `task-NNNN` reference inside any text (commit subject, decisions.md body).
_TASK_REFERENCE_RE = re.compile(r"\btask-(\d{4})\b", re.IGNORECASE)
# Header of a decisions.md entry: `## YYYY-MM-DD — title`.
_DECISIONS_ENTRY_HEADER_RE = re.compile(r"^##\s+(\d{4}-\d{2}-\d{2})\s+[—\-]\s+(.*)$")
# Escape-rate proxy: subject begins with `fix(` / `fix:` / `bug(` / `bug:`
# or contains the literal word `escape` anywhere.
_ESCAPE_SUBJECT_RE = re.compile(r"^(fix\s*[:(]|bug\s*[:(])|\bescape\b", re.IGNORECASE)

_CHANGE_CLASSES = ("mechanical", "routine", "consequential", "critical")

console = Console()


@dataclass
class _Contract:
    """One contract record extracted from contracts/task-*-*.md."""

    task_id: str  # "0057"
    path: Path
    change_class: str | None  # one of _CHANGE_CLASSES, or None if unparseable
    has_spec_citation: bool
    # Populated from git history (None if no commits touched the file):
    file_first_commit: datetime | None = None
    file_commit_count: int = 0
    file_commit_dates: list[datetime] = field(default_factory=list)
    # Populated from commit-message scan (None if no commit references this id):
    referencing_first_commit: datetime | None = None
    referencing_last_commit: datetime | None = None
    referencing_count: int = 0
    # First commit that touched a src/ path AND referenced this contract id:
    first_impl_session_commit: datetime | None = None


@dataclass
class _Commit:
    """One commit record from `git log`."""

    sha: str
    when: datetime
    subject: str


@dataclass
class _DecisionEntry:
    """One decisions.md entry — header date + body."""

    when: datetime
    title: str
    body: str
    referenced_tasks: set[str] = field(default_factory=set)


def _parse_git_iso(timestamp: str) -> datetime:
    """Parse `git log %ci` format (`YYYY-MM-DD HH:MM:SS ±HHMM`) to aware datetime."""
    # Normalise the timezone to ±HH:MM for fromisoformat (Python < 3.11 needed
    # the colon; 3.11+ accepts both, but be defensive).
    s = timestamp.strip()
    if len(s) >= 5 and (s[-5] == "+" or s[-5] == "-") and s[-3] != ":":
        s = s[:-2] + ":" + s[-2:]
    # `git log %ci` uses space separator — fromisoformat needs `T` only on older
    # 3.x; 3.11+ accepts the space. We rely on 3.11+ per pyproject.
    return datetime.fromisoformat(s)


def _git_repo_error(repo: Path) -> str | None:
    """Return an actionable error string if git is unusable at ``repo``, else None.

    Distinguishes "git missing / not a repository" (a real failure the caller
    must surface with a non-zero exit) from the legitimately-empty output that
    ``_run_git`` collapses to ``""``. Without this, ``metrics`` run outside a
    git repo would report all-zero figures and exit 0 — masking the failure.
    """
    try:
        r = subprocess.run(
            ["git", "rev-parse", "--is-inside-work-tree"],
            cwd=str(repo),
            capture_output=True,
            text=True,
            check=False,
        )
    except (OSError, subprocess.SubprocessError) as exc:
        return f"git is not available ({exc})."
    if r.returncode != 0 or r.stdout.strip() != "true":
        return f"{repo} is not a git repository."
    return None


def _run_git(args: list[str], cwd: Path) -> str:
    """Run a git command; return stdout (empty string on failure).

    An empty return is ambiguous (no matching output vs. git failure); callers
    that must not silently treat git failure as "no data" should first gate on
    :func:`_git_repo_error`.
    """
    try:
        r = subprocess.run(
            ["git", *args],
            cwd=str(cwd),
            capture_output=True,
            text=True,
            check=False,
        )
    except (OSError, subprocess.SubprocessError):
        return ""
    if r.returncode != 0:
        return ""
    return r.stdout or ""


def _parse_contract_header(path: Path) -> tuple[str | None, bool]:
    """Return (change_class, has_spec_citation) parsed from a contract header.

    Mirrors the parse used by ``scripts/lint_idd.py``::``rule_change_class_in_contracts``
    and ``rule_spec_citation_in_contracts``.
    """
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return None, False

    lines = text.splitlines()
    header_block = "\n".join(lines[:5])
    has_citation = bool(_CITATION_RE.search(header_block))

    change_class: str | None = None
    if len(lines) >= 3:
        row = lines[2]
        cells = [c.strip() for c in row.strip().strip("|").split("|")]
        # Resolve the Change class column by header name — the 3DD
        # contract template inserts `AC` as the second column, so a
        # positional cells[1] read would grab the AC ids instead.
        header_cells = [c.strip().lower() for c in lines[0].strip().strip("|").split("|")]
        try:
            class_idx = header_cells.index("change class")
        except ValueError:
            class_idx = 1
        if class_idx < len(cells):
            cell = cells[class_idx].lower()
            if cell:
                token = cell.split()[0].strip("*`").rstrip(".,;:")
                if token in _CHANGE_CLASSES:
                    change_class = token

    return change_class, has_citation


def _discover_contracts(repo: Path) -> dict[str, _Contract]:
    """Find every contracts/task-NNNN-*.md file in the repo.

    Includes `contracts/archive/` — metrics reports on delivery history,
    and closed contracts move there per `adr/0033`. (Enforcement tools
    — lint, `check ac` — scan top-level only; reporting tools include
    the archive.)
    """
    contracts: dict[str, _Contract] = {}
    contracts_dir = repo / "contracts"
    if not contracts_dir.is_dir():
        return contracts
    candidates = list(contracts_dir.iterdir())
    archive_dir = contracts_dir / "archive"
    if archive_dir.is_dir():
        candidates.extend(archive_dir.iterdir())
    for path in sorted(candidates):
        if not path.is_file():
            continue
        m = _CONTRACT_FILENAME_RE.match(path.name)
        if not m:
            continue
        task_id = m.group(1)
        change_class, has_citation = _parse_contract_header(path)
        contracts[task_id] = _Contract(
            task_id=task_id,
            path=path,
            change_class=change_class,
            has_spec_citation=has_citation,
        )
    return contracts


def _load_commits(repo: Path, since: str | None) -> list[_Commit]:
    """Load commits via `git log`, optionally filtered by `--since <date>`.

    ``since`` is passed straight to ``git log --since=``, which interprets it as
    a *date* (an "approxidate": ``2026-06-01``, ``1 week ago``). It is **not** a
    commit/ref selector — a SHA is not a valid ``--since`` value and git would
    silently ignore it, returning the full history. Filtering is by committer
    date (``%cI``), matching how ``git log --since`` itself selects commits.

    Output is sorted oldest-first.
    """
    args = ["log", "--format=%H%x09%cI%x09%s"]
    if since:
        args.append(f"--since={since}")
    raw = _run_git(args, repo)
    commits: list[_Commit] = []
    for line in raw.splitlines():
        if not line.strip():
            continue
        parts = line.split("\t", 2)
        if len(parts) < 3:
            continue
        sha, when_s, subject = parts
        try:
            when = _parse_git_iso(when_s)
        except (ValueError, TypeError):
            continue
        commits.append(_Commit(sha=sha, when=when, subject=subject))
    commits.sort(key=lambda c: c.when)
    return commits


def _enrich_contracts_with_file_history(repo: Path, contracts: dict[str, _Contract]) -> None:
    """Per-file `git log` to populate file_first_commit + file_commit_count."""
    for c in contracts.values():
        raw = _run_git(
            ["log", "--format=%cI", "--", str(c.path.relative_to(repo))],
            repo,
        )
        dates: list[datetime] = []
        for line in raw.splitlines():
            if not line.strip():
                continue
            try:
                dates.append(_parse_git_iso(line))
            except (ValueError, TypeError):
                continue
        c.file_commit_dates = sorted(dates)
        c.file_commit_count = len(dates)
        c.file_first_commit = c.file_commit_dates[0] if c.file_commit_dates else None


def _bulk_commit_details(repo: Path, shas: list[str]) -> dict[str, tuple[str, list[str]]]:
    """Return ``{sha: (body, files)}`` for ``shas`` via one ``git log`` call.

    Replaces a per-commit pair of ``git log -1 --format=%B`` + ``git show
    --name-only`` invocations with a single bulk ``git log`` whose output
    interleaves body and files using NUL separators (forbidden in both commit
    messages and filenames, so split is unambiguous).

    Output layout per commit (``--pretty=format:%x00%H%x00%B%x00`` +
    ``--name-only``)::

        \\x00<SHA>\\x00<BODY>\\x00\\n<file>\\n<file>\\n\\n<SHA>\\x00<BODY>\\x00\\n...

    Splitting on ``\\x00`` yields::

        ["", SHA1, BODY1, files_block1, SHA2, BODY2, files_block2, ...]

    ``--no-walk`` keeps the order of the supplied SHAs and skips parent
    traversal, so missing/unknown SHAs simply don't appear in the result.
    """
    result: dict[str, tuple[str, list[str]]] = {}
    if not shas:
        return result
    raw = _run_git(
        ["log", "--no-walk", "--name-only", "--pretty=format:%x00%H%x00%B%x00", *shas],
        repo,
    )
    if not raw:
        return result
    tokens = raw.split("\x00")
    # Layout: ['', SHA1, BODY1, files_block1, SHA2, BODY2, files_block2, ...].
    # For N commits there are 1 + 3*N tokens; the final files_block is the
    # last token (no trailing NUL). Iterate full triplets.
    i = 1
    while i + 2 <= len(tokens) - 1:
        sha = tokens[i]
        body = tokens[i + 1]
        files_block = tokens[i + 2]
        files = [line.strip() for line in files_block.splitlines() if line.strip()]
        result[sha] = (body, files)
        i += 3
    return result


def _enrich_contracts_with_commit_references(
    repo: Path, contracts: dict[str, _Contract], commits: list[_Commit]
) -> None:
    """Scan commit subjects/bodies for `task-NNNN` references."""
    # For each commit, also fetch the body once to scan it (cheap when there
    # are few commits; we cap at 5000 commits before falling back to subject-only).
    use_bodies = len(commits) <= 5000

    # Map sha -> list of referenced task ids.
    sha_to_refs: dict[str, set[str]] = {}
    # Map sha -> bool: did this commit touch a src/ path?
    sha_to_src: dict[str, bool] = {}

    # Single bulk `git log` over the window-filtered SHAs replaces a per-commit
    # pair of subprocess calls. On a ~250-commit window this drops ~500 spawns
    # to 1.
    bulk = _bulk_commit_details(repo, [c.sha for c in commits])

    for commit in commits:
        refs: set[str] = set()
        for m in _TASK_REFERENCE_RE.finditer(commit.subject):
            refs.add(m.group(1))
        body, files = bulk.get(commit.sha, ("", []))
        if use_bodies:
            for m in _TASK_REFERENCE_RE.finditer(body):
                refs.add(m.group(1))
        sha_to_refs[commit.sha] = refs

        # Touched src/ path? Read from the bulk-fetched file list.
        touched_src = any(f.startswith("src/") for f in files)
        sha_to_src[commit.sha] = touched_src

    # Walk commits oldest-first to populate per-contract first/last referencing.
    for commit in commits:
        for task_id in sha_to_refs.get(commit.sha, set()):
            c = contracts.get(task_id)
            if c is None:
                continue
            if c.referencing_first_commit is None or commit.when < c.referencing_first_commit:
                c.referencing_first_commit = commit.when
            if c.referencing_last_commit is None or commit.when > c.referencing_last_commit:
                c.referencing_last_commit = commit.when
            c.referencing_count += 1
            if sha_to_src.get(commit.sha) and c.first_impl_session_commit is None:
                c.first_impl_session_commit = commit.when


def _load_decisions_entries(repo: Path) -> list[_DecisionEntry]:
    """Parse decisions.md into entries (header + body)."""
    entries: list[_DecisionEntry] = []
    path = repo / "decisions.md"
    if not path.is_file():
        return entries
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return entries

    current_header: tuple[datetime, str] | None = None
    current_body: list[str] = []

    def flush() -> None:
        if current_header is None:
            return
        when, title = current_header
        body = "\n".join(current_body)
        entry = _DecisionEntry(when=when, title=title, body=body)
        for m in _TASK_REFERENCE_RE.finditer(title + "\n" + body):
            entry.referenced_tasks.add(m.group(1))
        entries.append(entry)

    for line in text.splitlines():
        m = _DECISIONS_ENTRY_HEADER_RE.match(line)
        if m:
            # Flush previous entry.
            flush()
            try:
                when = datetime.fromisoformat(m.group(1)).replace(tzinfo=UTC)
            except ValueError:
                current_header = None
                current_body = []
                continue
            current_header = (when, m.group(2).strip())
            current_body = []
        else:
            if current_header is not None:
                current_body.append(line)
    flush()
    return entries


def _median_and_p90(values: list[float]) -> tuple[float | None, float | None]:
    """Return (median, p90) — None if values is empty."""
    if not values:
        return None, None
    sorted_v = sorted(values)
    median = statistics.median(sorted_v)
    # Simple p90 — index = ceil(0.9 * N) - 1, clamped.
    idx = max(0, min(len(sorted_v) - 1, int(0.9 * len(sorted_v))))
    p90 = sorted_v[idx]
    return float(median), float(p90)


def _gate_latency(
    contracts: dict[str, _Contract], decisions: list[_DecisionEntry]
) -> dict[str, Any]:
    """Compute gate latency: ΔT from contract first-commit to matching decisions entry.

    Matches a contract to a decision entry when the entry references the
    contract's task id.
    """
    # Build a lookup: task_id -> list of (decisions_entry.when, ...).
    latencies_overall: list[float] = []
    latencies_by_class: dict[str, list[float]] = {cls: [] for cls in _CHANGE_CLASSES}

    for c in contracts.values():
        if c.file_first_commit is None:
            continue
        # Find matching decision entry — earliest one that references this task id.
        matching: list[_DecisionEntry] = []
        for entry in decisions:
            if c.task_id in entry.referenced_tasks:
                matching.append(entry)
        if not matching:
            continue
        # The handbook says "approval recorded" — earliest matching entry is the
        # closest analogue. If a contract's gate is re-decided later, that's a
        # separate gate event.
        earliest = min(matching, key=lambda e: e.when)
        delta_days = (earliest.when - c.file_first_commit).total_seconds() / 86400.0
        if delta_days < 0:
            # Sanity guard: decisions entries dated before the file's first
            # commit are skipped — common when a contract's commit reuses an
            # older decision date that pre-dated the contract file itself.
            continue
        latencies_overall.append(delta_days)
        if c.change_class:
            latencies_by_class[c.change_class].append(delta_days)

    median, p90 = _median_and_p90(latencies_overall)
    out: dict[str, Any] = {"median_days": median, "p90_days": p90, "n": len(latencies_overall)}
    out["by_class"] = {}
    for cls, vals in latencies_by_class.items():
        m, p = _median_and_p90(vals)
        out["by_class"][cls] = {"median_days": m, "p90_days": p, "n": len(vals)}
    return out


def _loop_time(contracts: dict[str, _Contract]) -> dict[str, Any]:
    """Compute loop time: ΔT from first referencing commit to last referencing commit."""
    overall: list[float] = []
    by_class: dict[str, list[float]] = {cls: [] for cls in _CHANGE_CLASSES}

    for c in contracts.values():
        if c.referencing_first_commit is None or c.referencing_last_commit is None:
            continue
        delta_days = (
            c.referencing_last_commit - c.referencing_first_commit
        ).total_seconds() / 86400.0
        overall.append(delta_days)
        if c.change_class:
            by_class[c.change_class].append(delta_days)

    median, p90 = _median_and_p90(overall)
    out: dict[str, Any] = {"median_days": median, "p90_days": p90, "n": len(overall)}
    out["by_class"] = {}
    for cls, vals in by_class.items():
        m, p = _median_and_p90(vals)
        out["by_class"][cls] = {"median_days": m, "p90_days": p, "n": len(vals)}
    return out


def _contract_rework_rate(contracts: dict[str, _Contract]) -> dict[str, Any]:
    """Heuristic rework: contract file edited in ≥ 2 commits AND an edit landed
    after the first src/-touching, contract-referencing commit.

    Mechanical class is excluded per handbook.
    """
    closed_overall = 0
    amended_overall = 0
    closed_by_class: dict[str, int] = {cls: 0 for cls in _CHANGE_CLASSES}
    amended_by_class: dict[str, int] = {cls: 0 for cls in _CHANGE_CLASSES}

    for c in contracts.values():
        if c.change_class == "mechanical":
            continue
        # "Closed" proxy: at least one referencing commit (i.e. the contract
        # has been worked).
        if c.referencing_count < 1:
            continue
        closed_overall += 1
        if c.change_class:
            closed_by_class[c.change_class] += 1

        is_amended = False
        if c.file_commit_count >= 2 and c.first_impl_session_commit is not None:
            # Any file-commit AFTER first_impl_session_commit?
            for d in c.file_commit_dates:
                if d > c.first_impl_session_commit:
                    is_amended = True
                    break
        if is_amended:
            amended_overall += 1
            if c.change_class:
                amended_by_class[c.change_class] += 1

    rate = (amended_overall / closed_overall) if closed_overall else None
    out: dict[str, Any] = {
        "rate": rate,
        "amended": amended_overall,
        "closed": closed_overall,
        "by_class": {},
    }
    for cls in _CHANGE_CLASSES:
        cl = closed_by_class[cls]
        am = amended_by_class[cls]
        out["by_class"][cls] = {
            "rate": (am / cl) if cl else None,
            "amended": am,
            "closed": cl,
        }
    return out


def _escape_rate(commits: list[_Commit]) -> dict[str, Any]:
    """Escape rate: fix-shaped commits ÷ total commits in window.

    Per-class breakdown is `n/a` because commit subjects don't carry class.
    """
    total = len(commits)
    escapes = sum(1 for c in commits if _ESCAPE_SUBJECT_RE.search(c.subject))
    rate = (escapes / total) if total else None
    out: dict[str, Any] = {
        "rate": rate,
        "escapes": escapes,
        "total_commits": total,
        "by_class": {cls: {"rate": None, "note": "n/a"} for cls in _CHANGE_CLASSES},
    }
    return out


def _evidence_completeness(contracts: dict[str, _Contract]) -> dict[str, Any]:
    """% of contracts with valid Spec citation AND ≥ 1 referencing commit.

    A partial impl of the handbook's 3-link chain (contract id → harness record
    → named approver). The harness-record link is deferred to `check trace`
    per ADR 0028.
    """
    total = len(contracts)
    complete = 0
    by_class_total: dict[str, int] = {cls: 0 for cls in _CHANGE_CLASSES}
    by_class_complete: dict[str, int] = {cls: 0 for cls in _CHANGE_CLASSES}
    for c in contracts.values():
        if c.change_class:
            by_class_total[c.change_class] += 1
        link_a = c.has_spec_citation
        link_b = c.referencing_count >= 1
        if link_a and link_b:
            complete += 1
            if c.change_class:
                by_class_complete[c.change_class] += 1
    rate = (complete / total) if total else None
    out: dict[str, Any] = {
        "rate": rate,
        "complete": complete,
        "total_contracts": total,
        "by_class": {},
    }
    for cls in _CHANGE_CLASSES:
        t = by_class_total[cls]
        cc = by_class_complete[cls]
        out["by_class"][cls] = {
            "rate": (cc / t) if t else None,
            "complete": cc,
            "total": t,
        }
    return out


def _compute_all(repo: Path, since: str | None) -> dict[str, Any]:
    """Top-level compute — discovers, enriches, and packages all metrics."""
    contracts = _discover_contracts(repo)
    commits = _load_commits(repo, since)
    _enrich_contracts_with_file_history(repo, contracts)
    _enrich_contracts_with_commit_references(repo, contracts, commits)
    decisions = _load_decisions_entries(repo)

    return {
        "window": {
            "since": since,
            "total_contracts": len(contracts),
            "total_commits": len(commits),
        },
        "gate_latency_days": _gate_latency(contracts, decisions),
        "loop_time_days": _loop_time(contracts),
        "contract_rework_rate": _contract_rework_rate(contracts),
        "escape_rate": _escape_rate(commits),
        "evidence_completeness": _evidence_completeness(contracts),
    }


def _fmt(v: float | None, fmt: str = "{:.2f}") -> str:
    return "n/a" if v is None else fmt.format(v)


def _render_text(data: dict[str, Any], by_class: bool) -> None:
    """Render a Rich table of the five metrics (overall, plus per-class if requested)."""
    window = data["window"]
    console.print(
        f"[bold]fire-phoenix metrics[/bold] — "
        f"contracts: {window['total_contracts']}, "
        f"commits in window: {window['total_commits']}, "
        f"since: {window['since'] or '(all)'}"
    )
    console.print()

    overall = Table(title="Overall", show_lines=False)
    overall.add_column("Metric", style="cyan")
    overall.add_column("Value")
    overall.add_column("n / count")

    gl = data["gate_latency_days"]
    overall.add_row(
        "Gate latency (days)",
        f"median {_fmt(gl['median_days'])} | p90 {_fmt(gl['p90_days'])}",
        f"n={gl['n']}",
    )
    lt = data["loop_time_days"]
    overall.add_row(
        "Loop time (days)",
        f"median {_fmt(lt['median_days'])} | p90 {_fmt(lt['p90_days'])}",
        f"n={lt['n']}",
    )
    rr = data["contract_rework_rate"]
    overall.add_row(
        "Contract rework rate",
        _fmt(rr["rate"], "{:.3f}"),
        f"{rr['amended']}/{rr['closed']}",
    )
    er = data["escape_rate"]
    overall.add_row(
        "Escape rate (proxy)",
        _fmt(er["rate"], "{:.3f}"),
        f"{er['escapes']}/{er['total_commits']}",
    )
    ec = data["evidence_completeness"]
    overall.add_row(
        "Evidence completeness",
        _fmt(ec["rate"], "{:.3f}"),
        f"{ec['complete']}/{ec['total_contracts']}",
    )
    console.print(overall)

    if by_class:
        per = Table(title="By change class", show_lines=False)
        per.add_column("Class", style="cyan")
        per.add_column("Gate latency (median d)")
        per.add_column("Loop time (median d)")
        per.add_column("Rework rate")
        per.add_column("Evidence completeness")
        per.add_column("Escape rate")
        for cls in _CHANGE_CLASSES:
            per.add_row(
                cls,
                _fmt(gl["by_class"][cls]["median_days"]),
                _fmt(lt["by_class"][cls]["median_days"]),
                _fmt(rr["by_class"][cls]["rate"], "{:.3f}"),
                _fmt(ec["by_class"][cls]["rate"], "{:.3f}"),
                "n/a",
            )
        console.print()
        console.print(per)


def run_metrics(
    since: str | None = None,
    by_class: bool = False,
    json_output: bool = False,
    repo: Path | None = None,
) -> int:
    """Public entry-point. Returns an exit code (0 on success).

    `repo` defaults to `Path.cwd()` — tests can override it.
    """
    if repo is None:
        repo = Path.cwd()
    git_error = _git_repo_error(repo)
    if git_error:
        console.print(f"[red]Error:[/red] cannot compute metrics — {git_error}")
        return 1
    data = _compute_all(repo, since)
    if json_output:
        # Emit compact JSON for machine consumption.
        print(json.dumps(data, default=str, sort_keys=True))
    else:
        _render_text(data, by_class)
    return 0


@app.command()
def metrics(
    since: str | None = typer.Option(
        None,
        "--since",
        help="Filter to commits with committer-date after <date> "
        "(a `git log --since` approxidate: `2026-06-01`, `1 week ago`). "
        "This is a date, not a commit/ref — a SHA is silently ignored by git.",
    ),
    by_class: bool = typer.Option(
        False,
        "--by-class/--no-by-class",
        help="Group every class-meaningful metric by Change class "
        "(mechanical / routine / consequential / critical).",
    ),
    json_output: bool = typer.Option(
        False,
        "--json/--no-json",
        help="Emit a compact JSON document instead of a Rich text table.",
    ),
) -> None:
    """Compute the five handbook ch. 16 §3 loop metrics from repo artefacts.

    Per `adr/0028-fire-phoenix-metrics.md` — reads `contracts/`,
    `decisions.md`, and `git log` only. Never reads the network, session logs,
    or anything outside the repo root.
    """
    exit_code = run_metrics(
        since=since, by_class=by_class, json_output=json_output, repo=Path.cwd()
    )
    raise typer.Exit(exit_code)
