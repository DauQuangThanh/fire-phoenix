"""`fire-phoenix check context` — validate .fire-phoenix context files.

Declaratively validates `.fire-phoenix/context.yml` (+ merged
`user-context.yml`) against the v3.0 schema (adr/0030): schema version, the
no-`current:`-in-project-file rule, top-level keys, and per-section key/type/
enum/path-existence checks. Extracted from `check.py` per D-05 (adr/0005 +
adr/0058).
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from .check_common import CheckFinding, console

# Type alias for the post-check callback applied to each (key, value) pair in
# a schema block after the type check passes. Callbacks may append to either
# the errors or warnings list passed by reference.
_PostCheck = Callable[[str, Any, list[str], list[str], Path], None]


def _type_label(t: type) -> str:
    """Human-readable label for a type used in error messages.

    Maps ``str`` → ``"string"`` (matching the original messages in paths /
    governance / current / language) and ``NoneType`` → ``"null"``. Falls back
    to the type's ``__name__`` for everything else (e.g. ``bool``).
    """
    if t is type(None):
        return "null"
    if t is str:
        return "string"
    return t.__name__


@dataclass
class _SchemaBlock:
    """Declarative description of one top-level section of context.yml.

    ``schema`` maps each expected key to the type (or tuple of types, ``isinstance``-style)
    its value must satisfy. ``None`` as a type is honoured via ``type(None)`` and
    causes the human-readable error message to include ``"or null"``.
    ``enum_values`` maps an optional subset of keys to the allowed string values
    for that key — validated only when the value is a ``str``.
    ``post_check`` runs once per key/value after the type check; it may append
    a warning (path-existence checks) or an error.
    ``tolerate_null`` skips both type-checks and post-checks when the value is
    ``None`` *without* surfacing ``"or null"`` in error messages — matches the
    pre-refactor behaviour where missing-key errors carry the diagnostic and
    None values silently pass type checks (preferences:/language:).
    """

    name: str
    schema: dict[str, type | tuple[type, ...]]
    enum_values: dict[str, tuple[str, ...]] = field(default_factory=dict)
    post_check: _PostCheck | None = None
    tolerate_null: bool = False


def _validate_block(
    block: _SchemaBlock,
    data: Any,
    errors: list[str],
    warnings: list[str],
    project_root: Path,
) -> None:
    """Validate one section of context.yml against its ``_SchemaBlock``.

    Records all failures into ``errors`` / ``warnings`` rather than raising,
    preserving the existing message shape so callers (and tests) see no diff.
    """
    if not isinstance(data, dict):
        errors.append(f"{block.name}: expected dict, got {type(data).__name__}")
        return

    expected_keys = set(block.schema.keys())
    actual_keys = set(data.keys())
    if actual_keys != expected_keys:
        missing = expected_keys - actual_keys
        extra = actual_keys - expected_keys
        if missing:
            errors.append(f"{block.name}: missing keys {missing}")
        if extra:
            errors.append(f"{block.name}: extra keys {extra}")

    for key, value in data.items():
        expected_type = block.schema.get(key)
        if expected_type is None:
            # Extra key — already surfaced above; no type to check against.
            continue

        # Normalise to a tuple for isinstance + human-readable error.
        types_tuple = expected_type if isinstance(expected_type, tuple) else (expected_type,)

        if value is None and (type(None) in types_tuple or block.tolerate_null):
            # None is accepted — either declared explicitly in the schema
            # (current.*) or silently tolerated (preferences:/language:).
            continue

        if not isinstance(value, types_tuple):
            type_names = " or ".join(_type_label(t) for t in types_tuple)
            errors.append(f"{block.name}.{key}: expected {type_names}, got {type(value).__name__}")
            continue

        # Enum validation runs only on present string values.
        allowed = block.enum_values.get(key)
        if allowed is not None and isinstance(value, str) and value not in allowed:
            errors.append(
                f"{block.name}.{key}: invalid value {value!r}. Allowed: {', '.join(allowed)}."
            )

        if block.post_check is not None:
            block.post_check(key, value, errors, warnings, project_root)


def _warn_path_exists(
    key: str, value: Any, errors: list[str], warnings: list[str], project_root: Path
) -> None:
    """``paths.*`` post-check: warn if the directory is missing on disk."""
    if isinstance(value, str):
        if not (project_root / value).exists():
            warnings.append(f"paths.{key}: directory does not exist ({value})")


def _warn_governance_target_exists(
    key: str, value: Any, errors: list[str], warnings: list[str], project_root: Path
) -> None:
    """``governance.*`` post-check: warn if file/dir target is missing on disk."""
    if isinstance(value, str):
        if not (project_root / value).exists():
            kind = "directory" if key.endswith("_dir") else "file"
            warnings.append(f"governance.{key}: {kind} does not exist ({value})")


def _warn_current_file_exists(
    key: str, value: Any, errors: list[str], warnings: list[str], project_root: Path
) -> None:
    """``current.*`` post-check: warn if the referenced file is missing on disk."""
    if isinstance(value, str):
        if not (project_root / value).exists():
            warnings.append(f"current.{key}: file does not exist ({value})")


def _check_language_non_empty(
    key: str, value: Any, errors: list[str], warnings: list[str], project_root: Path
) -> None:
    """``language.*`` post-check: reject empty / whitespace-only strings."""
    if isinstance(value, str) and not value.strip():
        errors.append(f"language.{key}: must be a non-empty string")


def check_context(project_root: Path | None = None) -> tuple[int, list[CheckFinding]]:
    """Validate .fire-phoenix/context.yml + user-context.yml (v3.0 per adr/0030).

    Checks:
    - Both files at schema_version == "3.0"
    - Project context.yml MUST NOT contain a ``current:`` block (it lives in
      user-context.yml only per adr/0030 §Decision)
    - Merged top-level keys are {schema_version, paths, governance, current,
      preferences, language, integrations}
    - paths.* has string values for {docs, intents, plans, tasks, templates, scripts}
    - governance.* has string values for {product_file, status_file, decisions_file,
      specs_dir, contracts_dir, adr_dir, adr_drafts_dir, decisions_pending_dir}
    - current.* has string or null values for {feature, intent, plan, tasks, checklist, branch}
    - preferences.non_tech_role_level ∈ {non-technical, familiar, fluent, technical}
    - preferences.tech_role_level ∈ {junior, mid, senior, staff}
    - Other preferences.* has correct types
    - Each paths.* directory exists (warn if not)
    - Each governance.*_dir directory exists (warn if not)
    - Each current.* path file exists (warn if not)

    Returns (exit_code, findings_list).
    """
    if project_root is None:
        project_root = Path.cwd()

    findings: list[CheckFinding] = []
    context_path = project_root / ".fire-phoenix" / "context.yml"
    if not context_path.exists():
        console.print("[yellow]Warning: .fire-phoenix/context.yml not found[/yellow]")
        return 0, findings

    try:
        from fire_phoenix_cli.context import (
            NON_TECH_ROLE_LEVELS,
            SCHEMA_VERSION,
            TECH_ROLE_LEVELS,
            SchemaVersionError,
            load_context_file,
        )

        context = load_context_file(project_root)
    except SchemaVersionError as e:
        # Schema mismatch is a recognised failure mode — surface as a structured
        # finding rather than a raw exception so users see the migration recipe.
        console.print(f"[red]schema_version mismatch: {e}[/red]")
        findings.append(
            CheckFinding(
                file=".fire-phoenix/context.yml",
                check="context",
                expected=f"schema_version: '{SCHEMA_VERSION}'",
                actual=str(e).split("; ", 1)[0] if "; " in str(e) else str(e),
                fix=(
                    "Bump schema_version to '3.0'; relocate the `current:` "
                    "block (and any personal overrides of "
                    "preferences:/language:) to .fire-phoenix/user-context.yml; "
                    "add .fire-phoenix/user-context.yml to your .gitignore. "
                    "See the upgrade guide for the full recipe."
                ),
            )
        )
        return 1, findings
    except Exception as e:
        console.print(f"[red]Error parsing context.yml: {e}[/red]")
        findings.append(
            CheckFinding(
                file=".fire-phoenix/context.yml",
                check="context",
                expected="Valid YAML",
                actual=str(e),
                fix="Fix the YAML syntax or delete and re-run fire-phoenix init --here",
            )
        )
        return 1, findings

    errors: list[str] = []
    warnings: list[str] = []

    # Check: schema_version == "3.0" (per adr/0030). load_context_file already
    # rejects mismatches, but a missing key arrives here as None.
    schema_version = context.get("schema_version")
    if schema_version != SCHEMA_VERSION:
        errors.append(f"schema_version: expected '{SCHEMA_VERSION}', got {schema_version!r}")

    # adr/0030: the project context.yml MUST NOT carry a `current:` block.
    # Load the raw project YAML directly to detect this (load_context_file
    # auto-fills `current` in the merged dict regardless of source file).
    try:
        import yaml as _raw_yaml

        with open(context_path, encoding="utf-8") as _raw_f:
            _raw_project = _raw_yaml.safe_load(_raw_f) or {}
        if isinstance(_raw_project, dict) and "current" in _raw_project:
            errors.append(
                "context.yml must NOT contain a `current:` block — that block "
                "lives in .fire-phoenix/user-context.yml only. Move the block "
                "to user-context.yml and remove it from context.yml."
            )
    except Exception:
        # YAML parse failure already surfaced above via load_context_file.
        pass

    # Check: top-level keys (governance: added in v2.0)
    expected_keys = {
        "schema_version",
        "paths",
        "governance",
        "current",
        "preferences",
        "language",
        "integrations",
    }
    actual_keys = set(context.keys())
    if actual_keys != expected_keys:
        missing = expected_keys - actual_keys
        extra = actual_keys - expected_keys
        if missing:
            errors.append(f"Missing top-level keys: {missing}")
        if extra:
            errors.append(f"Extra top-level keys: {extra}")

    # Each top-level dict section is validated declaratively. The ``_SchemaBlock``
    # carries the expected keys, per-key types, optional enum constraints, and
    # an optional post-check (path-existence warnings, non-empty asserts, …).
    # See ``_validate_block`` for the shared error/warning shape.
    schema_blocks = [
        _SchemaBlock(
            name="paths",
            schema={
                "docs": str,
                "intents": str,
                "plans": str,
                "tasks": str,
                "templates": str,
                "scripts": str,
            },
            post_check=_warn_path_exists,
        ),
        _SchemaBlock(
            name="governance",
            schema={
                "product_file": str,
                "status_file": str,
                "decisions_file": str,
                "specs_dir": str,
                "contracts_dir": str,
                "adr_dir": str,
                "adr_drafts_dir": str,
                "decisions_pending_dir": str,
            },
            post_check=_warn_governance_target_exists,
        ),
        _SchemaBlock(
            name="current",
            schema={
                "feature": (str, type(None)),
                "intent": (str, type(None)),
                "plan": (str, type(None)),
                "tasks": (str, type(None)),
                "checklist": (str, type(None)),
                "branch": (str, type(None)),
            },
            post_check=_warn_current_file_exists,
        ),
        _SchemaBlock(
            # Preferences keys all accept ``None`` silently (treated as "unset");
            # the missing-keys check above already flags omissions. Pre-refactor
            # behaviour did NOT surface "or null" in type-mismatch messages here.
            name="preferences",
            schema={
                "output_format": str,
                "task_numbering": str,
                "confirm_before_write": bool,
                "auto_update_context": bool,
                "non_tech_role_level": str,
                "tech_role_level": str,
            },
            enum_values={
                "non_tech_role_level": tuple(NON_TECH_ROLE_LEVELS),
                "tech_role_level": tuple(TECH_ROLE_LEVELS),
            },
            tolerate_null=True,
        ),
        _SchemaBlock(
            # Language keys also accept ``None`` silently. The non-empty check
            # only fires on present strings.
            name="language",
            schema={
                "output": str,
                "interaction": str,
            },
            post_check=_check_language_non_empty,
            tolerate_null=True,
        ),
    ]

    for block in schema_blocks:
        _validate_block(block, context.get(block.name, {}), errors, warnings, project_root)

    # Check: integrations is a list
    integrations = context.get("integrations")
    if not isinstance(integrations, list):
        errors.append(f"integrations: expected list, got {type(integrations).__name__}")

    # Print results
    console.print()
    for warning in warnings:
        console.print(f"  [yellow]⚠[/yellow] {warning}")

    if errors:
        for error in errors:
            console.print(f"  [red]✗[/red] {error}")
            findings.append(
                CheckFinding(
                    file=".fire-phoenix/context.yml",
                    check="context",
                    expected="Valid schema",
                    actual=error,
                    fix="Edit .fire-phoenix/context.yml to fix the issue, or delete and re-run fire-phoenix init --here",
                )
            )
        console.print("[red]Context: FAILED[/red]")
    else:
        console.print("[green]Context: OK[/green]")

    return (1 if findings else 0), findings
