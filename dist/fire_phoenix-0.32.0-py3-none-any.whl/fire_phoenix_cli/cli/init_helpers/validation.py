"""Upfront flag validation + project-path resolution for ``init``.

Every helper in this module either returns the validated value or raises
``typer.Exit`` to abort the command before any disk write happens. The
specific exit codes match the pre-refactor behaviour so external scripts
parsing them stay stable.
"""

from pathlib import Path
from typing import Any

import typer
from rich.panel import Panel

from fire_phoenix_cli.context import NON_TECH_ROLE_LEVELS, TECH_ROLE_LEVELS
from fire_phoenix_cli.installer import AGENT_CONFIG
from fire_phoenix_cli.ui import console

_BRANCH_NUMBERING_CHOICES = {"sequential", "timestamp"}
_ARCHETYPE_CHOICES = ("greenfield", "brownfield", "migration")


def _validate_scaffold_flags(archetype: str, no_scaffold: bool) -> None:
    """Validate ``--archetype`` and reject a non-greenfield archetype + ``--no-scaffold``.

    ``--archetype`` selects the scaffold variant (``greenfield`` default,
    ``brownfield`` per adr/0019, ``migration`` per adr/0042). A non-greenfield
    archetype opts INTO a variant scaffold; ``--no-scaffold`` opts OUT of
    scaffolding entirely — the two conflict.
    """
    if archetype not in _ARCHETYPE_CHOICES:
        console.print(
            f"[red]Error:[/red] --archetype must be one of "
            f"{', '.join(_ARCHETYPE_CHOICES)}; got '{archetype}'."
        )
        raise typer.Exit(1)
    if archetype != "greenfield" and no_scaffold:
        console.print(
            f"[red]Error:[/red] --archetype {archetype} and --no-scaffold are "
            "mutually exclusive: --archetype opts INTO a variant scaffold; "
            "--no-scaffold opts OUT of scaffolding entirely. Pick one."
        )
        raise typer.Exit(1)


def _validate_integration_flag(integration: str | None) -> tuple[str | None, Any]:
    """Resolve ``--integration`` and validate the registry key.

    Returns ``(ai_assistant, resolved_integration)`` — both ``None`` when
    no flag was passed. Raises ``typer.Exit(1)`` for an unknown key.
    """
    if not integration:
        return None, None
    from ...integrations import INTEGRATION_REGISTRY, get_integration

    resolved_integration = get_integration(integration)
    if not resolved_integration:
        console.print(f"[red]Error:[/red] Unknown integration: '{integration}'")
        available = ", ".join(sorted(INTEGRATION_REGISTRY))
        console.print(f"[yellow]Available integrations:[/yellow] {available}")
        raise typer.Exit(1)
    return integration, resolved_integration


def _validate_project_name_and_here(
    project_name: str | None,
    here: bool,
) -> tuple[str | None, bool]:
    """Normalize ``project_name`` and ``--here``.

    ``"."`` is rewritten to ``--here`` semantics. Returns the
    normalized ``(project_name, here)`` pair.
    """
    if project_name == ".":
        here = True
        project_name = None

    if here and project_name:
        console.print("[red]Error:[/red] Cannot specify both project name and --here flag")
        raise typer.Exit(1)

    if not here and not project_name:
        console.print(
            "[red]Error:[/red] Must specify either a project name, use '.' for current directory, or use --here flag"
        )
        raise typer.Exit(1)

    return project_name, here


def _validate_branch_numbering(branch_numbering: str | None) -> None:
    if branch_numbering and branch_numbering not in _BRANCH_NUMBERING_CHOICES:
        console.print(
            f"[red]Error:[/red] Invalid --branch-numbering value '{branch_numbering}'. "
            f"Choose from: {', '.join(sorted(_BRANCH_NUMBERING_CHOICES))}"
        )
        raise typer.Exit(1)


def _validate_role_levels(non_tech_role_level: str | None, tech_role_level: str | None) -> None:
    """Reject invalid role-level slugs before any disk write happens (adr/0030)."""
    if non_tech_role_level is not None and non_tech_role_level not in NON_TECH_ROLE_LEVELS:
        console.print(
            f"[red]Error:[/red] Invalid --non-tech-role-level value '{non_tech_role_level}'. "
            f"Choose from: {', '.join(NON_TECH_ROLE_LEVELS)} (per adr/0030)."
        )
        raise typer.Exit(1)
    if tech_role_level is not None and tech_role_level not in TECH_ROLE_LEVELS:
        console.print(
            f"[red]Error:[/red] Invalid --tech-role-level value '{tech_role_level}'. "
            f"Choose from: {', '.join(TECH_ROLE_LEVELS)} (per adr/0030)."
        )
        raise typer.Exit(1)


def _resolve_project_path(
    project_name: str | None,
    *,
    here: bool,
    force: bool,
) -> tuple[Path, str, bool]:
    """Resolve the target project path + handle ``--here``/``--force`` UX.

    Returns ``(project_path, project_name, dir_existed_before)``. May call
    ``typer.confirm`` and ``typer.Exit`` for the interactive merge confirm
    or directory-conflict error paths.
    """
    dir_existed_before = False
    if here:
        project_name = Path.cwd().name
        project_path = Path.cwd()
        dir_existed_before = True

        existing_items = list(project_path.iterdir())
        if existing_items:
            console.print(
                f"[yellow]Warning:[/yellow] Current directory is not empty ({len(existing_items)} items)"
            )
            console.print(
                "[yellow]Template files will be merged with existing content and may overwrite existing files[/yellow]"
            )
            if force:
                console.print(
                    "[cyan]--force supplied: skipping confirmation and proceeding with merge[/cyan]"
                )
            else:
                response = typer.confirm("Do you want to continue?")
                if not response:
                    console.print("[yellow]Operation cancelled[/yellow]")
                    raise typer.Exit(0)
    else:
        assert project_name is not None  # validated upstream by _validate_project_name_and_here
        project_path = Path(project_name).resolve()
        dir_existed_before = project_path.exists()
        if project_path.exists():
            if not project_path.is_dir():
                console.print(f"[red]Error:[/red] '{project_name}' exists but is not a directory.")
                raise typer.Exit(1)
            existing_items = list(project_path.iterdir())
            if force:
                if existing_items:
                    console.print(
                        f"[yellow]Warning:[/yellow] Directory '{project_name}' is not empty ({len(existing_items)} items)"
                    )
                    console.print(
                        "[yellow]Template files will be merged with existing content and may overwrite existing files[/yellow]"
                    )
                console.print(
                    f"[cyan]--force supplied: merging into existing directory '[cyan]{project_name}[/cyan]'[/cyan]"
                )
            else:
                error_panel = Panel(
                    f"Directory already exists: '[cyan]{project_name}[/cyan]'\n"
                    "Please choose a different project name or remove the existing directory.\n"
                    "Use [bold]--force[/bold] to merge into the existing directory.",
                    title="[red]Directory Conflict[/red]",
                    border_style="red",
                    padding=(1, 2),
                )
                console.print()
                console.print(error_panel)
                raise typer.Exit(1)
    return project_path, project_name, dir_existed_before


def _select_ais_and_resolve(
    ai_assistant: str | None,
    integration_options: str | None,
) -> tuple[list[str], dict[str, Any]]:
    """Run multi-select picker (or honour ``--integration``) and validate each key.

    Returns ``(selected_ais, resolved_integrations)``. Aborts via
    ``typer.Exit`` for unknown keys, or for the generic-integration case
    that requires ``--integration-options``.

    ``multi_select_integrations`` is looked up via the
    :mod:`fire_phoenix_cli.cli.init` module's namespace so tests that patch
    ``init.multi_select_integrations`` (the documented test seam pre-dating
    the helper extraction) keep working.
    """
    from fire_phoenix_cli.cli import init as _init_module

    from ...integrations import get_integration

    if ai_assistant:
        if ai_assistant not in AGENT_CONFIG:
            console.print(
                f"[red]Error:[/red] Invalid AI assistant '{ai_assistant}'. "
                f"Choose from: {', '.join(AGENT_CONFIG.keys())}"
            )
            raise typer.Exit(1)
        selected_ais = [ai_assistant]
    else:
        ai_choices = {key: config["name"] for key, config in AGENT_CONFIG.items()}
        selected_ais = _init_module.multi_select_integrations(
            ai_choices,
            "Select AI providers (Space to toggle, Enter to confirm)",
            {"claude"},
        )

    resolved_integrations: dict[str, Any] = {}
    for selected_ai in selected_ais:
        resolved = get_integration(selected_ai)
        if not resolved:
            console.print(f"[red]Error:[/red] Unknown agent '{selected_ai}'")
            raise typer.Exit(1)
        resolved_integrations[selected_ai] = resolved

    # Generic integration requires a commands directory; it must come via
    # --integration-options="--commands-dir <dir>".
    if len(selected_ais) == 1 and selected_ais[0] == "generic" and not integration_options:
        console.print(
            "[red]Error:[/red] --integration-options is required when using --integration generic"
        )
        console.print(
            "[dim]Example: fire-phoenix init my-project --integration generic "
            '--integration-options="--commands-dir .myagent/commands/"[/dim]'
        )
        raise typer.Exit(1)
    return selected_ais, resolved_integrations


def _check_agent_tool(
    selected_ais: list[str],
    ignore_agent_tools: bool,
) -> None:
    """Verify the primary AI CLI binary is on PATH (unless ``--ignore-agent-tools``)."""
    if ignore_agent_tools:
        return
    from fire_phoenix_cli.installer import check_tool

    primary_ai = selected_ais[0]
    agent_config = AGENT_CONFIG.get(primary_ai)
    if not (agent_config and agent_config["requires_cli"]):
        return
    install_url = agent_config["install_url"]
    if not check_tool(primary_ai):
        error_panel = Panel(
            f"[cyan]{primary_ai}[/cyan] not found\n"
            f"Install from: [cyan]{install_url}[/cyan]\n"
            f"{agent_config['name']} is required to continue with this project type.\n\n"
            "Tip: Use [cyan]--ignore-agent-tools[/cyan] to skip this check",
            title="[red]Agent Detection Error[/red]",
            border_style="red",
            padding=(1, 2),
        )
        console.print()
        console.print(error_panel)
        raise typer.Exit(1)


def _print_setup_panel(project_path: Path, *, here: bool) -> None:
    """Print the project-setup summary panel above the StepTracker render."""
    current_dir = Path.cwd()
    setup_lines = [
        "[cyan]fire-phoenix Project Setup[/cyan]",
        "",
        f"{'Project':<15} [green]{project_path.name}[/green]",
        f"{'Working Path':<15} [dim]{current_dir}[/dim]",
    ]
    if not here:
        setup_lines.append(f"{'Target Path':<15} [dim]{project_path}[/dim]")
    console.print(Panel("\n".join(setup_lines), border_style="cyan", padding=(1, 2)))


def _check_git_tool(no_git: bool) -> bool:
    """Probe for ``git`` on PATH unless ``--no-git`` was passed.

    Returns whether init should attempt ``git init`` later. Prints a
    yellow notice when git is unavailable so the user sees why the repo
    step gets skipped further down.
    """
    if no_git:
        return False
    from fire_phoenix_cli.installer import check_tool

    should_init_git = check_tool("git")
    if not should_init_git:
        console.print("[yellow]Git not found - will skip repository initialization[/yellow]")
    return should_init_git
