"""Tracker bootstrap + language/role-level resolution + phase orchestration for ``init``.

Three families of helper separated from the Typer command body so the
command in :mod:`cli.init` stays readable:

* :func:`_resolve_languages_and_roles` / :func:`_build_tracker` /
  :func:`_build_context_kwargs` — leaf helpers used during the Typer
  command's pre-Live-tracker setup.
* :func:`_run_install_phases` — the main phase orchestrator driven inside
  the ``Live`` tracker block. Per adr/0020 §Decision the order is:
  context.yml first (so integration setups can read concrete governance/
  path values) → integrations → shared-infra → custom-agents → optional
  context.yml rewrite → git extension → workflow → scaffold → chmod →
  init_opts persist → preset → auto-commit.

Both groups honour the same non-TTY fallback rules as
:mod:`cli.init_helpers.prompts`.
"""

from pathlib import Path
from typing import Any

import typer

from fire_phoenix_cli.config import save_init_options
from fire_phoenix_cli.context import (
    DEFAULT_INTERACTION_LANGUAGE,
    DEFAULT_NON_TECH_ROLE_LEVEL,
    DEFAULT_OUTPUT_LANGUAGE,
    DEFAULT_TECH_ROLE_LEVEL,
    SchemaVersionError,
    create_context_file,
    create_user_context_file,
    load_context_file,
)
from fire_phoenix_cli.installer import ensure_executable_scripts
from fire_phoenix_cli.installer.journal import InstallJournal
from fire_phoenix_cli.tracker import StepTracker
from fire_phoenix_cli.ui import console
from fire_phoenix_cli.version import get_fire_phoenix_version

from .git import _auto_commit_initial
from .governance import _resolve_paths_and_governance
from .panels import _render_install_conflicts
from .prompts import (
    _NON_TECH_ROLE_LEVEL_DESCRIPTIONS,
    _TECH_ROLE_LEVEL_DESCRIPTIONS,
    _prompt_with_default,
    _select_role_level,
)
from .scaffold import _scaffold_artefacts
from .setup import (
    _install_bundled_custom_agents,
    _install_bundled_workflow,
    _install_git_extension,
    _install_git_hooks,
    _install_governance_hooks,
    _install_integrations,
    _install_preset,
    _verify_and_install_shared_infra,
)


def _resolve_languages_and_roles(
    *,
    lang_output: str | None,
    lang_interaction: str | None,
    non_tech_role_level: str | None,
    tech_role_level: str | None,
) -> tuple[str, str, str, str]:
    """Prompt for any value the CLI didn't pre-fill (adr/0030).

    Each prompt fires only when its corresponding CLI flag is ``None``
    AND stdin is a TTY. Non-interactive invocations accept the documented
    default silently.
    """
    resolved_lang_output = lang_output or _prompt_with_default(
        "Language for written artefacts (specs, plans, ADRs, reviews)?",
        DEFAULT_OUTPUT_LANGUAGE,
    )
    resolved_lang_interaction = lang_interaction or _prompt_with_default(
        "Language for questions and confirmations?",
        DEFAULT_INTERACTION_LANGUAGE,
    )
    # Role-level prompts use arrow-key single-select per adr/0030 §Decision.
    # Each option is shown with its canonical one-liner from
    # docs/reference/role-levels.md so users see what each level means
    # while choosing. The default level is pre-highlighted in the picker.
    resolved_non_tech_role_level = non_tech_role_level or _select_role_level(
        "Technical level of non-tech roles (BA, PM, Scrum Master)",
        _NON_TECH_ROLE_LEVEL_DESCRIPTIONS,
        DEFAULT_NON_TECH_ROLE_LEVEL,
    )
    resolved_tech_role_level = tech_role_level or _select_role_level(
        "Technical level of tech roles (engineer, tech lead, architect)",
        _TECH_ROLE_LEVEL_DESCRIPTIONS,
        DEFAULT_TECH_ROLE_LEVEL,
    )
    return (
        resolved_lang_output,
        resolved_lang_interaction,
        resolved_non_tech_role_level,
        resolved_tech_role_level,
    )


def _build_tracker(selected_ais: list[str], *, no_scaffold: bool) -> StepTracker:
    """Pre-populate the StepTracker with every step the orchestrator emits.

    The tracker is rendered live during init; declaring every step up
    front (even those that may be ``skip``-ed) keeps the visual order
    stable from the user's perspective.
    """
    tracker = StepTracker("Initialize fire-phoenix Project")

    tracker.add("precheck", "Check required tools")
    tracker.complete("precheck", "ok")
    tracker.add("ai-select", "Select AI providers")
    tracker.complete("ai-select", f"{len(selected_ais)} provider(s)")

    tracker.add("integrations", "Install integrations")
    tracker.add("shared-infra", "Initialise .fire-phoenix/ state directory")

    scaffold_steps: list[tuple[str, str]] = []
    if not no_scaffold:
        scaffold_steps.append(("scaffold", "Scaffold L1-L4 IDD artefacts"))
    for key, label in [
        ("chmod", "Ensure scripts executable"),
        ("git", "Install git extension"),
        ("workflow", "Install bundled workflow"),
        *scaffold_steps,
        # adr/0031: auto-commit step lands between scaffolding and the
        # final "project ready" marker so the user sees it in the tracker
        # render even when it's skipped (--no-git / dirty pre-init tree).
        ("commit", "Create initial commit"),
        ("final", "Finalize"),
    ]:
        tracker.add(key, label)
    return tracker


def _build_context_kwargs(
    *,
    union_integrations: list[str],
    resolved_paths_block: dict[str, str],
    resolved_governance: dict[str, str],
    resolved_lang_output: str,
    resolved_lang_interaction: str,
    resolved_non_tech_role_level: str,
    resolved_tech_role_level: str,
) -> dict[str, Any]:
    """Bundle the kwargs for :func:`context.create_context_file`.

    Reused twice — once with the union ``integrations`` set before the
    integration loop, and (only when ``installed_keys`` diverges from
    ``selected_ais``) a second time after the loop with the truthful list.
    """
    return {
        "integrations": union_integrations,
        "docs_dir": resolved_paths_block["docs"],
        "intents_dir": resolved_paths_block["intents"],
        "plans_dir": resolved_paths_block["plans"],
        "tasks_dir": resolved_paths_block["tasks"],
        "templates_dir": resolved_paths_block["templates"],
        "scripts_dir": resolved_paths_block["scripts"],
        "product_file": resolved_governance["product_file"],
        "status_file": resolved_governance["status_file"],
        "decisions_file": resolved_governance["decisions_file"],
        "specs_dir": resolved_governance["specs_dir"],
        "contracts_dir": resolved_governance["contracts_dir"],
        "adr_dir": resolved_governance["adr_dir"],
        "output_lang": resolved_lang_output,
        "interaction_lang": resolved_lang_interaction,
        "non_tech_role_level": resolved_non_tech_role_level,
        "tech_role_level": resolved_tech_role_level,
    }


def _run_install_phases(
    *,
    project_path: Path,
    selected_ais: list[str],
    resolved_integrations: dict[str, Any],
    runtime_script_type: str,
    integration_options: str | None,
    no_git: bool,
    should_init_git: bool,
    no_scaffold: bool,
    archetype: str,
    force: bool,
    pre_init_dirty: set[str],
    resolved_lang_output: str,
    resolved_lang_interaction: str,
    resolved_non_tech_role_level: str,
    resolved_tech_role_level: str,
    here: bool,
    branch_numbering: str | None,
    preset: str | None,
    docs_dir: str | None,
    intents_dir: str | None,
    plans_dir: str | None,
    tasks_dir: str | None,
    templates_dir: str | None,
    scripts_dir: str | None,
    product_file: str | None,
    status_file: str | None,
    decisions_file: str | None,
    specs_dir: str | None,
    contracts_dir: str | None,
    adr_dir: str | None,
    tracker,
) -> None:
    """Drive every disk-touching phase inside the Live tracker block.

    Per adr/0020 §Decision "Order-of-operations change": context.yml is
    written FIRST so that integration setups (and the scaffold step) can
    read concrete governance/path values from a single source of truth.
    """
    project_path.mkdir(parents=True, exist_ok=True)
    # adr/0061 Stage 2: init owns ONE journal across all its write phases so a
    # crash mid-init leaves a recoverable trail (surfaced at the next command
    # start via installer.journal.orphans). Only actual new writes are recorded
    # — see the conditional record for the preserve-existing user-context file.
    # Cleared only on full success at the end of this function.
    journal = InstallJournal(project_path)
    context_path = project_path / ".fire-phoenix" / "context.yml"

    # Reject pre-existing v1.0 context.yml — no silent migration.
    if context_path.exists():
        try:
            load_context_file(project_path)
        except SchemaVersionError as schema_err:
            console.print(f"[red]Error:[/red] {schema_err}")
            raise typer.Exit(1)  # noqa: B904

    (
        resolved_governance,
        resolved_paths_block,
        existing_integrations,
    ) = _resolve_paths_and_governance(
        context_path=context_path,
        docs_dir=docs_dir,
        intents_dir=intents_dir,
        plans_dir=plans_dir,
        tasks_dir=tasks_dir,
        templates_dir=templates_dir,
        scripts_dir=scripts_dir,
        product_file=product_file,
        status_file=status_file,
        decisions_file=decisions_file,
        specs_dir=specs_dir,
        contracts_dir=contracts_dir,
        adr_dir=adr_dir,
    )

    union_integrations = list(dict.fromkeys(existing_integrations + selected_ais))

    # Shared keyword bundle for create_context_file — reused below if the
    # actual installed_keys diverges from selected_ais (e.g. an integration
    # silently skipped). ``integrations`` is overridden in the second call.
    context_kwargs = _build_context_kwargs(
        union_integrations=union_integrations,
        resolved_paths_block=resolved_paths_block,
        resolved_governance=resolved_governance,
        resolved_lang_output=resolved_lang_output,
        resolved_lang_interaction=resolved_lang_interaction,
        resolved_non_tech_role_level=resolved_non_tech_role_level,
        resolved_tech_role_level=resolved_tech_role_level,
    )

    # Journal context.yml only when this run CREATES it — not when overwriting a
    # pre-existing one — so a teardown-on-failure never removes a user's own
    # context.yml (adr/0061: record only actual new writes).
    if not context_path.exists():
        journal.record(".fire-phoenix/context.yml")
    create_context_file(project_path, **context_kwargs)

    # Scaffold the per-user .fire-phoenix/user-context.yml (adr/0030).
    # Same values are seeded as the team default in context.yml so
    # users start with no divergence; preserve-existing semantics so
    # re-init never overwrites an existing user file.
    # user-context.yml is preserve-existing: journal it only when this init will
    # actually create it, so a failure never surfaces/removes a pre-existing
    # user file (adr/0061 — record only on an actual new write).
    if not (project_path / ".fire-phoenix" / "user-context.yml").exists():
        journal.record(".fire-phoenix/user-context.yml")
    create_user_context_file(
        project_path,
        output_lang=resolved_lang_output,
        interaction_lang=resolved_lang_interaction,
        non_tech_role_level=resolved_non_tech_role_level,
        tech_role_level=resolved_tech_role_level,
    )

    installed_keys, install_conflicts, written_paths = _install_integrations(
        project_path,
        selected_ais,
        resolved_integrations,
        runtime_script_type=runtime_script_type,
        integration_options=integration_options,
        tracker=tracker,
    )

    # Verify asset integrity + install shared infra (scripts, templates)
    _verify_and_install_shared_infra(project_path, force=force, tracker=tracker)

    # Deploy bundled custom agents into each installed integration's
    # subagents folder (e.g. .claude/agents/ for Claude, etc.).
    _install_bundled_custom_agents(project_path, installed_keys, force=force, journal=journal)

    # Install the governance guardrail + audit hook pack, on by default for
    # Claude Code (adr/0040 / W5). No-op for providers without native hooks.
    _install_governance_hooks(project_path, installed_keys, force=force)

    # context.yml was already written before the integration loop
    # (per adr/0020). If the actual installed_keys diverges from the
    # selected_ais we wrote earlier (e.g. an integration silently
    # skipped), re-render the file with the accurate list so the
    # integrations: field stays truthful.
    if installed_keys != selected_ais:
        final_integrations = list(dict.fromkeys(existing_integrations + installed_keys))
        create_context_file(
            project_path,
            **{**context_kwargs, "integrations": final_integrations},
        )

    _install_git_extension(
        project_path,
        no_git=no_git,
        should_init_git=should_init_git,
        tracker=tracker,
    )

    _install_bundled_workflow(project_path, tracker=tracker)

    # adr/0056: the context file each installed provider reads gets BOTH the
    # rich project-memory body (scaffold) AND the managed marker block
    # (post-scaffold upsert). Dedup by context_file so the four AGENTS.md
    # providers (Codex/Copilot/Kiro/OpenCode) share a single write + block.
    context_providers = []
    _seen_context_files: set[str] = set()
    for key in installed_keys:
        provider = resolved_integrations[key]
        ctx_file = getattr(provider, "context_file", None)
        if ctx_file and ctx_file not in _seen_context_files:
            _seen_context_files.add(ctx_file)
            context_providers.append(provider)

    # R-05/task-0111: validate every target context path up front — before any
    # scaffold write or upsert mutates a file — so a path that exists as a
    # non-regular file (e.g. a directory) fails closed here rather than
    # crashing mid-loop after earlier providers were already written, leaving
    # silent partial state. (Full journaling of the phases is deferred — E-04.)
    for provider in context_providers:
        ctx_path = project_path / provider.context_file
        if ctx_path.exists() and not ctx_path.is_file():
            raise RuntimeError(
                f"Cannot write agent context file {provider.context_file!r}: the "
                f"path exists but is not a regular file. Remove or rename it and "
                f"re-run init."
            )

    # Scaffold L1-L4 IDD artefacts (preserve-existing) per adr/0018.
    # archetype (adr/0019 brownfield, adr/0042 migration) swaps the root.
    _scaffold_artefacts(
        no_scaffold=no_scaffold,
        archetype=archetype,
        project_path=project_path,
        provider_context_files=[p.context_file for p in context_providers],
        resolved_governance=resolved_governance,
        resolved_paths_block=resolved_paths_block,
        tracker=tracker,
        journal=journal,  # adr/0061: record each newly-created scaffold artefact
    )

    # Post-scaffold: inject the managed marker block into each installed
    # provider's context file — appended after the rich body the scaffold just
    # wrote (greenfield: body first, managed block last), or into the user's
    # existing file (brownfield), or as the sole content (--no-scaffold). Runs
    # regardless of --no-scaffold so an integration always gets its context
    # file (adr/0056; replaces the inline upsert deferred in
    # init_helpers/setup.py).
    for provider in context_providers:
        # If the scaffold already wrote (and journaled) this body the file now
        # exists; only when it does NOT (e.g. --no-scaffold) does the upsert
        # create it — journal that new file so teardown can roll it back too.
        if not (project_path / provider.context_file).exists():
            journal.record(provider.context_file)
        provider.upsert_context_section(project_path)

    # Fix permissions after all installs (scripts + extensions)
    ensure_executable_scripts(project_path, tracker=tracker)

    # Persist the CLI options so later operations (e.g. preset add)
    # can adapt their behaviour without re-scanning the filesystem.
    # Must be saved BEFORE preset install so _get_skills_dir() works.
    # Pick the first selected integration as the primary for display-only decisions
    # (next-steps panel, agent tool checks).
    primary_integration = resolved_integrations[selected_ais[0]]
    init_opts = {
        "integration": primary_integration.key,
        "integrations": installed_keys,  # Phase 3: track all selected integrations
        "branch_numbering": branch_numbering or "sequential",
        "context_file": primary_integration.context_file,
        "here": here,
        "fire_phoenix_version": get_fire_phoenix_version(),
    }
    # Ensure ai_skills is set for SkillsIntegration so downstream
    # tools (extensions, presets) emit SKILL.md overrides correctly.
    from ...integrations.skills_integration import SkillsIntegration as _SkillsPersist

    if isinstance(primary_integration, _SkillsPersist):
        init_opts["ai_skills"] = True
    save_init_options(project_path, init_opts)

    # Report installation conflicts if any
    _render_install_conflicts(install_conflicts, written_paths, project_path)

    # Install preset if specified
    _install_preset(project_path, preset)

    # adr/0031: auto-commit the scaffolded artefacts so the
    # user's working tree is clean after init. Skipped under
    # --no-git OR when pre-init dirty changes were detected.
    _auto_commit_initial(
        project_path=project_path,
        pre_init_dirty=pre_init_dirty,
        tracker=tracker,
        no_git=no_git,
    )

    # adr/0044 (Phase B soft floor): install the provider-agnostic git-hook
    # governance floor AFTER the auto-commit, so the guardrail never blocks
    # init's own commit. Graceful no-op when the project is not a git repo.
    _install_git_hooks(project_path)

    # adr/0061 Stage 2: every write phase above succeeded — the manifests are
    # authoritative for the installed files, so the recovery journal has served
    # its purpose. Clear it (success = no partial state to surface).
    journal.clear()

    tracker.complete("final", "project ready")
