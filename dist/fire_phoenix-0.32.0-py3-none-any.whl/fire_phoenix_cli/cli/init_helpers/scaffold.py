"""L1-L4 + .gitignore + CODEOWNERS scaffolding (adr/0018, adr/0026, adr/0031).

Preserve-existing semantics across the board — every helper here treats an
existing destination as load-bearing user content and never overwrites.
Each function returns enough information for the caller to surface what
happened in the StepTracker.
"""

import shutil
import sys
from pathlib import Path
from typing import TYPE_CHECKING

from ...fsutil import atomic_write_text, validate_rel_path

if TYPE_CHECKING:
    from ...installer.journal import InstallJournal
from .governance import (
    _GOVERNANCE_DIR_DEFAULTS,
    _GOVERNANCE_DIR_KEY,
    _GOVERNANCE_FILE_DEFAULTS,
    _GOVERNANCE_FILE_KEY,
    _build_sentinel_map,
)

# L1-L4 IDD scaffold targets per adr/0018, made project-configurable in adr/0020.
# Source files in assets/init-scaffold/ keep canonical names; destination filenames
# and L2/L3/L4 directory names are resolved from .fire-phoenix/context.yml's
# `governance:` block at scaffold time.
#
# Per adr/0056 the rich project-memory body (source `CLAUDE.md`) is NO LONGER a
# fixed-name L1 file here — it is written to EACH installed provider's context
# file (CLAUDE.md / AGENTS.md / GEMINI.md / .mdc) by
# `_scaffold_provider_context_files`, so `CLAUDE.md` is intentionally absent
# from this governance-file list.
_CANONICAL_SCAFFOLD_FILES: tuple[str, ...] = (
    "PRODUCT.md",
    "STATUS.md",
    "decisions.md",
)


def _render_scaffold_body(
    body: str,
    *,
    project_name: str,
    sentinels: dict[str, str],
) -> str:
    """Substitute the scaffold template sentinels into *body* (adr/0020).

    Single source for the sentinel substitution the L1-L4, provider-context,
    and baseline scaffold writers all perform, so a new sentinel added here
    reaches every writer instead of drifting across hand-copied loops.
    """
    rendered = body.replace("<<PROJECT_NAME>>", project_name)
    for sentinel, value in sentinels.items():
        rendered = rendered.replace(sentinel, value)
    return rendered


def _scaffold_l1_l4(
    scaffold_root: Path,
    project_path: Path,
    *,
    project_name: str,
    governance: dict,
    paths: dict,
) -> tuple[list[str], list[str]]:
    """Copy bundled L1-L4 scaffold into ``project_path``.

    Returns ``(created, preserved)`` — relative paths created vs.
    skipped because the target already existed. Per ``adr/0018``
    preserve-existing semantics: an existing target is NEVER overwritten.

    Per ``adr/0020``: destination filenames/dirs come from the
    ``governance:`` block of the project's ``.fire-phoenix/context.yml``.
    Template body sentinels (``<<PROJECT_NAME>>`` plus the 12
    governance/path sentinels from ``_build_sentinel_map``) are substituted
    at scaffold time. Single ``{`` braces in templates (``{TBD-source — …}``,
    ``{context.paths.docs}``) are emitted verbatim — the agent-context files
    reference paths by the ``{context.*}`` placeholder form (resolved from
    context.yml at session start), not init-substituted concrete paths.
    """
    sentinels = _build_sentinel_map(governance, paths)

    created: list[str] = []
    preserved: list[str] = []

    for canonical_src in _CANONICAL_SCAFFOLD_FILES:
        src = scaffold_root / canonical_src
        # Each L1 file's destination name follows the user's governance config,
        # falling back to the documented docs/-rooted default (adr/0026) when
        # the governance dict omits the key. (The rich project-memory body is
        # NOT in this list — adr/0056 routes it to each provider's context file
        # via _scaffold_provider_context_files.)
        gov_key = _GOVERNANCE_FILE_KEY.get(canonical_src)
        if gov_key:
            default_dst = _GOVERNANCE_FILE_DEFAULTS.get(canonical_src, canonical_src)
            dst_name = governance.get(gov_key, default_dst)
        else:
            dst_name = canonical_src
        # Defense-in-depth (F-07): reject a governance filename that escapes root.
        validate_rel_path(project_path, dst_name, key=gov_key or canonical_src)
        dst = project_path / dst_name
        if dst.exists():
            preserved.append(dst_name)
            continue
        rendered = _render_scaffold_body(
            src.read_text(encoding="utf-8"),
            project_name=project_name,
            sentinels=sentinels,
        )
        dst.parent.mkdir(parents=True, exist_ok=True)
        atomic_write_text(dst, rendered)
        created.append(dst_name)

    for canonical_dir, gov_key in _GOVERNANCE_DIR_KEY.items():
        default_dir = _GOVERNANCE_DIR_DEFAULTS.get(canonical_dir, canonical_dir)
        dst_dir_name = governance.get(gov_key, default_dir)
        validate_rel_path(project_path, dst_dir_name, key=gov_key)
        dir_target = project_path / dst_dir_name
        gitkeep = dir_target / ".gitkeep"
        if dir_target.exists() and not gitkeep.exists():
            # Directory already exists with content — preserve as-is, no .gitkeep
            preserved.append(dst_dir_name + "/")
            continue
        if gitkeep.exists():
            preserved.append(f"{dst_dir_name}/.gitkeep")
            continue
        dir_target.mkdir(parents=True, exist_ok=True)
        gitkeep.write_text("", encoding="utf-8")
        created.append(f"{dst_dir_name}/.gitkeep")

    return created, preserved


def _scaffold_provider_context_files(
    scaffold_root: Path,
    project_path: Path,
    *,
    provider_context_files: list[str],
    project_name: str,
    governance: dict,
    paths: dict,
) -> tuple[list[str], list[str]]:
    """Write the rich project-memory body into each installed provider's context file.

    Per ``adr/0056``: the source is the canonical scaffold ``CLAUDE.md`` body
    (Source-of-truth, Build/test/run, Conventions, Working-rules, Danger-zones,
    Negative-constraints). Provider-uniform *mechanics* and the context-file
    imports live in the managed overlay the post-scaffold upsert injects — NOT
    in this body — so the same rendered body is correct for every provider.

    Sentinel substitution matches :func:`_scaffold_l1_l4`. Preserve-existing
    (``adr/0018``) governs per file: an existing provider context file is never
    overwritten (the post-scaffold upsert still refreshes only its marker
    block). ``.mdc`` frontmatter is added by the upsert step, not here — the
    scaffold-then-upsert pair runs in one post-scaffold loop in the
    orchestrator, so the only window in which a ``.mdc`` lacks its frontmatter
    is a process death between the two calls; this is accepted per the epic
    design (the upsert owns the frontmatter transform, kept out of this
    provider-agnostic writer).

    Fail closed (``adr/0056`` §Failure conditions): if there are providers to
    write but the scaffold body source is missing, raise rather than silently
    skip — a silent skip reinstates the overlay-only asymmetry the epic closes.

    Returns ``(created, preserved)`` relative paths for the tracker.
    """
    created: list[str] = []
    preserved: list[str] = []
    if not provider_context_files:
        return created, preserved
    src = scaffold_root / "CLAUDE.md"
    if not src.is_file():
        raise FileNotFoundError(
            f"Scaffold body source not found: {src} — cannot write provider "
            f"context files ({', '.join(provider_context_files)}). Aborting to "
            f"avoid an overlay-only partial install (adr/0056)."
        )

    sentinels = _build_sentinel_map(governance, paths)
    rendered = _render_scaffold_body(
        src.read_text(encoding="utf-8"),
        project_name=project_name,
        sentinels=sentinels,
    )

    for context_file in provider_context_files:
        # Defense-in-depth (F-07): reject a context-file path that escapes root.
        validate_rel_path(project_path, context_file, key="context_file")
        dst = project_path / context_file
        if dst.exists():
            preserved.append(context_file)
            continue
        dst.parent.mkdir(parents=True, exist_ok=True)
        atomic_write_text(dst, rendered)
        created.append(context_file)

    return created, preserved


def _scaffold_gitignore(scaffold_root: Path, project_path: Path) -> tuple[bool, str]:
    """Copy ``example.gitignore`` from the scaffold root to ``<project>/.gitignore``.

    Per adr/0026: preserve-existing semantics — an existing ``.gitignore`` at
    the destination is NEVER overwritten. Idempotent: re-running this on a
    project that already has a ``.gitignore`` is a no-op. If the source
    ``example.gitignore`` is missing from the scaffold (unexpected — should
    only happen with a corrupted wheel), the function reports the miss and
    returns without writing.

    Returns ``(wrote, reason)`` for the caller to surface in tracker output.
    """
    src = scaffold_root / "example.gitignore"
    dst = project_path / ".gitignore"
    if dst.exists():
        return False, "preserved existing"
    if not src.exists():
        return False, "example.gitignore not found"
    shutil.copy2(src, dst)
    return True, "created from example.gitignore"


def _scaffold_codeowners(scaffold_root: Path, project_path: Path) -> tuple[bool, str]:
    """Copy ``CODEOWNERS`` from the scaffold root to ``<project>/CODEOWNERS``.

    Per adr/0031: preserve-existing semantics — an existing ``CODEOWNERS`` at
    the destination is NEVER overwritten. Lands at project root (GitHub
    honours either root or ``.github/CODEOWNERS``; root is the more
    discoverable default). Self-documenting template body teaches syntax +
    shows commented examples + lands one live ``*  @{TBD-source}`` rule.

    Returns ``(wrote, reason)`` for the caller to surface in tracker output.
    """
    src = scaffold_root / "CODEOWNERS"
    dst = project_path / "CODEOWNERS"
    if dst.exists():
        return False, "preserved existing"
    if not src.exists():
        return False, "CODEOWNERS template not found"
    shutil.copy2(src, dst)
    return True, "created from template"


def _scaffold_user_guide(scaffold_root: Path, project_path: Path) -> tuple[bool, str]:
    """Copy ``FP-USER-GUIDE.md`` from the scaffold root to ``<project>/FP-USER-GUIDE.md``.

    Preserve-existing semantics, same as ``_scaffold_codeowners`` /
    ``_scaffold_gitignore``: an existing destination is NEVER overwritten.
    The guide is a static, project-agnostic explainer of Intent-Driven
    Development and the six-step Fire Phoenix flow — it carries no
    sentinels and needs no per-project rendering, so a verbatim copy
    (rather than a pass through ``_scaffold_l1_l4``'s sentinel substitution)
    is correct here.

    Returns ``(wrote, reason)`` for the caller to surface in tracker output.
    """
    src = scaffold_root / "FP-USER-GUIDE.md"
    dst = project_path / "FP-USER-GUIDE.md"
    if dst.exists():
        return False, "preserved existing"
    if not src.exists():
        return False, "FP-USER-GUIDE.md template not found"
    shutil.copy2(src, dst)
    return True, "created from template"


def _scaffold_baseline(
    scaffold_root: Path,
    project_path: Path,
    *,
    project_name: str,
    governance: dict,
    paths: dict,
) -> tuple[list[str], list[str]]:
    """Copy the bundled ``baseline/`` head tree into ``{paths.docs}/baseline/``.

    The ``baseline/`` head is the living specification of the system as it
    currently IS (adr/0049). Seeded per archetype by the scaffold source it is
    copied from (greenfield README-only / brownfield ``capabilities.md`` with
    OBSERVED-INFERRED-UNKNOWN tags / migration ``parity-ledger.md``).

    The destination root is derived from ``paths['docs']`` (adr/0020) — the head
    is NOT a new governance-configurable key, it inherits the docs root (task-0092
    scope note). Preserve-existing semantics per ``adr/0018``: an existing file at
    the destination is NEVER overwritten. Markdown bodies get the same sentinel
    substitution as :func:`_scaffold_l1_l4`; non-markdown files are copied
    verbatim. Returns ``(created, preserved)`` relative paths for the tracker.

    The constitution head is intentionally NOT scaffolded here: it is the existing
    ``standards.md`` produced by ``/standardize`` (decisions.md rider 2026-07-14).
    """
    baseline_src = scaffold_root / "baseline"
    created: list[str] = []
    preserved: list[str] = []
    if not baseline_src.is_dir():
        return created, preserved

    docs_root = paths.get("docs", "docs")
    # Defense-in-depth (F-07): reject a docs root that escapes the project.
    validate_rel_path(project_path, docs_root, key="docs")
    baseline_dst_root = project_path / docs_root / "baseline"

    sentinels = _build_sentinel_map(governance, paths)

    for src in sorted(p for p in baseline_src.rglob("*") if p.is_file()):
        rel = src.relative_to(baseline_src)
        dst = baseline_dst_root / rel
        rel_display = (Path(docs_root) / "baseline" / rel).as_posix()
        if dst.exists():
            preserved.append(rel_display)
            continue
        dst.parent.mkdir(parents=True, exist_ok=True)
        if src.suffix == ".md":
            rendered = _render_scaffold_body(
                src.read_text(encoding="utf-8"),
                project_name=project_name,
                sentinels=sentinels,
            )
            atomic_write_text(dst, rendered)
        else:
            shutil.copy2(src, dst)
        created.append(rel_display)

    return created, preserved


def _scaffold_artefacts(
    *,
    no_scaffold: bool,
    archetype: str,
    project_path: Path,
    provider_context_files: list[str],
    resolved_governance: dict[str, str],
    resolved_paths_block: dict[str, str],
    tracker,
    journal: "InstallJournal | None" = None,
) -> None:
    """Run the L1-L4 + .gitignore + CODEOWNERS scaffold step.

    No-op when ``--no-scaffold`` is set. ``archetype`` selects the scaffold
    source root: ``greenfield`` (default), ``brownfield`` (adr/0019, source
    archaeology tags), or ``migration`` (adr/0042, brownfield source +
    greenfield target + a baked-in parity obligation). Reports created /
    preserved counts into the StepTracker. The ``adr/0030`` flag signalling a
    preserved ``.gitignore`` is set on the ``sys`` module the same way the
    pre-extraction code did, so
    :func:`init_helpers.panels._render_gitignore_preserved_notice` fires
    identically.
    """
    from fire_phoenix_cli.installer import (
        _locate_init_scaffold,
        _locate_init_scaffold_brownfield,
        _locate_init_scaffold_migration,
    )

    if no_scaffold:
        return
    tracker.start("scaffold")
    if archetype == "brownfield":
        scaffold_root = _locate_init_scaffold_brownfield()
    elif archetype == "migration":
        scaffold_root = _locate_init_scaffold_migration()
    else:
        scaffold_root = _locate_init_scaffold()
    if scaffold_root is None:
        # Fail closed (adr/0056 §Failure conditions): a missing scaffold source
        # must abort init, never continue to a partial "project ready" state
        # with overlay-only context files.
        tracker.error("scaffold", "init-scaffold assets not found")
        raise FileNotFoundError(
            f"init-scaffold assets not found for archetype {archetype!r}; "
            f"cannot scaffold the project (aborting to avoid a partial install)."
        )
    created, preserved = _scaffold_l1_l4(
        scaffold_root,
        project_path,
        project_name=project_path.name,
        governance=resolved_governance,
        paths=resolved_paths_block,
    )
    # adr/0056: write the rich project-memory body into each installed
    # provider's context file (deduped for the shared AGENTS.md). The
    # post-scaffold upsert phase then injects the managed marker block.
    ctx_created, ctx_preserved = _scaffold_provider_context_files(
        scaffold_root,
        project_path,
        provider_context_files=provider_context_files,
        project_name=project_path.name,
        governance=resolved_governance,
        paths=resolved_paths_block,
    )
    created.extend(ctx_created)
    preserved.extend(ctx_preserved)
    # Per adr/0026: scaffold a top-level .gitignore from the
    # bundled example.gitignore. Preserves any pre-existing
    # .gitignore (idempotent, non-destructive).
    gitignore_wrote, gitignore_reason = _scaffold_gitignore(scaffold_root, project_path)
    if gitignore_wrote:
        created.append(".gitignore")
    elif gitignore_reason == "preserved existing":
        preserved.append(".gitignore")
        # adr/0030: surface the user-context.yml gitignore
        # gap so the user knows to add it manually.
        sys._fire_phoenix_gitignore_preserved = True  # type: ignore[attr-defined]

    # Per adr/0031: scaffold a project-root CODEOWNERS from
    # the bundled self-documenting template. Preserves any
    # pre-existing CODEOWNERS at the destination.
    codeowners_wrote, codeowners_reason = _scaffold_codeowners(scaffold_root, project_path)
    if codeowners_wrote:
        created.append("CODEOWNERS")
    elif codeowners_reason == "preserved existing":
        preserved.append("CODEOWNERS")

    # Static, project-agnostic Intent-Driven Development + Fire Phoenix
    # user guide, copied verbatim into every scaffolded project root.
    # Preserves any pre-existing FP-USER-GUIDE.md at the destination.
    user_guide_wrote, user_guide_reason = _scaffold_user_guide(scaffold_root, project_path)
    if user_guide_wrote:
        created.append("FP-USER-GUIDE.md")
    elif user_guide_reason == "preserved existing":
        preserved.append("FP-USER-GUIDE.md")

    # adr/0049 migration stage 1 (task-0092): scaffold the baseline/ head —
    # the living specification of the system as it currently IS — under the
    # configured docs root, seeded per archetype. Preserve-existing.
    baseline_created, baseline_preserved = _scaffold_baseline(
        scaffold_root,
        project_path,
        project_name=project_path.name,
        governance=resolved_governance,
        paths=resolved_paths_block,
    )
    created.extend(baseline_created)
    preserved.extend(baseline_preserved)

    # adr/0061: record each NEWLY-created scaffold artefact (the `created` list
    # excludes preserve-existing files) into init's journal, before we report
    # success, so a later-phase failure can roll back exactly this run's new
    # files — never a preserved (pre-existing) one.
    if journal is not None:
        for rel in created:
            journal.record(rel)

    parts = []
    if created:
        parts.append(f"{len(created)} created")
    if preserved:
        parts.append(f"{len(preserved)} preserved")
    tracker.complete("scaffold", "; ".join(parts) if parts else "no-op")
