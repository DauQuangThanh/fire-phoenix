"""`fire-phoenix check trace` — 5-link audit chain validation.

Walks `git log --name-only`, identifies touched contracts under
`governance.contracts_dir` (default `contracts/`), parses each
contract's header-table Spec column with the same `_CITATION_RE`
used by `scripts/lint_idd.py` Rule 2, resolves the cited spec
(`PRODUCT.md` / `specs/epic-*.md` / `adr/NNNN-*.md`) on disk, and
emits a matrix of `(commit_sha, contract, spec, spec_section, status)`
rows. Status is `OK` when the cited file exists, `BROKEN` otherwise.

Default output is a Markdown table written to
`{context.paths.docs}/trace/<timestamp>.md`. `--json` switches to a
JSON envelope on stdout.

Offline: reads only `git log` (local objects) and local files. No
network. Per `PRODUCT.md` §Invariants and `adr/0025`.
"""

from __future__ import annotations

import json
import re
import subprocess
from dataclasses import asdict, dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from rich.console import Console
from rich.table import Table

from fire_phoenix_cli.context import SchemaVersionError, load_context_file

from . import app

# Citation pattern — mirrors `scripts/lint_idd.py` `_CITATION_RE`.
# Kept in sync by hand; src/ cannot import from scripts/ (build-time
# separation). If lint_idd.py Rule 2 evolves the pattern, update here
# too. See `adr/0025` §Decision (why duplicate, not import).
_CITATION_RE = re.compile(
    r"PRODUCT\.md|specs/epic-[a-z0-9-]+\.md|adr/\d{4}-[a-z0-9-]+\.md",
    re.IGNORECASE,
)

console = Console()


@dataclass
class TraceRow:
    """One row of the trace matrix.

    Attributes:
        commit_sha: 40-char SHA of the commit that touched the contract.
        contract: Repo-relative path to the contract file.
        spec: Repo-relative path to the cited spec, or empty string if
            citation could not be extracted.
        spec_section: The full Spec column text (or a diagnostic message
            when status is BROKEN due to malformed header).
        status: "OK" if the cited spec exists on disk, "BROKEN" otherwise.
    """

    commit_sha: str
    contract: str
    spec: str
    spec_section: str
    status: str


def _resolve_contracts_dir(project_root: Path) -> str:
    """Read `governance.contracts_dir` from `.fire-phoenix/context.yml`.

    Falls back to `"contracts"` if context is missing / malformed; the
    trace command must work even on a fresh checkout without context.
    """
    try:
        context = load_context_file(project_root)
    except SchemaVersionError:
        return "contracts"
    except Exception:
        return "contracts"

    governance = context.get("governance") if isinstance(context, dict) else None
    if isinstance(governance, dict):
        contracts_dir = governance.get("contracts_dir")
        if isinstance(contracts_dir, str) and contracts_dir.strip():
            return contracts_dir.strip().rstrip("/")
    return "contracts"


def _resolve_docs_dir(project_root: Path) -> str:
    """Read `paths.docs` from `.fire-phoenix/context.yml`.

    Falls back to `"docs"` if context is missing / malformed. Per
    `adr/0020`: paths owned by context.yml must not be hardcoded.
    """
    try:
        context = load_context_file(project_root)
    except SchemaVersionError:
        return "docs"
    except Exception:
        return "docs"

    paths = context.get("paths") if isinstance(context, dict) else None
    if isinstance(paths, dict):
        docs = paths.get("docs")
        if isinstance(docs, str) and docs.strip():
            return docs.strip().rstrip("/")
    return "docs"


def _run_git_log(project_root: Path, since: str | None) -> list[tuple[str, list[str]]]:
    """Run `git log --name-only` and return [(sha, [files...]), ...].

    Returns an empty list if the repository has no commits in the
    window or no `.git` directory.
    """
    if not (project_root / ".git").exists():
        return []

    cmd = ["git", "log", "--name-only", "--pretty=format:COMMIT:%H"]
    if since:
        cmd.append(f"--since={since}")

    try:
        result = subprocess.run(
            cmd,
            cwd=project_root,
            capture_output=True,
            text=True,
            check=False,
            timeout=30,
        )
    except (subprocess.SubprocessError, FileNotFoundError):
        return []

    if result.returncode != 0:
        return []

    commits: list[tuple[str, list[str]]] = []
    current_sha: str | None = None
    current_files: list[str] = []
    for line in result.stdout.splitlines():
        if line.startswith("COMMIT:"):
            if current_sha is not None:
                commits.append((current_sha, current_files))
            current_sha = line[len("COMMIT:") :].strip()
            current_files = []
        elif line.strip():
            current_files.append(line.strip())
    if current_sha is not None:
        commits.append((current_sha, current_files))
    return commits


def _extract_spec_column(contract_path: Path) -> tuple[str, str]:
    """Read contract header table; return (spec_column_text, error_or_empty).

    Header table format (line 3):
        | Spec | Change class | Approver | Author + date |

    Returns:
        (spec_text, "") if extraction succeeded;
        ("", error_message) otherwise.
    """
    try:
        lines = contract_path.read_text(encoding="utf-8").splitlines()
    except OSError as exc:
        return "", f"unreadable: {exc}"

    if len(lines) < 3:
        return "", "header table missing (need 3+ lines)"

    row = lines[2]
    cells = [c.strip() for c in row.strip().strip("|").split("|")]
    if len(cells) < 1:
        return "", "header table row 3 has no cells"

    spec_text = cells[0]
    if not spec_text:
        return "", "Spec column is empty"
    return spec_text, ""


def _build_rows(
    project_root: Path,
    feature: str | None,
    since: str | None,
) -> list[TraceRow]:
    """Build the trace matrix for the project.

    Walks git log, identifies touched contracts, parses each, resolves
    citations, and assembles a `TraceRow` per (commit, contract) pair.
    """
    contracts_dir = _resolve_contracts_dir(project_root)
    contracts_prefix = contracts_dir + "/"

    if not (project_root / ".git").exists():
        return [
            TraceRow(
                commit_sha="",
                contract="",
                spec="",
                spec_section="Not a git repository",
                status="BROKEN",
            )
        ]

    commits = _run_git_log(project_root, since)
    if not commits:
        return []

    rows: list[TraceRow] = []
    # Track (commit, contract) pairs we've already processed within
    # this run so the same touch in two commits doesn't dedupe — but
    # the same touch in the same commit isn't emitted twice.
    seen_in_commit: set[tuple[str, str]] = set()

    for sha, files in commits:
        for fpath in files:
            if not fpath.startswith(contracts_prefix):
                continue
            key = (sha, fpath)
            if key in seen_in_commit:
                continue
            seen_in_commit.add(key)

            resolved = _resolve_with_archive(project_root, fpath)
            if resolved is None:
                # Contract was touched in this commit but has since been
                # removed (not archived). Emit a BROKEN row so it isn't
                # silently skipped.
                rows.append(
                    TraceRow(
                        commit_sha=sha,
                        contract=fpath,
                        spec="",
                        spec_section="contract file no longer exists",
                        status="BROKEN",
                    )
                )
                continue

            spec_text, err = _extract_spec_column(resolved)
            if err:
                rows.append(
                    TraceRow(
                        commit_sha=sha,
                        contract=fpath,
                        spec="",
                        spec_section=err,
                        status="BROKEN",
                    )
                )
                continue

            # Apply --feature filter against the raw spec text.
            if feature and feature.lower() not in spec_text.lower():
                continue

            citations = _CITATION_RE.findall(spec_text)
            if not citations:
                rows.append(
                    TraceRow(
                        commit_sha=sha,
                        contract=fpath,
                        spec="",
                        spec_section=spec_text,
                        status="BROKEN",
                    )
                )
                continue

            # Emit one row per distinct citation in the Spec column.
            for citation in _dedup_preserve_order(citations):
                status = "OK" if _resolve_with_archive(project_root, citation) else "BROKEN"
                rows.append(
                    TraceRow(
                        commit_sha=sha,
                        contract=fpath,
                        spec=citation,
                        spec_section=spec_text,
                        status=status,
                    )
                )

    return rows


def _resolve_with_archive(project_root: Path, rel_path: str) -> Path | None:
    """Resolve `rel_path` on disk, falling back to its `archive/` sibling.

    Per `adr/0033`: closed specs/contracts move into `<dir>/archive/`;
    pre-archive references resolve by prepending `archive/` to the
    basename. Returns the existing path, or None if neither location
    exists.
    """
    direct = project_root / rel_path
    if direct.exists():
        return direct
    parts = Path(rel_path)
    archived = project_root / parts.parent / "archive" / parts.name
    if archived.exists():
        return archived
    return None


def _dedup_preserve_order(items: list[str]) -> list[str]:
    """Return `items` with duplicates removed, preserving first-seen order."""
    seen: set[str] = set()
    out: list[str] = []
    for item in items:
        key = item.lower()
        if key in seen:
            continue
        seen.add(key)
        out.append(item)
    return out


def _render_markdown(rows: list[TraceRow]) -> str:
    """Render the trace matrix as a Markdown table."""
    header = "| Commit | Contract | Spec | Status | Notes |\n|---|---|---|---|---|\n"
    if not rows:
        return header + "| _(no commits in window)_ |  |  |  |  |\n"

    body_lines: list[str] = []
    for row in rows:
        sha_short = row.commit_sha[:8] if row.commit_sha else "—"
        contract = row.contract or "—"
        spec = row.spec or "—"
        # Escape pipes in the section snippet so the table stays well-formed.
        notes = (row.spec_section or "").replace("|", "\\|").replace("\n", " ")
        if len(notes) > 200:
            notes = notes[:197] + "..."
        body_lines.append(f"| `{sha_short}` | `{contract}` | `{spec}` | {row.status} | {notes} |")
    return header + "\n".join(body_lines) + "\n"


def _render_console_table(rows: list[TraceRow]) -> Table:
    """Render the trace matrix as a Rich table for stdout."""
    table = Table(title="Trace matrix", show_lines=False)
    table.add_column("Commit", style="dim")
    table.add_column("Contract", style="cyan")
    table.add_column("Spec", style="magenta")
    table.add_column("Status", style="bold")
    for row in rows:
        status_style = "green" if row.status == "OK" else "red"
        table.add_row(
            (row.commit_sha[:8] if row.commit_sha else "—"),
            row.contract or "—",
            row.spec or "—",
            f"[{status_style}]{row.status}[/{status_style}]",
        )
    return table


def _write_markdown_report(project_root: Path, rows: list[TraceRow]) -> Path:
    """Write the Markdown report to `{paths.docs}/trace/<timestamp>.md`."""
    docs_dir = _resolve_docs_dir(project_root)
    timestamp = datetime.now(UTC).strftime("%Y%m%d-%H%M%S")
    out_dir = project_root / docs_dir / "trace"
    out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / f"{timestamp}.md"

    total = len(rows)
    ok = sum(1 for r in rows if r.status == "OK")
    broken = sum(1 for r in rows if r.status == "BROKEN")

    header = (
        f"# Trace matrix — {timestamp} UTC\n\n"
        f"Generated by `fire-phoenix check trace` per `adr/0025-fire-phoenix-check-trace.md`.\n\n"
        f"- Total rows: {total}\n"
        f"- OK: {ok}\n"
        f"- BROKEN: {broken}\n\n"
        f"## Matrix\n\n"
    )
    out_path.write_text(header + _render_markdown(rows), encoding="utf-8")
    return out_path


def _summary(rows: list[TraceRow]) -> dict[str, int]:
    """Return the summary aggregate for the matrix."""
    return {
        "total": len(rows),
        "ok": sum(1 for r in rows if r.status == "OK"),
        "broken": sum(1 for r in rows if r.status == "BROKEN"),
    }


def run_trace(
    feature: str | None,
    since: str | None,
    json_output: bool,
    project_root: Path | None = None,
) -> int:
    """Walk merged commits, resolve contract → spec citations, emit a matrix.

    Args:
        feature: Optional slug filter; restricts to contracts whose Spec
            column contains the slug substring (case-insensitive).
        since: Optional `git log --since=<ref>` value (e.g. `"30 days ago"`).
        json_output: If True, emit JSON to stdout. Otherwise write a
            Markdown report to `{paths.docs}/trace/<timestamp>.md`.
        project_root: Project root (defaults to `Path.cwd()`).

    Returns:
        Exit code: 0 if every row is OK (or no rows), 1 if any BROKEN
        row exists.
    """
    if project_root is None:
        project_root = Path.cwd()

    rows = _build_rows(project_root, feature, since)
    summary = _summary(rows)

    if json_output:
        payload: dict[str, Any] = {
            "rows": [asdict(r) for r in rows],
            "summary": summary,
        }
        print(json.dumps(payload, indent=2, ensure_ascii=False))
    else:
        if rows:
            console.print(_render_console_table(rows))
        out_path = _write_markdown_report(project_root, rows)
        try:
            rel = out_path.relative_to(project_root)
        except ValueError:
            rel = out_path
        console.print(f"\n[bold]Report written:[/bold] {rel}")
        console.print(
            f"[dim]Total: {summary['total']} | OK: {summary['ok']} | "
            f"BROKEN: {summary['broken']}[/dim]"
        )

    return 0 if summary["broken"] == 0 else 1


__all__ = ["run_trace", "TraceRow"]

# Suppress unused-import lint for the package-level `app` import; kept
# for parity with sibling modules whose `app` reference is implicit via
# decorators on the shared Typer group.
_ = app
